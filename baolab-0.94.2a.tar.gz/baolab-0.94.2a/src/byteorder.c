#define BYTEORDER_MAIN

#include "byteorder.h"

int byteorder() {
  short v_short;
  char  *v_ch;
  int    order;

  v_short = 1;
  v_ch = (void *)(&v_short);

/*  printf("%i %i\n",v_ch[0],v_ch[1]); */

  if (v_ch[0] == 1)
    order = BO_LITTLE_ENDIAN;
  else
    order = BO_BIG_ENDIAN;

  return order;
}
