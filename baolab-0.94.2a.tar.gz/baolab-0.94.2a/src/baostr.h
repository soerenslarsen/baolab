#include <termios.h>
#include <ctype.h>

#ifndef BAOSTR_MAIN

extern int nargs(
  char *
);

extern void argn(
  char *,
  int ,
  char *
);

extern char *upcstr(
  char *
);

extern void sglspc(
  char *
);

extern void remspace(
  char *
);

extern void remeqspc(
  char *
);

extern void insargs(
  char *,
  char *
);

extern void itoa(
  int,
  char *
);

extern void ftoa(
  float,
  char *
);

extern int bgetchar( void );

extern int bscanf(
  char *,
  void *
);

extern int bgets(
  char *
);

extern void bputs(
  const char *
);

extern void bputch(
  char
);

void getwinsize(
  int *,    /* Width */
  int *     /* Height */
);

extern void clreol(
);

extern void clreos(
);

extern void setcurxy(
  int, int
);

void setscroll(
  int , int 
);

#endif

#define CTRL_A 1
#define CTRL_B 2
#define CTRL_C 3
#define CTRL_D 4
#define CTRL_E 5
#define CTRL_F 6
#define CTRL_G 7
#define CTRL_H 8
#define CTRL_I 9
#define CTRL_J 10
#define CTRL_K 11
#define CTRL_L 12
#define CTRL_M 13
#define CTRL_N 14
#define CTRL_O 15
#define CTRL_P 16
#define CTRL_W 23
#define DEL    0177

typedef char strarr[100][500];

#define ARROW_LEFT  (256+75)
#define ARROW_RIGHT (256+77)
#define ARROW_UP    (256+72)
#define ARROW_DOWN  (256+80)
