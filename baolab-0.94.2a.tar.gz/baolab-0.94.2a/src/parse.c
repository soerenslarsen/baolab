#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "baostr.h"

/* ------------------------------------------------------------------- */

void subst(
  char *s,
  int  p1,int p2,int n
)
{
  char tmps[10];
  char tmps2[500];
  int  i,j;

  itoa(n,tmps); 

  for(i=0,j=0;i<p1;i++) tmps2[j++] = s[i];
  tmps2[j++] = '[';
  for(i=0;tmps[i] != '\0';i++) tmps2[j++] = tmps[i]; 
  tmps2[j++] = ']';
  for(i=p2+1;s[i] != '\0';i++) tmps2[j++] = s[i];
  tmps2[j] = '\0';

  strcpy(s,tmps2);
}


/* ------------------------------------------------------------------- */

int noperators( /* Returns the number of operators in txt */
  char *txt
)
{
  int i,n=0;

  for (i=0;txt[i] != '\0'; i++) {
    if ((txt[i-1] == ' ') && (txt[i+1] == ' ')) {
      if (txt[i] == '*')  n++;
      if (txt[i] == '/')  n++;
      if (txt[i] == '-')  n++;
      if (txt[i] == '+')  n++;
    }
  }

  return n;
}

/* ------------------------------------------------------------------- */


int firstop(     /* Returns the position of the first operator in txt. */
                 /* The operators are checked in order of decreasing   */
                 /* priority. Returns -1 if no operators are found.    */
  char *txt
)
{
  int i,first=-1;

  for (i=0;(txt[i] != '\0') && (first==-1); i++) 
    if ((txt[i-1] == ' ') && (txt[i+1] == ' ')) if (txt[i] == '*') first=i;

  for (i=0;(txt[i] != '\0') && (first==-1); i++) 
    if ((txt[i-1] == ' ') && (txt[i+1] == ' ')) if (txt[i] == '/') first=i;

  for (i=0;(txt[i] != '\0') && (first==-1); i++) 
    if ((txt[i-1] == ' ') && (txt[i+1] == ' ')) if (txt[i] == '+') first=i;
    
  for (i=0;(txt[i] != '\0') && (first==-1); i++) 
    if ((txt[i-1] == ' ') && (txt[i+1] == ' ')) if (txt[i] == '-') first=i;

  return first;
}

/* ------------------------------------------------------------------- */

void renumber(             /* Renumbers all references in txt in the range */
                           /* l1 <= ref <= l2 by adding n to them.         */
  char *txt,
  int  l1,int l2,int n
)
{
  int p1=0,p2,n1,i;
  char tmps[10];

  do {
    p2 = 0;
    for (i=p1;(txt[i] != '[') && (txt[i] != '\0');i++);
    if (txt[i] == '[') {
      p1 = i;
      for (i=p1;(txt[i] != ']') && (txt[i] != '\0'); i++);
      if (txt[i] == ']') {
        p2 = i;
        for (i=p1+1;i<p2;i++) tmps[i-p1-1] = txt[i]; tmps[i-p1-1] = '\0';
        n1 = atoi(tmps);
        if ((n1>=l1) && (n1<=l2)) subst(txt,p1,p2,n1+n);
      }
    }
    p1++;
  } while (p2 != 0);
}

/* ------------------------------------------------------------------- */

void express(
                /* cont returns the containts of <n1 op n2>, pl and pr */
                /* the boundaries of cont. op is located at position n */
		/* in txt.                                             */
  char *txt,
  int  n,
  char *cont,
  int  *pl,int *pr
)
{
  int i,j,l;

  i = n-1;
/*  while ((i>0) && (txt[i-1] != '*') && (txt[i-1] != '/') && (txt[i-1] != '-')
                && (txt[i-1] != '+')) i-- ; */
  while ((i>0) && (txt[i-1] != ' ')) i--;

  *pl = i;
  for(j=0,l=i;l<n;l++) cont[j++] = txt[l];
  cont[j++] = txt[n];
  
  i = n+2; 
/*  while ((txt[i] != '\0') && (txt[i] != '*') && (txt[i] != '/') &&
         (txt[i] != '-') && (txt[i] != '+')) 
    cont[j++] = txt[i++]; */

  cont[j++] = ' ';
  while ((txt[i] != '\0') && (txt[i] != ' ')) cont[j++] = txt[i++];
  *pr = i-1;

  cont[j] = '\0';
}

/* ------------------------------------------------------------------- */

int parantes(
  char *txt,  /* The string to search for a paranthesis. */
  int  i0,    /* Position to search from.  */
  char *cont, /* Contents of the paranthesis. */
  int  *left  /* left will return the position of the first "(". */
              /* Returns the position of the corresponding ")", -1 if none. */
)
{
  int i = i0;
  int pl=-1,pr=0,nl=0,nr=0;
 
  while ((txt[i] != '\0') && (pr==0)) {
    if (txt[i] == '(') {
      if (nl==0) pl = i;
      nl++;
    }
    if ((txt[i] == ')') && (nl>0)) if (++nr == nl) pr = i;
    i++;
  }

  if ((pl>=0) && (pr>pl)) {
    for (i=pl+1;i<pr;i++) cont[i-pl-1] = txt[i];
    cont[i-pl-1] = '\0';
    *left = pl;
    return pr;
  }
  else
    return -1;
}

/* ------------------------------------------------------------------- */

int minref(
  char *txt
)
{
  char tmps[10];
  int  i,j,n,min;

  min = 1000; i = 0;
  do {
    for (;((txt[i] != '[') && (txt[i] != '\0')); i++);
    if (txt[i] == '[') {
      for (j=0,i++;(txt[i] != ']');i++) tmps[j++] = txt[i];
      tmps[j] = '\0';
      n = atoi(tmps);
      if (n<min) min = n;
    }
  } while (txt[i] != '\0');

  return (min==1000) ? -1 : min;
}

/* ------------------------------------------------------------------- */

void parse(
  char *expr,
  strarr subexpr
)
{
  /* char subexpr[100][80]; */
  int  maxexp,i,j,done,pl,pr,m,n;
  char tmpstr[500];

  sglspc(expr);  /* First of all, we want to remove all spaces wider */
                 /* than one character because they can be extremely */
		 /* confusing.                                       */

  puts(expr);

  strcpy(subexpr[0],expr);
  maxexp = 1; done = 0; 

  do {             /* Now we can sort out any parantheses  */
    n = 0; m = maxexp;
    for (i=0;i<m;i++) {
      pr = parantes(subexpr[i],0,subexpr[maxexp],&pl);

      while (pr >= 0)  {
        subst(subexpr[i],pl,pr,maxexp);
        maxexp++; n++;
        pr=parantes(subexpr[i],0,subexpr[maxexp],&pl);
      }
    }
    done = (n==0);
  } while (!done); 

  done = 0;        /* Reduce all expressions to two arguments and an */
                   /* operator.                                      */
  do {
    n = 0;
    for (i=0;i<maxexp;i++) {
      while (noperators(subexpr[i]) > 1) {
        express(subexpr[i], firstop(subexpr[i]), tmpstr, &pl, &pr);
        subst(subexpr[i],pl,pr,maxexp);
        strcpy(subexpr[maxexp++],tmpstr);
        n++;
      }
    } 
    done = (n==0);
  } while (!done);

  done = 0;        /* All we have left to do now is to make sure that */
                   /* no expressions are referenced before they have  */
                   /* been calculated.                                */
  do {
    for (i=0; (i<maxexp) && 
           ((minref(subexpr[i]) ==-1) || (minref(subexpr[i]) > i)); i++);
    if (i==maxexp) done = 1;
    else {
      m = minref(subexpr[i]); 
      strcpy(tmpstr,subexpr[i]);
      for (j=i;j>m;j--) strcpy(subexpr[j],subexpr[j-1]);
      strcpy(subexpr[m],tmpstr);

      for (j=0;j<maxexp;j++) renumber(subexpr[j],i,i,-i);
      for (j=0;j<maxexp;j++) renumber(subexpr[j],m,i-1,1);
      for (j=0;j<maxexp;j++) renumber(subexpr[j],0,0,m); 
    }
  } while (!done);

  subexpr[maxexp][0] = '\0'; /* The sequence is ended by an empty string */

}

/* ------------------------------------------------------------------- 

void main() {
  char expr[80];
  int  i;
  strarr test;

  printf("Expression:  "); gets(expr);
  parse(expr,test);
  for (i=0;test[i][0] != '\0';i++) printf("[%i]: %s \n",i,test[i]);
}

*/
