#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <math.h>
#include "baostr.h"
#include "wutil.h"
#include "polyfit.h"

extern Display *DISPLAY;

typedef struct {
          float dxmin, dxmax, dymin, dymax;
	  int   pxmin, pxmax, pymin, pymax;
        } plotstruct;

/* ====================================================================== */

float farrmin(
  float *x,
  int n
) {
  int i;
  float m;

  m = x[0];
  for (i=0; i<n; i++) if (x[i] < m) m = x[i];

  return m;
}

/* ====================================================================== */

float farrmax(
  float *x,
  int n
) {
  int i;
  float m;

  m = x[0];
  for (i=0; i<n; i++) if (x[i] > m) m = x[i];

  return m;
}

/* ====================================================================== */

void getxy(
  plotstruct *plotattr,
  Window win,
  int xpix, 
  int ypix,
  float *xdat,
  float *ydat
) {
  XWindowAttributes winattr;
  float ddx, pdx, ddy, pdy;

  XGetWindowAttributes(DISPLAY,win,&winattr);
  pdx = winattr.width;
  pdy = winattr.height;

  ddx = plotattr->dxmax - plotattr->dxmin;
  ddy = plotattr->dymax - plotattr->dymin;

  (*xdat) = plotattr->dxmin + xpix*ddx/pdx;
  (*ydat) = plotattr->dymin + (pdy - ypix)*ddy/pdy;

  return;
}

/* ====================================================================== */

int getpt(
  float *xx,
  float *yy,
  int   *dstatus,
  int    ndat,
  float  datax,
  float  datay,
  plotstruct *plotattr
) {
  int i, imin;
  float d, dx, dy, dmin;
  float pdx, pdy;

  pdx = plotattr->dxmax - plotattr->dxmin;
  pdy = plotattr->dymax - plotattr->dymin;

  dx = (datax - xx[0]) / pdx;
  dy = (datay - yy[0]) / pdy;
  imin = 0;
  dmin = dx*dx + dy*dy;

  for (i=0; i<ndat; i++) {
    if ((xx[i] > plotattr->dxmin) && (xx[i] < plotattr->dxmax) &&
        (yy[i] > plotattr->dymin) && (yy[i] < plotattr->dymax)) {
      dx = (datax - xx[i]) / pdx;
      dy = (datay - yy[i]) / pdy;
      d = dx*dx + dy*dy;
      if (d < dmin) {
	dmin = d;
	imin = i;
      }
    }
  }

  return imin;
}

/* ====================================================================== */

void delpt(
  float *xx,
  float *yy,
  int   *dstatus,
  int    ndat,
  float  datax,
  float  datay,
  plotstruct *plotattr
) {
  int i;

  i = getpt(xx,yy,dstatus,ndat,datax,datay,plotattr);
  dstatus[i] = 1;
}

/* ====================================================================== */

void xaxis(
  Window  win,
  GC      gc,
  Window  pwin,
  GC      pgc,
  plotstruct *plotattr
)
{
  float x,s,stepsz,marksz,marksz10;
  int   xx,nstep, ndec;
  char  txt[10], s1[10];
  int   px1, px2, py1, py2;
  int   pwdx, pwdy;
  float lo, hi;
  XWindowAttributes winattr;
  XGCValues   gcval;
  XCharStruct xchar;
  int i1,i2,i3, tw, th;

  XGetWindowAttributes(DISPLAY,pwin,&winattr);
  pwdx = winattr.width;
  pwdy = winattr.height;
  px1 = winattr.x;
  px2 = winattr.width + px1;
  py1 = winattr.y;
  py2 = winattr.height + py1;
  lo  = plotattr->dxmin;
  hi  = plotattr->dxmax;

  s = (hi-lo) / 10.0;
  stepsz = 0.1;
  while (stepsz < s) stepsz *= 10;
  marksz = stepsz / 10.0;
  marksz10 = stepsz;

  nstep = (int)((hi-lo)/stepsz);
  if (nstep == 1) stepsz /= 5; else
  if (nstep == 2) stepsz /= 2; else
  if (nstep == 9) stepsz *= 3; else
  if (nstep == 8) stepsz *= 2;

  XDrawLine(DISPLAY,pwin,pgc,0,pwdy-1,pwdx-1,pwdy-1); /* Draw the axis itself */
  XDrawLine(DISPLAY,pwin,pgc,0,0,pwdx-1,0);  

  x = ceil(lo/marksz)*marksz;   /* Set Marks on X-axis */
  do {
    xx = (int)((x-lo)/(hi-lo)*(px2-px1)); 
    XDrawLine(DISPLAY,pwin,pgc,xx,pwdy-1,xx,pwdy-5);
    x = x+marksz;  
  } while (x<hi);

  x = ceil(lo/marksz10)*marksz10;   /* Set Marks on X-axis */
  do {
    xx = (int)((x-lo)/(hi-lo)*(px2-px1)); 
    XDrawLine(DISPLAY,pwin,pgc,xx,pwdy-1,xx,pwdy-10);
    XDrawLine(DISPLAY,pwin,pgc,xx,0,xx,10);
    x = x+marksz10;  
  } while (x<hi);

  x = ceil(lo/stepsz)*stepsz;  /* Write some text indicating the interval */

  ndec = (int)ceil(-log10(stepsz));
  if (ndec < 0) ndec = 0;
  sprintf(s1,"%%0.%if",ndec);

  XGetGCValues(DISPLAY, gc, GCFont, &gcval);

  do {
    xx = px1+(int)((x-lo)/(hi-lo)*(px2-px1));
    sprintf(txt,s1,x);
    XQueryTextExtents(DISPLAY,gcval.font,txt,strlen(txt),&i1,&i2,&i3,&xchar);
    tw = xchar.width;
    th = xchar.ascent;
    XDrawLine(DISPLAY,win,gc,xx,py2,xx,py2+5); 
    XDrawString(DISPLAY,win,gc,xx-tw/2,py2+th+15,txt,strlen(txt));
    x = x+stepsz;
  } while (x<hi);

  XFlush(DISPLAY);
}

/* ==================================================================== */

void yaxis(
  Window  win,
  GC      gc,
  Window  pwin,
  GC      pgc,
  plotstruct *plotattr
)
{
  float y,s,stepsz,marksz,marksz10;
  int   yy,nstep;
  char  txt[10], s1[10];
  int   px1, px2, py1, py2;
  int   pwdx, pwdy;
  float lo, hi;
  int   ndec;
  XWindowAttributes winattr;
  XGCValues   gcval;
  XCharStruct xchar;
  int i1,i2,i3, tw, th;

  XGetWindowAttributes(DISPLAY,pwin,&winattr);
  pwdx = winattr.width;
  pwdy = winattr.height;
  px1 = winattr.x;
  px2 = winattr.width + px1;
  py1 = winattr.y;
  py2 = winattr.height + py1;

  lo  = plotattr->dymin;
  hi  = plotattr->dymax;

  s = (hi-lo) / 10.0;
  stepsz = 0.1;
  while (stepsz < s) stepsz *= 10;
  marksz = stepsz / 10.0;
  marksz10 = stepsz;

  nstep = (int)((hi-lo)/stepsz);
  if (nstep == 1) stepsz /= 5; else
  if (nstep == 2) stepsz /= 2; else
  if (nstep == 9) stepsz *= 3; else
  if (nstep == 8) stepsz *= 2;

  XDrawLine(DISPLAY,pwin,pgc,0,0,0,pwdy-1);  /* Draw the axis itself */
  XDrawLine(DISPLAY,pwin,pgc,pwdx-1,0,pwdx-1,pwdy-1);  

  y = ceil(lo/marksz)*marksz;   /* Set Marks on Y-axis */
  do {
    yy = pwdy-(int)((y-lo)/(hi-lo)*(py2-py1));
    XDrawLine(DISPLAY,pwin,pgc,0,yy,5,yy);
    y = y+marksz;  
  } while (y<hi);

  y = ceil(lo/marksz10)*marksz10;   /* Set Marks on Y-axis */
  do {
    yy = pwdy-(int)((y-lo)/(hi-lo)*(py2-py1));
    XDrawLine(DISPLAY,pwin,pgc,0,yy,10,yy);
    XDrawLine(DISPLAY,pwin,pgc,pwdx-10,yy,pwdx-1,yy);
    y = y+marksz10;  
  } while (y<hi);

  ndec = (int)ceil(-log10(stepsz));
  if (ndec < 0) ndec = 0;
  sprintf(s1,"%%0.%if",ndec); 
  XGetGCValues(DISPLAY, gc, GCFont, &gcval);

  y = ceil(lo/stepsz)*stepsz;  /* Write some text indicating the interval */

  do {
    yy = py2-(int)((y-lo)/(hi-lo)*(py2-py1));
    sprintf(txt,s1,y);
    XQueryTextExtents(DISPLAY,gcval.font,txt,strlen(txt),&i1,&i2,&i3,&xchar);
    tw = xchar.width;
    th = xchar.ascent;
    XDrawLine(DISPLAY,win,gc,px1-5,yy,px1,yy); 
    XDrawString(DISPLAY,win,gc,px1-15-tw,yy+th/2,txt,strlen(txt));
    y = y+stepsz;
  } while (y<hi);

  XFlush(DISPLAY);
}

/* ====================================================================== */

void samprng(
  Window  win,
  GC      gc,
  Window  pwin,
  GC      pgc,
  plotstruct *plotattr,
  float fitx1,
  float fitx2
)
{
  int   px1, px2;
  int wx, wy;
  float ddx, ddy;

  wx = width(pwin);
  wy = height(pwin);
  ddx = plotattr->dxmax - plotattr->dxmin;
  ddy = plotattr->dymax - plotattr->dymin;

  if (fitx1 < plotattr->dxmin) px1 = 0; else
  if (fitx1 > plotattr->dxmax) px1 = wx; else
  px1 = (fitx1 - plotattr->dxmin) * wx/ddx;

  if (fitx2 < plotattr->dxmin) px2 = 0; else
  if (fitx2 > plotattr->dxmax) px2 = wx; else
  px2 = (fitx2 - plotattr->dxmin) * wx/ddx;


  XDrawLine(DISPLAY,pwin,pgc,px1,wy-5,px2,wy-5);  
  XDrawLine(DISPLAY,pwin,pgc,px1,wy-2,px1,wy-8);
  XDrawLine(DISPLAY,pwin,pgc,px2,wy-2,px2,wy-8);

  XFlush(DISPLAY);
}

/* ====================================================================== */

static void plotdata(
  float *xx,
  float *yy,
  int   *dstatus,
  int ndat,
  Window win,
  GC     gc,
  Window pwin,
  GC     pgc,
  plotstruct *plotattr,
  char   *title,
  float  fitx1,
  float  fitx2
) {
  XGCValues   gcval;
  XCharStruct xchar;
  int i1,i2,i3;
  int wx, wy, tw;
  int x, y;
  float ddx, ddy;
  int i;

  wx = width(pwin);
  wy = height(pwin);

  xaxis(win, gc, pwin, pgc, plotattr);
  yaxis(win, gc, pwin, pgc, plotattr);
  samprng(win, gc, pwin, pgc, plotattr, fitx1, fitx2);

  XGetGCValues(DISPLAY, gc, GCFont, &gcval);
  XQueryTextExtents(DISPLAY,gcval.font,title,strlen(title),&i1,&i2,&i3,&xchar);
  tw = xchar.width;
  XDrawString(DISPLAY,win,gc,
     (width(win)-tw)/2,0.05*height(win),title,strlen(title));

  ddx = plotattr->dxmax - plotattr->dxmin;
  ddy = plotattr->dymax - plotattr->dymin;

  for (i=0; i<ndat; i++) {
    x = (xx[i] - plotattr->dxmin) * wx/ddx;
    y = wy - (yy[i] - plotattr->dymin) * wy/ddy;

    switch (dstatus[i]) {
      case 0 : cross(pwin, pgc, x, y, 2);
               break;
      case 1 : XDrawArc(DISPLAY, pwin, pgc, x-3, y-3, 6, 6, 0, 64 * 360);
               break;
    }
  }

}

/* ====================================================================== */

static void plotfit(
  Window win,
  GC     gc,
  plotstruct *plotattr,
  float  *a,
  int   na
) {
  XPoint *xypoints;
  int    nxy, i;
  float  ddx, ddy, pdx, pdy;
  float  datx, daty, px, py;

  nxy = 50;
  xypoints = (XPoint *)malloc(sizeof(XPoint)*nxy);

  ddx = plotattr->dxmax - plotattr->dxmin;
  ddy = plotattr->dymax - plotattr->dymin;
  pdx = width(win);
  pdy = height(win);

  for (i=0; i<nxy; i++) {
    datx = plotattr->dxmin + (ddx*i)/50;
    daty = polyval(datx, a, na);
    px = (datx - plotattr->dxmin) * pdx/ddx;
    py = pdy - (daty - plotattr->dymin) * pdy/ddy;
    xypoints[i].x = px;
    xypoints[i].y = py;
  }

  XDrawLines(DISPLAY, win, gc, xypoints, nxy, CoordModeOrigin);

  free(xypoints);
}

/* ====================================================================== */

int dofit(
  float *xx,
  float *yy,
  int   *dstatus,
  int   ndat,
  float *a,
  int   na,
  float fitx1,
  float fitx2
) {
  float *fx, *fy;
  int   i,nact;

  fx = (float *)malloc(sizeof(float)*ndat);
  fy = (float *)malloc(sizeof(float)*ndat);

  nact = 0;
  for (i=0; i<ndat; i++) {
    if ((dstatus[i] == 0) && (xx[i] >= fitx1) && (xx[i]<=fitx2)) {
      fx[nact] = xx[i];
      fy[nact] = yy[i];
      nact++;
    }
  }

  i = polyfit(fx, fy, nact, a, na);

  free(fx);
  free(fy);

  return i;
}

/* ====================================================================== */

void getcmd(
  char *s
) {
  printf("**XFIT> ");
  bscanf("%S",s); 
}

/* ====================================================================== */

void showxhlp() {
  puts("XFIT keystrokes:");
  puts("");
  puts("X - Discard this fit");
  puts("I - Interrupt");
  puts("d - Delete datapoint near cursor");
  puts("u - Undelete datapoint near cursor");
  puts("f - Carry out fit");
  puts(":order <order> - set order of fitting polynomium");
  puts(":?order - show order of fitting polynomium");
  puts(":?fit - show current fit");
}

/* ====================================================================== */

int xfit(
  float *xx,
  float *yy,
  int   ndat,
  float *a,
  int   na,
  int   maxna,
  char *title
) {
  int  *dstatus;
  XGCValues pgcval;
  GC gc1, gc2, pgc;
  int screen;
  Window win, pwin;
  XWindowChanges xwchanges;
  plotstruct plotattr;
  int  quit = 0;
  int  mode = 0;
  int  i,n;
  int  x, y;
  int  fitx1, fitx2;
  int  wx1, wdx, wy1, wdy;
  float ddx, ddy, datax, datay;
  XEvent event;
  KeySym  keysym;
  XComposeStatus compose;
  char  tmps[80];

/*  if ((DISPLAY = XOpenDisplay(dspname)) == NULL) {
    puts("** ERROR: Could not open display.");
    return 0;
  } */

  screen = DefaultScreen(DISPLAY);

  dstatus = (int *)malloc(sizeof(int)*ndat);
  for (i=0; i<ndat; i++) dstatus[i] = 0;

  wopen("Interactive fitting",&win,&gc1,&gc2);
/*  font = XLoadFont(DISPLAY,"9x15");
  XSetFont(DISPLAY,gc1,font); */

  wx1 = 0.1 * width(win);
  wdx = 0.8 * width(win);
  wy1 = 0.1 * height(win);
  wdy = 0.8 * height(win);

  pwin = XCreateSimpleWindow(DISPLAY,win,wx1, wy1, wdx, wdy, 0,
         BlackPixel(DISPLAY,screen), WhitePixel(DISPLAY,screen));
  pgcval.foreground = BlackPixel(DISPLAY,screen);
  pgcval.background = WhitePixel(DISPLAY,screen);
  pgcval.line_width = 1;
  pgc = XCreateGC(DISPLAY,pwin, (GCForeground | GCBackground | GCLineWidth),
		                   &pgcval);
  XMapWindow(DISPLAY,pwin);
  XFlush(DISPLAY);

  XSelectInput(DISPLAY,win, ButtonPressMask | ButtonReleaseMask |
                    Button1MotionMask | Button3MotionMask | KeyPressMask |
		    StructureNotifyMask | VisibilityChangeMask);
  XSelectInput(DISPLAY,pwin, ButtonPressMask | ButtonReleaseMask |
                    Button1MotionMask | Button3MotionMask | KeyPressMask |
		    StructureNotifyMask | VisibilityChangeMask);

  ddx = farrmax(xx,ndat) - farrmin(xx,ndat);
  ddy = farrmax(yy,ndat) - farrmin(yy,ndat);
  fitx1 = farrmin(xx,ndat);
  fitx2 = farrmax(xx,ndat);
  plotattr.dxmin = farrmin(xx,ndat) - 0.05*ddx;
  plotattr.dxmax = farrmax(xx,ndat) + 0.05*ddx;
  plotattr.dymin = farrmin(yy,ndat) - 0.05*ddy;
  plotattr.dymax = farrmax(yy,ndat) + 0.05*ddy;

  dofit(xx, yy, dstatus, ndat, a, na, fitx1, fitx2);

  plotdata(xx, yy, dstatus, ndat, win, gc1, pwin, pgc, &plotattr, title, fitx1, fitx2);
  plotfit(pwin, pgc, &plotattr, a, na);

  do {
    XNextEvent(DISPLAY,&event);

    switch (event.type) {
      case ConfigureNotify:
	  xwchanges.x = 0.1 * width(win);
	  xwchanges.width = 0.8 * width(win);
	  xwchanges.y = 0.1 * height(win);
	  xwchanges.height = 0.8 * height(win);
	  XConfigureWindow(DISPLAY, pwin, CWX | CWY | CWWidth | CWHeight, &xwchanges);
      case VisibilityNotify:
	  plotdata(xx, yy, dstatus, ndat, win, gc1, pwin, pgc, &plotattr, title, fitx1, fitx2);
	  plotfit(pwin, pgc, &plotattr, a, na);
	break;
    
      case KeyPress:
	  tmps[0] = '\0';
	  n = XLookupString(&(event.xkey),tmps,80,&keysym,&compose); 
	  if (keysym == XK_Escape) quit = 1; else
	  if (keysym == XK_End) quit = 1; else

          switch (mode) {                  /* Regular input mode */
	    case 0 : switch (tmps[0]) {
	               case '?' :
		       case 'h' : showxhlp(); break;
	               case 'X' : quit = 1;
		                 na = -1;
			         break;
	               case 'I' : quit = 1;
		                 na = -2;
			         break;
		       case 'q' : quit = 1;
				 break;
		       case 'r' : XClearWindow(DISPLAY,pwin);
				  plotdata(xx, yy, dstatus, ndat, win, gc1, pwin, pgc, &plotattr, title, fitx1, fitx2);
				  plotfit(pwin, pgc, &plotattr, a, na);
				 break;
                       case 's' : if (event.xany.window == pwin) {
		                   x = event.xkey.x; y = event.xkey.y;
                                   getxy(&plotattr,pwin,x,y,&datax,&datay);
				   puts("Press ''s'' again..");
				   mode = 2;
		                 } break;
		       case 'd' :
		       case 'u' : 
				 if (event.xany.window == pwin) {
		                   x = event.xkey.x; y = event.xkey.y;
				   getxy(&plotattr,pwin,x,y,&datax,&datay);
				   i = getpt(xx,yy,dstatus,ndat,datax,datay,&plotattr);
				   dstatus[i] = (tmps[0] == 'd') ? 1 : 0;
				   XClearWindow(DISPLAY,pwin);
				   plotdata(xx, yy, dstatus, ndat, win, gc1, pwin, pgc, &plotattr, title, fitx1, fitx2);
				   plotfit(pwin, pgc, &plotattr, a, na);
                                 } else
				   puts("** ERROR: Must be in plot area to select data points.");
				 break;

		       case 'f' : dofit(xx, yy, dstatus, ndat, a, na, fitx1, fitx2);
				 XClearWindow(DISPLAY,pwin);
				 plotdata(xx, yy, dstatus, ndat, win, gc1, pwin, pgc, &plotattr, title, fitx1, fitx2);
				 plotfit(pwin, pgc, &plotattr, a, na);
				 break;

		       case 'w' : mode = 1;
		                  ddx = farrmax(xx,ndat) - farrmin(xx,ndat);
				  ddy = farrmax(yy,ndat) - farrmin(yy,ndat);
				  y = event.xkey.y;
				 break;

		       case ':' : getcmd(tmps);
				 if (!strncmp(tmps,"order",5)) {
				   i = atoi(tmps+5);
				   if (i > maxna)
				     printf("** Error: Highest allowed order = %d\n",maxna);
				   else
				     na = i;
                                   printf("Fitting order = %d\n",na);
                                 }
				 if (!strncmp(tmps,"?order",6)) printf("Order = %d\n",na);
				 if (!strncmp(tmps,"?fit",4)) {
				   printf("Coefficients = ");
				   for (i=0; i<=na; i++) printf("%6.2e ",a[i]);
				   puts("");
				 }
				 break;
		     }
		     break;

	    case 1 : switch (tmps[0]) {    /* Adjust viewport */
		       case 'a' : plotattr.dxmin = farrmin(xx,ndat) - 0.05*ddx;
				  plotattr.dxmax = farrmax(xx,ndat) + 0.05*ddx;
				  plotattr.dymin = farrmin(yy,ndat) - 0.05*ddy;
				  plotattr.dymax = farrmax(yy,ndat) + 0.05*ddy;
				  break;

		       case 'l' : x = event.xkey.x;
		                  if (event.xany.window == pwin) {
                                    getxy(&plotattr,pwin,x,y,&datax,&datay);
				    plotattr.dxmin = datax;
                                  } else
				    plotattr.dxmin = farrmin(xx,ndat) - 0.05*ddx;
				  break;

		       case 'r' : x = event.xkey.x;
		                  if (event.xany.window == pwin) {
				    getxy(&plotattr,pwin,x,y,&datax,&datay);
				    plotattr.dxmax = datax;
                                  } else
				    plotattr.dxmax = farrmax(xx,ndat) + 0.05*ddx;
				  break;

		       case 't' : y = event.xkey.y;
		                  if (event.xany.window == pwin) {
                                    getxy(&plotattr,pwin,x,y,&datax,&datay);
                                    plotattr.dymax = datay;
                                  } else
				    plotattr.dymax = farrmax(yy,ndat) + 0.05*ddy;
				  break;

		       case 'b' : y = event.xkey.y;
		                  if (event.xany.window == pwin) {
				    getxy(&plotattr,pwin,x,y,&datax,&datay);
				    plotattr.dymin = datay;
                                  } else
				    plotattr.dymin = farrmin(yy,ndat) - 0.05*ddy;
				  break;
		     }
		     XClearWindow(DISPLAY,win);
		     XClearWindow(DISPLAY,pwin);
		     plotdata(xx, yy, dstatus, ndat, win, gc1,pwin, pgc,  &plotattr, title, fitx1, fitx2);
		     plotfit(pwin, pgc, &plotattr, a, na);
		     mode = 0;
		     break;

            case 2 : switch (tmps[0]) {    /* Set sample range */
	               case 's' : fitx1 = datax;
		                  x = event.xkey.x; y = event.xkey.y;
                                  getxy(&plotattr,pwin,x,y,&datax,&datay);
				  fitx2 = datax;
			          puts("Done setting sample range.");
			          mode = 0;
				  break;
	             }  
		     XClearWindow(DISPLAY,win);
		     XClearWindow(DISPLAY,pwin);
		     plotdata(xx, yy, dstatus, ndat, win, gc1,pwin, pgc,  &plotattr, title, fitx1, fitx2);
		     plotfit(pwin, pgc, &plotattr, a, na);
		     break; /* End set sample range */
          }
          break;

    }
  } while (!quit);

  wclose(win,gc1,gc2); 
  free(dstatus);

  if (na < maxna) for (i=na+1; i<=maxna; i++) a[i] = 0.0;

  return na;
}
