#include "fitsutil.h"
#include <sys/wait.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "baostr.h"
#include "baolab.h"
#include "wutil.h"
#include "byteorder.h"
/* #include "arch.h" */

extern void paramstr(char *, char*);

/* ==================================================================== */

#include "rainbow.pal"

/* ==================================================================== */

void hist_yaxis(
  Window  win,
  GC      gc,
  int     wdx, int wdy,
  float   hmax
)
{
  float hm1 = 1.0;
  float f,f0;
  char  txt[10];
  int   y;

  while (hm1 <= hmax) {
    f0 = pow(10.0,(hm1-1.0));
    f = f0;

    while (f<pow(10.0,hm1)) {
      y = wdy-30-(int)((wdy-50)*log10(f)/hmax);
      XDrawLine(DISPLAY,win,gc,45,y,52,y);
      f += f0;
    }

    XSetLineAttributes(DISPLAY,gc,1,LineOnOffDash,
		       CapButt,JoinRound);
    itoa((int)(pow(10.0,hm1)+0.5),txt);
    y = wdy-30-(int)((wdy-50)*hm1/hmax);
    XDrawString(DISPLAY,win,gc,10,y,txt,strlen(txt));
    XDrawLine(DISPLAY,win,gc,45,y,wdx,y);
    hm1 += 1;
    XSetLineAttributes(DISPLAY,gc,1,LineSolid,
		       CapButt,JoinRound);
  }
}

void showhisto(
  Window win,
  GC     gc1, GC gc2,
  float *histdata,
  int   nhist,
  float locut, float hicut
)
{
  char    *dspname;
  int     wdx,wdy;

  float   hm1,hmax;
  int     i;
  XWindowAttributes winattr;

  dspname = NULL;
  XGetWindowAttributes(DISPLAY,win,&winattr);
  wdx = winattr.width;
  wdy = winattr.height;

  hm1 = histdata[0];
  for (i=0;i<nhist;i++) if (histdata[i] > hm1) hm1 = histdata[i];
  hmax = 1.0;
  while (hmax < hm1) hmax += 1;

  XClearWindow(DISPLAY,win);
  XDrawLine(DISPLAY,win,gc2,50,10,50,wdy-10);

  hist_yaxis(win,gc1,wdx,wdy,hmax);
  make_xaxis(win,gc1,locut,hicut);

  for (i=1;i<nhist;i++) {
    XDrawLine( DISPLAY,win,gc1,
	       50+((wdx-70)*(i-1))/nhist, 
		(int)(wdy-30-((wdy-50)*histdata[i-1])/hmax),
	       50+((wdx-70)*i)/nhist,
		(int)(wdy-30-((wdy-50)*histdata[i])/hmax) );
  }
  XFlush(DISPLAY);
}

/* -------------------------------------------------------------------- */

int gethisto(
  float locut, float hicut,
  float *image,
  int   npix,
  long *histdata,
  int  *nhist
)
{
  int     i,ii;

  if (locut >= hicut) hicut = locut+1;
  *nhist = (hicut-locut >= *nhist) ? *nhist : (int)(hicut-locut+1);
  for (i=0;i< (*nhist) ;i++) histdata[i] = 0;

  if (image != NULL) {
    for (i=0;i<npix;i++) {
      if (image[i] <= locut) (histdata[0])++; else
      if (image[i] >= hicut) (histdata[(*nhist)-1])++; else {
        ii = (int)((*nhist)*(image[i]-locut+1.0)/(hicut-locut)-1.0);
        histdata[ii]++;
      }
    }
    return 1;
  } else
    return 0;
}

/* -------------------------------------------------------------------- */

void histogram(char *params)
{
  static float locut=0,hicut=4095;
  static char imname[255] = "";
  char   tmps[100];
  float *imdata;
  long histdata[1000];
  float fltdata[1000];
  hstruct hdr;
  int  i,npix,nhist;

  if (getpar("HISTO.LOCUT",tmps)) locut = atof(tmps);
  if (getpar("HISTO.HICUT",tmps)) hicut = atof(tmps);

  if (nargs(params) == 3 || nargs(params) == 1) {
    argn(params,1,imname);
    if (nargs(params) == 3) {
      argn(params,2,tmps); locut = atof(tmps);
      argn(params,3,tmps); hicut = atof(tmps);
    }
  } else {
    printf("Input image  :  "); cscanf("%s",imname);
    printf("Locut        :  "); cscanf("%6.1f",&locut); 
    printf("Hicut        :  "); cscanf("%6.1f",&hicut);
  }

  nhist = 1000;
  imdata = floatfitsimage(&hdr,imname,FALSE);

  if (imdata != NULL) {
    npix = hdr.naxis1 * hdr.naxis2;
    gethisto(locut,hicut,imdata,npix,histdata,&nhist); 

    for (i=0;i<nhist;i++) {
      if (histdata[i] > 0) fltdata[i] = log10(histdata[i]); else
      fltdata[i] = 0;
    }

    if (PLOTWIN == -1) {
      if (wopen("BAOLab Plot 0",&(WIN[0]),&(GC1[0]),&(GC2[0]))) {
        PLOTWIN = 0;
        WEXIST[0] = 1;
      } else
        puts(CANT_OPEN_WIN);
    }

    free(imdata);
    if (PLOTWIN != -1)
      showhisto(WIN[PLOTWIN],GC1[PLOTWIN],GC2[PLOTWIN],
               fltdata,nhist,locut,hicut);
  } else
    puts(" ** Error reading input image");
}

/* ==================================================================== */

void drawplot(
  Window  win,
  GC      gc1, GC gc2,
  float *plotdata,
  int  nplot
)
{
  XWindowAttributes winattr;
  float   pmax;
  int     wdx,wdy,i;

  pmax = plotdata[0];
  for (i=0; i<nplot; i++) if (pmax < plotdata[i]) pmax = plotdata[i];
  if (pmax < 1) pmax = 1;

  XGetWindowAttributes(DISPLAY,win,&winattr);
  wdx = winattr.width;
  wdy = winattr.height;

  XClearWindow(DISPLAY,win);

  make_xaxis(win,gc1,0.0,(float)nplot); 
  make_yaxis(win,gc1,0.0,pmax);

  for (i=1;i<nplot;i++) {
    XDrawLine(DISPLAY,win,gc1,
	   50+((wdx-70)*(i-1))/nplot,
	   wdy-30-(int)((wdy-50)*plotdata[i-1]/pmax),
	   50+((wdx-70)*i)/nplot,
	   wdy-30-(int)((wdy-50)*plotdata[i]/pmax));
  }

  XFlush(DISPLAY);

}

/* -------------------------------------------------------------------- */

void plotscan(
  char *params,
  int  mode    /* 0 = row, 1 = col */
)
{
  char inname[255];
  float *imdata;
  float *plotdata;
  hstruct hdr;
  int   nplot,x,y;

  if (nargs(params) == 1) {
    argn(params,1,inname);
  } else {
    printf("Input image:  "); bgets(inname);
  }

  imdata = floatfitsimage(&hdr,inname,FALSE);

  if (imdata != NULL) {
    switch (mode) {
      case 0 : nplot = hdr.naxis1;
	       plotdata = (float *)malloc(4*nplot);
	       for (x=0;x<nplot;x++) {
		 plotdata[x] = 0;
		 for (y=0;y<hdr.naxis2;y++) plotdata[x] += 
					       imdata[hdr.naxis1*y+x];
	       }
	       break;

      case 1 : nplot = hdr.naxis2;
	       plotdata = (float *)malloc(4*nplot);
	       for (y=0;y<nplot;y++) {
		 plotdata[y] = 0;
		 for (x=0;x<hdr.naxis1;x++) plotdata[y] += 
					       imdata[x+hdr.naxis1*y];
	       }
    }

    free(imdata);

    if (PLOTWIN == -1) {
      if (wopen("BAOLab Plot 0",&(WIN[0]),&(GC1[0]),&(GC2[0]))) {
        PLOTWIN = 0;
        WEXIST[0] = 1;
      } else
        puts(CANT_OPEN_WIN);
    }

    if (PLOTWIN != -1)
      drawplot(WIN[PLOTWIN],GC1[PLOTWIN],GC2[PLOTWIN],
	       plotdata,nplot);
    free(plotdata);
  } else
    puts(" ** Error reading input image.");
}

void plotscan0(char *params)
{
  plotscan(params,0);
}

void plotscan1(char *params)
{
  plotscan(params,1);
}

/* ==================================================================== */

Colormap cmap;

int reservcol(long *pixels)
{
  int      screen;
  int      depth;
/*  Colormap cmap; */
  unsigned long planemask;
  Status   status;

  screen = DefaultScreen(DISPLAY);
  cmap = DefaultColormap(DISPLAY,screen);
  depth = DisplayPlanes(DISPLAY,DefaultScreen(DISPLAY));
  if (depth > 8) {
    printf("  Sorry, we do not support dynamical color allocation on \n");
    printf("  %i bit displays. We are working on it.\n",depth);
  }
  status = XAllocColorCells(DISPLAY,cmap,False,&planemask,0,(unsigned long*)pixels,128);
  return status;
}

/* ==================================================================== */

void showpal(
  Window win,
  GC     gc
)
{
  unsigned char *data;
  int    screen,x,y;
  Visual *visual;
  XImage *image;
  int    wdx,wdy;
  unsigned long p;

  wdx = width(win);  wdy = height(win);
  screen = XDefaultScreen(DISPLAY);
  visual = DefaultVisual(DISPLAY,screen);

  data = (unsigned char *)malloc(wdx*(wdy-4)*PIXELSZ); 

  for (x=0;x<wdx;x++) {
    for (y=0;y<wdy-4;y++) {
      p = PIXELS[(int)(x*128.0/wdx)];
      memcpy(data + (y*wdx+x)*PIXELSZ, &p, PIXELSZ);
    }
  } 

  image = XCreateImage(DISPLAY,visual,DEPTH,ZPixmap,0,
                       (char *)data,
                       wdx,wdy-4, 8,wdx*PIXELSZ);  
/*  image->bits_per_pixel = DEPTH;   */

  XPutImage(DISPLAY,win,gc,image,0,0,0,2,wdx,wdy-4);

  XDestroyImage(image); 
}

/* ==================================================================== */

int openimagewin(
  imstruct *image,
  char     *title,
  int      imdx, int imdy, int zoom
)
{
  Visual  *visual;
  Window   win,pwin;
  char    *dspname;
  int      screen;
  int      npix;
  GC       gc;
  XColor    colors[256];
  XColor   tmpcol;
  XGCValues gcval;
  unsigned short ii;
  XSetWindowAttributes setattr;
  int      dxz,dyz;

  XTextProperty winname;
  XSizeHints *size_hints;

  if (DISPLAY == NULL) return FALSE;

    DEPTH = DisplayPlanes(DISPLAY,DefaultScreen(DISPLAY));

/*  if (XMatchVisualInfo(DISPLAY,DefaultScreen(DISPLAY),dep,
      PseudoColor,&vis_info)) puts("PseudoColor Visual OK");
  if (XMatchVisualInfo(DISPLAY,DefaultScreen(DISPLAY),dep,
      DirectColor,&vis_info)) puts("DirectColor Visual OK");
  if (XMatchVisualInfo(DISPLAY,DefaultScreen(DISPLAY),dep,
      TrueColor,&vis_info)) puts("TrueColor Visual OK"); */

  if (!(DEPTH == 8 || DEPTH == 24)) {
    puts("  ** Could not open image window: Incompatible display.");
    puts("  ** Only 8-bit and 24-bit displays are supported.");
    return FALSE;
  }

  if (DEPTH == 8) {
    PIXELSZ = 1;
    TRUECOL = FALSE;
    if (!COLRES) COLRES = reservcol(PIXELS);  /* Maybe this is the very  */
					      /* first window. Then we   */
					      /* have to reserve colors. */

    if (COLRES) {
   /*   cmap = DefaultColormap(DISPLAY,XDefaultScreen(DISPLAY)); */

      for (ii=0;ii<128;ii++) {
	colors[ii].pixel = PIXELS[ii];
	colors[ii].flags = DoRed | DoGreen | DoBlue;
	colors[ii].red   = PAL[ii][0];
	colors[ii].green = PAL[ii][1];
	colors[ii].blue  = PAL[ii][2];
      }
      XStoreColors(DISPLAY,cmap,colors,128);
    } 
 /*   else {
      puts("  ** Error: Unable to allocate colours, need 128 free colours.");
      return FALSE;
    } */
  }

  if (DEPTH == 24) {
    PIXELSZ = 4;
    COLRES = TRUE;
    TRUECOL = TRUE;
    cmap = DefaultColormap(DISPLAY,XDefaultScreen(DISPLAY));

    for (ii=0; ii<128; ii++) {
      tmpcol.red = PAL[ii][0];
      tmpcol.green = PAL[ii][1];
      tmpcol.blue = PAL[ii][2];
      if (!XAllocColor(DISPLAY,cmap,&tmpcol)) COLRES = FALSE;
      PIXELS[ii] = tmpcol.pixel;

/*    After the Leopard X11 related fixes I am no longer sure if this   */
/*    is needed.                                                        */
      if (byteorder() == BO_BIG_ENDIAN) PIXELS[ii] = PIXELS[ii] << 8;   

    }
  }

  if (!COLRES) {
    puts("  ** Error: Unable to allocate colours, need 128 free colours.");
    return FALSE;
  }

  if (COLRES) {
    dspname = NULL;

    screen = XDefaultScreen(DISPLAY);
    visual = DefaultVisual(DISPLAY,screen);

    npix = imdx*imdy;
    if (zoom > 0) {
      dxz = imdx*zoom;
      dyz = imdy*zoom;
    } else {
      dxz = -imdx/zoom;
      dyz = -imdy/zoom;
    }

    win = XCreateSimpleWindow(DISPLAY,RootWindow(DISPLAY,screen),300,50,
			      dxz,dyz+15,
			      0,BlackPixel(DISPLAY,screen),
			      BlackPixel(DISPLAY,screen));

    pwin = XCreateSimpleWindow(DISPLAY,win,0,dyz,
			      dxz,15,
			      0,BlackPixel(DISPLAY,screen),
			      BlackPixel(DISPLAY,screen)); 

    size_hints = XAllocSizeHints();
    size_hints->flags = PPosition | PSize | PMinSize;
    size_hints->min_width = dxz;
    size_hints->min_height= dyz;
    XStringListToTextProperty(&title,1,&winname);
    XSetWMProperties(DISPLAY,win,&winname,NULL,NULL,0,size_hints,
		     NULL,NULL);

    gcval.foreground = WhitePixel(DISPLAY,screen);
    gcval.background = BlackPixel(DISPLAY,screen);
    gcval.function   = GXcopy;
    gcval.line_width = 1;
    gc = XCreateGC(DISPLAY,win, (GCForeground | GCBackground | GCFunction |
                                 GCLineWidth), &gcval);

    setattr.backing_store = Always;
    XChangeWindowAttributes(DISPLAY,win,CWBackingStore,&setattr);
    XChangeWindowAttributes(DISPLAY,pwin,CWBackingStore,&setattr);

    XSelectInput(DISPLAY,win,StructureNotifyMask | ExposureMask | 
                             ButtonPressMask);
    XMapWindow(DISPLAY,win);
    XMapWindow(DISPLAY,pwin);
    showpal(pwin,gc); 

    XFlush(DISPLAY);
    free(size_hints);

    image->palwin = pwin; 
    image->window = win;
    image->gc     = gc;
    return TRUE;
  } else
    return FALSE;
}

/* -------------------------------------------------------------------- */

void updatepal() 
{
/*  Colormap cmap;  */
  int      screen,ii;
  XColor   colors[256];
  XColor   tmpcol;

  screen = DefaultScreen(DISPLAY);

  if (TRUECOL) { 
    for (ii=0; ii<128; ii++) {
      tmpcol.red = PAL[ii][0];
      tmpcol.green = PAL[ii][1];
      tmpcol.blue = PAL[ii][2];
      if (!XAllocColor(DISPLAY,cmap,&tmpcol)) COLRES = FALSE;
      PIXELS[ii] = tmpcol.pixel;
/*      if (strcmp(ARCH,"Linux") != NULL) PIXELS[ii] = PIXELS[ii] << 8; */
/*    Not sure this is needed any longer.                               */
      if (byteorder() == BO_BIG_ENDIAN) PIXELS[ii] = PIXELS[ii] << 8;   
    }
  } else {

/*  cmap = DefaultColormap(DISPLAY,screen); */

    for (ii=0;ii<128;ii++) {
      colors[ii].pixel = PIXELS[ii];
      colors[ii].flags = DoRed | DoGreen | DoBlue;
      colors[ii].red   = PAL[ii][0];
      colors[ii].green = PAL[ii][1];
      colors[ii].blue  = PAL[ii][2];
    }
    XStoreColors(DISPLAY,cmap,colors,128);
  }

  XFlush(DISPLAY);
}

/* -------------------------------------------------------------------- */
 
void freecol( long *pixels )
{
  int screen;
/*  Colormap cmap; */

  screen = DefaultScreen(DISPLAY);
/*  cmap = DefaultColormap(DISPLAY,screen); */

  XFreeColors(DISPLAY, cmap, (unsigned long*)pixels, 128, 0);
}

/* -------------------------------------------------------------------- */

void updateim(
  Window   win,
  GC       gc,
  unsigned char    *pixdata,
  int      imdx, int imdy, int zoom
)
{
  Visual *visual;
  int    wdx,wdy,npix,screen;
  int    j,i,x,y,xx,yy;
  XWindowChanges winch;
  unsigned int  chmask;
  char   *tmpdata, *imgdata;
  XSetWindowAttributes setattr;
  XImage *ximg;
  int    sum,z,scaledn,dxz,dyz;
  char   tmps[80];
  char   t;
  long   pl;

  screen = XDefaultScreen(DISPLAY);
  visual = DefaultVisual(DISPLAY,screen);
  wdx = width(win);
  wdy = height(win);

  if (zoom>0) {
    dxz = imdx*zoom;
    dyz = imdy*zoom;
  } else {
    dxz = imdx / (-zoom);
    dyz = imdy / (-zoom);
  }

  winch.width = dxz;
  winch.height = dyz+15;

  chmask = CWWidth | CWHeight;

  if ((wdx != winch.width) || (wdy != winch.height)) {
    XReconfigureWMWindow(DISPLAY,win,screen,chmask,&winch);

    XDestroyWindow(DISPLAY,IMAGE->palwin);

    IMAGE->palwin = XCreateSimpleWindow(DISPLAY,win,0,dyz,
				dxz,15,
				0,BlackPixel(DISPLAY,screen),
				BlackPixel(DISPLAY,screen));

    setattr.backing_store = Always;
    XChangeWindowAttributes(DISPLAY,IMAGE->palwin,CWBackingStore,&setattr);
    XMapWindow(DISPLAY,IMAGE->palwin);
    XFlush(DISPLAY);
  }

  npix = imdx*imdy;

/*  puts("  Preparing pixel data.."); */

  for (i=0;i<npix;i++) pixdata[i] >>= 1;

  tmpdata = (char *)malloc(dxz*dyz);
 
/*  puts("  Preparing image structure.."); */

  if (zoom > 0) {

    for (y=0;y<imdy;y++) {
      i = y*imdx;
      for (yy=0;yy<zoom;yy++) {
	for (xx=0;xx<zoom;xx++) {
	  j = (zoom*y + yy)*zoom*imdx + xx;
	  for (x=0;x<imdx;x++) {
	    tmpdata[j] = pixdata[i+x]; 
	    j += zoom;
    } } } }
  } else {
    j = 0;
    scaledn = 2;

    if (getpar("DISP.SCALEDN",tmps)) {
      if (strstr(tmps,"TRUNC") == tmps) scaledn = 1;
      if (strstr(tmps,"AVG") == tmps) scaledn = 2;
    }

    switch (scaledn) {
      case 1 :  for (y=0; y<dyz; y++) {
		  i = y * (-zoom) * imdx;
		  for (x=0; x<dxz; x++) {
		    tmpdata[j++] = pixdata[i];
		    i -= zoom;
		  }
                } break;

      case 2 :  z = zoom*zoom;
                for (y=0; y<dyz; y++) {
		  i = y * (-zoom) * imdx;
		  for (x=0; x<dxz; x++) {
		    sum = 0; 
		    for (yy=0; yy< -zoom; yy++)
		      for (xx=0; xx< -zoom; xx++)
		        sum += pixdata[i+xx+imdx*yy];
		      tmpdata[j++] = sum/z;
		    i -= zoom;
		  }
                } break;
    }
  }

/*  puts("  Creating image.."); */

  npix = dxz*dyz;
  imgdata = (char *)malloc(npix*PIXELSZ);
  for (i=0; i<dxz*dyz; i++) {
    t = tmpdata[i];
    pl = PIXELS[t];
    memcpy(imgdata + PIXELSZ*i, &pl, PIXELSZ);
  }
  free(tmpdata);

  ximg = XCreateImage(DISPLAY,visual,DEPTH,ZPixmap,0,
                      imgdata,
                      dxz,dyz, 8,dxz*PIXELSZ); 
/*  ximg->bits_per_pixel = DEPTH;  */

/*  puts("  Displaying image.."); */

  XPutImage(DISPLAY,win,gc,ximg,0,0,0,0, dxz,dyz);
  showpal(IMAGE->palwin,gc); 
  XFlush(DISPLAY);
  XDestroyImage(ximg);
}

/* -------------------------------------------------------------------- */

int do_display(             /* This routine is awfully ugly but it is a lot */
                            /* of work to make it nicer.                    */
  char *filename,
  int  zoom, int autocut,
  float *_locut, float *_hicut
)
{
  float *image;
  hstruct hdr;
  int   result = FALSE;
  int   n,i,count,npix;
  char *pixdata;
  float lo1,hi1;
  char  tmps[100];
  float locut,hicut,autolo,autohi;
  int   nhist = 1000;
  long  histo[1000];
  float l,f;

  locut = *_locut;
  hicut = *_hicut;

  if (DISPLAY == NULL) {
    puts(CANT_OPEN_WIN);
    return FALSE;
  }

  if (IMAGE == NULL) {               /* We must open a new image window  */
    IMAGE = (imstruct *)malloc((size_t)sizeof(imstruct));

    if (IMAGE == NULL) {
      puts("  ** Error: Unable to allocate memory.");
      free(image);
      return FALSE;
    }

    for (i=0; i<4096; i++) IMAGE->tff[i] = (unsigned char)(i/16); 
							   /* Make TFF */
    IMAGE->nr = 0;
    strcpy(IMAGE->tffname,"lin");
    strcpy(IMAGE->fname,"");
    IMAGE->zoom = 1;
    IMAGE->mapped = FALSE;
    IMAGE->next = NULL;
    IMAGE->prev = NULL;
  }

  image = floatfitsimage(&hdr,filename,FALSE);        /* OK */

  if (image == NULL) {
    if (!IMAGE->mapped) {
      free(IMAGE);
      IMAGE = NULL;
    }
    return FALSE;
  }

  if (getpar("DISP.AUTOLO",tmps)) autolo = atof(tmps); 
  if (getpar("DISP.AUTOHI",tmps)) autohi = atof(tmps);
  if (autolo < 0) autolo = 0;
  if (autohi > 100) autohi = 100;
  if (autolo > autohi) autolo = 0;
  if (zoom==0) zoom = 1;

  if (!(IMAGE->mapped)) {
    result = openimagewin(IMAGE,"BAOImage 0",hdr.naxis1,hdr.naxis2,zoom);
    IMAGE->mapped = result;

    if (!IMAGE->mapped) {
      free(IMAGE);
      IMAGE = NULL;
    }
  } else 
    result = TRUE;

  if (result) {
    npix = hdr.naxis1*hdr.naxis2;
    pixdata = (char *)malloc((size_t)npix);

    if (autocut) {
      locut = image[0]; hicut = image[0];
      for (i=0;i<npix;i++) { 
	if (image[i] < locut) locut = image[i];
	if (image[i] > hicut) hicut = image[i];
      }
      gethisto(locut,hicut,image,npix,histo,&nhist);

      i = count = 0;
      n = (int)(autolo*npix/100.0);
      while (count <= n) count += (int)histo[i++];
      lo1 = (hicut-locut)*i*1.0/nhist+locut;

      n = (int)(autohi*npix/100.0);
      while (count <= n) count += (int)histo[i++];
      hi1 = (hicut-locut)*i*1.0/nhist+locut;

      locut = lo1;   hicut = hi1;
      if (fabs(locut-hicut) < 0.1) hicut = locut+1;
    }
    printf("  locut = %7.2f,  hicut = %7.2f\n",locut,hicut);

/*    puts("  Preparing bitmap data.."); */
    f = 4095.0/(hicut-locut);
    l = locut;

    for (i=0;i<npix;i++) {
      if (image[i] <= locut) pixdata[i] = IMAGE->tff[0]; else
      if (image[i] >= hicut) pixdata[i] = IMAGE->tff[4095]; else
      /* ... Calculate value between locut and hicut ... */
      pixdata[i] = IMAGE->tff[(short)(f*(image[i]-l))];
    }

    updateim(IMAGE->window,IMAGE->gc,(unsigned char *)pixdata,hdr.naxis1,hdr.naxis2,zoom);
    
    if (IMAGE->fname != filename) strcpy(IMAGE->fname,filename);
    IMAGE->zoom = zoom;
    IMAGE->locut = locut;
    IMAGE->hicut = hicut;

    free(pixdata); 
  }

  free(image); 

  *_locut = locut;
  *_hicut = hicut;

  return result;
}

/* -------------------------------------------------------------------- */

void imdisp(char *params)
{
  static char  imname[255] = "";
  char   tmps[255];
  static float locut=0,hicut=4095;
  hstruct hdr;
  int     autocut=0;
  int     zoom=1;
  float   tmpz;
  int     dx,dy,x1,x2,y1,y2;

  if (getpar("DISP.ZOOM",tmps)) zoom = atoi(tmps);
  if (getpar("DISP.SETCUT",tmps)) autocut = (strstr(tmps,"AUTO") == tmps);

  if (nargs(params) >= 1) {
    remeqspc(params);
    argn(params,1,imname);

    if (nargs(params) >= 3) {
      argn(params,2,tmps);  locut = atof(tmps);
      argn(params,3,tmps);  hicut = atof(tmps);
      autocut = 0;
    } 
  } else {
    printf("  Image to display   :  "); cscanf("%s",imname);
    if (!autocut) {
      printf("  Locut              :  "); cscanf("%7.2f",&locut); 
      printf("  Hicut              :  "); cscanf("%7.2f",&hicut); 
    }
  }

  if (getheader(&hdr, imname, FALSE)) {
    if (getcorners(imname,&x1,&y1,&x2,&y2)) {
      dx = x2-x1;
      dy = y2-y1;
    } else {
      dx = hdr.naxis1;
      dy = hdr.naxis2;
    }
    tmpz = (zoom > 0) ? zoom : -1/zoom;

    if (dx*tmpz > DisplayWidth(DISPLAY,DefaultScreen(DISPLAY)) ||
        dy*tmpz > DisplayHeight(DISPLAY,DefaultScreen(DISPLAY)) ) {
      puts("  ** Error: Image dimensions times zoom > physical screen size.");
      return;
    }

    if (!do_display(imname,zoom,autocut,&locut,&hicut)) puts("  ** Error.");
  } else 
    puts("  ** Error: Could not open FITS file.");
}

/* ==================================================================== */

void imclose(char *params)
{
  imstruct *tmpimg, *prev, *next;
  int nr;
  char tmps[25];

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }

  if (nargs(params) > 0) {
    argn(params,1,tmps);
    nr = atoi(tmps);
  } else {
    printf("  Delete window no:  "); if (!bgets(tmps)) return;
    nr = atoi(tmps);
  }

  tmpimg = IMAGE;
  while (tmpimg->prev != NULL) tmpimg = tmpimg->prev;
  while (tmpimg->next != NULL && tmpimg->nr != nr) tmpimg = tmpimg->next;

  if (tmpimg->nr == nr) {
    XFreeGC(DISPLAY,tmpimg->gc);

    XDestroyWindow(DISPLAY,tmpimg->window);
    XFlush(DISPLAY);

    IMAGE = tmpimg;
    next = IMAGE->next;
    prev = IMAGE->prev;

    if (IMAGE->prev != NULL)  {
      IMAGE = IMAGE->prev;
      IMAGE->next = next;
      if (next != NULL) next->prev = prev;
    } else 
    if (IMAGE->next != NULL) {
      IMAGE = IMAGE->next;
      IMAGE->prev = NULL;
    } else {
      IMAGE = NULL;
      freecol(PIXELS);
      COLRES = FALSE;
    }

    free(tmpimg);
  } else
    printf(WIN_DONT_EXIST);
}

/* ==================================================================== */

void setpal(char *params)
{
  unsigned short j,i,ii;
  char     fname[255];
  FILE     *file;
  char     *ch;
  char     s1[255],tmps[255];
  unsigned short tmppal[1000][3];
  

  if (strstr(params,"gray") == params) {
    for (i=0;i<128;i++)
      PAL[i][0] = PAL[i][1] = PAL[i][2] = 512*i;
  } else
  if (strstr(params,"false1") == params) {
          for(i=0;i<18;i++) {
	    PAL[i][0] = 0;
	    PAL[i][1] = 0;
	    PAL[i][2] = (unsigned short)(65536.0/18.0 * i);
	  }

          for(i=18;i<36;i++) {
	    PAL[i][0] = (unsigned short)(65536.0/18.0*(i-18));
            PAL[i][1] = 0;
            PAL[i][2] = 65535;
          }

          for(i=36;i<54;i++) {
            PAL[i][0] = 65535;
            PAL[i][1] = (unsigned short)(65536.0/36.0*(i-36));
            PAL[i][2] = (unsigned short)(65536.0/36.0*(72-i));
	  }

          for(i=54;i<72;i++) {
            PAL[i][0] = 65535;
            PAL[i][1] = (unsigned short)(65536.0/36.0*(i-36));
            PAL[i][2] = (unsigned short)(65536.0/36.0*(72-i));
          }

          for(i=72;i<90;i++) {
            PAL[i][0] = (unsigned short)(65536.0/36.0*(108-i));
            PAL[i][1] = 65535;
            PAL[i][2] = (unsigned short)(65536.0/36.0*(i-72));
          }

          for(i=90;i<108;i++) {
            PAL[i][0] = (unsigned short)(65536.0/36.0*(108-i));
            PAL[i][1] = 65535;
            PAL[i][2] = (unsigned short)(65536.0/36.0*(i-72));
          }

          for(i=108;i<128;i++) {
            PAL[i][0] = (unsigned short)(65536.0/36.0*(i-108));
            PAL[i][1] = 65535;
	    PAL[i][2] = 65535;
	  }
  } else
  if (strstr(params,"false2") == params) {
    for(i=0;i<128;i++) {
      PAL[i][0] = 1000*rainbow[6*i];
      PAL[i][1] = 1000*rainbow[6*i+1];
      PAL[i][2] = 1000*rainbow[6*i+2];
    }
  } else
  if (strstr(params,"false3") == params) {
    for(i=0;i<128;i++) {
      PAL[i][0] = 1000*rainbow[6*i+1];
      PAL[i][1] = 1000*rainbow[6*i+2];
      PAL[i][2] = 1000*rainbow[6*i];
    }
  } else
  if (strstr(params,"false4") == params) {
          for (i=0;i<8;i++) {
	    PAL[i][0] = 10000; 
	    PAL[i][1] = 10000;
	    PAL[i][2] = 10000;
	  }  
	  for (i=8;i<16;i++) {
	    PAL[i][0] = 30000;
	    PAL[i][1] = 0;
	    PAL[i][2] = 0;
	  }
	  for (i=16;i<24;i++) {
	    PAL[i][0] = 0;
	    PAL[i][1] = 30000;
	    PAL[i][2] = 0;
	  }
	  for (i=24;i<32;i++) {
	    PAL[i][0] = 0;
	    PAL[i][1] = 0;
	    PAL[i][2] = 30000;
	  }
	  for (i=32;i<40;i++) {
	    PAL[i][0] = 30000;
	    PAL[i][1] = 30000;
	    PAL[i][2] = 0;
	  }
	  for (i=40;i<48;i++) {
	    PAL[i][0] = 30000;
	    PAL[i][1] = 0;
	    PAL[i][2] = 30000;
	  }
	  for (i=48;i<56;i++) {
	    PAL[i][0] = 0;
	    PAL[i][1] = 30000;
	    PAL[i][2] = 30000;
	  }
	  for (i=56;i<64;i++) {
	    PAL[i][0] = 30000;
	    PAL[i][1] = 30000;
	    PAL[i][2] = 30000;
	  }

          for (i=64;i<128;i++) {
	    PAL[i][0] = PAL[i-64][0]*2;
	    PAL[i][1] = PAL[i-64][1]*2;
	    PAL[i][2] = PAL[i-64][2]*2;
          }
  } else {
    puts("  Non-standard palette. Searching for definition file.");
    if (getpar("PALETTE.FILE",fname)) {
      file = fopen(fname,"r");
      if (file == NULL) {
        puts("  ** Error: Unable to open palette file.");
        return;
      }
      
      do {
        ch = fgets(tmps,255,file);
      } while ((ch != NULL) && (strstr(tmps,params) == NULL));

      if (strstr(tmps,params) != NULL) {
        i = 0;
	ch = fgets(tmps,255,file);
	while ((ch != NULL) && (strstr(tmps,"end") == NULL)) {
	  argn(tmps,1,s1); tmppal[i][0] = (unsigned short)atoi(s1); 
	  argn(tmps,2,s1); tmppal[i][1] = (unsigned short)atoi(s1); 
	  argn(tmps,3,s1); tmppal[i][2] = (unsigned short)atoi(s1); 
	  i++;
	  ch = fgets(tmps,255,file);
	}

	if (i > 0) {
	  printf("  %i palette entries read.\n",i);
	  for (ii=0;ii<128;ii++) {
	    j = (int)(ii/128.0*i);
	    PAL[ii][0] = tmppal[j][0];
	    PAL[ii][1] = tmppal[j][1];
	    PAL[ii][2] = tmppal[j][2];
	  }
	} else
	  printf("  ** Error: No data for %s\n",params);
      } else
        printf("  ** Palette definition [%s] not found\n",params);
    } else
      puts("  No palette file defined.");
  }

  if (COLRES) updatepal();
  if (IMAGE != NULL) {
    if (TRUECOL) 
      do_display(IMAGE->fname,IMAGE->zoom,0,&(IMAGE->locut),&(IMAGE->hicut)) ;
  }
}

/* ==================================================================== */

int calctff(
  char *tffname,
  unsigned char *tff
)
{
  int i;
  char tmps[80];
  float power,lmax,lmin,a0;
  int  result = TRUE;

  if (strstr(tffname,"lin") == tffname) {
    for (i=0; i<4096; i++) tff[i] = i / 16; 
  } else
  if (strstr(tffname,"pow") == tffname) {
    argn(tffname,2,tmps); power = atof(tmps);
    if (power > 0) {
      for (i=0; i<4096; i++) 
	tff[i] = (unsigned char)(255.0*pow(i/4096.0,power));
    } else {
      puts("  ** Error: Power must be specified and > 0.");
      result = FALSE;
    }
  } else
  if (strstr(tffname,"log") == tffname) {
    argn(tffname,2,tmps); power = atof(tmps);
    if (power >= 1) {
      if (power > 1000) power = 1000;
      a0 =  1/power;
      lmin = log10(a0);
      lmax = log10(a0+1);

      for (i=0; i<4096; i++)
      tff[i] = (unsigned char)
		   (255.0*(log10(i/4096.0+a0) -lmin)/(lmax-lmin) );
    } else {
      puts("  ** Error: Effect must be >= 1.");
      result = FALSE;
    }
  } else {
    puts("  ** Error: Unknown tff.");
    result = FALSE;
  }

  if (result) {
    argn(tffname,nargs(tffname),tmps);
    if (strstr(tmps,"neg") == tmps)
      for (i=0; i<4096; i++) tff[i] = 255-tff[i];
  } 

  return result;
}

/* ==================================================================== */

void tff(char *params) 
{

  if (IMAGE != NULL) {
    if (nargs(params) > 0) {
   /*   argn(params,1,tffname);
      if (nargs(params) == 2) {
	argn(params,2,tmps);
	strcat(tffname," ");
	strcat(tffname,tmps);
      } */

      if (calctff(params,IMAGE->tff)) {
        strcpy(IMAGE->tffname,params);
        do_display(IMAGE->fname,IMAGE->zoom,0,&(IMAGE->locut),&(IMAGE->hicut));
      }
    } else
      printf("  Current tff: %s\n",IMAGE->tffname);
  } else
    puts(NO_IMAGE_WINS);
}

/* ==================================================================== */
