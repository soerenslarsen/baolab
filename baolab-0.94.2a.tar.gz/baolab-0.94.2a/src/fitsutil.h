#define H_FLOAT 1
#define H_INT   2
#define H_BOOL  3
#define H_ASCII 4
#define H_COMM  5

#define D_FLOAT -32
#define D_LONGINT 32
#define D_SHORT   16
#define D_DEFAULT 0

/* #include "architec.h" */

typedef struct _card {
  char image[80];
  struct _card *next;
  struct _card *prev;
} cardstruct;


typedef struct {
  int ncards;   /* Actually not a card, but very useful to know */
  int nused;
  int bitpix;
  int naxis;
  int naxis1,naxis2;
  float bscale,bzero;
  cardstruct *card;
} hstruct;

#ifndef FITS_UTIL_MAIN

extern int F_DATATYPE;
extern float F_EXTVAL;

extern short swap( short );
extern int   iswap( int );
extern float fswap( float );

extern int getheader(  /* Get data from FITS-header */
  hstruct* ,
  char*    ,
  int  
);

extern int getcorners(
  char *,
  int *,
  int *,
  int *,
  int *
);

extern short *shortfitsimage( 
  hstruct* ,
  char*    ,
  int  
);


extern float *floatfitsimage( 
  hstruct* ,
  char*    ,
  int  
);

extern void addcard(
  hstruct *,
  char *,
  void *,
  int
);

extern void wrendcard( int );

extern void wrempcard( int );

extern void savefitsfile(
  hstruct *,      /* Header information for new file */
  void *,         /* Data array         */
  int   ,         /* Data array format (16, 32, -32) */
  char *
);

extern void freehdr(
  hstruct *
);

extern void *readlnx(
  char *
);

#endif
