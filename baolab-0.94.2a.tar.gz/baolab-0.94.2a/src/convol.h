float *mkp2arr(
  int,     /* dimx */
  int,     /* dimy */
  float *, /* inparr */
  int *    /* new dimension */
);

void getp2arr(
  int,        /* dim */
  float *,    /* p2arr */
  int,        /* dimx */
  int,        /* dimy */
  float *     /* resarr */
);

void convol(
  int , 
  float *, 
  float *, 
  float *
);
