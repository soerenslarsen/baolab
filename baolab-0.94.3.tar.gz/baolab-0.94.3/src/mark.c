#include "utils.h"
#include "fitsutil.h"
#include "baolab.h"
#include "baostr.h"

#define CIRCLE 1
#define BOX 2

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void addmark(
  float *image,
  hstruct *hdr,
  float  x,
  float  y,
  float  radius,
  float  width,
  int  value,
  int type
) {

  int xx,yy;
  int rw;
  int ofs1;
  float d;

  rw = (int)ceil(radius + width);
  if (x > rw && y > rw &&
      x < hdr->naxis1-rw && y < hdr->naxis2-rw) {
    switch (type) {
      case CIRCLE: for (yy = y-rw; yy<=y+rw; yy++) {
                     ofs1 = yy*hdr->naxis1;
                     for (xx = x-rw; xx<=x+rw; xx++) {
                       d = sqrt(sqr(xx-x) + sqr(yy-y));
                       if (d >= radius && d <= radius+width) {
               	         image[xx+ofs1] = value;
	               }
                     }
                   }
		   break;
      case BOX:    for (yy=y-(radius+width); yy<=y+radius+width; yy++) {
                     for (xx=x-(radius+width); xx<=x-radius; xx++)
		       image[xx + yy*hdr->naxis1] = value;
                     for (xx=x+radius; xx<=x+radius+width; xx++)
		       image[xx + yy*hdr->naxis1] = value;
                   }
                   for (xx=x-(radius+width); xx<=x+radius+width; xx++) {
                     for (yy=y-(radius+width); yy<=y-radius; yy++)
		       image[xx + yy*hdr->naxis1] = value;
                     for (yy=y+radius; yy<=y+radius+width; yy++)
		       image[xx + yy*hdr->naxis1] = value;
                   }
                   break;
     }
  }
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void do_mark(
  char *imname,
  char *outname,
  float *x,
  float *y,
  int   n,
  float radius,
  float width,
  int value,
  int type
) {
  float *image;
  hstruct hdr;
  int   i;
  char  tmps[255];

  image = floatfitsimage(&hdr,imname,TRUE);
  if (image != NULL) {
    sprintf(tmps,"%i marker(s) added by BAOLAB",n);
    addcard(&hdr,"HISTORY",tmps,H_COMM);

    for (i=0; i<n; i++)
      addmark(image,&hdr,x[i],y[i],radius,width,value,type);

    savefitsfile(&hdr,image,-32,outname);
    free(image);
    freehdr(&hdr);
  } else
    puts(IM_READ_ERR);
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

void mark(char *params) {

  static char imname[255] = "", cooname[255] = "", outname[255] = "";
  char   tmps[255];
  float  radius = 10.0,width=2; 
  int    value=32767;
  float  *x, *y;
  int    n,type = CIRCLE;


  if (getpar("MARK.RADIUS",tmps)) radius = atof(tmps);
  if (getpar("MARK.WIDTH",tmps)) width = atof(tmps);
  if (getpar("MARK.VALUE",tmps)) value = atoi(tmps);
  if (getpar("MARK.TYPE",tmps))  {
    if (strstr(tmps,"CIRCLE") == tmps) type = CIRCLE; else
    if (strstr(tmps,"BOX") == tmps) type = BOX; else
    printf("  Unknown marker type: MARK.TYPE = %s. Using CIRCLE\n",tmps);
  }

  if (nargs(params) == 3) {
    argn(params,1,imname);
    argn(params,2,cooname);
    argn(params,3,outname);
  } else {
    printf("  Image name      : "); cscanf("%s",imname);
    printf("  Coordinate file : "); cscanf("%s",cooname);
    printf("  Output image    : "); cscanf("%s",outname);
  }

  n = getcoolst(cooname,&x,&y);
  if (n > 0) {
    printf(" %i marker coordinate(s) read..\n",n);
    do_mark(imname,outname,x,y,n,radius,width,value,type);
    puts(" Done!");
  }
  else
    puts("  ** Error reading coordinate list.");

  free(x);
  free(y);
}
