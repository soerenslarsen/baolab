void lsqlin(
  float *x,      /*  X-values */
  float *y,      /*  Y-values */
  float *w,      /*  Weights  */
  float *sigsq,  /*  Errors squared  -- must be greater than 0 */
  int    n,      /*  Number of data points */
  float *_a,     /*  Return in *_a and *_b : y = _a x + _b  */
  float *_b
) {
  float s, sx, sy, sxx, sxy;
  float si,si_r;
  float delta;
  float a, b;
  int i;

  s = sx = sy = sxx = sxy = 0.;

  for (i=0; i<n; i++) {
    si_r = w[i]/sigsq[i];
    s   += si_r;
    sx  += x[i]*si_r;
    sy  += y[i]*si_r;
    sxx += x[i]*x[i]*si_r;
    sxy += x[i]*y[i]*si_r;
  }

  delta = s*sxx - sx*sx;
  a = (s*sxy - sx*sy) / delta;
  b = (sxx*sy - sx*sxy) / delta;

  *_a = a;
  *_b = b;
}
