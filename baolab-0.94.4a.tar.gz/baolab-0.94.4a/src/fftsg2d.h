  extern void rdft2d(
    int,
    int, 
    int,
    double **,
    double *,
    int *,
    double *
  );

  extern void cdft2d(
    int,
    int, 
    int,
    double **,
    double *,
    int *,
    double *
  );

  extern void rdft2dsort(
    int,
    int,
    int,
    double **
  );
