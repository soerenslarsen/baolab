/* 
 * Try to reconstruct the intrinsic shape of a compact, but non-stellar
 * object in an image with known PSF. This task attempts to find the
 * intrinsic shape of a compact object by convolving a number of models
 * with the PSF until the best match to the observed profile is reached.
 * This is one of the more complex tasks in BAOLAB, inspired by work on
 * compact star clusters in nearby galaxies. 
 *
 * ISHAPE will write output to a logfile, and a FITS format image can
 * be stored. The FITS image contains 1) the object to be fit, 2) the model
 * that is obtained by convolving the intrinsic profile with the PSF, 
 * 3) the residuals and 4) the weights assigned to individual pixels.
 * This is arranged as follows:
 *
 *   0,0 -----------------------
 *  |             |             |
 *  |             |             |
 *  |  Residuals  |  Weights    |
 *  |             |             |
 *  |             |             |
 *  |---------------------------|
 *  |             |             |
 *  |             |             |
 *  |   Model     |   Data      |
 *  |             |             |
 *  |             |             |
 *   --------------------------- 
 */

#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"
#include "utils.h"
#include "neldmead.h" 
#include "convol.h"
#include "lsqlin.h"
#include <float.h>

#define RANGE_ERR FLT_MAX

extern void findmax_flt(      /* in baolab2.c */
  float *,    /* data to be fit */
  int,       /* dx - really radius! */
  int,       /* dy - really radius! */
  int,       /* method (FITMAX / FITPOLY / FITRPOLY / FITNONE) */
  float *,   /* maxx */
  float *    /* maxy */
);

extern int fill_array(    /* in mkpsf.c */
  float*,  /* array, */
  int,     /* dim    */
  int,     /* type   */
  float,   /* fwhmx  */
  float,   /* fwhmy  */
  float,   /* position angle */
  float,   /* index          */
  float,   /* rltot          */
  char*    /* file - if USER psf */
);

extern float king_cc(    /* in mkpsf.c */
  float,   /* fwhm */
  float,   /* tidal radius */
  float*   /* concentration parameter */
);

extern int median(        /* In baolab2.c */
  int *,
  int
) ;

extern float fmedian(        /* In baolab2.c */
  float *,
  int
) ;

static float bestfit( 
  ishapestruct *, /* par    */
  float *,        /* object */
  float *,        /* psf    */
  hstruct,        /* phdr   */
  float,          /* fwhmx  */
  float,          /* fwhmy  */
  float,          /* pangle */
  float,          /* index  */
  float *         /* residuals */
) ;

char *PSFNAME[] = {"","GAUSS","GAUSS2","MOFFAT15","MOFFAT25","LORENZ",
                   "USER","DELTA","HUBBLE","LUGGER","KING5","KING15","KING30",
		   "KING100","KINGn","MOFFATn","KINGx","MOFFATx","EXPN",
		   "EFF10","EFF15","EFF25","EFFn","EFFx",
		   "EFFCn10","EFFCn15","EFFCn25",
		   "EFFCx10","EFFCx15","EFFCx25",
		   "KINGt","SERSICx",
		   "SERSICn"};

/* Global variables for simplex_func */

static float *OBJECT[2];
static float *MODEL[2];
static ishapestruct *PAR[2];
static float *BINNED[2];
static float *PSF[2];
static hstruct PHDR[2];
static int   MDIM[2];

/* Global variables for simplex_func3 */

static int S3_IFIX[4];    /* Parameter(s) to keep fixed                 */
static float S3_PFIX[4];  /* Value(s) of the parameter(s) to keep fixed */
static float S3_CHSQ;


/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void write_pars(
  ishapestruct *par
) {
  fprintf(par->logfile,"Parameter settings:\n");
  fprintf(par->logfile,"  FITRAD = %i\n",par->fitrad);
  fprintf(par->logfile,"  CENTERRAD = %0.1f\n",par->centerrad);
  fprintf(par->logfile,"  MAXCITER = %i\n",par->maxciter);
  switch (par->centermethod) {
    case FITMAX   : fprintf(par->logfile,"  CENTERMETHOD = MAX\n"); break;
    case FITPOLY  : fprintf(par->logfile,"  CENTERMETHOD = POLY\n"); break;
    case FITRPOLY : fprintf(par->logfile,"  CENTERMETHOD = RPOLY\n"); break;
    case FITNONE  : fprintf(par->logfile,"  CENTERMETHOD = NONE\n"); break;
  }
  fprintf(par->logfile,"  CTRESH   = %0.2f\n",par->ctresh);
  fprintf(par->logfile,"  CLEANRAD = %0.2f\n",par->cleanrad);
  fprintf(par->logfile,"  SHAPE = %s\n",PSFNAME[par->shape]);
  fprintf(par->logfile,"  INDEX = %0.2f\n",par->index);
  fprintf(par->logfile,"  ELLIPTICAL = %s\n",par->elliptical ? "YES" : "NO");
  fprintf(par->logfile,"  EPADU   = %0.2f\n",par->epadu);
  fprintf(par->logfile,"  USEDK   = %s\n",par->usedk ? "YES" : "NO");
  fprintf(par->logfile,"  DKERNEL = %s\n",par->dkname);
  fprintf(par->logfile,"  RON     = %0.2f e-\n",par->ron);
  fprintf(par->logfile,"  FWHMMAX = %0.1f\n",par->fwhmmax);
/*  fprintf(par->logfile,"  AMPLTOL = %e\n",par->ampltol);   */
  fprintf(par->logfile,"  FTOL    = %e\n",par->ftol);
  fprintf(par->logfile,"  EFTOL   = %e\n",par->eftol);
  fprintf(par->logfile,"  ITMAX   = %i\n",ITMAX);
  fprintf(par->logfile,"  FWHMTOL = %0.2f\n",par->fwhmtol);
  fprintf(par->logfile,"  RESIMAGE= %s\n",par->resimage);
  fprintf(par->logfile,"  REPLACE = %s\n",par->replace ? "YES" : "NO");
  fprintf(par->logfile,"  KEEPLOG = YES\n");                  /* ! */
  fprintf(par->logfile,"  LOGFILE = %s\n",par->logname);
  fprintf(par->logfile,"  CALCERR = %s\n",par->calcerr ? "YES" : "NO");
  fprintf(par->logfile,"  CORRERR = %s\n\n",par->correrr ? "YES" : "NO");
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static float nfree(
  ishapestruct *par
) {
  float nf,n;

  if (par->elliptical) {
    nf = 7.;            /* x, y, amplitude, background, fwhmx, fwhmy, pa */
  } else {
    nf = 5.;            /* x, y, amplitude, background, fwhm */
  }

  if (par->shape == EFFn || par->shape == MOFFATn || par->shape == KINGn ||
      par->shape == SERSICn || 
      par->shape == EFFCn10 || par->shape == EFFCn15 || par->shape == EFFCn25)
    nf += 1;

  n = sqr(2*par->fitrad + 1);
  if (nf > n-1) nf = n-1;

  return nf;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

int is_resolved(
  float chsqr,
  float chsq0,
  float nsig,
  ishapestruct *par
) {
  int dof;
  float chsq1sig;

  dof = sqr(2*par->fitrad+1) - nfree(par);
  chsq1sig = chsqr - sqr(nsig)/dof; 
  if (chsq0 > chsq1sig) 
    return 1;
  else
    return 0;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float *getobj(      /* Extract the object at position x,y from image */
  float *image,
  int x,
  int y,
  hstruct hdr,
  ishapestruct *par
) {
  float *objarr;
  float *tmparr;
  int dx,dy,r,i,j,x1,y1,x0,y0;
  float maxx, maxy;

  tmparr = (float *)malloc(sizeof(float)*sqr(2*par->centerrad+1));
  r = par->centerrad;

  x0 = x;
  y0 = y;
  maxx = 0;
  maxy = 0;
  j = 0;

  /* First some work to find the actual centre of the object */

  if (par->centermethod != FITNONE) {
    do {
      i = 0;
      x1 = x; y1 = y;

      for (dy=-r; dy<=r; dy++) 
        for (dx=-r; dx<=r; dx++) 
          tmparr[i++] = image[(size_t)hdr.naxis1*(size_t)(y+dy) + (size_t)(x+dx)];

      findmax_flt(tmparr,r,r,par->centermethod,&maxx, &maxy);
      x += maxx;
      y += maxy;
      j++;
    }  while ((x1 != x || y1 != y) && j < par->maxciter && 
	      sqrt(sqr(x-x0)+sqr(y-y0))<=par->centerrad);
  }
             
  par->xcentre = maxx;
  par->ycentre = maxy;
           
  free(tmparr);
              
  if (sqrt(sqr(x-x0)+sqr(y-y0))>par->centerrad) {
    if (par->verbose)
      puts(" ** Error: Maximum centering shift exceeded.");
    if (par->keeplog && par->logmode > 1)
      fputs(" ** Error: Maximum centering shift exceeded.\n",par->logfile);
    return NULL;
  }         
            
  if (j == par->maxciter && (x1 != x || y1 != y)) {
    if (par->verbose)
      puts(" ** Error: Maximum number of centering iterations exceeded.");
    if (par->keeplog && par->logmode > 1)
      fputs(" ** Error: Maximum number of centering iterations exceeded.\n",
        par->logfile);
    return NULL;
  }                        
               
  /* Now finally get the object stored into the objarr array */
               
  r = par->fitrad;    
  i = 0;         
  objarr = (float *)malloc(sizeof(float)*sqr(2*r+1));
  par->weights = (float *)malloc(sizeof(float)*sqr(2*r+1));
               
  for (dy=-r; dy<=r; dy++) 
    for (dx=-r; dx<=r; dx++)  {
      objarr[i++] = image[(size_t)hdr.naxis1*(size_t)(y+dy) + (size_t)(x+dx)];
    }         

  par->fitsec[0] = x-r;
  par->fitsec[1] = x+r;
  par->fitsec[2] = y-r;
  par->fitsec[3] = y+r;
                  
  if (par->verbose)
    printf("  Got object at position x,y=%i,%i, adjusted to %i,%i\n",x0,y0,x,y);
  if (par->keeplog && par->logmode > 1)
    fprintf(par->logfile,
            "  Got object at position x,y=%i,%i, adjusted to %i,%i\n",
            x0,y0,x,y);
  return objarr;
}                  
                  
/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float *make_model(
  ishapestruct *par,
  float *psf,
  hstruct phdr,
  int i_shape,
  float fwhmx,
  float fwhmy,
  float pangle,
  float index,
  int   *_dim
) {
  float *psf_cnv;
  float *guess_cnv;
  float *result;
  float  fwmax, c, cc;
  int dim, psfdmax;
  int i;

  /* PSF into 2^n square array */

/*  Obsolete, now using mkp2arr
  dim = 2;
  psfdmax = (phdr.naxis1 > phdr.naxis2) ? phdr.naxis1 : phdr.naxis2;
  while (dim < psfdmax) dim *= 2;
  psf_cnv = (float *)malloc(sizeof(float)*sqr(dim));
  for (i=0; i<sqr(dim); i++) psf_cnv[i] = 0.0;

  y1 = dim/2 - phdr.naxis2/2;
  y2 = y1+phdr.naxis2;
  x1 = dim/2 - phdr.naxis1/2;
  x2 = x1+phdr.naxis1;
  i = 0;

  for (y=y1; y<y2; y++)
    for (x=x1; x<x2; x++)
      psf_cnv[y*dim+x] = psf[i++]; */

  /* Check if the PSF is smaller than the fitting area.                 */
  /* With some care this might work in some cases, so we allow it.      */
  /* However we still want to make sure the model array is large enough */
  /* to hold the convolved model.                                       */

  psfdmax = (phdr.naxis1 > phdr.naxis2) ? phdr.naxis1 : phdr.naxis2;
  if (psfdmax/10 < 2*par->fitrad+2) {
    dim = 2;
    while (dim/10 < 2*par->fitrad+2) dim *= 2; 
  } else
    dim = 0;     /* Array dimension will be computed by mkp2arr */

  psf_cnv = mkp2arr(phdr.naxis1,phdr.naxis2,psf,&dim);

  /* Guess into 2^n square array */

  guess_cnv = (float *)malloc(sizeof(float)*sqr(dim));

  if (fill_array(guess_cnv,dim,par->shape,fwhmx,fwhmy,pangle,index,par->fitrad,NULL)) {
    result = (float *)malloc(sizeof(float)*sqr(dim));

    /* Convolve the two */

    if (par->elliptical) {
      if (par->verbose) {
        puts("  Convolving PSF and OBJECT arrays -> MODEL array");
        printf("  SHAPE=%s (elliptical), FWHM=%0.2f,%0.2f, PANGLE=%0.2f", 
           PSFNAME[par->shape],fwhmx,fwhmy,pangle);
        if (par->shape == KINGn || par->shape == MOFFATn ||
           par->shape == KINGx || par->shape == MOFFATx ||
           par->shape == SERSICx || par->shape == SERSICn ||
           par->shape == EFFx  || par->shape == EFFn ||
           par->shape==EFFCn10 || par->shape==EFFCn15 || par->shape==EFFCn25 ||
           par->shape==EFFCx10 || par->shape==EFFCx15 || par->shape==EFFCx25)
	  printf(", INDEX=%0.2f",index);
	if (par->shape == KINGt) {
	  fwmax = (fwhmx > fwhmy) ? fwhmx : fwhmy;
	  cc = king_cc(fwmax, index, &c); 
	  printf(", INDEX=%0.2f (c=%0.2f)",index,c);
        } 
        printf("\n");
      }

      if (par->keeplog && par->logmode>2) {
        fprintf(par->logfile,"  FWHM=%0.2f,%0.2f, PANGLE=%0.2f.. ",
	 fwhmx,fwhmy,pangle);
        if (par->shape == KINGn || par->shape == MOFFATn ||
           par->shape == KINGx || par->shape == MOFFATx ||
           par->shape == SERSICx || par->shape == SERSICn ||
	   par->shape == EFFx  || par->shape == EFFn ||
           par->shape==EFFCn10 || par->shape==EFFCn15 || par->shape==EFFCn25 ||
           par->shape==EFFCx10 || par->shape==EFFCx15 || par->shape==EFFCx25)
	  fprintf(par->logfile,", INDEX=%0.2f ",index);
	if (par->shape == KINGt) {
	  fwmax = (fwhmx > fwhmy) ? fwhmx : fwhmy;
	  cc = king_cc(fwmax, index, &c); 
	  fprintf(par->logfile,", INDEX=%0.2f (c=%0.2f)",index,c);
        } 
      }
    } else {
      if (par->verbose) {
        puts("  Convolving PSF and OBJECT arrays -> MODEL array");
        printf("  SHAPE=%s (circular), FWHM=%0.2f\n", 
           PSFNAME[par->shape],fwhmx);
      }

      if (par->keeplog && par->logmode>2)
        fprintf(par->logfile,"  FWHMX,FWHMY=%0.2f,%0.2f.. ",fwhmx,fwhmy);
    }

    convol(dim,guess_cnv,psf_cnv,result); 
    if (par->verbose) puts("  Done convolving.");

    *_dim = dim;
    free(psf_cnv);
    free(guess_cnv);
    return result;

  } else {
    free(guess_cnv);
    if (par->verbose) puts("  ** Error creating object.");
    return NULL;
  }
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void rebin_model(
  float *model,
  int    dim,
  ishapestruct *par,
  float xc,
  float yc,
  float *result
) {
  float max,sum;
  int i,x,y,x1,y1,x2,y2;
  int r,yp,xp;
  int d;
  float *dkp2, *resp2, *result2;

/*  printf("  Rebinning MODEL array at position %0.2f,%0.2f\n",xc,yc); */
  r = par->fitrad;
  for (i=0; i<sqr(2*r+1); i++) result[i] = 0.0;

  /* Rebin the convolved image into an array of the same size as 'object' */
  max = 0.0;
  
  for (y=-r; y<=r; y++) {
    y1 = (dim/2) + 10*(y-yc) - 5;
    y2 = (dim/2) + 10*(y-yc) + 5;

    for (x=-r; x<=r; x++) {
      x1 = (dim/2) + 10*(x-xc) - 5;
      x2 = (dim/2) + 10*(x-xc) + 5;
      sum = 0.0;

      if (x1>0 && y1>0 && x2<dim && y2<dim) {
	for (yp = y1; yp<y2; yp++) {
	  for (xp = x1; xp<x2; xp++)
	    sum += model[dim*yp + xp];
	}
	result[(r+y)*(2*r+1) + (r+x)] = sum;
	if (sum > max) max = sum;
      }
    }
  }

  /* After rebinning, convolve with diffusion kernel if desired   */

  if (par->usedk) {
    d = 0;
    resp2 = mkp2arr(2*r+1, 2*r+1, result, &d);
    dkp2 = mkp2arr(par->dimdk, par->dimdk, par->diffkernel, &d);

    result2 = (float *)malloc(sizeof(float)*d*d);

    convol(d, resp2, dkp2, result2);
    getp2arr(d, result2, 2*r+1, 2*r+1, result);

    max = 0.0;
    for (i=0; i<sqr(2*r+1); i++) 
      if (result[i] > max) max = result[i];

    free(resp2);
    free(dkp2);
    free(result2);
  }

  for (i=0; i<sqr(2*r+1); i++) result[i] /= max;

/*  printf("BBBBBBB %i\n",dim);
  for (i=0; i<sqr(2*r+1); i++) printf("%0.2e\n",result[i]);  */
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float chi_sqr(
  ishapestruct *par,
  float *model,
  float *object,
  float ampl,
  int n,
  float *fbkg,
  float *residuals,
  int   fitbkg       /* Fit the background ? (or use value stored in *fbkg) */
) {
  float bkg,chsqr,chsqr_red;
  int   i,x,y,dy,dx;
  float diff,errsq,w,wsum;
  float serrsq;
  float nf;
  float oi;

  bkg = 0.0;
  w = 0.0;

  if (fitbkg) {
    for (i=0; i<n; i++) {
      bkg += par->weights[i]*(object[i] - ampl*model[i])/n;
      w += par->weights[i]/n;
    }
    bkg /= w;
  } else
    bkg = *fbkg;

  chsqr = 0.0;
  serrsq = 0.0;

  /* Calculate the reduced chi-square */

  wsum = 0.;
  for (i=0; i<n; i++) {
 /*    chsqr += sqr((object[i] - bkg) - ampl*model[i]); */
    diff = par->epadu * ((object[i] - bkg) - ampl*model[i]);
    if (object[i] > 0) oi = object[i]; else oi = 0.;
    errsq = sqr(par->ron) + oi*par->epadu;  
      /* Background included in object */
    chsqr += par->weights[i]*sqr(diff)/errsq;
    wsum  += par->weights[i];
    serrsq += errsq;
  }

  /* Number of free parameters in fit */

  chsqr_red = (chsqr / wsum) * (n/(n-nfree(par)));
/*  printf("chi_sqr: %f %f %i %f\n",chsqr,wsum,n,nfree(par)); */

  if (residuals != NULL) {
    par->bknoise = sqrt(serrsq) / par->epadu; /* Total noise in ADU, for  */
                                              /* later S/N calculation.   */
    dx = dy = par->fitrad*2 + 1;
    for (y=0; y<dy; y++)
      for (x=0; x<dx; x++) {
        residuals[x+2*dx*y] = object[x+dx*y] - ampl*model[x+dx*y];
      }
/*    for (i=0; i<n; i++) residuals[i] = object[i] - ampl*model[i]; */
  }

  *fbkg = bkg;
/*  return chsqr/n; */
  return chsqr_red; 
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

/*
float dchi_sqr_da(
  ishapestruct *par,
  float *model,
  float *object,
  int   n,
  float ampl,
  float da
) {
  float bkg;

  return (chi_sqr(par,model,object,ampl+da,n,&bkg,NULL,TRUE) 
        - chi_sqr(par,model,object,ampl,n,&bkg,NULL,TRUE)) / da;
}
*/

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float mdiff(
  float *x,      /*  x     -- X-values */
  float *y,      /*  y     -- Y-values */
  float *w,      /*  w     -- Weights  */
  float *sigsq,  /*  sigsq -- Errors squared  */
  int   n        /*  n     -- Number of data points */
) {
  int i;
  float ws, sum, sws;

  sum = sws = 0.;
  for (i=0; i<n; i++) {
     ws = w[i]/sigsq[i]; 
     sum += ws*(y[i]-x[i]);
     sws += ws;
  }
  return sum/sws;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float chi_sqr_min(
  /*
   *  Calculates chi_sqr for the 'model' fit to 'object'.
   *  The two arrays represent the model and the actual observations
   *  of a compact object. This function will not attempt any positional
   *  alignment, but scaling and a background offset will be applied in 
   *  order to obtain the smallest possible chi_sqr
   */
  float *object,
  float *model,
  ishapestruct *par,
  float *fampl,        
  float *fbkg,
  float *residuals
) {
  float chsqr;
  float *sigsq;
  int i,n,r;
  float bkg;
  float ampl;

  r = par->fitrad;

  n = sqr(2*r+1);
  sigsq = (float *)malloc(sizeof(float)*n);
  for (i=0; i<n; i++)
    sigsq[i] = sqr(par->ron) + object[i]*par->epadu;  


  lsqlin(model,object,par->weights,sigsq,n,&ampl, &bkg);
  *fbkg = bkg;
  *fampl = ampl;

  if ((ampl < 0) && par->nonneg) {
/*      printf("LSQFIT : Ampl = %0.2f -> 0.0\n",ampl);
      printf("         Bkg  = %0.2f -> %0.2f\n",bkg, mdiff(model,object,par->weights,sigsq,n));  */
      ampl = 0.;
      bkg = mdiff(model,object,par->weights,sigsq,n);
  } 
/*  else 
  {
      printf("LSQFIT : Ampl = %0.2f\n",ampl);
      printf("         Bkg  = %0.2f\n",bkg); 
  } */

/*  puts("AAAAAAAAAAAAAAAA");
  for (i=0; i<n; i++)
    printf("%0.2e %0.1f %0.1f\n",model[i],model[i]*ampl+bkg,object[i]);
*/

  if (ampl < 0) {
    SIMPLEX_ERR = 1;
    free(sigsq);
    return -1.0;
  }

  chsqr = chi_sqr(par,model,object,ampl,n,fbkg,residuals,FALSE);
  free(sigsq);

  return chsqr;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float simplex_funk1(     
  float *p              /* p[0] = dx , p[1] = dy */
) {
  float ampl,fbkg;

  rebin_model(MODEL[0],MDIM[0],PAR[0],p[0],p[1],BINNED[0]);
  return chi_sqr_min(OBJECT[0],BINNED[0],PAR[0],&ampl,&fbkg,NULL); 
}

float simplex_funk2(
  float *p
) {
  return bestfit(PAR[1],OBJECT[1],PSF[1],PHDR[1], 
              1.0/p[0],1.0/p[1],p[2],p[3],NULL);
}

float simplex_funk3(
  float *p
) {
  int i;
  float pfit[4];

  
  for (i=0; i<4; i++) {
    if (S3_IFIX[i]) 
      pfit[i] = S3_PFIX[i];
    else
      pfit[i] = p[i];
  }

  S3_CHSQ = bestfit(PAR[1],OBJECT[1],PSF[1],PHDR[1], 
                      1.0/pfit[0],1.0/pfit[1],pfit[2],pfit[3],NULL);
  return S3_CHSQ;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static float bestfit(     /* Returns -1 on failure, chi_sqr otherwise */
  ishapestruct *par,
  float *object,
  float *psf,
  hstruct phdr,
  float fwhmx,
  float fwhmy,
  float pangle,
  float index,         /* log(index) for KINGn/EFFCn/MOFFATn/SERSICn */
  float *residuals
) {
  float *binned, *model;
  int    n,r,i,mdim;
/*  float  p0[3];           For powell */
/*  float  **xi0;           For powell */
  float  p[MP][NP];      /* For amoeba */
  float  y[MP];
  float  tindex;
  float  tmp[2];
  float  chsqr;
  float  ampl,bkg;
  int    xi,yi,dx,dy;
  float  norm;
  int    lo, hi, count;

  switch (par->shape) {
    case KINGx:
    case KINGt:
    case EFFx:
    case EFFCx10:
    case EFFCx15:
    case EFFCx25: 
    case SERSICx:
    case MOFFATx: tindex = par->index; break;

    case KINGn:   /*  tindex = exp(index); break; */
    case EFFn:
    case SERSICn:
    case MOFFATn: /* tindex = fabs(1/index); break; */
    case EFFCn10:
    case EFFCn15:
    case EFFCn25: tindex = exp(index); break;
  }

  binned = (float *)malloc(sizeof(float)*sqr(2*par->fitrad+1));
  model = make_model(par,psf,phdr,par->shape,
                   fabs(fwhmx),fabs(fwhmy),pangle,tindex,&mdim);

  OBJECT[0] = object;
  MODEL[0] = model;
  MDIM[0] = mdim;
  PAR[0] = par;
  BINNED[0] = binned;

/*  Stuff for POWELL minimisation: */
/*
  p0[1] = 0.0; p0[2] = 0.0;

  xi0 = (float **)malloc(sizeof(float *)*3);
  xi0[1] = (float *)malloc(sizeof(float)*3);
  xi0[2] = (float *)malloc(sizeof(float)*3);
  xi0[1][1] = 0.0;
  xi0[1][2] = 1.0;
  xi0[2][1] = 1.0;
  xi0[2][2] = 0.0;

  powell(p0,xi0,2,par->ftol,&i, &chsqr, &simplex_funk1);
  free(xi0[1]);
  free(xi0[2]);
  free(xi0);

  p[0][0] = p0[1];
  p[0][1] = p0[2];
*/
/*  End of stuff for POWELL minimisation */

/*  Stuff for AMOEBA minimisation: */
  p[0][0] = -0.2; p[0][1] = -0.2; 
  p[1][0] = -0.2; p[1][1] =  0.2;
  p[2][0] =  0.2; p[2][1] =  0.2;

  for (i=0; i<3; i++) {
    tmp[0] = p[i][0]; 
    tmp[1] = p[i][1]; 
    y[i] = simplex_funk1(tmp);
  }

  if (par->verbose) puts("  Finding best fit position ");

/*  i = amoeba(p,y,2,par->ftol,&simplex_funk1); */
  i = neldermead(p, y, 2, par->ftol, &simplex_funk1);
  if (!i) {
    if (SIMPLEX_ERR) {
      free(binned);
      free(model);
      return -1.0;
    } else {
      if (par->keeplog && par->logmode>2)
        fputs("\n  ** Warning: Itmax exceeded in amoeba (convergence not reached)\n",
      par->logfile);
    }
  }


/*  End of stuff for AMOEBA minimisation */

  tmp[0] = p[0][0];
  tmp[1] = p[0][1];
/*  chsqr = simplex_funk(tmp); */
  rebin_model(model,mdim,par,p[0][0],p[0][1],binned);
  chsqr = chi_sqr_min(object,binned,par,&ampl,&bkg,residuals); 

  if (residuals != NULL) {
    r = par->fitrad;
    n = sqr(2*r+1);
    dx = dy = 2*r+1;
    par->bkg = bkg;
    par->flux = 0.0;

    for (yi=0; yi<dy; yi++)
      for (xi=0; xi<dx; xi++) {
        residuals[xi+2*dx*(yi+dy)] = bkg + ampl*binned[xi+yi*dx];
        residuals[xi+dx+2*dx*(yi+dy)] = object[xi+yi*dx];
        par->flux += ampl*binned[xi+yi*dx];
      }
  } 

  if (par->verbose)
    printf("chi_sqr_min: x,y=%0.2f,%0.2f, chi_sqr=%0.2f\n",tmp[0],tmp[1],chsqr);
  if (par->keeplog && par->logmode>2)
    fprintf(par->logfile," x,y=%0.2f,%0.2f  chi_sqr = %0.2f\n",
             tmp[0],tmp[1],chsqr);

  free(model);
  free(binned);
  return chsqr;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float dchi_sqr_dfwhm(
  ishapestruct *par,
  float *object,
  float *psf,
  hstruct phdr,
  float fwhm,
  float dfwhm,
  float *chsqr
) {
  
  float chsqr1, chsqr2;
  float dummy;

  chsqr1 = bestfit(par,object,psf,phdr,fwhm,fwhm,0.0,dummy,NULL);
  chsqr2 = bestfit(par,object,psf,phdr,fwhm+dfwhm,fwhm+dfwhm,0.0,dummy,NULL);

  *chsqr = chsqr1;

  return (chsqr2 - chsqr1) / dfwhm;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static float fitshape1d(   /* Fit a circular SHAPE */
  ishapestruct *par,
  float *object,
  float *psf,
  hstruct phdr,
  float *residuals,
  float *fwhmxy
) {
  float fwhm1,fwhm2,fwhm, fwhmtune;
  float d1,d2;
  float chsq1,chsq2,chsq;
  float dummy;
  int   tmp;
  float tmpb;
  float ax, bx, cx, fa, fb, fc, fbest;
  float f1,f2;
  float x0,x1,x2,x3,xbest;
  float R, C;
  float c,cc;

  fwhm1 = 0.001;
  fwhm2 = par->fwhmmax;
  fwhm = (fwhm1+fwhm2)/2.0;

  d1 = dchi_sqr_dfwhm(par,object,psf,phdr,fwhm1,par->fwhmtol/2.0,&chsq1);
  d2 = dchi_sqr_dfwhm(par,object,psf,phdr,fwhm2,par->fwhmtol/2.0,&chsq2);

  if (d1 > 0) {
    puts("  ** Object appears stellar.");
    if (par->keeplog && par->logmode>0) 
      fputs("  ** Object appears stellar.\n",par->logfile);
    *fwhmxy = fwhm = 0.0;
  } else if (d2 < 0) {
    puts("  ** Object appears to be larger than FWHMMAX.");
    if (par->keeplog && par->logmode>0) 
      fputs("  ** Object appears to be larger than FWHMMAX.\n",par->logfile);
    *fwhmxy = fwhm = fwhm2;
  } else {

    /* Initialize for Golden Section Search */

    R = 0.61803399; C = 1 - R;
    ax = 0.001;        fa = bestfit(par,object,psf,phdr,ax,ax,0.0,dummy,NULL);
    cx = par->fwhmmax; fc = bestfit(par,object,psf,phdr,cx,cx,0.0,dummy,NULL);
    tmpb = cx - ax;

    do {
      tmpb /= 2;
      bx = (fa < fc) ? ax + tmpb : cx - tmpb;
      fb = bestfit(par,object,psf,phdr,bx,bx,0.0,dummy,NULL);
    } while (((fb > fa) || (fb > fc)) && (tmpb > 0.01));

    if (tmpb < 0.01) {
      printf("** Warning: No minimum found between FWHM=%0.2f and %0.2f\n",
        0.0, par->fwhmmax);
      if (par->keeplog && par->logmode>0) 
        fprintf(par->logfile,
	       "** Warning: No minimum found between FWHM=%0.2f and %0.2f\n",
               0.0, par->fwhmmax);
      fwhm = 0.0;
    } else {

      /* Carry out golden section search for minimum */

      x0 = ax;
      x3 = cx;

      if (fabs(cx-bx) > fabs(bx-ax)) {
	x1 = bx;
	x2 = bx + C * (cx-bx);
      } else {
	x2 = bx;
	x1 = bx - C * (bx-ax);
      }

      f1 = bestfit(par,object,psf,phdr,x1,x1,0.0,dummy,NULL);
      f2 = bestfit(par,object,psf,phdr,x2,x2,0.0,dummy,NULL);
      do { 
	if (f2 < f1) {
	  x0 = x1;
	  x1 = x2;
	  x2 = R * x1 + C * x3;
	  f1 = f2;
	  f2 = bestfit(par,object,psf,phdr,x2,x2,0.0,dummy,NULL);
	} else {
	  x3 = x2;
	  x2 = x1;
	  x1 = R * x2 + C * x0;
	  f2 = f1;
	  f1 = bestfit(par,object,psf,phdr,x1,x1,0.0,dummy,NULL);
	}
      } while (fabs(x2-x1) > par->fwhmtol && (!SIMPLEX_ERR));

      if (f1 < f2) { 
        fwhm = x1; 
        fbest = f1;
      } else {
        fwhm = x2;
        fbest = f2;
      }

      if (SIMPLEX_ERR) {
	if (par->keeplog && par->logmode>1) 
	  fputs("\n  ** Error: Could not find a best fit\n",par->logfile);
	puts("  ** Error: Could not find a best fit\n");
	return -1.0;
      } 
/*      else 
      {
      
      ** Fine tune search for minimum, if desired **

        fwhmtune = 0.2;
        xbest = fwhm;
        x1 = fwhm-par->fwhmtol;
        do {
          f1 = bestfit(par,object,psf,phdr,x1,x1,0.0,dummy,NULL);
          if (f1 < fbest) {
            fbest = f1;
            xbest = x1;
          }
          x1 -= par->fwhmtol;
        } while (x1 > fwhm-fwhmtune && x1 > 0);

        x2 = fwhm+par->fwhmtol;
        do {
          f2 = bestfit(par,object,psf,phdr,x2,x2,0.0,dummy,NULL);
          if (f2 < fbest) {
            fbest = f2;
            xbest = x2;
          }
          x2 += par->fwhmtol;
        } while (x2 < fwhm+fwhmtune);

        fwhm = xbest;
      }
*/

    }
    *fwhmxy = fwhm;
  }

  chsq = bestfit(par,object,psf,phdr,fwhm,fwhm,0.0,dummy,residuals);
/*  printf("\n  Best fit: FWHM=%0.2f (chi_sqr=%0.2f)\n",fwhm,chsq);
  printf("  ----------------------------------\n"); 
  if (par->keeplog && par->logmode>1)
    fprintf(par->logfile,"\n  Best fit: FWHM=%0.2f (chi_sqr=%0.2f)\n",fwhm,chsq);
*/

  tmp = par->shape;
  par->shape = DELTA;
  par->chsq0 = bestfit(par,object,psf,phdr,0.0,0.0,0.0,dummy,NULL);
  par->shape = tmp;

  printf("\n  Best fit (for SHAPE=%s and %i deg. of freedom): \n", 
    PSFNAME[par->shape], (int)(sqr(2*par->fitrad+1)-nfree(par)));

  printf("    FWHM              = %0.2f\n",fwhm);
  if (par->shape == KINGt) {
    cc = king_cc(fwhm,par->index, &c);
    printf("    Rt/Rc             = %0.2f\n",c);
  }
  printf("    Flux (ADU)        = %0.3e\n",par->flux);
  printf("    Background        = %0.3e\n",par->bkg);
  printf("    S/N               = %0.1f\n",par->flux/par->bknoise);
  printf("    Chi_sqr_nu        = %0.2f\n",chsq);
  printf("    Chi_sqr_nu (0)    = %0.2f\n",par->chsq0);
/*  printf("    Resolved (2 sig)  = %s\n",is_resolved(chsq,par->chsq0,2.0,par)?"YES":"NO"); */
  puts("  ------------------------------");

  if (par->keeplog && par->logmode>1) {
    fprintf(par->logfile,"\n  Best fit (for SHAPE=%s and %i deg. of freedom): \n", 
      PSFNAME[par->shape], (int)(sqr(2*par->fitrad+1)-nfree(par)));

    fprintf(par->logfile,"    FWHM              = %0.2f\n",fwhm);
    if (par->shape == KINGt)
      fprintf(par->logfile,"    Rt/Rc             = %0.2f\n",c);
    fprintf(par->logfile,"    Flux (ADU)        = %0.3e\n",par->flux);
    fprintf(par->logfile,"    Background        = %0.3e\n",par->bkg);
    fprintf(par->logfile,"    S/N               = %0.1f\n",par->flux/par->bknoise);
    fprintf(par->logfile,"    Chi_sqr_nu        = %0.2f\n",chsq);
    fprintf(par->logfile,"    Chi_sqr_nu (0)    = %0.2f\n",par->chsq0);
    fprintf(par->logfile,"  ------------------------------\n");
  }

/*    *fwhmxy = fwhm; 
  }  */

  return chsq;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static float fitshape2d(   /* Fit an elliptical SHAPE */
                           /* Returns -1 on failure, chi-square on success */
  ishapestruct *par,
  float *object,
  float *psf,
  hstruct phdr,
  float *residuals,
  float *major, 
  float *ratio,
  float *pangle,
  float *index
) {
  int   i,result;
  ishapestruct psave;
/*  float p0[4]; */
/*  float **xi0; */
  float p[MP][NP];
  float y[MP];
  float chsq, chsq0, flux;
  float i1;
  int   fitidx = FALSE;
  int   tmp, nit;
  float c, cc;

  /* POWELL stuff */
/*
  PAR[1] = par;
  OBJECT[1] = object;
  PSF[1] = psf;
  PHDR[1] = phdr;

  xi0 = matrix(1,3,1,3);
  p0[1] = 1.0/par->fwhmmax;
  p0[2] = 1.0/par->fwhmmax;
  p0[3] = 0.0;

  xi0[1][1] = 1.0;  xi0[2][1] = 0.0;  xi0[3][1] = 0.0;
  xi0[1][2] = 0.0;  xi0[2][2] = 1.0;  xi0[3][2] = 0.0;
  xi0[1][3] = 0.0;  xi0[2][3] = 0.0;  xi0[3][3] = 1.0;

  if (par->verbose) {
    puts("***********************************************");
    puts("Now searching for best fitting SHAPE parameters");
    puts("***********************************************");
  }

  powell(p0,xi0,3,par->eftol,&i, &chsq, &simplex_funk2);

  p[0][0] = p0[1];
  p[0][1] = p0[2];
  p[0][2] = p0[3];

  chsq = bestfit(par,object,psf,phdr,1./p0[1],1./p0[2],p0[3],dummy,residuals);

  tmp = par->shape;
  par->shape = DELTA;
  par->chsq0 = bestfit(par,object,psf,phdr,0.0,0.0,0,dummy,NULL);
  par->shape = tmp;

  free_matrix(xi0,1,3,1,3);
*/
  /* End of POWELL stuff */

  /* Find the best fit as a function of fwhmx, fwhmy and the position angle  */
  /* p[*][0] = 1/fwhmx, p[*][1] = 1/fwhmy, p[*][2] = pangle, p[*][3] = index */

  /* AMOEBA stuff */

  switch (par->shape) {
    case KINGn  : /* i1 = log(par->index); fitidx = TRUE; break; */
    case EFFn:
    case MOFFATn: /* i1 = 1./par->index; fitidx = TRUE; break; */
    case SERSICn: /* i1 = par->index; fitidx = TRUE; break; */
    case EFFCn10:
    case EFFCn15:
    case EFFCn25: i1 = log(par->index); fitidx = TRUE; break;
  } 

  p[0][0] = 1/par->fwhmmax;   p[0][1] = 1/par->fwhmmax;   p[0][2] = 0.0;   p[0][3] = i1 - 0.2;
  p[1][0] = 1.5/par->fwhmmax; p[1][1] = 1.5/par->fwhmmax; p[1][2] = 0.0;   p[1][3] = i1;
  p[2][0] = 1/par->fwhmmax;   p[2][1] = 1.5/par->fwhmmax; p[2][2] = pi/4;  p[2][3] = i1 + 0.2;
  p[3][0] = 1/par->fwhmmax;   p[3][1] = 1.5/par->fwhmmax; p[3][2] = -pi/4; p[3][3] = i1 - 0.2;
  p[4][0] = 1/par->fwhmmax;   p[4][1] = 1.5/par->fwhmmax; p[4][2] = -pi/4; p[4][3] = i1 + 0.2;

  if (par->verbose) puts("  Initialising for AMOEBA ..");
  for (i=0; i<(fitidx ? 5 : 4); i++) 
    y[i] = bestfit(par,object,psf,phdr,
                   1./p[i][0],1./p[i][1],p[i][2],p[i][3],NULL);

  /* bestfit returns a negative value (-1) on error. So y[*] should be */
  /* positive.                                                         */

  if (y[0] >= 0 && y[1] >= 0 && y[2] >= 0 && y[3] >=0) { 
    PAR[1] = par;
    OBJECT[1] = object;
    PSF[1] = psf;
    PHDR[1] = phdr;

    if (par->verbose) {
      puts("***********************************************");
      puts("Now searching for best fitting SHAPE parameters");
      puts("***********************************************");
    }

/*    result = amoeba(p,y,(fitidx ? 4 : 3),par->eftol,&simplex_funk2); */
    result = neldermead(p,y,(fitidx ? 4 : 3),par->eftol,&simplex_funk2);
    chsq = bestfit(par,object,psf,phdr,
                   1./p[0][0],1./p[0][1],p[0][2],p[0][3],residuals);

    nit = 1;
    do {
      nit++; 
      chsq0 = chsq;
      if (par->verbose)
	puts("*** Restarting AMOEBA to check reality of minimum ***");
      if (par->keeplog && par->logmode>2) 
	fputs("*** Restarting AMOEBA to check reality of minimum ***\n",par->logfile);

     
       p[1][0] = p[0][0]/2.0; p[1][1] = p[0][1]*2.0; p[1][2] = p[0][2]+0.1; p[1][3] = p[0][3]+1.0;
       p[2][0] = p[0][0]*2.0; p[2][1] = p[0][1]/2.0; p[2][2] = p[0][2]+0.1; p[2][3] = p[0][3]+1.0;
       p[3][0] = p[0][0]*2.0; p[3][1] = p[0][1]*2.0; p[3][2] = p[0][2]-0.1; p[3][3] = p[0][3]+1.0;
       p[4][0] = p[0][0]*2.0; p[4][1] = p[0][1]*2.0; p[4][2] = p[0][2]+0.1; p[4][3] = p[0][3]-1.0;

/*
       p[1][0] = p[0][0]-0.1; p[1][1] = p[0][1]+0.1; p[1][2] = p[0][2]+0.1; p[1][3] = p[0][3]+0.1;
       p[2][0] = p[0][0]+0.1; p[2][1] = p[0][1]-0.1; p[2][2] = p[0][2]+0.1; p[2][3] = p[0][3]+0.1;
       p[3][0] = p[0][0]+0.1; p[3][1] = p[0][1]+0.1; p[3][2] = p[0][2]-0.1; p[3][3] = p[0][3]+0.1;
       p[4][0] = p[0][0]+0.1; p[4][1] = p[0][1]+0.1; p[4][2] = p[0][2]+0.1; p[4][3] = p[0][3]-0.1;
*/
      for (i=0; i<(fitidx ? 5 : 4); i++) 
	y[i] = bestfit(par,object,psf,phdr,
		       1./p[i][0],1./p[i][1],p[i][2],p[i][3],NULL);
      result = neldermead(p,y,(fitidx ? 4 : 3),par->eftol,&simplex_funk2);

      chsq = bestfit(par,object,psf,phdr,
                     1./p[0][0],1./p[0][1],p[0][2],p[0][3],residuals);

      if ((chsq < chsq0) && (nit < 10))
        if (par->keeplog && par->logmode>2) 
           fputs("*** Found a better fit, doing another round.. ***\n",par->logfile);

    } while ((chsq < chsq0) && (nit<10));
    flux = par->flux;

    tmp = par->shape; 
    par->shape = DELTA;
    par->chsq0 = bestfit(par,object,psf,phdr,0.0,0.0,0,0.0,NULL);
    par->shape = tmp; 
  } else
    result = FALSE;

  /* End of AMOEBA stuff */

  if (chsq < 0 || (!result)) {
    if (par->keeplog && par->logmode>1) 
      fputs("\n  ** Error: Could not find a best fit\n",par->logfile);
    puts("  ** Error: Could not find a best fit\n");
    return -1.0;
  }

  if (par->verbose) puts("Done!");

  switch (par->shape) {
    case KINGx  : 
    case KINGt  :
    case EFFx   :
    case SERSICx:
    case MOFFATx: 
    case EFFCx10:
    case EFFCx15:
    case EFFCx25: (*index) = par->index; break;

    case KINGn  : /* (*index) =  exp(p[0][3]); break; */
    case EFFn   :
    case MOFFATn: /* (*index) =  1./p[0][3]; break; */
    case SERSICn: /* (*index) = p[0][3]; break; */
    case EFFCn10:
    case EFFCn15:
    case EFFCn25: (*index) = exp(p[0][3]); break;
  } 
/*  *index = 1./p[0][3]; */

  if (fabs(1./p[0][0]) > fabs(1./p[0][1])) {
    *major = 1./p[0][0];
    *ratio = p[0][0] / p[0][1];
    *pangle = p[0][2]*180/pi;
  } else {
    *major = 1./p[0][1];
    *ratio = p[0][1] / p[0][0];
    *pangle = 90 + p[0][2]*180/pi;
  }
  while ((*pangle) > 90.) (*pangle) -= 180.;
  while ((*pangle) < -90.) (*pangle) += 180.;

  printf("  Best fit (for SHAPE=%s and %i deg. of freedom): \n", 
    PSFNAME[par->shape], (int)(sqr(2*par->fitrad+1)-nfree(par)));

  if (par->shape == SERSICn || par->shape == SERSICx)
    printf("    FWHM, Major axis  = %0.2e\n",(*major));
  else
    printf("    FWHM, Major axis  = %0.2f\n",(*major));
  printf("    Minor/major       = %0.2f\n",(*ratio));
  printf("    Pos. angle        = %0.0f deg.\n",(*pangle));
  if (par->shape == KINGn || par->shape == MOFFATn ||
      par->shape == EFFn  || par->shape == EFFx ||
      par->shape == SERSICn || par->shape == SERSICx ||
      par->shape == KINGx || par->shape == MOFFATx ||
      par->shape == KINGt ||
      par->shape==EFFCn10 || par->shape==EFFCn15 || par->shape==EFFCn25 ||
      par->shape==EFFCx10 || par->shape==EFFCx15 || par->shape==EFFCx25)
    printf("    Index             = %0.2f\n",(*index));
  if (par->shape == KINGt) {
    cc = king_cc((*major), (*index), &c);
    printf("    Rt/Rc             = %0.2f\n",c);
  }
  printf("    Flux (ADU)        = %0.3e\n",par->flux);
  printf("    Background        = %0.3e\n",par->bkg);
  printf("    S/N               = %0.1f\n",par->flux/par->bknoise);
  printf("    Chi_sqr_nu        = %0.2f\n",chsq);
  printf("    Chi_sqr_nu (0)    = %0.2f\n",par->chsq0);
/*  printf("    Resolved (2 sig)  = %s\n",is_resolved(chsq,par->chsq0,2.0,par)?"YES":"NO"); */
  puts("  ------------------------------");

  if (par->keeplog && par->logmode>1) {
    fprintf(par->logfile,"  Best fit (for SHAPE=%s and %i deg. of freedom): \n", 
      PSFNAME[par->shape], (int)(sqr(2*par->fitrad+1)-nfree(par)));

    if (par->shape == SERSICn || par->shape == SERSICx)
      fprintf(par->logfile,"    FWHM, Major axis  = %0.2e\n",(*major));
    else
      fprintf(par->logfile,"    FWHM, Major axis  = %0.2f\n",(*major));
    fprintf(par->logfile,"    Minor/major       = %0.2f\n",(*ratio));
    fprintf(par->logfile,"    Pos. angle        = %0.0f deg.\n",(*pangle));
    if (par->shape == KINGn || par->shape == MOFFATn ||
        par->shape == EFFn  || par->shape == EFFx ||
        par->shape == SERSICn  || par->shape == SERSICx ||
        par->shape == KINGx || par->shape == MOFFATx ||
	par->shape == KINGt ||
        par->shape==EFFCn10 || par->shape==EFFCn15 || par->shape==EFFCn25 ||
        par->shape==EFFCx10 || par->shape==EFFCx15 || par->shape==EFFCx25)
      fprintf(par->logfile,"    Index             = %0.2f\n",(*index));
    if (par->shape == KINGt)
      fprintf(par->logfile,"    Rt/Rc             = %0.2f\n",c);
    fprintf(par->logfile,"    Flux (ADU)        = %0.3e\n",par->flux);
    fprintf(par->logfile,"    Background        = %0.3e\n",par->bkg);
    fprintf(par->logfile,"    S/N               = %0.1f\n",par->flux/par->bknoise);
    fprintf(par->logfile,"    Chi_sqr_nu        = %0.2f\n",chsq);
    fprintf(par->logfile,"    Chi_sqr_nu(0)     = %0.2f\n",par->chsq0);
    fputs("  ------------------------------\n",par->logfile);
  }

  return chsq;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static float bisect_fit(
  ishapestruct *par,
  float *object,
  float *psf,
  hstruct phdr,
  float  pfit[4],      /* Potential parameters to fit. */
  int    ifix[4],      /* Parameters to keep fixed     */
  float  pfmin,        /* Search for solution between pfmin and pfmax */
  float  pfmax,
  int    ipfref,       /* Which one to return in case no fit is found? */
                       /* 1=pfmin, 2=pfmax                             */
  int    ifit,         /* Which parameter to fit?      */
  float  chsqfit,      /* Target chi-square value      */
  int    nfit,
  int    correrr,      /* Account for correlated errors? (i.e. run AMOEBA */
                       /* again - takes much longer).                     */
  float  chsqbest      /* Chi-square of best fit       */
) {
  int   result,i,j;
  int   nit, nitmax;
  float pfit1[4], pfit2[4];
  float pfitm[4],pfitt[4];
  float chsq1, chsq2, chsqm;
  float p[MP][NP];
  float y[MP];

  nitmax = 25;

  for (i=0; i<4; i++) {
    pfit1[i] = pfit[i];
    pfit2[i] = pfit[i];
    pfitm[i] = pfit[i];
  }

  pfit1[ifit] = pfmin;
  pfit2[ifit] = pfmax;

  if (par->elliptical) {
    chsq1 = bestfit(par, object, psf, phdr, 
                    pfit1[0], pfit1[1], pfit1[2], pfit1[3], NULL) - chsqfit;
    chsq2 = bestfit(par, object, psf, phdr, 
                    pfit2[0], pfit2[1], pfit2[2], pfit2[3], NULL) - chsqfit;
  } else {
    chsq1 = bestfit(par, object, psf, phdr, 
                    pfit1[0], pfit1[0], pfit1[2], pfit1[3], NULL) - chsqfit;
    chsq2 = bestfit(par, object, psf, phdr, 
                    pfit2[0], pfit2[0], pfit2[2], pfit2[3], NULL) - chsqfit;
  }

  if (sgn(chsq1) == sgn(chsq2)) {
    return (ipfref == 1) ? pfmin : pfmax;
  } 

  nit = 0;
  do {
    pfitm[ifit] = (pfit1[ifit]+pfit2[ifit])/2;

    if (par->verbose) {
      printf("  BISECT: Parameters = %0.2f %0.2f %0.2f\n",
               pfit1[ifit],pfitm[ifit],pfit2[ifit]);
    }

    if (par->keeplog && par->logmode>2) {
      fprintf(par->logfile,"  BISECT: Parameters = %0.2f %0.2f %0.2f\n",
               pfit1[ifit],pfitm[ifit],pfit2[ifit]);
    }

    if (correrr) {

      /* AMOEBA stuff */
      /* Mostly identical to code in fitshape2d, except that we want to keep */
      /* one of the parameters fixed.                                        */

      p[0][0] = 1/par->fwhmmax;   p[0][1] = 1/par->fwhmmax;   p[0][2] = 0.0;   p[0][3] = pfit[3] - 0.2;
      p[1][0] = 1.5/par->fwhmmax; p[1][1] = 1.5/par->fwhmmax; p[1][2] = 0.0;   p[1][3] = pfit[3];
      p[2][0] = 1/par->fwhmmax;   p[2][1] = 1.5/par->fwhmmax; p[2][2] = pi/4;  p[2][3] = pfit[3] + 0.2;
      p[3][0] = 1/par->fwhmmax;   p[3][1] = 1.5/par->fwhmmax; p[3][2] = -pi/4; p[3][3] = pfit[3] - 0.2;
      p[4][0] = 1/par->fwhmmax;   p[4][1] = 1.5/par->fwhmmax; p[4][2] = -pi/4; p[4][3] = pfit[3] + 0.2;

      for (i=0; i<4; i++) S3_IFIX[i] = ifix[i];
      S3_IFIX[ifit] = 1;          /* Keep this fixed as well */
      S3_PFIX[0] = 1./pfitm[0];
      S3_PFIX[1] = (par->elliptical) ? 1./pfitm[1] : 1/pfitm[0];
      S3_PFIX[2] = pfitm[2];
      S3_PFIX[3] = pfitm[3];

      if (par->verbose) puts("** Initialising for AMOEBA ..");
      for (i=0; i<nfit+1; i++) {
        for (j=0; j<4; j++) {
          if (S3_IFIX[j])
            pfitt[j] = S3_PFIX[j];
          else
            pfitt[j] = p[i][j];
        }
        if (par->elliptical) {
          y[i] = bestfit(par,object,psf,phdr,
		       1./pfitt[0],1./pfitt[1],pfitt[2],pfitt[3],NULL); 
        } else {
          y[i] = bestfit(par,object,psf,phdr,
		       1./pfitt[0],1./pfitt[0],pfitt[2],pfitt[3],NULL); 
        }
/*	y[i] = bestfit(par,object,psf,phdr,
		       1./p[i][0],1./p[i][1],p[i][2],p[i][3],NULL); */
      }

      if (par->verbose) 
        printf("** Running AMOEBA with parameter %i=const (%0.2f)\n",
	          ifit,pfitm[ifit]);

      if (par->keeplog && par->logmode > 2)
        fprintf(par->logfile,
	        "** Running AMOEBA with parameter %i=const (%0.2f)\n",
	          ifit,pfitm[ifit]);

/*      result = amoeba(p,y,nfit,par->eftol,&simplex_funk3); */
      result = neldermead(p,y,nfit,par->eftol,&simplex_funk3); 
      chsqm = S3_CHSQ - chsqfit;

    } else {
      if (par->elliptical) {
        chsqm = bestfit(par, object, psf, phdr, 
                       pfitm[0], pfitm[1], pfitm[2], pfitm[3], NULL) - chsqfit;
      } else {
        chsqm = bestfit(par, object, psf, phdr, 
                       pfitm[0], pfitm[0], pfitm[2], pfitm[3], NULL) - chsqfit;
      }
    }

    if (par->verbose) 
      printf("  Chi-sqr-red = %0.4f %0.4f %0.4f\n",
              chsq1+chsqfit,chsqm+chsqfit,chsq2+chsqfit);
    if (par->keeplog && par->logmode > 2) {
      fprintf(par->logfile,"  Chi-sqr-red = %0.4f %0.4f %0.4f\n",
                       chsq1+chsqfit,chsqm+chsqfit,chsq2+chsqfit);
    }

    if (chsqm+chsqfit < chsqbest) {
      pfitm[ifit] = RANGE_ERR;
      if (par->verbose)
        printf("  Oops. Found a better fit than the best-fit value. Will return nan\n");
      if (par->keeplog && par->logmode > 2) {
        fprintf(par->logfile,"  Oops. Found a better fit than the best-fit value. Will return nan\n");
      }
    }

    if (sgn(chsqm) == sgn(chsq1)) {
      chsq1 = chsqm;
      pfit1[ifit] = pfitm[ifit];
    } else {
      chsq2 = chsqm;
      pfit2[ifit] = pfitm[ifit];
    }

  } while ((fabs(chsq1-chsq2) > 1E-3) && (++nit < nitmax) && (pfitm[ifit] != RANGE_ERR));

  if (pfitm[ifit] == RANGE_ERR)
    return nanf("");
  else
    return pfitm[ifit];
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void calcerr1d(
  ishapestruct *par, 
  float *object, 
  float *psf, 
  hstruct phdr, 
  float *residuals,
  float major, 
  float chsq_fit, 
  float *emajor
) {
  int i,n,ifit,nfit;
  float pa,minor,i1,chsq_1sig;
  float pfmax, pfmin;
  float chsq,chsq1,chsq2;
  float major_max, major_min;
  float pfit[4];
  int   ifix[4];

  n = sqr(2*par->fitrad+1);
  chsq_1sig = chsq_fit + 1./(n-nfree(par));
                                   /* Reduced chi_sqr at 1-sig error limits */
  nfit = 3;

  minor = major;
  pa = 0.0;
  i1 = par->index;

  pfit[0] = fabs(major);
  pfit[1] = fabs(minor);
  pfit[2] = 0;      /* PA */
  pfit[3] = i1;

  ifix[0] = ifix[1] = ifix[2] = ifix[3] = 1;

  chsq = bestfit(par, object, psf, phdr, major, minor, pa, i1, NULL);

  if (par->verbose) {
    printf("Reduced chi-sqr (best) = %0.5f\n",chsq_fit);
    printf("Reduced chi-sqr (1sig) = %0.5f\n",chsq_1sig);
  }

  if (par->keeplog && par->logmode > 2) {
    fprintf(par->logfile,"Reduced chi-sqr (best) = %0.5f\n",chsq_fit);
    fprintf(par->logfile,"Reduced chi-sqr (1sig) = %0.5f\n",chsq_1sig);
  }

  pfmax = fabs(major);
  if (pfmax < 0.5) pfmax = 0.5;

  i = 0;
  do {
    pfmax *= 2.0;
//    chsq2 = bestfit(par, object, psf, phdr, pfmax, fabs(minor), pa, i1, NULL);
    chsq2 = bestfit(par, object, psf, phdr, pfmax, pfmax, pa, i1, NULL);
  } while  ((chsq2 < chsq_1sig) && (++i < 3));

  ifit = 0;

  if (par->verbose) puts("Major axis, max");
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"Major axis, max\n");

  major_max = bisect_fit(par, object, psf, phdr, pfit, ifix, fabs(major), 
                         pfmax, 2, ifit, chsq_1sig, nfit, 0, chsq_fit);

  if (par->verbose) puts("Major axis, min");
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"Major axis, min\n");

  major_min = bisect_fit(par, object, psf, phdr, pfit, ifix, 1E-3, fabs(major), 
                         1, ifit, chsq_1sig, nfit, 0, chsq_fit);

  emajor[0] = major - major_min;
  emajor[1] = major_max - major;

  printf("  1-sigma confidence interval:\n");
  printf("    FWHM: Min= %0.3f Max= %0.3f\n", 
      major_min, major_max);
  printf("  ============================\n");

  if (par->keeplog && par->logmode > 1) {
    fprintf(par->logfile,"  1-sigma confidence interval:\n");
    fprintf(par->logfile,"    FWHM: Min= %0.3f Max= %0.3f\n", 
        major_min, major_max);
    fprintf(par->logfile,"  ============================\n");
  }

  return;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void calcerr2d(   /* Estimate errors on a 2-D fit */
  ishapestruct *par,
  float *object,
  float *psf,
  hstruct phdr,
  float *residuals,
  float major, 
  float ratio,
  float pangle,
  float index,
  float chsq_fit,        /* The chi square of the best fit */
  float *emajor,
  float *eratio,
  float *epangle,
  float *eindex
) {
  int   n,i,result;
  ishapestruct psave;
/*  float p0[4]; */
/*  float **xi0; */
  float p[MP][NP];
  float y[MP];
  float chsq1, chsq2, chsq, flux;
  float i1;
  float lowlim;
  int   fitidx = FALSE;
  int   nfit;
  int   tmp;
  float c, cc;

  float chsq_1sig;
  int   iest;
  float pa,minor, amajor, aminor;
  float major_max, major_min;
  float minor_max, minor_min;
  float pa_max, pa_min;
  float pfit[4];
  int   ifix[4];
  float ifit;
  float pfmin, pfmax, index_max, index_min;
  float ifit_max, ifit_min;

  n = sqr(2*par->fitrad+1);
  chsq_1sig = chsq_fit + 1./(n-nfree(par));
                                   /* Reduced chi_sqr at 1-sig error limits */

  /* Now calculate the error limits on each parameter. */

  nfit = 3;
  i1 = index;

  switch (par->shape) {
    case KINGn  : /* i1 = log(index); fitidx = TRUE; nfit = 4; break; */
    case EFFn:
    case MOFFATn: /* i1 = fabs(1./index); fitidx = TRUE; nfit = 4; break; */
    case SERSICn: /* i1 = fabs(index); fitidx = TRUE; nfit = 4; break; */
    case EFFCn10:
    case EFFCn15:
    case EFFCn25: i1 = log(index); fitidx = TRUE; nfit = 4; break;
  } 

  amajor = fabs(major);
  aminor = fabs(ratio * amajor);
  pa = pangle * pi / 180.;

  pfit[0] = amajor;
  pfit[1] = aminor;
  pfit[2] = pa;
  pfit[3] = i1;

  chsq = bestfit(par, object, psf, phdr, amajor, aminor, pa, i1, NULL);

  if (par->verbose) {
    printf("Reduced chi-sqr (best) = %0.5f\n",chsq_fit);
    printf("Reduced chi-sqr (1sig) = %0.5f\n",chsq_1sig);
  }

  if (par->keeplog && par->logmode > 2) {
    fprintf(par->logfile,"Reduced chi-sqr (best) = %0.5f\n",chsq_fit);
    fprintf(par->logfile,"Reduced chi-sqr (1sig) = %0.5f\n",chsq_1sig);
  }

  pfmax = amajor;
  if (pfmax < 0.5) pfmax = 0.5;

  i = 0;
  do {
    pfmax *= 2.0;
    chsq2 = bestfit(par, object, psf, phdr, pfmax, aminor, pa, i1, NULL);
  } while  ((chsq2 < chsq_1sig) && (++i < 3));

  ifit = 0;
  ifix[0] = 0; ifix[1] = 0; ifix[2] = 1; ifix[3] = 0;

  if (par->verbose) puts("Major axis, max");
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"Major axis, max\n");

  major_max = bisect_fit(par, object, psf, phdr, pfit, ifix, amajor, 
                         pfmax, 2, ifit, chsq_1sig, nfit, par->correrr, 
			 chsq_fit);

  if (par->verbose) printf("  Major axis upper bound = %0.2f\n", major_max);
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"  Major axis upper bound = %0.2f\n", major_max);


  if (par->verbose) puts("Major axis, min");
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"Major axis, min\n");

  lowlim=1e-3;
  if (par->shape == SERSICn || par->shape == SERSICx) lowlim=1e-10; 

  if (amajor > lowlim)  
    major_min = bisect_fit(par, object, psf, phdr, pfit, ifix, lowlim,
                           amajor, 1, ifit, chsq_1sig, nfit, par->correrr,
			   chsq_fit);
  else
    major_min = lowlim;

  if (par->verbose) printf("  Major axis lower bound = %0.2f\n", major_min);
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"  Major axis lower bound = %0.2f\n", major_min);

  ifit = 1;
  ifix[0] = 0; ifix[1] = 0; ifix[2] = 1; ifix[3] = 0;

  if (par->verbose) puts("Minor axis, max");
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"Minor axis, max\n");

  minor_max = bisect_fit(par, object, psf, phdr, pfit, ifix, aminor, 
                         pfmax, 2, ifit, chsq_1sig, nfit, par->correrr,
			 chsq_fit);

  if (par->verbose) printf("  Minor axis upper bound = %0.2f\n", minor_max);
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"  Minor axis upper bound = %0.2f\n", minor_max);

  if (par->verbose) puts("Minor axis, min");
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"Minor axis, min\n");

  if (aminor > lowlim)
    minor_min = bisect_fit(par, object, psf, phdr, pfit, ifix, lowlim,
                           aminor, 1, ifit, chsq_1sig, nfit, par->correrr,
                           chsq_fit);
  else
    minor_min = lowlim;

  if (par->verbose) printf("  Minor axis lower bound = %0.2f\n", minor_min);
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"  Minor axis lower bound = %0.2f\n", minor_min);

  ifit = 2;
  ifix[0] = 1; ifix[1] = 1; ifix[2] = 0; ifix[3] = 1;

  if (par->verbose) puts("PA, max");
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"PA, max\n");

  pa_max = bisect_fit(par, object, psf, phdr, pfit, ifix, pa, pa+pi/2, 2,
                      ifit, chsq_1sig, nfit, 0, chsq_fit);

  if (par->verbose) puts("PA, min");
  if (par->keeplog && par->logmode>2) 
    fprintf(par->logfile,"PA, min\n");

  pa_min = bisect_fit(par, object, psf, phdr, pfit, ifix, pa-pi/2, pa, 1,
			 ifit, chsq_1sig, nfit, 0, chsq_fit);

  if (nfit == 4) {
    pfmax = i1;
    pfmin = i1;

    do {
      pfmax += 1.0;
      chsq2 = bestfit(par, object, psf, phdr, amajor, aminor, pa, pfmax, NULL);
    } while  ((chsq2 < chsq_1sig) && (pfmax < i1+5));

    do {
      pfmin -= 1.0;
      chsq2 = bestfit(par, object, psf, phdr, amajor, aminor, pa, pfmin, NULL);
    } while  ((chsq2 < chsq_1sig) && (pfmin > i1-5));

    ifit = 3;
    ifix[0] = 0; ifix[1] = 0; ifix[2] = 1; ifix[3] = 0;

    if (par->verbose) puts("Index, max");
    if (par->keeplog && par->logmode>2) 
      fprintf(par->logfile,"Index, max\n");

    ifit_max = bisect_fit(par, object, psf, phdr, pfit, ifix, i1, pfmax, 2,
  			 ifit, chsq_1sig, nfit, par->correrr, chsq_fit);

    if (par->verbose) puts("Index, min");
    if (par->keeplog && par->logmode>2) 
      fprintf(par->logfile,"Index, min\n");

    ifit_min = bisect_fit(par, object, psf, phdr, pfit, ifix, pfmin, i1, 1,
			 ifit, chsq_1sig, nfit, par->correrr, chsq_fit);
  }

  emajor[0] = amajor - major_min;
  emajor[1] = major_max - amajor;
  epangle[0] = (pa - pa_min)*180/pi;
  epangle[1] = (pa_max - pa)*180/pi;

  eratio[0] = sqrt(  sqr( (1./amajor)*(aminor-minor_min) )
                   + sqr( (aminor/sqr(amajor)) * (major_max-amajor) ) );
  eratio[1] = sqrt(  sqr( (1./amajor)*(minor_max-aminor) )
                   + sqr( (aminor/sqr(amajor)) * (amajor-major_min) ) );
  if (eratio[0] > ratio) eratio[0] = ratio;

  printf("  1-sigma confidence intervals:\n");
  if (par->shape == SERSICn || par->shape == SERSICx) {
    printf("    FWHM, major axis: Min= %0.3e Max= %0.3e\n", 
        major_min, major_max);
    printf("    FWHM, minor axis: Min= %0.3e Max= %0.3e (fit= %0.3e )\n", 
        minor_min, minor_max, aminor);
  } else {
    printf("    FWHM, major axis: Min= %0.3f Max= %0.3f\n", 
        major_min, major_max);
    printf("    FWHM, minor axis: Min= %0.3f Max= %0.3f (fit= %0.3f )\n", 
        minor_min, minor_max, aminor);
  }

  printf("    Minor/Major     : Min= %0.3f Max= %0.3f (derived)\n",
      ratio-eratio[0], ratio+eratio[1]);
  printf("    PA              : Min= %0.1f Max= %0.1f\n", 
      pa_min*180/pi, pa_max*180/pi);

  if (par->keeplog && par->logmode > 1) {
    fprintf(par->logfile,"  1-sigma confidence intervals:\n");
    if (par->shape == SERSICn || par->shape == SERSICx) {
      fprintf(par->logfile,"    FWHM, major axis: Min= %0.3e Max= %0.3e\n", 
          major_min, major_max);
      fprintf(par->logfile,"    FWHM, minor axis: Min= %0.3e Max= %0.3e (fit= %0.3e )\n", 
          minor_min, minor_max, aminor);
    } else {
      fprintf(par->logfile,"    FWHM, major axis: Min= %0.3f Max= %0.3f\n", 
          major_min, major_max);
      fprintf(par->logfile,"    FWHM, minor axis: Min= %0.3f Max= %0.3f (fit= %0.3f )\n", 
          minor_min, minor_max, aminor);
    }
    fprintf(par->logfile,"    Minor/Major     : Min= %0.3f Max= %0.3f (derived)\n",
        ratio-eratio[0], ratio+eratio[1]);
    fprintf(par->logfile,"    PA              : Min= %0.1f Max= %0.1f\n", 
        pa_min*180/pi, pa_max*180/pi);
  }

  if (nfit==4) {
    switch (par->shape) {
      case EFFn:
      case MOFFATn: /* index_max = 1./ifit_min; 
                    index_min = 1./ifit_max; break; */

      case KINGn: /* index_max = exp(ifit_max);
                  index_min = exp(ifit_min); break; */

      case SERSICn: /* index_max = ifit_max;
                  index_min = ifit_min; break; */

      case EFFCn10:
      case EFFCn15:
      case EFFCn25: index_max = exp(ifit_max);
                   index_min = exp(ifit_min); break;
    }

    printf("    Index           : Min= %0.2f Max= %0.2f\n",index_min,index_max);
    if (par->keeplog && par->logmode > 1)
      fprintf(par->logfile,
        "    Index           : Min= %0.2f Max= %0.2f\n", index_min, index_max);

    eindex[0] = index - index_min;
    eindex[1] = index_max - index;

  }

  printf("  ==============================\n");
  if (par->keeplog && par->logmode > 1)
    fprintf(par->logfile,"  ==============================\n");

  return;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void writeres(
  ishapestruct *par,
  char  *srcname,
  float x,
  float y,
  char *psfname,
  float *residuals,
  float major,
  float ratio,
  float pangle,
  float index,
  float chsq,
  char  *resname       /* Will contain name of FITS file on return */
) {
  int r;
  hstruct hdr;
  char   tmps[255],s1[100],s2[100],s3[100];
  int n,xi,yi;

  r = par->fitrad;
  hdr.naxis1 = 2*(2*r+1);
  hdr.naxis2 = 2*(2*r+1);
  hdr.bscale = 1.0;
  hdr.bzero = 0.0;
  hdr.bitpix = -32;
  hdr.card = NULL;

#define ADDC addcard(&hdr,"COMMENT",tmps,H_COMM)

  sprintf(tmps,"Residual image from BAOLAB-%s/ISHAPE",VERSION);   ADDC;
  username(s1);
  datestr(s2); s2[strlen(s2)-1] = '\0';
  gethostname(s3,100);
  sprintf(tmps,"%s@%s",s1,s3);  ADDC;
  sprintf(tmps,"%s",s2);  ADDC;
  sprintf(tmps,"Log: %s", par->keeplog ? par->logname : "<none>"); ADDC;

  sprintf(tmps,"Input image = %s",srcname);               ADDC;
  sprintf(tmps,"Object position: x,y = %0.1f,%0.1f",x,y); ADDC;
  sprintf(tmps,"PSF = %s",psfname); ADDC;
  sprintf(tmps,"Diffusion kernel: %s", par->usedk ? par->dkname : "<none>") ; ADDC;
  sprintf(tmps,"Fitting radius = %d", par->fitrad); ADDC;
  sprintf(tmps,"CLEANRAD = %0.1f", par->cleanrad); ADDC;
  sprintf(tmps,"EPADU = %0.3f", par->epadu); ADDC; 
  sprintf(tmps,"RON = %0.3f", par->ron); ADDC; 
  sprintf(tmps,"FWHMTOL = %0.3f", par->fwhmtol); ADDC; 
  if (par->elliptical) {
    sprintf(tmps,"SHAPE = %s (elliptical)",PSFNAME[par->shape]); ADDC;
    if (par->shape == SERSICn || par->shape == SERSICx) 
      { sprintf(tmps,"Major axis  = %0.3e",major);    ADDC; }
    else
      { sprintf(tmps,"Major axis  = %0.2f",major);    ADDC; }
    sprintf(tmps,"Minor/major = %0.2f",ratio);    ADDC;
    sprintf(tmps,"Pangle = %0.1f deg.",pangle);    ADDC;
  } else {
    sprintf(tmps,"SHAPE model = %s (circular)",PSFNAME[par->shape]); ADDC;
    sprintf(tmps,"FWHM = %0.2f",major);    ADDC;
  }
  if (par->shape == KINGn || par->shape == MOFFATn ||
    par->shape == EFFn  || par->shape == EFFx ||
    par->shape == SERSICn  || par->shape == SERSICx ||
    par->shape == KINGx || par->shape == MOFFATx ||
    par->shape == KINGt ||
    par->shape==EFFCn10 || par->shape==EFFCn15 || par->shape==EFFCn25 ||
    par->shape==EFFCx10 || par->shape==EFFCx15 || par->shape==EFFCx25) {
      sprintf(tmps,"Index = %0.2f",index);    ADDC;
  }
  sprintf(tmps,"Flux (ADU) = %0.3e",par->flux); ADDC;
  sprintf(tmps,"Background = %0.3e",par->bkg); ADDC;
  sprintf(tmps,"S/N = %5.2f",par->flux/par->bknoise);  ADDC;
  sprintf(tmps,"CHI-SQR = %5.2f",chsq);  ADDC;
  sprintf(tmps,"CHI-SQR0 = %5.2f",par->chsq0);  ADDC;

  n = sqr(2*r+1);
  for (yi=0; yi<2*r+1; yi++)
    for (xi=0; xi<2*r+1; xi++)
      residuals[(2*r+1) + xi+yi*hdr.naxis1] = 
	n*1000*par->weights[xi+yi*(2*r+1)];

/*  buff = (short *)malloc(sizeof(short)*hdr.naxis1*hdr.naxis2);
  for (i=0; i<hdr.naxis1*hdr.naxis2; i++) buff[i] = (short)residuals[i];
  savefitsfile(&hdr,buff,16,par->resimage);*/

  if (strcmp(par->resimage,"DEFAULT") == 0) {
    if (par->comment[0] == '\0')
      sprintf(resname,"ishape-res.fits");
    else
      sprintf(resname,"ishape-res-%s.fits",par->comment);
  }
  else
    strcpy(resname, par->resimage);

/*  savefitsfile(&hdr,residuals,-32,par->resimage); */
  savefitsfile(&hdr,residuals,-32,resname); 

/*  free(buff); */
  freehdr(&hdr);
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

void replace(
  ishapestruct *par,
  char *imname,
  float *residuals
) {
  float *image;
  hstruct hdr;
  char s[255];
  int x,y,dx,dy,i,j;

  image = floatfitsimage(&hdr,imname,TRUE);
  dy = dx = 2*par->fitrad + 1;
  i = 0;
  for (y=par->fitsec[2]; y<par->fitsec[2]+dy; y++) {
    j = 0;
    for (x=par->fitsec[0]; x<par->fitsec[0]+dx; x++) {
      image[hdr.naxis1*y+x] = residuals[i+j];
      j++;
    }
    i += 2*dx;
  }
  
  sprintf(s,"ISHAPE removed object at [%i:%i,%i:%i]",
    par->fitsec[0], par->fitsec[1], par->fitsec[2], par->fitsec[3]);
  addcard(&hdr,"HISTORY",s,H_COMM);

  savefitsfile(&hdr,image,-32,imname);
  freehdr(&hdr);
  free(image);
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float *radprof(
  float *object,
  ishapestruct *par
) {
  int i,n,r,x,y;
  float rr;
  float *data;

  r = par->fitrad;
  n = sqr(2*r+1);
  i = 0;
  data = (float *)malloc(3*sizeof(float)*n);

  for (y=-r; y<=r; y++) 
    for (x=-r; x<=r; x++) {
      rr = sqrt(sqr(x-par->xcentre)+sqr(y-par->ycentre));
/*      fprintf(par->logfile,"%0.1f %0.1f\n",rr,object[i]); */
      data[i] = rr;
      data[i+n] = object[i];
      data[i+2*n] = i;
      i++;
    } 

  return data;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void sort_prof(
  float *prof,
  ishapestruct *par
) {
  int i,j,n,r,jmin;
  float tmpr,tmpv,tmpi;
  float rmin;

  r = par->fitrad;
  n = sqr(2*r+1);

  for (i=0; i<n; i++) {
    rmin = prof[i];
    jmin = i;
    for (j=i; j<n; j++) 
      if (prof[j] < prof[jmin]) {
        jmin = j;
	rmin = prof[jmin];
      }

    if (jmin != i) {
      tmpr = prof[i];       
      tmpv = prof[i+n];          
      tmpi = prof[i+2*n];

      prof[i] = prof[jmin]; 
      prof[i+n] = prof[jmin+n];  
      prof[i+2*n] = prof[jmin+2*n];

      prof[jmin] = tmpr;    
      prof[jmin+n] = tmpv;
      prof[jmin+2*n] = tmpi;
    }
  }
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void mfilter_prof(
  float *prof,
  ishapestruct *par
) {
  int i,j,r,n;
  float *marr;
  float *tmparr;
  float tot,var,stdev,dev;

  r = par->fitrad;
  n = sqr(2*r+1);
  marr = (float *)malloc(sizeof(float)*n);
  tmparr = (float *)malloc(sizeof(float)*9);

  for (i=0; i<n; i++) {
    marr[i] = 0;
    par->weights[i] = 1.0;
  }

  for (i=4; i<n-4; i++) {
    for (j=0; j<9; j++) tmparr[j] = prof[i+n+j-4];
    marr[i] = prof[i+n] - fmedian(tmparr,9);
  }

  for (i=4; i<n-4; i++) {
    var = 0;
    for (j=-4; j<=4; j++) var += sqr(marr[i+j])/9.0;
    stdev = sqrt(var);

    dev = fabs(marr[i]/stdev);

    if (prof[i] < par->cleanrad)    /* Do not reject pixels within cleanrad */
      par->weights[(int)prof[i+2*n]] = 1.0;
    else {
      if (dev < 1)
	par->weights[(int)prof[i+2*n]] = 1.0;
      else if (dev > par->ctresh)
	par->weights[(int)prof[i+2*n]] = 0.0;
      else
	par->weights[(int)prof[i+2*n]] = 1.0/sqr(dev);
    }
  }

  tot = 0.0;
  for (i=0; i<n; i++) tot += par->weights[i];
  for (i=0; i<n; i++) par->weights[i] /= tot;

  free(tmparr);
  free(marr);
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void calc_weights(
  float *object,
  ishapestruct *par
) {
  float *weights;
  float *prof;
  int   r;

  r = par->fitrad;
  weights = (float *)malloc(sizeof(float)*sqr(2*r+1));

  prof = radprof(object,par);
  sort_prof(prof,par);
  mfilter_prof(prof,par);

  free(prof);
  free(weights);
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static float *reduce_psf(
  float *psf,
  hstruct *phdr,
  int  pdimopt
) {
  float *pnew;
  int i, x, y;
  int x0, y0;
  int p0i;

  pnew = (float *)malloc(sizeof(float)*pdimopt*pdimopt);

  i = 0;
  for (y=0; y<pdimopt; y++) {
    x0 = (phdr->naxis1-pdimopt)/2;
    y0 = (phdr->naxis2-pdimopt)/2 + y;
    p0i = x0 + y0*phdr->naxis1;
    for (x=0; x<pdimopt; x++) {
      pnew[i] = psf[p0i];
      i++;
      p0i++;
    }
  }

  phdr->naxis1 = pdimopt;
  phdr->naxis2 = pdimopt;
  return pnew;
}


/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void do_ishape(
  char *imname,        /* Image name - ignore if image_arr is != NULL       */
  float x,
  float y,
  char *psfname,
  ishapestruct *par,
  float *image_arr,    /* Array with image data - if NULL, read from imname */
  hstruct *hdr_in
) {
  float *image, *psf, *ptmp;
  float *object;
  hstruct hdr, phdr, dhdr;
  float *residuals;
  float major,ratio,pangle,chsq,index;
  float emajor[2], eratio[2], epangle[2], eindex[2];
  float cc,c;
  int   pdimopt;
  char  sformat[255], resname[255];

  /* Read diffusion kernel, if necessary */

  if (par->usedk) {
    par->diffkernel = floatfitsimage(&dhdr,par->dkname,FALSE);
    if (par->diffkernel == NULL) {
      puts("  ** Error reading diffusion kernel.");
      return;
    } else {
      if (dhdr.naxis1 == dhdr.naxis2) {
        par->dimdk = dhdr.naxis1;
	freehdr(&dhdr);
      } else {
        puts("  ** Error: diffusion kernel must be quadratic.");
        free(par->diffkernel);
	return;
      }
    }
  }

  /* Read the image itself */

  if (image_arr == NULL) {
    image = floatfitsimage(&hdr,imname,FALSE);
    if (image == NULL) {
      puts(IM_READ_ERR);
      if (par->usedk) free(par->diffkernel);
      return;
    }
  } else {
    image = image_arr;
    hdr = *hdr_in;
  }

  /* Check if the object is too close to the edge */

  if (x<=par->fitrad+par->centerrad+1 || 
      x>=hdr.naxis1-par->fitrad-par->centerrad-1 ||
      y<=par->fitrad+par->centerrad+1 || 
      y>=hdr.naxis2-par->fitrad-par->centerrad-1) {
    puts("  ** Error: Object too close to edge of image.");
    if (par->keeplog && par->logmode>1)
      fputs("  ** Error: Object too close to edge of image.\n",
	  par->logfile);

    if (image_arr == NULL) free(image); 
    if (par->usedk) free(par->diffkernel);
    return;
  }

  /* Extract the object from the image */

  object = getobj(image,x,y,hdr,par); /* If successful (return value != NULL) */
                                      /* getobj also allocates par->weights */
  if (image_arr == NULL) free(image);

  if (object == NULL) {
    if (par->keeplog) {
      if (par->logmode > 1)
        fprintf(par->logfile,"@# <image> <x> <y> <psf> <SHAPE> <FWHM> <RATIO> <PA> <CHISQR> <CHISQR0> <FLUX> <S/N>\n");
      if (par->logmode > 0)
        fprintf(par->logfile,"@@F %s %4.0f %4.0f %s %s OBJ-ERROR - - - - - - %s\n",
	     imname,x,y,psfname,PSFNAME[par->shape],par->comment);
    }
    if (par->usedk) free(par->diffkernel);
    return;
  }

  /* Read the PSF */

  psf = floatfitsimage(&phdr,psfname,FALSE);
  if (psf == NULL) {
    puts("  ** Error reading PSF image.");
    free(object);
    free(par->weights); 
    if (par->usedk) free(par->diffkernel);
    return;
  }

  /* Allocate an array to hold the residuals */

  residuals = (float *)malloc(4*sizeof(float)*sqr(2*par->fitrad+1));
  calc_weights(object,par); 

  /* Check PSF dimensions */

  if (phdr.naxis1/10 < 2*par->fitrad+1) {
    puts("  ** Warning: PSF radius smaller than fitting radius.");
    if (par->keeplog) 
      fprintf(par->logfile,
        "  ** Warning: PSF radius smaller than fitting radius.\n");
  }

  pdimopt = 2;
  while (pdimopt/10 < 2*par->fitrad+2) pdimopt *= 2;
  if (phdr.naxis1 > pdimopt) {
/*    printf("  ** Warning: PSF size = %d pixels, optimal < %d pixels (fitrad=%d)\n",phdr.naxis1,pdimopt,par->fitrad);
    printf("  ** Warning: Large PSF will increase computation time.\n");
    printf("  ** Warning: Reducing PSF to %d x %d pixels.\n",pdimopt,pdimopt); */
    ptmp = reduce_psf(psf,&phdr,pdimopt);
    free(psf);
    psf = ptmp;
  }

  /* Then, do the actual fitting -- either 1-D or 2-D */

  if (par->elliptical) {
    chsq = fitshape2d(par,object,psf,phdr,residuals,
                      &major,&ratio,&pangle,&index);
    if (par->calcerr && chsq > 0) {
      if (par->verbose) puts("Now estimating errors..");
      calcerr2d(par, object, psf, phdr, residuals,
               major, ratio, pangle, index, chsq,
	       emajor, eratio, epangle, eindex);
    }
  } else {
    chsq = fitshape1d(par,object,psf,phdr,residuals,&major);
    index = par->index;
    ratio = 1.0;
    pangle = 0.0;
    eratio[0] = eratio[1] = 0.0;
    epangle[0] = epangle[1] = 0.0;

    if (par->calcerr) {
      if (par->verbose) puts("Now estimating errors..");
      calcerr1d(par, object, psf, phdr, residuals,
               major, chsq, emajor);
    }
  }

  /* Write out the results */

  if (chsq > 0) {

    writeres(par,imname,x,y,psfname, 
             residuals,major,ratio,pangle,index,chsq,resname);
    if (par->verbose) printf("  Residuals saved to %s\n",resname);
    if (par->keeplog) {
      if (par->logmode > 1)
        fprintf(par->logfile,"@#F <image> <x> <y> <psf> <SHAPE> <FWHM> <RATIO> <PA> <CHISQR> <CHISQR0> <FLUX> <S/N> [INDEX] \n");
      if (par->logmode > 0) {
	if (par->shape == SERSICn || par->shape == SERSICx)
	  strcpy(sformat,"@@F %s %4.0f %4.0f %s %s %0.2e %0.2f %5.1f %0.2f %0.2f %0.1e %0.1f");
	else
	  strcpy(sformat,"@@F %s %4.0f %4.0f %s %s %0.2f %0.2f %5.1f %0.2f %0.2f %0.1e %0.1f");

        fprintf(par->logfile,sformat,
                         imname,x,y,psfname,PSFNAME[par->shape],
			 fabs(major),fabs(ratio),pangle,chsq,par->chsq0,par->flux,
			 par->flux/par->bknoise);
        if (par->shape == KINGn || par->shape == MOFFATn ||
	    par->shape == EFFn  || par->shape == EFFx ||
	    par->shape == SERSICn  || par->shape == SERSICx ||
            par->shape == KINGx || par->shape == MOFFATx ||
            par->shape==EFFCn10 || par->shape==EFFCn15 || par->shape==EFFCn25 || 
            par->shape==EFFCx10 || par->shape==EFFCx15 || par->shape==EFFCx25 || 
	    par->shape == KINGt)
          fprintf(par->logfile," %0.2f",index);
        if (par->shape == KINGt) {
	  cc = king_cc(major, index, &c);
	  fprintf(par->logfile," ( %0.2f )",c);
        }

        fprintf(par->logfile," %s\n",par->comment);

	if (par->calcerr) {
	  if (par->logmode > 1)
	    fprintf(par->logfile,"@#E <+/-FWHM> <+/-RATIO> <+/-PA> [+/-INDEX]\n");
	}
      }
      if (par->logmode > 0 && par->calcerr) {
	if (par->shape == SERSICn || par->shape == SERSICx)
	  strcpy(sformat,"@@E %0.3e %0.3e  %0.3f %0.3f  %0.1f %0.1f");
	else
	  strcpy(sformat,"@@E %0.3f %0.3f  %0.3f %0.3f  %0.1f %0.1f");

        fprintf(par->logfile,sformat,
            emajor[1], -emajor[0], 
	    eratio[1], -eratio[0], 
	    epangle[1], -epangle[0]);
        if (par->shape == KINGn || par->shape==MOFFATn || par->shape==EFFn ||
	    par->shape == SERSICn ||
            par->shape==EFFCn10 || par->shape==EFFCn15 || par->shape==EFFCn25 ||
            par->shape==EFFCx10 || par->shape==EFFCx15 || par->shape==EFFCx25)
	  fprintf(par->logfile,"  %0.3f %0.3f",
	      eindex[1],-eindex[0]);
        fprintf(par->logfile," %s\n",par->comment);
      }

      fprintf(par->logfile,"  Residuals saved to %s\n",resname);
    }
    if (par->replace) replace(par,imname,residuals);
  } else {
    if (par->keeplog) {
      if (par->logmode > 1)
        fprintf(par->logfile,"@# <image> <x> <y> <psf> <SHAPE> <FWHM> <RATIO> <PA> <CHISQR> <CHISQR0> <FLUX> <S/N>\n");
      if (par->logmode > 0)
        fprintf(par->logfile,"@@F %s %4.0f %4.0f %s %s FIT-ERROR - - - - - - %s\n",
	     imname,x,y,psfname,PSFNAME[par->shape],par->comment);
    }
  }

  free(psf);
  free(residuals);
  free(object);
  free(par->weights);
  if (par->usedk) free(par->diffkernel);
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static int check_setup(
  /* Perform some consistency check on parameter settings */
  ishapestruct *par
) {
  int result = TRUE;

  if (par->elliptical == NO) {
    if (par->shape == KINGn || par->shape == MOFFATn || par->shape == EFFn ||
        par->shape == SERSICn ||
	par->shape == EFFCn10 || par->shape == EFFCn15 || par->shape == EFFCn25
	) {
      puts(" ** Error: KINGn, SERSICn, MOFFATn/EFFn and EFFCn models are");
      puts("    not supported for circular fits.");
      result = FALSE;
    }
  }

  return result;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

void ishape(char *params) {

  static char imname[255] = "", psfname[255] = "", tmps[255];
  static char cooname[255] = "";
  static float x=0,y=0;
  FILE   *coofile;
  ishapestruct par;
  char  *ch, s1[255],s2[255];
  int   multi = 0;
  float *image_arr;
  hstruct hdr_in;

  /* Input data:
   *  - An image
   *  - Approximate (x,y) coordinates of the object within the image
   *  - The PSF, in the usual (mkpsf, mksynth) sub-sampled format
   * Output:
   *  - A small section of the image, surrounding the object, with the
   *    best fitting model subtracted
   *  - The best fit parameters (fwhm, chi_sqr, etc...)
   */

   strcpy(par.resimage,"/dev/null");
   par.fitrad = 10;               /* Radius of region to be fitted */
   par.centerrad = 5.0;           /* Centering radius (=tolerance) */
   par.maxciter = 10;             /* Maximum number of centering iterations */
   par.centermethod = FITMAX;     /* Method used for finding centre */
   par.cleanrad = 5.0;        /* Do NOT clean the profile inside this radius */
   par.ctresh = 2.0;          /* Has no meaning yet */
   par.elliptical = NO;           /* Fit an elliptical profile ? */
   par.keeplog = NO;              /* Write to logfile? */
   par.logmode = 3;               /* Log everything    */
   par.verbose = YES;
   par.calcerr = NO;              /* Calculate errors? Default=NO for      */
                                  /*   compatibility with older versions.  */
   par.correrr = NO;              /* Account for correlated errors (YES)   */
                                  /* or keep other parameters fixed when   */
				  /* calculating the errors on a given     */
				  /* quantity (NO)                         */
   par.replace = NO;              /* Remove the object from the image?      */
   par.epadu = 1.5;               /* e-/ADU conversion factor (for chi_sqr) */
   par.ron = 7;                   /* Read-out noise in e- */
   par.shape = HUBBLE;            /* Model to use for intrinsic profile */
   par.index = 5.0;               /* Initial guess for KINGn / MOFFATn index */
/*   par.ampltol = 1.0e-5;  Accuracy with which to determine ampl - OBSOLETE */
   par.ftol = 1.0e-8;             /* FTOL for amoeba when finding position */
   par.eftol = 1.0e-3;            /* FTOL for amoeba when finding profile */
   par.nonneg = TRUE;             /* Force non-negative amplitude of model */
   par.fwhmtol = 0.25;            /* FWHM tolerance when elliptical=NO    */
   par.fwhmmax = 5.0;                /* Estimated max. FWHM               */
   par.usedk = FALSE;                /* Use diffusion kernel?             */
   par.diffkernel = NULL;
   par.dimdk = 0;                    /* Size of diffusion kernel          */
   strcpy(par.logname,"ishape.log"); /* Name of logfile.                  */
   strcpy(par.comment,"");           /* Optional comment.                  */

   if (getpar("ISHAPE.FITRAD",tmps)) par.fitrad = atoi(tmps);
   if (getpar("ISHAPE.CENTERRAD",tmps)) par.centerrad = atof(tmps);
   if (getpar("ISHAPE.MAXCITER",tmps)) par.maxciter = atoi(tmps);
   if (getpar("ISHAPE.CENTERMETHOD",tmps)) {
     if (strstr(tmps,"MAX") == tmps) par.centermethod = FITMAX; else
     if (strstr(tmps,"POLY") == tmps) par.centermethod = FITPOLY; else
     if (strstr(tmps,"NONE") == tmps) par.centermethod = FITNONE; else
     if (strstr(tmps,"RPOLY") == tmps) par.centermethod = FITRPOLY; else {
       printf("  Invalid parameter: ISHAPE.CENTERMETHOD = %s. Using MAX.\n",tmps);
       par.centermethod = FITMAX;
     }
   }

   if (getpar("ISHAPE.SHAPE",tmps)) {
     if (strstr(tmps,"GAUSS") != NULL) par.shape = GAUSS; else
     if (strstr(tmps,"GAUSS2") != NULL) par.shape = GAUSS2; else
     if (strstr(tmps,"MOFFAT15") != NULL) par.shape = MOFFAT15; else
     if (strstr(tmps,"MOFFAT25") != NULL) par.shape = MOFFAT25; else
     if (strstr(tmps,"LUGGER") != NULL) par.shape = LUGGER; else
     if (strstr(tmps,"LORENZ") != NULL) par.shape = LORENZ; else
     if (strstr(tmps,"HUBBLE") != NULL) par.shape = HUBBLE; else
     if (strstr(tmps,"KING5") != NULL) par.shape = KING5; else
     if (strstr(tmps,"KING15") != NULL) par.shape = KING15; else
     if (strstr(tmps,"KING30") != NULL) par.shape = KING30; else
     if (strstr(tmps,"KING100") != NULL) par.shape = KING100; else
     if (strstr(tmps,"KINGn") != NULL) par.shape = KINGn; else
     if (strstr(tmps,"KINGx") != NULL) par.shape = KINGx; else
     if (strstr(tmps,"KINGt") != NULL) par.shape = KINGt; else
     if (strstr(tmps,"MOFFATn") != NULL) par.shape = MOFFATn; else
     if (strstr(tmps,"MOFFATx") != NULL) par.shape = MOFFATx; else
     if (strstr(tmps,"EXPN") != NULL) par.shape = EXPN; else
     if (strstr(tmps,"EFF10") != NULL) par.shape = EFF10; else
     if (strstr(tmps,"EFF15") != NULL) par.shape = EFF15; else
     if (strstr(tmps,"EFF25") != NULL) par.shape = EFF25; else
     if (strstr(tmps,"EFFCn10") != NULL) par.shape = EFFCn10; else
     if (strstr(tmps,"EFFCn15") != NULL) par.shape = EFFCn15; else
     if (strstr(tmps,"EFFCn25") != NULL) par.shape = EFFCn25; else
     if (strstr(tmps,"EFFCx10") != NULL) par.shape = EFFCx10; else
     if (strstr(tmps,"EFFCx15") != NULL) par.shape = EFFCx15; else
     if (strstr(tmps,"EFFCx25") != NULL) par.shape = EFFCx25; else
     if (strstr(tmps,"EFFn") != NULL) par.shape = EFFn; else
     if (strstr(tmps,"EFFx") != NULL) par.shape = EFFx; else
     if (strstr(tmps,"SERSICx") != NULL) par.shape = SERSICx; else
     if (strstr(tmps,"SERSICn") != NULL) par.shape = SERSICn; else
     if (strstr(tmps,"USER") != NULL) par.shape = USER; else
     if (strstr(tmps,"DELTA") != NULL) par.shape = DELTA; else {
       printf("  ** Error: Unsupported OBJECT type '%s'\n",tmps);
       return;
     }
   }

   if (getpar("ISHAPE.INDEX",tmps)) par.index = atof(tmps);
   if (getpar("ISHAPE.CTRESH",tmps)) par.ctresh = atof(tmps);
   if (getpar("ISHAPE.CLEANRAD",tmps)) par.cleanrad = atof(tmps);

   if (getpar("ISHAPE.EPADU",tmps)) par.epadu = atof(tmps);
   if (getpar("ISHAPE.RON",tmps)) par.ron = atof(tmps);
/*   if (getpar("ISHAPE.AMPLTOL",tmps)) par.ampltol = atof(tmps); */
   if (getpar("ISHAPE.FTOL",tmps)) par.ftol = atof(tmps);
   if (getpar("ISHAPE.ITMAX",tmps)) ITMAX = atof(tmps);
   if (getpar("ISHAPE.EFTOL",tmps)) par.eftol = atof(tmps);
   if (getpar("ISHAPE.NONNEG",tmps)) par.nonneg = (strstr(tmps,"YES") != NULL);
   if (getpar("ISHAPE.FWHMMAX",tmps)) par.fwhmmax = atof(tmps);
   if (getpar("ISHAPE.FWHMTOL",tmps)) par.fwhmtol = atof(tmps);
   if (getpar("ISHAPE.RESIMAGE",tmps)) strcpy(par.resimage,tmps);
   if (getpar("ISHAPE.REPLACE",tmps)) 
      par.replace = (strstr(tmps,"YES") != NULL);
   if (getpar("ISHAPE.ELLIPTICAL",tmps)) 
      par.elliptical = (strstr(tmps,"YES") != NULL);
   if (getpar("ISHAPE.USEDK",tmps)) par.usedk = (strstr(tmps,"YES") != NULL);
   if (getpar("ISHAPE.DKERNEL",tmps)) strcpy(par.dkname,tmps); 
   if (getpar("ISHAPE.KEEPLOG",tmps)) 
      par.keeplog = (strstr(tmps,"YES") != NULL);
   if (getpar("ISHAPE.VERBOSE",tmps)) 
      par.verbose = (strstr(tmps,"YES") != NULL);
   if (getpar("ISHAPE.LOGFILE",tmps)) strcpy(par.logname,tmps);
   if (getpar("ISHAPE.LOGMODE",tmps)) par.logmode = atoi(tmps);
   if (getpar("ISHAPE.CALCERR",tmps)) 
      par.calcerr = (strstr(tmps,"YES") != NULL);
   if (getpar("ISHAPE.CORRERR",tmps)) 
      par.correrr = (strstr(tmps,"YES") != NULL);
   if (getpar("ISHAPE.COMMENT",tmps)) strcpy(par.comment,tmps);

   if (nargs(params) == 4) {
     argn(params,1,imname);
     argn(params,2,tmps); x = atof(tmps);
     argn(params,3,tmps); y = atof(tmps); 
     argn(params,4,psfname);
   } else if (nargs(params) == 3) {
     argn(params,1,imname);
     argn(params,2,cooname); 
     multi = 1;
     argn(params,3,psfname);
   } else {
     printf("  Input image    : "); cscanf("%s",imname);
     printf("  X coordinate   : "); cscanf("%0.1f",&x);
     printf("  Y coordinate   : "); cscanf("%0.1f",&y); 
     printf("  PSF file       : "); cscanf("%s",psfname);
   }

   if (!check_setup(&par)) return;

   if (par.keeplog) {
     par.logfile = fopen(par.logname,"a");
     if (par.logmode > 1) {
       fprintf(par.logfile,"\nLog file for BAOLAB %s/ISHAPE\n",VERSION);
       username(s1);
       datestr(s2);
       gethostname(tmps,255);
       fprintf(par.logfile,"%s@%s %s\n\n",s1,tmps,s2);    
       fprintf(par.logfile,"User input: \n");
       fprintf(par.logfile,"  Input image = %s\n",imname);
       if (multi)
         fprintf(par.logfile,"  Coordinates = %s\n",cooname);
       else
         fprintf(par.logfile,"  Coordinates = %0.1f,%0.1f\n",x,y);
       fprintf(par.logfile,"  PSF file    = %s\n\n",psfname);
       write_pars(&par);
     }
   }

   if (multi) {
     coofile = fopen(cooname,"r");
     if (coofile != NULL) {
       image_arr = floatfitsimage(&hdr_in,imname,FALSE);
       if (image_arr == NULL) {
         puts(IM_READ_ERR);
       } else {
         while ((ch = fgets(tmps,100,coofile)) != NULL) {
           argn(tmps,1,s1); x = atof(s1);
           argn(tmps,2,s1); y = atof(s1);
           argn(tmps,3,par.comment);
           do_ishape(imname,x,y,psfname,&par,image_arr,&hdr_in);
         }
	 free(image_arr);
       }
       fclose(coofile);
     } else {
       printf("  ** Error opening coordinate file.\n");
       if (par.keeplog) 
         fprintf(par.logfile,"  ** Error opening coordinate file.\n");
     }
   } else {
     do_ishape(imname,x,y,psfname,&par,NULL,NULL);
   }

   if (par.keeplog) fclose(par.logfile);
}
