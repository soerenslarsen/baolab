#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"
#include "utils.h"

#define max(A,B) ((A)>(B)?(A):(B))

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float *makepsf(
  cosmicstruct *cpar
) {
  float *psf;
  hstruct phdr;
  int x, y, dx, dy, i;
  float dsq,p, fwsq;

  psf = NULL;

  if (cpar->psftype == USER) {
    psf = floatfitsimage(&phdr, cpar->psfname, 0);
    if (psf != NULL) {
      cpar->psfdim = phdr.naxis1;
      if (phdr.naxis1 != phdr.naxis2) {
        puts(" ** Error: NAXIS1 != NAXIS2");
	free(psf);
	psf = NULL;
      }
    }
  } else {
    psf = (float *)malloc(sizeof(float)*sqr(cpar->psfdim));
    dy = dx = cpar->psfdim / 2;
    fwsq = sqr(cpar->fwhm);

    for (i=0, y=-dy; y<=dy; y++)
      for (x=-dx; x<=dx; x++) {
        dsq = sqr(x) + sqr(y);

        switch (cpar->psftype) {
	  case GAUSS    : p = exp(-2.77*dsq/fwsq); break;
	  case MOFFAT15 : p = 1.0/pow(1.0 + 2.37*dsq/fwsq, 1.5); break;
	  case MOFFAT25 : p = 1.0/pow(1.0 + 1.30*dsq/fwsq, 2.5); break;
	}

	psf[i++] = p;
      }
  }

  puts(" PSF:");
  for (i=0,y=0; y<cpar->psfdim; y++) {
    for (x=0; x<cpar->psfdim; x++) printf("%5.2f ",psf[i++]);
    puts("");
  }

  return psf;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static float bkgr(
  int x, 
  int y, 
  float annulus, 
  float dannulus,
  hstruct *hdr,
  float *img
) {
  float f[1000];
  int   n, r, dx, dy;
  int   j0;
  float r1sq,r2sq, dsq;

  n = 0;
  r1sq = sqr(annulus);
  r2sq = sqr(annulus+dannulus);
  r = (annulus+dannulus+1);

  for (dy = -r; dy<=r; dy++) {
    j0 = hdr->naxis1*(y+dy);
    for (dx = -r; dx<=r; dx++) {
      dsq = sqr(dx) + sqr(dy);
      if ((dsq >= r1sq) && (dsq <= r2sq)) {
        f[n++] = img[j0 + x + dx];
      }
    }
  }

  fsort(f, n);
  return f[n/2];
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void replace(
  float *img, 
  hstruct *hdr,
  int    x, 
  int    y, 
  float  rgrow, 
  float bk
) {
  int x1, y1, r; 
  float dsq, rsq;

  r = (int)(rgrow+1);
  rsq = sqr(rgrow+0.01);

  for (y1 = y-r; y1<=y+r; y1++)
    for (x1 = x-r; x1<=x+r; x1++) {
      dsq = sqr(x-x1) + sqr(y-y1);
      if (dsq < rsq) img[y1*hdr->naxis1 + x1] = bk;
    }
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

float *do_cosm(
  float *img,
  hstruct *hdr,
  float *psf,
  cosmicstruct *cpar
) {
  int   dx, dy, x, y, i, d, np, j0, j1, k;
  int   pdx, pdy, xp, yp;
  int   del, it;
  int   n1,n2;
  float bk,maxp;
  float *img2, *img3;
  float p, p1, p2, noise, bknoise;
  
  dx = hdr->naxis1;
  dy = hdr->naxis2;
  pdx = cpar->psfdim;
  pdy = cpar->psfdim;
  np = pdx*pdy;

  maxp = 0.0;
  for (i=0; i<np; i++) if (psf[i] > maxp) maxp = psf[i];
  for (i=0; i<np; i++) psf[i] /= maxp;

  img2 = (float *)malloc(sizeof(float)*dx*dy);
  img3 = (float *)malloc(sizeof(float)*dx*dy);

  for (i=0; i<dx*dy; i++) img3[i] = img[i];

  d = (int)(cpar->annulus + cpar->dannulus+1);

  for (it=0; it<cpar->niter; it++) {

    printf("  Iteration = %i\n",it+1);
    printf("  <==================================================>");
    fflush(stdout);
    putchar(CTRL_M); printf("  <");

    for (i=0; i<dx*dy; i++) img2[i] = img3[i];

    n1 = 0;

    for (y=d; y<dy-d; y++) {
      for (x=d; x<dx-d; x++) {
	i = hdr->naxis1 * y + x;
	bk = bkgr(x, y, cpar->annulus, cpar->dannulus, hdr, img3);
	p = img3[i] - bk;

        bknoise = sqrt(max(bk*cpar->epadu,0) + sqr(cpar->ron));  
                                                /* Noise in e- */
        bknoise /= cpar->epadu;                 /* Noise in ADU */

        /* Do not change pixels < thresh above bkg */
	if (p > cpar->thresh*bknoise) {  
	  del = FALSE;
	  k = 0;

	  for (yp=-(pdy-1)/2; yp<=(pdy-1)/2; yp++) {
	    j0 = i + yp*hdr->naxis1;
	    for (xp=-(pdx-1)/2; xp<=(pdx-1)/2; xp++) {
	      j1 = j0 + xp;
	      if (j1 != i) {
	        noise = sqrt(max(img3[j1]*cpar->epadu,0) + sqr(cpar->ron));  
	                                                /* Noise in e- */
	        noise /= cpar->epadu;                   /* Noise in ADU */
                p2 = psf[k]*p;
                if (p2 > cpar->sigma*noise) {      
                  p1 = img3[j1] - bk;
                  if (p1 < p2-cpar->sigma*noise) del=TRUE;
		}
	      }
	      k++;
	    }
	  }

	  if (del) replace(img2, hdr, x, y, cpar->rgrow, bk);
	}
      }
      n2 = (int)(50.0*(y-d)/(dy-2.0*d)+0.5);
      while (n1 < n2) {
        putc('*',stdout); fflush(stdout); n1++;
      }
    }
    puts("");

    for (i=0; i<dx*dy; i++) img3[i] = img2[i];
  }

  free(img3);

  return img2;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

void cosmic(char *params) {

  static char imname[255] = "", outname[255] = "";
  char tmps[255];
  float *img, *img2, *psf;
  hstruct hdr;
  cosmicstruct cpar;

  if (nargs(params) == 2) {
    argn(params,1,imname);
    argn(params,2,outname);
  } else {
    printf("  Input  image   : "); cscanf("%s",imname);
    printf("  Output image   : "); cscanf("%s",outname);
  }

  if (getpar("COSMIC.ANNULUS",tmps)) cpar.annulus = atof(tmps);
  if (getpar("COSMIC.DANNULUS",tmps)) cpar.dannulus = atof(tmps);
  if (getpar("COSMIC.THRESHOLD",tmps)) cpar.thresh = atof(tmps);
  if (getpar("COSMIC.RON",tmps)) cpar.ron = atof(tmps);
  if (getpar("COSMIC.EPADU",tmps)) cpar.epadu = atof(tmps);
  if (getpar("COSMIC.SIGMA",tmps)) cpar.sigma = atof(tmps);
  if (getpar("COSMIC.FWHM",tmps)) cpar.fwhm = atof(tmps);
  if (getpar("COSMIC.RGROW",tmps)) cpar.rgrow = atof(tmps);
  if (getpar("COSMIC.PSFDIM",tmps)) cpar.psfdim = atoi(tmps);
    cpar.psfdim = 2*(cpar.psfdim/2)+1;
  if (getpar("COSMIC.PSFTYPE",tmps)) {
    if (strstr(tmps,"GAUSS") != NULL) cpar.psftype = GAUSS; else
    if (strstr(tmps,"MOFFAT15") != NULL) cpar.psftype = MOFFAT15; else
    if (strstr(tmps,"MOFFAT25") != NULL) cpar.psftype = MOFFAT25; else
    if (strstr(tmps,"USER") != NULL) cpar.psftype = USER; else {
      printf("  ** Error: Unsupported PSF type '%s'\n",tmps);
      return;
    }
  }
  if (getpar("COSMIC.NITER",tmps)) cpar.niter = atoi(tmps);
    if (cpar.niter < 1) cpar.niter = 1;
  if (getpar("COSMIC.PSFFILE",tmps)) strcpy(cpar.psfname,tmps);

  psf = makepsf(&cpar);
  if (psf == NULL) {
    puts(" ** Error reading PSF!");
    return;
  }

  img = floatfitsimage(&hdr,imname,TRUE);

  if (img == NULL) {
    puts(IM_READ_ERR);
    free(psf);
    return;
  }

  puts("  Removing cosmic rays .. ");

  addcard(&hdr,"COMMENT","BAOLAB/COSMIC removed CRs", H_COMM);
  img2 = do_cosm(img,&hdr,psf,&cpar);

  savefitsfile(&hdr, img2, -32, outname);
  free(img);
  free(img2);
  free(psf);
  freehdr(&hdr);
}
