/* ====================================================================== */
/*                                                                        */
/* Compute a King model as in King, I. R. 1966, AJ 71, 64, and return     */
/* various derived quantities.                                            */
/*                                                                        */
/* These routines come with *no warranty whatsoever*. They were written   */
/* by Soeren Larsen and have been used in                                 */
/* Larsen et al. 2002, AJ 124, 2615--2624.                                */
/* There is no guarantee that they will be suitable for any particular    */
/* purpose. There may be undiscovered bugs, some of which may seriously   */
/* compromise any scientific results.                                     */
/*                                                                        */
/* If these routines are helpful for your scientific work, a note in the  */
/* acknowledgements of any resulting publication would be much            */
/* appreciated.                                                           */
/*                                                                        */
/* ====================================================================== */


/* ---------------------------------------------------------------------- */

double *calcphiw(
  double *, /* w */
  double *, /* phiw */
  double *, /* vdisp */
  int       /* nw */
); 

/* ---------------------------------------------------------------------- */

double interp(
  double *, /* x */
  double *, /* y */
  int,      /* n */
  double    /* xx */
);

/* ---------------------------------------------------------------------- */

void calc_r(
/*                                                                         */
/*  Integrate the Poisson equation directly in the form given in the King  */ 
/* paper. Not optimal, requires some interpolation etc.                    */
/* This is useful as a consistency check though.                           */
/*                                                                         */
  double *, /* w */
  double *, /* rhorel */
  double *, /* rout */
  int       /* n   */
);

/* ---------------------------------------------------------------------- */

void calc_r2(
/*                                                                         */
/* Integrate the inverted form of the Poisson equation. Initial            */
/* conditions are slightly more tricky because dr_dw is infinite at r=0.   */
/*                                                                         */
  double *, /* w      */
  double *, /* rhorel */
  double *, /* rout   */
  int       /* n      */
);

/* ---------------------------------------------------------------------- */

double project(            /*  Returns p = sigma(r=0) / rho(r=0) */
  double *, /* r       */
  double *, /* rho     */
  double *, /* sigma   */
  double *, /* w       */
  double *, /* phiw    */
  double *, /* vdisp   */
  double *, /* vdispp  */
  double *, /* vdap    */
  int,      /* n       */
  double *pvd  /* pvd = vdispp(r=0) / vdisp(r=0) */
);

/* ---------------------------------------------------------------------- */

double vdslit(
  double,   /* w       */      /* Slit width in units of core radius */
  double,   /* l       */      /* Length */
  double *, /* r       */
  double *, /* sigma   */
  double *, /* vdispp  */
  int       /* n       */
);

/* ---------------------------------------------------------------------- */

double hlrp(
  double *, /* r       */
  double *, /* sigma   */
  int       /* nw      */
);

/* ---------------------------------------------------------------------- */

double hmr3d(
  double *, /* r      */
  double *, /* rho    */
  int       /* nw     */
);

/* ---------------------------------------------------------------------- */

double hwhm(
  double *,  /* r      */
  double *,  /* sigma  */
  int        /* nw     */
);

/* ---------------------------------------------------------------------- */

double mu(
  double *, /* r     */
  double *, /* rho   */
  int       /* nw    */
);

/* ---------------------------------------------------------------------- */

double eb(
  double *, /* r     */
  double *, /* rho   */
  double *, /* w     */
  int       /* nw    */
);
