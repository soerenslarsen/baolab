#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"
#include "utils.h"
#include "convol.h"

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static int get_user_psf(
  float *array,
  int   dim,
  char  *file
) {
  float *fdata;
  int    xc, yc,i,j;
  int    x,y,x1,y1;
  hstruct hdr;

  fdata = floatfitsimage(&hdr,file,FALSE);
  if (fdata == NULL) {
    printf("  ** PSF read error: Could not open file '%s'\n",file);
    return 0;
  }

  for (i=0; i<dim*dim; i++) array[i] = 0.0;
  xc = hdr.naxis1 / 2;
  yc = hdr.naxis2 / 2;

  for (y=0,j=0; y<hdr.naxis2; y++)
    for (x=0; x<hdr.naxis1; x++, j++) {
      x1 = x-xc; y1 = y-yc;
      if (x1>=-dim/2 && x1<dim/2 && y1>=-dim/2 && y1<dim/2) {
	i = x1 + dim/2 + (y1 + dim/2)*dim;
	array[i] = fdata[j];
      }
    }

  free(fdata);
  return 1;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static float calc_cc(
  float c
) {
  float x1, x2;
  x1 = sqrt(0.5) + (1-sqrt(0.5))/sqrt(1+sqr(c));
  x2 = 2 * sqrt(sqr(1/x1) - 1);
  return x2;
}

float king_cc(
  float fwhm,
  float rt,
  float *_c
) {
  float rc,c,cc;
  int i;

  rc = fwhm / 2;
  for (i=0; i<10; i++) {
    c = rt/rc;
    cc = calc_cc(c);
    rc = fwhm / cc;
/*    printf("%0.2f %0.2f %0.2f %0.2f %0.2f\n",rc,fwhm,rt,c,cc); */
  }

  *_c = c;

  return cc;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

int fill_array(
  float *array,
  int   dim,
  int   type,
  float fwhmx,      /* Fwhm along PSF x-axis                             */
  float fwhmy,      /* Fwhm along PSF y-axis                             */
  float pangle,     /* PSF x-axis position angle (in radians)            */
  float index,      /* Index (only used for KINGn/MOFFATn/EFFn/EFFCn)    */
  float rltot,      /* Radius within which Ltot is evaluated (for EFFCn) */
  char *file
) {
  int x, y;
  int n = 0;
  float z;
  float rt,fwmax, fwmin;
  float phys_x, phys_y;
  float x1,x2;
  float fx,fy,fxy;
  float c;
  float cc;
  float ca,sa;
  float ltot;

  /*   fx = 1/fwhmx in image coordinate system */
  /*   fy = 1/fwhmy in image coordinate system */
  /*   fxy = 1/fwhmxy in image coordinate system */
  /*   psf = psf(sqr(fx*x) + sqr(fy*y) + fxy*x*y) */

  if (type == SERSICx || type == SERSICn)
    fwmin = 1e-5;
  else
    fwmin = 1e-3;

  if (fwhmx < fwmin) { 
/*   fprintf(stderr,"  fill_array: fwhmx was %e, reset to 1E-5\n",fwhmx); */
    fwhmx = fwmin;
  }

  if (fwhmy < fwmin) { 
/*    fprintf(stderr,"  fill_array: fwhmy was %e, reset to 1E-5\n",fwhmy); */
    fwhmy = fwmin; 
  } 

  sa = sin(pangle);
  ca = cos(pangle);

  fx  = sqrt(sqr(ca/fwhmx) + sqr(sa/fwhmy));
  fy  = sqrt(sqr(sa/fwhmx) + sqr(ca/fwhmy));
  fxy = 2*ca*sa/sqr(fwhmx) - 2*ca*sa/sqr(fwhmy);

  if (type == GAUSS2) {
    puts("  ** Sorry, PSF type GAUSS2 is not currently supported in this task.");
    return 0;
  }

  if (type == USER) {
    return get_user_psf(array,dim,file);
  }

  if (type == KINGt) {
    rt = index;
    if (fwhmx > rt) {
      printf(" ** PSF Warning: FWHMx (%0.1f) > Rtidal (%0.1f) , setting FWHMx = Rtidal\n",fwhmx,rt);
      fwhmx = rt;
    }
    if (fwhmy > rt) {
      printf(" ** PSF Warning: FWHMy (%0.1f) > Rtidal (%0.1f) , setting FWHMy = Rtidal\n",fwhmy,rt);
      fwhmy = rt;
    }
    fwmax = (fwhmx > fwhmy) ? fwhmx : fwhmy;
    cc = king_cc(fwmax, rt, &c)/2;
/*    printf("CC = %0.2f C = %0.2f\n",cc,c);  */
  }

  ltot = 0.;

  for (y=0; y<dim; y++)
    for (x=0; x<dim; x++, n++) {
        phys_x = (x - (dim/2)) / 10.0;
        phys_y = (y - (dim/2)) / 10.0;

	switch (type) {
	  case GAUSS : 
		       array[n] = exp(-2.77*(sqr(fx*phys_x)
					    +sqr(fy*phys_y)
					    +fxy*phys_x*phys_y )) ; 
		       break;

/*	  case GAUSS2: 
		       array[n] = 
		  (1-par.psfweight)*exp(-2.77*(pow(phys_x/fwhmx,2) 
					     + pow(phys_y/fwhmy, 2)))
	       +     par.psfweight*exp(-2.77*(pow(phys_x/(fwhm2*fwhmx),2) 
					+ pow(phys_y/(fwhm2*fwhmy),2)));
		       break; */

          case EFF15:
	  case EFFCn15:
	  case EFFCx15:
	  case MOFFAT15: 
		       z = sqr(fx*2.0*0.77*phys_x) 
			 + sqr(fy*2.0*0.77*phys_y)
			 + fxy*phys_x*phys_y*sqr(2.0*0.77);
		       array[n] = 1.0/pow(1 + z,1.5);
		       break;

	  case EFF25: 
	  case EFFCn25:
	  case EFFCx25:
	  case MOFFAT25: 
		       z = sqr(fx*2.0*0.57*phys_x) 
			 + sqr(fy*2.0*0.57*phys_y)
			 + fxy*phys_x*phys_y*sqr(2.0*0.57);
		       array[n] = 1.0/pow(1 + z,2.5);
		       break;

	  case EFFx : 
	  case EFFn : 
	  case MOFFATx : 
	  case MOFFATn : 
		       cc = sqrt(pow(2.0,1.0/index)-1);
		       z = sqr(fx*2.0*cc*phys_x) 
			 + sqr(fy*2.0*cc*phys_y)
			 + fxy*phys_x*phys_y*sqr(2.0*cc);
		       array[n] = 1.0/pow(1 + z,index);
		       break;

	  case LUGGER: 
		       z = sqr(fx*2.0*phys_x/0.89) 
			 + sqr(fy*2.0*phys_y/0.89)
			 + fxy*phys_x*phys_y*sqr(2.0/0.89);
		       array[n] = 1.0/pow(1 + z,0.9);
		       break;

	  case EFF10:
	  case EFFCn10:
	  case EFFCx10:
          case HUBBLE:
	  case LORENZ:
		       z = sqr(fx*2.0*phys_x) 
			 + sqr(fy*2.0*phys_y)
			 + fxy*phys_x*phys_y*4;
		       array[n] = 1.0/(1 + z);
		       break;

          case EXPN  : 
		       z = sqr(fx*2.0*phys_x*log(0.5)) 
			 + sqr(fy*2.0*phys_y*log(0.5))
			 + fxy*phys_x*phys_y*sqr(2.0*log(0.5));
                       array[n] = exp(-sqrt(z));
	               break;

	  case KINGx :
          case KINGn : c = index; 
                       x1 = sqrt(1.0+c*c);
                       x2 = 1.0/sqr(1.0/sqrt(2.0)*(1.0-1.0/x1) + 1./x1) - 1;
                       cc = sqrt(x2);
                       goto king;
          case KING5 : c = 5.0; cc = 0.843; goto king;
          case KING15: c = 15.0; cc = 0.946; goto king;
          case KING30: c = 30.0; cc = 0.973; goto king;
          case KING100: c = 100.0; cc = 0.992;
	  case KINGt :
          king:         z = sqr(fx*2.0*phys_x*cc)
			  + sqr(fy*2.0*phys_y*cc)
			  + fxy*phys_x*phys_y*sqr(2.0*cc);
			if (z < sqr(c)) {
                          array[n] = 
			    sqr( 1.0/sqrt(1 + z) - 1.0/sqrt(1+sqr(c)) );
/*                          printf("%0.3e %0.3e %0.3e %0.3e %0.3e %0.3e %0.3e %0.3e\n", phys_x, phys_y, fx, fy, fxy, z, c, array[n]); */
                        } else
			  array[n] = 0.0;
			break;

          case SERSICx :
	  case SERSICn :
	               c = index;
		       cc = pow(log(2.0), c);
                       z = sqr(fx*2.0*phys_x*cc)
			  + sqr(fy*2.0*phys_y*cc)
			  + fxy*phys_x*phys_y*sqr(2.0*cc);
		       array[n] = exp(-pow(sqrt(z), 1/c));
		       break;

          case DELTA:
	               if (x==dim/2 && y==dim/2)
		         array[n] = 1;
		       else
		         array[n] = 0;
		       break;
	}

	if ( (fabs(phys_x) < rltot) && (fabs(phys_y) < rltot) )
	  ltot += array[n];
      }

  if (type==EFFCn10 || type==EFFCn15 || type==EFFCn25 ||
      type==EFFCx10 || type==EFFCx15 || type==EFFCx25) {
    x = dim/2;
    y = dim/2;
    array[x + y*dim] += ltot * index;
  }

  return 1;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

void do_mkcmppsf(
  char *outname,
  mkpsfstruct par
) {
  float *psf, *obj, *cmb;
  float *outim;
  int   mindim, dim = 2, i, n;
  int   x,y;
  hstruct hdr;
  float max,dummy;
  char  tmps[255];

  mindim = 4*(int)par.radius * 10;   /* Subsampling by a factor of 10.     */
  while (dim < mindim) dim *= 2;     /* dim must be 2^n because we want to */
                                     /* use FFT.                           */
  psf = (float *)malloc(sizeof(float)*dim*dim);
  obj = (float *)malloc(sizeof(float)*dim*dim);
  cmb = (float *)malloc(sizeof(float)*dim*dim);
  outim = (float *)malloc(par.radius*par.radius*100*sqr(sizeof(float)));

  puts("  Generating PSF array..");
  if (fill_array(psf,dim,par.psftype,par.fwhmpsfx,par.fwhmpsfy,
       par.pangle*pi/180, par.index, par.radius, par.psffile)) {
    puts("  Generating OBJECT array..");
    if (fill_array(obj,dim,par.objtype,par.fwhmobjx,par.fwhmobjy, 
          par.objangle*pi/180, par.index, par.radius, par.objfile)) {
      puts("  Convolving PSF and OBJECT arrays..");
      convol(dim,obj,psf,cmb);
      n = dim*dim;
      max = 0;
      for (i=0; i<n; i++) if (cmb[i] > max) max = cmb[i];

      for (y=-par.radius*10, i=0; y<par.radius*10; y++)
        for (x=-par.radius*10; x<par.radius*10; x++,i++) {
	  outim[i] = (float)((30000.0/max)*cmb[dim/2+x + dim*(dim/2+y)]);
	}

      hdr.naxis1 = 2*par.radius*10;
      hdr.naxis2 = 2*par.radius*10;
      hdr.card = NULL;
      hdr.bitpix = par.bitpix;
      hdr.bscale = 1.0;
      hdr.bzero = 0.0;

    #define ADDC addcard(&hdr,"COMMENT",tmps,H_COMM)
      addcard(&hdr,"COMMENT","Composite PSF image by BAOLAB",H_COMM);
      sprintf(tmps,"FWHMOBJX = %0.2f",par.fwhmobjx);  ADDC;
      sprintf(tmps,"FWHMOBJY = %0.2f",par.fwhmobjy);  ADDC;
      sprintf(tmps,"OBJANGLE = %0.2f",par.objangle);  ADDC;
      sprintf(tmps,"FWHMPSFX = %0.2f",par.fwhmpsfx);  ADDC;
      sprintf(tmps,"FWHMPSFY = %0.2f",par.fwhmpsfy);  ADDC;
      sprintf(tmps,"PANGLE = %0.2f",par.pangle);  ADDC;

      switch (par.psftype) {
	  case GAUSS    : sprintf(tmps,"PSFTYPE = GAUSS"); break;
          case GAUSS2   : sprintf(tmps,"PSFTYPE = GAUSS2"); break;
	  case EFF10    : sprintf(tmps,"PSFTYPE = EFF10"); break;
	  case EFF15    : sprintf(tmps,"PSFTYPE = EFF15"); break;
          case EFF25    : sprintf(tmps,"PSFTYPE = EFF25"); break;
          case EFFx     : sprintf(tmps,"PSFTYPE = EFFx"); break;
	  case MOFFAT15 : sprintf(tmps,"PSFTYPE = MOFFAT15"); break;
          case MOFFAT25 : sprintf(tmps,"PSFTYPE = MOFFAT25"); break;
          case KING5    : sprintf(tmps,"PSFTYPE = KING5"); break;
          case KING15   : sprintf(tmps,"PSFTYPE = KING15"); break;
          case KING30   : sprintf(tmps,"PSFTYPE = KING30"); break;
          case KING100  : sprintf(tmps,"PSFTYPE = KING100"); break;
	  case LORENZ   : sprintf(tmps,"PSFTYPE = LORENZ"); break;
	  case LUGGER   : sprintf(tmps,"PSFTYPE = LUGGER"); break;
	  case EXPN     : sprintf(tmps,"PSFTYPE = EXPN"); break;
	  case SERSICx  : sprintf(tmps,"PSFTYPE = SERSICx"); break;
          case USER     : sprintf(tmps,"PSFTYPE = USER"); break;
      }
      addcard(&hdr,"COMMENT",tmps,H_COMM);

      switch (par.objtype) {
	  case GAUSS    : sprintf(tmps,"OBJTYPE = GAUSS"); break;
          case GAUSS2   : sprintf(tmps,"OBJTYPE = GAUSS2"); break;
	  case EFFCx10  : sprintf(tmps,"OBJTYPE = EFFCx10"); break;
	  case EFFCx15  : sprintf(tmps,"OBJTYPE = EFFCx15"); break;
          case EFFCx25  : sprintf(tmps,"OBJTYPE = EFFCx25"); break;
	  case EFF10    : sprintf(tmps,"OBJTYPE = EFF10"); break;
	  case EFF15    : sprintf(tmps,"OBJTYPE = EFF15"); break;
          case EFF25    : sprintf(tmps,"OBJTYPE = EFF25"); break;
          case EFFx     : sprintf(tmps,"OBJTYPE = EFFx"); break;
	  case MOFFAT15 : sprintf(tmps,"OBJTYPE = MOFFAT15"); break;
          case MOFFAT25 : sprintf(tmps,"OBJTYPE = MOFFAT25"); break;
          case KING5    : sprintf(tmps,"OBJTYPE = KING5"); break;
          case KING15   : sprintf(tmps,"OBJTYPE = KING15"); break;
          case KING30   : sprintf(tmps,"OBJTYPE = KING30"); break;
          case KING100  : sprintf(tmps,"OBJTYPE = KING100"); break;
          case KINGx    : sprintf(tmps,"OBJTYPE = KINGx"); break;
          case KINGt    : sprintf(tmps,"OBJTYPE = KINGt"); break;
	  case LORENZ   : sprintf(tmps,"OBJTYPE = LORENZ"); break;
	  case LUGGER   : sprintf(tmps,"OBJTYPE = LUGGER"); break;
	  case HUBBLE   : sprintf(tmps,"OBJTYPE = HUBBLE"); break;
	  case DELTA    : sprintf(tmps,"OBJTYPE = DELTA "); break;
	  case EXPN     : sprintf(tmps,"OBJTYPE = EXPN"); break;
	  case SERSICx  : sprintf(tmps,"OBJTYPE = SERSICx"); break;
          case USER     : sprintf(tmps,"OBJTYPE = USER"); break;
      }
      addcard(&hdr,"COMMENT",tmps,H_COMM);

      if (par.objtype==EFFx || par.objtype==KINGx || par.objtype==KINGt ||
          par.objtype==SERSICx ||
	  par.objtype==EFFCx10 || par.objtype==EFFCx15 || par.objtype==EFFCx25) {
        sprintf(tmps,"INDEX = %0.2f",par.index);
        addcard(&hdr,"COMMENT",tmps,H_COMM);
      }

      savefitsfile(&hdr,outim,-32,outname);
      freehdr(&hdr);
      puts("  Done!");
    }
  }

  free(outim);
  free(psf);
  free(obj);
  free(cmb);
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

void mkcmppsf(char *params)
/* 
 * Create a composite PSF, consisting of a convolution of two
 * of the standard BAOLAB psf's. The motivation for this task is to
 * provide a way to simulate the apparance of non-stellar yet compact 
 * objects in a CCD image (for example star clusters in distant galaxies).
 */
{
  char tmps[255];
  static char outname[255] = "";
  mkpsfstruct par;

  par.bitpix = -32;

  if (getpar("MKCMPPSF.FWHMPSFX",tmps)) par.fwhmpsfx = atof(tmps);
  if (getpar("MKCMPPSF.FWHMPSFY",tmps)) par.fwhmpsfy = atof(tmps);
  if (getpar("MKCMPPSF.PANGLE",tmps)) par.pangle = atof(tmps);
  if (getpar("MKCMPPSF.FWHMOBJX",tmps)) par.fwhmobjx = atof(tmps);
  if (getpar("MKCMPPSF.FWHMOBJY",tmps)) par.fwhmobjy = atof(tmps);
  if (getpar("MKCMPPSF.OBJANGLE",tmps)) par.objangle = atof(tmps);
  if (getpar("MKCMPPSF.RADIUS",tmps)) par.radius = atof(tmps);
  if (getpar("MKCMPPSF.PSFFILE",tmps)) strcpy(par.psffile,tmps);
  if (getpar("MKCMPPSF.OBJFILE",tmps)) strcpy(par.objfile,tmps);
  if (getpar("MKCMPPSF.BITPIX",tmps)) par.bitpix = atof(tmps);
  if (getpar("MKCMPPSF.INDEX",tmps)) par.index = atof(tmps);

  if (getpar("MKCMPPSF.PSFTYPE",tmps)) {
    if (strstr(tmps,"GAUSS") != NULL) par.psftype = GAUSS; else
    if (strstr(tmps,"GAUSS2") != NULL) par.psftype = GAUSS2; else
    if (strstr(tmps,"EFF10") != NULL) par.psftype = EFF10; else
    if (strstr(tmps,"EFF15") != NULL) par.psftype = EFF15; else
    if (strstr(tmps,"EFF25") != NULL) par.psftype = EFF25; else
/*    if (strstr(tmps,"EFFx") != NULL) par.psftype = EFFx; else */
    if (strstr(tmps,"MOFFAT15") != NULL) par.psftype = MOFFAT15; else
    if (strstr(tmps,"MOFFAT25") != NULL) par.psftype = MOFFAT25; else
    if (strstr(tmps,"KING5") != NULL) par.psftype = KING5; else
    if (strstr(tmps,"KING15") != NULL) par.psftype = KING15; else
    if (strstr(tmps,"KING30") != NULL) par.psftype = KING30; else
    if (strstr(tmps,"KING100") != NULL) par.psftype = KING100; else
    if (strstr(tmps,"LORENZ") != NULL) par.psftype = LORENZ; else
    if (strstr(tmps,"LUGGER") != NULL) par.psftype = LUGGER; else
    if (strstr(tmps,"EXPN") != NULL) par.psftype = EXPN; else
    if (strstr(tmps,"DELTA") != NULL) par.psftype = DELTA; else
/*    if (strstr(tmps,"SERSICx") != NULL) par.psftype = SERSICx; else */
    if (strstr(tmps,"USER") != NULL) par.psftype = USER; else { 
      printf("  ** Error: Unsupported PSF type '%s'\n",tmps);
      return;
    }
  }

  if (getpar("MKCMPPSF.OBJTYPE",tmps)) {
    if (strstr(tmps,"GAUSS") != NULL) par.objtype = GAUSS; else
    if (strstr(tmps,"GAUSS2") != NULL) par.objtype = GAUSS2; else
    if (strstr(tmps,"EFF10") != NULL) par.objtype = EFF10; else
    if (strstr(tmps,"EFF15") != NULL) par.objtype = EFF15; else
    if (strstr(tmps,"EFF25") != NULL) par.objtype = EFF25; else
    if (strstr(tmps,"EFFCx10") != NULL) par.objtype = EFFCx10; else
    if (strstr(tmps,"EFFCx15") != NULL) par.objtype = EFFCx15; else
    if (strstr(tmps,"EFFCx25") != NULL) par.objtype = EFFCx25; else
    if (strstr(tmps,"EFFx") != NULL) par.objtype = EFFx; else
    if (strstr(tmps,"MOFFAT15") != NULL) par.objtype = MOFFAT15; else
    if (strstr(tmps,"MOFFAT25") != NULL) par.objtype = MOFFAT25; else
    if (strstr(tmps,"KING5") != NULL) par.objtype = KING5; else
    if (strstr(tmps,"KING15") != NULL) par.objtype = KING15; else
    if (strstr(tmps,"KING30") != NULL) par.objtype = KING30; else
    if (strstr(tmps,"KING100") != NULL) par.objtype = KING100; else
    if (strstr(tmps,"KINGx") != NULL) par.objtype = KINGx; else
    if (strstr(tmps,"KINGt") != NULL) par.objtype = KINGt; else
    if (strstr(tmps,"LORENZ") != NULL) par.objtype = LORENZ; else
    if (strstr(tmps,"LUGGER") != NULL) par.objtype = LUGGER; else
    if (strstr(tmps,"HUBBLE") != NULL) par.objtype = HUBBLE; else
    if (strstr(tmps,"SERSICx") != NULL) par.objtype = SERSICx; else
    if (strstr(tmps,"EXPN") != NULL) par.objtype = EXPN; else
    if (strstr(tmps,"USER") != NULL) par.objtype = USER; else
    if (strstr(tmps,"DELTA") != NULL) par.objtype = DELTA; else {
      printf("  ** Error: Unsupported OBJECT type '%s'\n",tmps);
      return;
    }
  }

  if (nargs(params) == 1) {
    argn(params,1,outname); 
  } else {
    printf("  Output file name: "); cscanf("%s",outname);
  }

  do_mkcmppsf(outname,par);
} 
