#define BO_LITTLE_ENDIAN 0     /* PC / INTEL and DEC - style */
#define BO_BIG_ENDIAN 1        /* Almost everybody else      */

#ifndef BYTEORDER_MAIN

  extern int byteorder();

#endif
