#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "utils.h"

#define ARRSIZE 100000
static int PIXNR[ARRSIZE+1];

/*
#ifndef RAND_MAX
#define RAND_MAX 4294967296.0
#endif
*/

/*                                                                       */
/* ===================================================================== */
/*                                                                       */

void initpsf(
  float *prob,
  int    n_elements,
  float *acc
) {

  int i,j;
  double r, sum;

  sum = 0.0;

  for (i=0; i<n_elements; i++) {  /* Sum up the accumulated probability */
				  /* distribution.                      */
    sum += prob[i];
    acc[i] = sum; 
  }
  for (i=0; i<n_elements; i++) acc[i] /= acc[n_elements-1]; 
  /* Just to make sure ..               */

  j = 0;
  for (i=0; i<ARRSIZE; i++) {     /* Generate a table where the i'th    */
				  /* element contains the number of the */
				  /* pixel where a photon labeled 'i'   */
				  /* will arrive.                       */
    r = i/(double)ARRSIZE;
    while (acc[j+1] < r) j++;
    if (j+1 >= n_elements) puts("** WARNING: INTERNAL ERROR.");
    PIXNR[i] = j;
  }

  PIXNR[ARRSIZE] = n_elements-1;

}

/*                                                                       */
/* ===================================================================== */
/*                                                                       */

void syntpsf(
  float *acc,
  int n_elements,
  float n_photons,
  int *psf
) {
  int i,j,pix;
  double r;
  int ni_photons;

  for (i=0; i<n_elements; i++) psf[i] = 0;

  ni_photons = lrint(n_photons);
  for (i=0; i<ni_photons; i++) {
/*    r = rand()*1.0/RAND_MAX;  */
    r = nrand(); 
    j = (int)(r*ARRSIZE);

    if (PIXNR[j] == PIXNR[j+1]) {  /* We've hit one of the very probable */
				   /* pixels.                            */
      pix = PIXNR[j]; 
    } else {
      pix = PIXNR[j];
      while ((acc[pix] < r) && (pix<n_elements)) pix++; 
      pix--;
    }
    psf[pix]++;
  }
}
