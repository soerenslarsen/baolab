#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"
#include "utils.h"
#include "alloc.h"

#ifdef USE_FFTW3
#include <fftw3.h>
#else
#include "fftsg2d.h"
#endif

/*
 *  Currently only handles quadratic images - NO CHECK !
 *  The PSF should be centered at pixel nr. (dim/2 , dim/2), starting
 *  at (0,0) and ending at (dim-1, dim-1).
 */

float *mkp2arr(
  /* Rearrange the input array with dimensions dimx*dimy into a new array */
  /* with dimensions dimp2*dimp2, where dimp2 is a power of 2 (for FFT)   */
  /* If dimp2 > 0 then that value will be used. Otherwise use smallest    */
  /* possible (that is greater than dimx and dimy)                        */

  int dimx, 
  int dimy,
  float *inparr,
  int *dimp2
) {
  int dim,n,i;
  int y1, x1, y2;
  int  j1, j2;
  float *outarr;

  if ((*dimp2) == 0) {
    dim = 2;
    while (dim < dimx || dim < dimy) dim *= 2;
  } else
    dim = (*dimp2);

  n = sqr(dim);

  outarr = (float *)malloc(sizeof(float)*n);
  for (i = 0; i<n; i++) outarr[i] = 0.0;

  for (y1=0; y1<dimy; y1++) {
    y2 = y1 + dim/2 - dimy/2;    /* y position in new array */
    j2 = y2*dim + dim/2 -dimx/2;
    j1 = y1*dimx;
    for (x1=0; x1<dimx; x1++) outarr[x1+j2] = inparr[x1+j1];
  }

  (*dimp2) = dim;
  return outarr;
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

void getp2arr(
  int dim,
  float *p2arr,
  int dimx,
  int dimy,
  float *resarr
) {
  int x1,y1,y2,j1,j2;

  for (y1=0; y1<dimy; y1++) {
    y2 = y1 + dim/2 - dimy/2;       /* y position in n^2 array */
    j2 = y2*dim + dim/2 -dimx/2;
    j1 = y1*dimx;
    for (x1=0; x1<dimx; x1++) resarr[j1+x1] = p2arr[j2+x1];
  }
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

static void rearrange_psf_quadrants(int dim, float *fpsf) {
/* Reorder the PSF array and normalise */
  int   x,y;
  int   i,n,n1,n2;
  float tmp;
  float sum;

  n = dim*dim; sum = 0.0;
  for (i=0; i<n; i++) sum += fpsf[i];

  for (x=0; x<dim/2; x++)
    for (y=0; y<dim/2; y++) {
      n1 = x + y*dim;
      n2 = x + dim/2 + (y+ dim/2)*dim;
      tmp = fpsf[n2];
      fpsf[n2] = fpsf[n1] / sum;
      fpsf[n1] = tmp / sum;

      n1 = x + dim/2 + y*dim;
      n2 = x + (y+ dim/2)*dim;
      tmp = fpsf[n2];
      fpsf[n2] = fpsf[n1] / sum;
      fpsf[n1] = tmp /sum;
    }
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

#ifdef USE_FFTW3
/* Use the FFTW3 fourier transform routines                                */

void convol(int dim, float *src, float *psf, float *dst) { 

  double *in, *acnv;
  int    i, nr, nc, nthreads;
  double rsrc, isrc, rpsf, ipsf;
  fftw_complex *out_ft, *asrc_ft, *apsf_ft, *acnv_ft;
  fftw_plan p;

  rearrange_psf_quadrants(dim, psf); 

/* Initialise variables for FFTs */

  nthreads = 8;
  i = fftw_init_threads();
  fftw_plan_with_nthreads(nthreads);

  nr = dim*dim;           /* Dimension of real arrays    */
  nc = dim*((dim/2+1));   /* Dimension of complex arrays */

  in       = (double*) fftw_malloc(sizeof(double) * nr);
  acnv     = (double*) fftw_malloc(sizeof(double) * nr);
  out_ft   = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * nc);
  asrc_ft  = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * nc);
/*  apsf_ft  = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * nc); */
  acnv_ft  = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * nc);

  p = fftw_plan_dft_r2c_2d(dim, dim, in, out_ft, FFTW_ESTIMATE);

/* Source array */

  for (i=0; i<nr; i++) in[i] = src[i];
  fftw_execute(p);
  for (i=0; i<nc; i++) {
    asrc_ft[i][0] = out_ft[i][0];
    asrc_ft[i][1] = out_ft[i][1];
  }

/* PSF array */

  for (i=0; i<nr; i++) in[i] = psf[i];
  fftw_execute(p);
/*  for (i=0; i<nc; i++) {
    apsf_ft[i][0] = out_ft[i][0];
    apsf_ft[i][1] = out_ft[i][1];
  } */

  fftw_destroy_plan(p);

/* Multiply FFTs */

  for (i=0; i<nc; i++) {
    rsrc = asrc_ft[i][0];
    isrc = asrc_ft[i][1];
/*    rpsf = apsf_ft[i][0];
    ipsf = apsf_ft[i][1]; */
    rpsf = out_ft[i][0];
    ipsf = out_ft[i][1]; 
    acnv_ft[i][0] = rsrc*rpsf - isrc*ipsf;
    acnv_ft[i][1] = rsrc*ipsf + isrc*rpsf;
  }

/* Inverse transform */

  p = fftw_plan_dft_c2r_2d(dim, dim, acnv_ft, acnv, FFTW_ESTIMATE);
  fftw_execute(p);
  fftw_destroy_plan(p);

  for (i=0; i<nr; i++) dst[i] = acnv[i]/(dim*dim);

  fftw_free(in);
  fftw_free(acnv);
  fftw_free(out_ft);
  fftw_free(asrc_ft);
/*  fftw_free(apsf_ft); */
  fftw_free(acnv_ft);

  fftw_cleanup_threads();
}
#else

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

/* Uses the FFT2D fourier transform routine                */
/* by Takuya OOURA (1997, 2001) - see fft2d subdirectory.  */
/* When compiling with gcc13, -O2 must be off              */

void convol(int dim, float *src, float *psf, float *dst) { 
/* void convol_FFT2D(int dim, float *src, float *psf, float *dst) {  */

  float  rsrc, isrc, rpsf, ipsf;

  double **asrc, **apsf, **acnv;
  int    *ip;
  double *w;
  int    i,j1,j2,tj2, dims[2];
  int    n;

  rearrange_psf_quadrants(dim, psf); 

/* Source array */

  asrc = alloc_2d_double(dim,2*dim);
  apsf = alloc_2d_double(dim,2*dim);
  acnv = alloc_2d_double(dim,2*dim);
  ip = alloc_1d_int(dim+2);
  w  = alloc_1d_double(dim+2);
  ip[0] = 0;

  for (i=0,j1=0; j1<dim; j1++)
    for (j2=0; j2<dim; j2++)
      asrc[j1][j2] = src[i++];

/*  cdft2d(dim,2*dim,1,asrc,NULL, ip, w);  */
  rdft2d(dim,dim,1,asrc,NULL, ip, w); 
  rdft2dsort(dim,dim,1,asrc); 

/* PSF array */

  for (i=0,j1=0; j1<dim; j1++)
    for (j2=0; j2<dim; j2++)
      apsf[j1][j2] = psf[i++];

/*  cdft2d(dim,2*dim,1,apsf,NULL, ip, w);  */
  rdft2d(dim,dim,1,apsf,NULL, ip, w); 
  rdft2dsort(dim,dim,1,apsf);

/* Multiply FFTs */

  for (j1=0; j1<dim; j1++)
    for (j2=0; j2<dim; j2++) {
      tj2 = 2*j2;
      rsrc = asrc[j1][tj2];
      isrc = asrc[j1][tj2+1];
      rpsf = apsf[j1][tj2];
      ipsf = apsf[j1][tj2+1];
      acnv[j1][tj2]   = rsrc*rpsf - isrc*ipsf;
      acnv[j1][tj2+1] = rsrc*ipsf + isrc*rpsf;
    }

/* Inverse transform */

/*  ip[0] = 0;  */
/*  cdft2d(dim,2*dim,-1,acnv,NULL, ip, w);  */
  rdft2dsort(dim,dim,-1,acnv);
  rdft2d(dim,dim,-1,acnv,NULL, ip, w); 

  for (i=0,j1=0; j1<dim; j1++)
    for (j2=0; j2<dim; j2++)
      dst[i++] = acnv[j1][j2] * 2.0/dim/dim; 

  free_1d_double(w);
  free_1d_int(ip);
  free_2d_double(acnv);
  free_2d_double(apsf);
  free_2d_double(asrc);
}

#endif

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

/* Uses the FFTN fourier transform routine                     */
/* (Distributable under Gnu public license, but rather slow)   */

/*
void convol(int dim, float *src, float *psf, float *dst) {

  float *resrc, *repsf, *imsrc, *impsf;
  float *recnv, *imcnv;
  int    i, dims[2];
  int    n;

  rearrange_psf_quadrants(dim, psf); 

  resrc = (float *)malloc(sizeof(float)*dim*dim);
  imsrc = (float *)malloc(sizeof(float)*dim*dim);
  repsf = (float *)malloc(sizeof(float)*dim*dim);
  impsf = (float *)malloc(sizeof(float)*dim*dim);
  recnv = (float *)malloc(sizeof(float)*dim*dim);
  imcnv = (float *)malloc(sizeof(float)*dim*dim);

  dims[0] = dim;
  dims[1] = dim;
  n = dim*dim;

  for (i=0; i<n; i++) {
    resrc[i] = src[i];
    repsf[i] = psf[i];
    imsrc[i] = 0.;
    impsf[i] = 0.;
  }

  fftnf(2, dims, resrc, imsrc, 1, -1);
  fftnf(2, dims, repsf, impsf, 1, -1);

  for (i=0; i<n; i++) {
    recnv[i] = resrc[i]*repsf[i] - imsrc[i]*impsf[i];
    imcnv[i] = resrc[i]*impsf[i] + repsf[i]*imsrc[i];
  }

  fftnf(2,dims, recnv, imcnv, -1, -1);

  for (i = 0; i<n; i++) dst[i] = recnv[i];

  free(resrc);
  free(imsrc);
  free(repsf);
  free(impsf);
  free(recnv);
  free(imcnv);
}

*/

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

  /* Uses the FFT function from Numerical Recipes */
  
/*
void convol(int dim, float *src, float *psf, float *dst) {

  float ***data1, ***data2;
  float **speq1, **speq2;
  int   i,j,k;
  float fac,*sp1,*sp2;
  float re,im;

  rearrange_psf_quadrants(dim, psf); 

  data1 = f3tensor(1,1,1,dim,1,dim);
  data2 = f3tensor(1,1,1,dim,1,dim);
  speq1 = matrix(1,1,1,2*dim);
  speq2 = matrix(1,1,1,2*dim);

  for (i = 0, j=1; j<=dim; j++)
    for (k=1; k<=dim; k++) {
      data1[1][j][k] = src[i];
      data2[1][j][k] = psf[i];
      i++;
    }

  rlft3(data1,speq1,1,dim,dim,1);
  rlft3(data2,speq2,1,dim,dim,1);
  fac = 2.0/(dim*dim);
  sp1 = &data1[1][1][1];
  sp2 = &data2[1][1][1];

  for (j=1; j<=dim*dim/2; j++) {
    re = sp1[0]*sp2[0] - sp1[1]*sp2[1];
    im = sp1[0]*sp2[1] + sp1[1]*sp2[0];
    sp1[0] = fac*re;
    sp1[1] = fac*im;
    sp1 += 2;
    sp2 += 2;
  }

  sp1 = &speq1[1][1];
  sp2 = &speq2[1][1];

  for (j=1; j<=1*dim; j++) {
    re = sp1[0]*sp2[0] - sp1[1]*sp2[1];
    im = sp1[0]*sp2[1] + sp1[1]*sp2[0];
    sp1[0] = fac*re;
    sp1[1] = fac*im;
    sp1 += 2;
    sp2 += 2;
  }

  rlft3(data1,speq1,1,dim,dim,-1);

  for (i = 0, j=1; j<=dim; j++)
    for (k=1; k<=dim; k++) {
      dst[i++] = data1[1][j][k];
    }

  free_matrix(speq2,1,1,1,2*dim);
  free_matrix(speq1,1,1,1,2*dim);
  free_f3tensor(data2,1,1,1,dim,1,dim);
  free_f3tensor(data1,1,1,1,dim,1,dim);
}
*/

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

  /* Uses the kube_fft FFT function */

/*

void convol(int dim, float *src, float *psf, float *dst) {

  COMPLEX *csrc, *cpsf, *cdst;
  int i,npix;

  rearrange_psf_quadrants(dim, psf); 
  npix = dim*dim;
  csrc = (COMPLEX *)malloc(sizeof(COMPLEX)*npix);
  cpsf = (COMPLEX *)malloc(sizeof(COMPLEX)*npix);
  cdst = (COMPLEX *)malloc(sizeof(COMPLEX)*npix);
  for (i=0; i<npix; i++) {
    csrc[i].re = src[i]; csrc[i].im = 0.0;
    cpsf[i].re = psf[i]; cpsf[i].im = 0.0;
  }
  forward_fft(csrc,dim,dim);
  forward_fft(cpsf,dim,dim);
  for (i=0; i<npix; i++) {
    cdst[i].re = csrc[i].re * cpsf[i].re - csrc[i].im * cpsf[i].im;
    cdst[i].im = csrc[i].re * cpsf[i].im + cpsf[i].re * csrc[i].im;
  }
  inverse_fft(cdst,dim,dim);
  for (i=0; i<npix; i++) dst[i] = cdst[i].re;

  free(cdst); free(cpsf); free(csrc);
}

*/

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

void imconvol(char *params) 
{
  static char imname[255] = "",
              outname[255] = "",
	      kernname[255] = "";

  float *im, *kern;
  float *p1, *p2, *p3;
  float *dst;
  hstruct hdr, khdr;
  int n,x,y,dim,x0i,y0i,x0k,y0k;
  float scale = 1.0;
  float bkgval = 0.0;
  int   boundary = CONST;
  float n1,n2;
  char  tmps[100];

  if (getpar("IMCONVOL.SCALE",tmps)) scale = atof(tmps);
  if (getpar("IMCONVOL.BKGVALUE",tmps)) bkgval = atof(tmps);
  if (getpar("IMCONVOL.BOUNDARY",tmps)) {
    if (strstr(tmps,"CONST") == tmps) boundary = CONST;
    if (strstr(tmps,"NEAREST") == tmps) boundary = NEAREST;
  }

  if (nargs(params) == 3) {
    argn(params,1,imname);
    argn(params,2,kernname);
    argn(params,3,outname);
  } else {
    printf("  Source      :  "); cscanf("%s",imname);
    printf("  Kernel      :  "); cscanf("%s",kernname);
    printf("  Destination :  "); cscanf("%s",outname);
  }

  im = floatfitsimage(&hdr,imname,TRUE);
  if (im != NULL) {
    kern = floatfitsimage(&khdr,kernname,FALSE);
    if (kern != NULL) {
      dim = 2;
      while (dim < hdr.naxis1 || dim < hdr.naxis2 || 
	     dim < khdr.naxis1 || dim < khdr.naxis2) dim *= 2;
      x0i = (dim - hdr.naxis1) / 2 + 1;
      y0i = (dim - hdr.naxis2) / 2 + 1;
      x0k = (dim - khdr.naxis1) / 2 + 1;
      y0k = (dim - khdr.naxis2) / 2 + 1;

      p1 = (float *)malloc(sizeof(float)*dim*dim);
      p2 = (float *)malloc(sizeof(float)*dim*dim);
      p3 = (float *)malloc(sizeof(float)*dim*dim);
      dst = (float *)malloc(sizeof(float)*hdr.naxis1*hdr.naxis2);

      for (n=0; n<dim*dim; n++) {
	p1[n] = bkgval;
	p2[n] = 0.0;
      }

      for (y=0; y<hdr.naxis2; y++)
	for (x=0; x<hdr.naxis1; x++)
	  p1[(y0i+y)*dim + x0i+x] = im[y*hdr.naxis1+x];
      for (y=0; y<khdr.naxis2; y++)
	for (x=0; x<khdr.naxis1; x++)
	  p2[(y0k+y)*dim + x0k+x] = kern[y*khdr.naxis1+x];

      if (boundary == NEAREST) {
	for (y=0; y<dim; y++) {
	  n1 = p1[y*dim+x0i];  n2 = p1[(y+1)*dim-x0i-1]; 
	  for (x=0; x<x0i; x++) {
	    p1[y*dim+x] = n1;  p1[(y+1)*dim-x-1] = n2; 
	  }
	} 

	for (x=0; x<dim; x++) {
	  n1 = p1[y0i*dim+x]; n2 = p1[(dim-y0i)*dim-x-1]; 
	  for (y=0; y<y0i; y++) {
	    p1[y*dim+x] = n1; p1[(dim-y)*dim-x-1] = n2; 
	  }
	} 
      }

      puts("  Convolving...");
      convol(dim, p1, p2, p3);
      puts("  Done.");

      for (y=0; y<hdr.naxis2; y++)
        for (x=0; x<hdr.naxis1; x++) 
	  dst[y*hdr.naxis1+x] = p3[(y0i+y)*dim + x0i+x] * scale; 

      sprintf(tmps,"IMCONVOL: %s * %s",imname,kernname);
      addcard(&hdr,"HISTORY",tmps,H_COMM);

      savefitsfile(&hdr,dst,-32,outname);

      free(kern);
      freehdr(&khdr);
      free(p1);
      free(p2);
      free(p3);
      free(dst);
    } else
      puts("  ** Error reading kernel image");

    freehdr(&hdr);
    free(im);

  } else
    puts(IM_READ_ERR);
}

void deconvol(char *params)   /* Never finished this one ... */
{
  static char imname[255] = "",
              outname[255] = "",
	      srcname[255] = "";

  short *im, *out;
  float *fim, *fpsf, *fout;
  float *px, *py, *pm;
  int   i,np,npix;
  hstruct hdr,phdr;

  if (nargs(params) == 3) {
    argn(params,1,imname);
    argn(params,2,srcname);
    argn(params,3,outname);
  } else {
    printf("  Image to be deconvolved :  "); cscanf("%s",imname);
    printf("  Point source list       :  "); cscanf("%s",srcname);
    printf("  Output image            :  "); cscanf("%s",outname);
  }

  im = shortfitsimage(&hdr,imname,TRUE);
  if (im != NULL) {
    np = getstarlst(srcname,&px,&py,&pm);
    if (np > 0) {
      printf("  %i point sources read from input file.\n",np);
      npix = hdr.naxis1 * hdr.naxis2;

      fim = (float *)malloc(sizeof(float)*npix);
      fout = (float *)malloc(sizeof(float)*npix);
      fim = (float *)malloc(sizeof(float)*npix);
      out = (short *)malloc(sizeof(short)*npix);

      fpsf = floatfitsimage(&phdr,"psf128",FALSE);
/*      rearrange_psf_quadrants(hdr.naxis1, fpsf); */

      for (i=0; i<npix; i++) fim[i] = (float)im[i];

      convol(hdr.naxis1, fim,fpsf,fout);

      freehdr(&phdr);
      free(fpsf);
   
      addcard(&hdr,"HISTORY","Magain et. al. deconvolved.",H_COMM);
      for (i=0; i<npix; i++) out[i] = (short)fout[i];
      savefitsfile(&hdr,out,16,outname);
      free(px); free(py); free(pm); free(fim); free(out); free(fout);
    }
    free(im);
    freehdr(&hdr); 
  } else
    puts(IM_READ_ERR);
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */
