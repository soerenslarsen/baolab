#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"

extern void parse(char *, strarr);   /* Declared in parse.c   */
extern int median(int *, int);       /*          in baolab2.c */
extern float fmedian(float *, int);  /*          in baolab2.c */

/* ==================================================================== */

void lnx2fts(
  char *params
)
{
  static char lnxname[255] = "",fitsname[255] = "";
  char  tmps[255];
  short *fitsdata;
  hstruct header;

  if (nargs(params) != 2) {
    printf("  Lynxx image :  "); cscanf("%s",lnxname);
    printf("  FITS image  :  "); cscanf("%s",fitsname);
  } else {
    argn(params,1,lnxname);
    argn(params,2,fitsname);
  }

  printf("  %s --> %s\n",lnxname,fitsname); 
   
  fitsdata = (short*)readlnx(lnxname);

  if (fitsdata != NULL) {
    header.bitpix = 16;
    header.naxis1 = 192;
    header.naxis2 = 165;
    header.bscale = 1.0;
    header.bzero  = 0.0;
    header.card = NULL;
    strcpy(tmps,"From Lynxx: "); strcat(tmps,lnxname);
    addcard(&header,"HISTORY",tmps,H_COMM);

    savefitsfile(&header,fitsdata,16,fitsname);
    free(fitsdata);
    freehdr(&header);
  }
  else {
    printf("Error opening/reading '%s'\n",lnxname);
  }
}

/* ==================================================================== */

void w2fts(
  char *params
)
{
  hstruct header;
  short *buff;
  static char  ftsname[255]="",wname[255]="";
  char  tmps[255];
  static int   rezx = 192,rezy = 165;
  char  xs[100],ys[100];
  int   rezxd=192,rezyd=165;
  int   doswap = FALSE, i, laest,handle;
  int   x,xlo,xhi;

  if (getpar("W2FTS.REZX",xs)) rezxd = atoi(xs); 
  if (rezxd==0) rezxd = 192;

  if (getpar("W2FTS.REZY",ys)) rezyd = atoi(ys);
  if (rezyd==0) rezyd = 165;

  if (getpar("W2FTS.SWAP",tmps)) doswap = (strstr(tmps,"YES") == tmps);
    
  if (nargs(params) == 4) {
    argn(params,1,wname);
    argn(params,2,tmps);  rezx = atoi(tmps);
    argn(params,3,tmps);  rezy = atoi(tmps);
    argn(params,4,ftsname);
  } else {
    printf("  16-bit file  :  "); cscanf("%s",wname);
    printf("  X-size       :  "); cscanf("%i",&rezxd); 
    rezx = rezxd;
    printf("  Y-size       :  "); cscanf("%i",&rezyd); 
    rezy = rezyd;
    printf("  Output image :  "); cscanf("%s",ftsname);
  }

  printf("  Converting %s (%i x %i) --> %s\n",wname,rezx,rezy,ftsname);
  if (doswap) puts("  Swapping byte-order.");

  buff = (short *)malloc(2*rezx*rezy);

  header.bitpix = 16;
  header.naxis1 = rezx;
  header.naxis2 = rezy;
  header.bscale = 1.0;
  header.bzero  = 0.0;
  header.card   = NULL;
  strcpy(tmps,"From 16-bit raw: "); strcat(tmps,wname);
  addcard(&header,"HISTORY",tmps,H_COMM);

  handle = open(wname,O_RDONLY);
  laest = read(handle,buff,2*rezx*rezy);
  close(handle);

  if (laest==2*rezx*rezy) {
    if (doswap) for (i=0; i<laest/2; i++) {
      x = buff[i];
      xlo = x & 0X00FF;
      xhi = x & 0XFF00;
      x = ((xlo << 8) & 0XFF00) | ((xhi >> 8) & 0X00FF); 
      buff[i] = x;
    }
    savefitsfile(&header,buff,16,ftsname);
  } else 
    puts("  ** Error reading input file.");

  free(buff);
  freehdr(&header);
}

/* ==================================================================== */

void imarit(
  char *params
)
{
  static char    tmps[255],op[255] = "+",
                 name1[255] = "",name2[255] = "",name3[255] = "";
  hstruct h1,h2;
  float   *data1,*data2;
  float   *data3;
  int     i,npix,reporg=0;
  float   repvalue=0.0;
  float   f;

  if (getpar("IMARIT.DZEROVAL",tmps)) {
    repvalue = atof(tmps); 
    if (strstr(tmps,"ORG") != NULL) reporg = 1;
  }

  if (nargs(params)==4) {
    argn(params,1,name1);
    argn(params,2,op);
    argn(params,3,name2);
    argn(params,4,name3);
  } else {
    printf("  Image #1    :  "); cscanf("%s",name1);
    printf("  Op (+ - * /):  "); cscanf("%s",op);
    printf("  Image #2    :  "); cscanf("%s",name2);
    printf("  Result      :  "); cscanf("%s",name3);
  }

  if ((op[0] == '*') || (op[0] == '/') || 
      (op[0] == '-') || (op[0] == '+')) {
    data1 = floatfitsimage(&h1,name1,TRUE);
    data2 = floatfitsimage(&h2,name2,FALSE);

    if ((data1 != NULL) && (data2 != NULL)) {
      if ((h1.naxis1 == h2.naxis1) && (h1.naxis2 == h2.naxis2)) {
        npix = h1.naxis1*h1.naxis2;
	data3 = (float *)malloc(sizeof(float)*npix);

        switch (op[0]) {
	  case '*' : for (i=0;i<npix;i++)
                       data3[i] = data1[i] * data2[i];
		     break;
	  case '+' : for (i=0;i<npix;i++)
                       data3[i] = data1[i] + data2[i];
		     break;
	  case '-' : for (i=0;i<npix;i++)
                       data3[i] = data1[i] - data2[i];
		     break;
	  case '/' : for (i=0;i<npix;i++) {
	               f = data2[i];
		       if (fabs(f) > 0.000001)
                         data3[i] = data1[i] / f;
                       else {
			 if (reporg) repvalue = data1[i];
		         data3[i] = repvalue;
                       }
                     }
		     break;
	}

	h1.bscale = 1; h1.bzero = 0;
	if ((h1.bitpix == -32) || (h2.bitpix == -32)) h1.bitpix=-32;
	strcpy(tmps,"IMARIT ");
	strcat(tmps,name1); strcat(tmps," ");
	strcat(tmps,op); strcat(tmps," "); strcat(tmps,name2);
	addcard(&h1,"HISTORY",tmps,H_COMM);
        savefitsfile(&h1,data3,-32,name3);

      } else
        puts(" ** Error: Images not same format.");

      free(data1);
      free(data2);
      free(data3);

    } else
      puts(" ** Error reading image file(s)");
      
    freehdr(&h1);

  } else 
    puts(" ** Illegal operator.");
}

/* ==================================================================== */

void imstat(
  char *params
)
{
  static char  filename[255] = "";
  float   *buff;
  hstruct header;
  int     npix,i;
  float   min,max;
  float   f,sum,avg,stdev,varians;

  if (nargs(params) == 1)
    argn(params,1,filename);
  else {
    printf("  File :  "); 
    cscanf("%s",filename);
  }

  buff = floatfitsimage(&header,filename,FALSE);
  if (buff != NULL) {
    npix = header.naxis1*header.naxis2; 
    min = 100000; max = -100000;
    sum = 0;

    for (i=0;i<npix;i++) {
      sum += buff[i];
      if (buff[i] > max) max = buff[i];
      if (buff[i] < min) min = buff[i];
    }
    avg = sum/npix;
    printf("  Imstat output: \n");
    printf("   No. of pixels = %6i\n",npix);
    printf("   Min. value    = %7.1f\n",min);
    printf("   Max. value    = %7.1f\n",max);
    printf("   Avg. value    = %7.1f\n",avg);

    varians = 0;
    for (i=0;i<npix;i++) {
      f = buff[i]-avg;
      varians += f*f;
    }
    varians /= npix;
    stdev = sqrt(varians);

    printf("   Variance      = %8.2f\n",varians);
    printf("   Std. dev.     = %8.2f\n",stdev);

    free(buff);
  } else
    printf("  ** Error reading file: %s\n",filename);

}

/*									*/
/* ============== The following routines belong to IMCALC ============= */
/*									*/

int analyse_expr(

/*  Returns 1 if ok and 0 if some error occurred.  */

  char *expr,
  int  *a1,int *a2,  /* Type of arguments: 1=string, 2=float, 3=ref. to expr */
  char *op,
  int    *i1,int *i2,    /* Ref, if this is the type of arg1 and/or arg2 */
  float  *d1,float *d2,  /* Float, if this is the type */
  char   *s1,char *s2    /* string, if this is the type */
)
{
  int i,j;
  char tmps[100],tmps1[100];
  char **endp;
  void *tmp;
  char tmpchr;

  *op = '\0';
  if (strstr(expr," * ") != NULL) *op = '*';
  if (strstr(expr," / ") != NULL) *op = '/';
  if (strstr(expr," + ") != NULL) *op = '+';
  if (strstr(expr," - ") != NULL) *op = '-';

  if (*op != '\0') {

    for (i=0; expr[i] == ' '; i++);
    for (j=0; expr[i] != ' '; i++,j++) tmps[j] = expr[i];
    tmps[j] = '\0'; remspace(tmps);

    tmp = &tmpchr;
    endp = (char **)&tmp;
    *a1 = 0;
    *d1 = strtod(tmps,endp); 
    if (*endp!=tmps) *a1 = 2; 

    if (*a1==0) {
      if (tmps[0] == '[') {
	for(i=1,j=0;(tmps[i] != '\0') && (tmps[i] != ']');i++) 
	   tmps1[j++] = tmps[i]; 
	tmps1[j] = '\0';
	if (tmps[i] == ']') {
	  *i1 = atoi(tmps1);
	  *a1 = 3;    
	}
      }
    }

    if (*a1==0) {
      *a1 = 1;
      strcpy(s1,tmps);
    }

    if (*op != '\0') {
      for (i=0;expr[i] == ' '; i++); 
      for (   ;expr[i] != ' '; i++); 
      i+=3;
      for (j=0;expr[i] != '\0';i++) tmps[j++] = expr[i];
      tmps[j] = '\0'; remspace(tmps);

      *a2 = 0; 
      *d2 = strtod(tmps,endp);
      if (*endp != tmps) *a2 = 2; 

      if (*a2==0) {
	if (tmps[0] == '[') {
	  for(i=1,j=0;(tmps[i] != '\0') && (tmps[i] != ']');i++) 
	    tmps1[j++] = tmps[i];
	  tmps1[j] = '\0';
	  if (tmps[i] == ']') {
	    *i2 = atoi(tmps1);
	    *a2 = 3;    
	  }
	}
      }

      if (*a2==0) {
	*a2 = 1;
	strcpy(s2,tmps);
      }
    } 
    else {
      s2[0] = '\0';
      *a2 = 0;
    }
    return 1;
  } else
    return 0;
}

/* ---------------------------------------------------------------------- */
 
float *calc(
  imdatatype *data,
  float  *constant,
  int    arg[100][5],
  int    maxexp,
  hstruct *header
)
{
  int i,rezx,rezy,npix;
  int j;
  float result[100];
  float *output;
  float d1,d2;
  int   repvalue = 0, reporg = 0;
  char tmps[100];

  if (getpar("IMCALC.DZEROVAL",tmps)) {
    repvalue = (int)atof(tmps); 
    if (strstr(tmps,"ORG") != NULL) reporg = 1;
  }

  rezx = data[0].header.naxis1; 
  rezy = data[0].header.naxis2;
  npix = rezx*rezy;

  output = (float *)malloc(sizeof(float)*npix);

  if (output == NULL) 
    puts("  ** Error allocating memory.");
  else {
    for (i=0;i<npix;i++) {

      for (j=maxexp;j>=0;j--) {
	switch (arg[j][3]) {
	  case 1 : d1 = data[arg[j][0]].image[i]; break;
	  case 2 : d1 = constant[arg[j][0]]; break;
	  case 3 : d1 = result[arg[j][0]];
	}

	switch (arg[j][4]) {
	  case 1 : d2 = data[arg[j][1]].image[i]; break;
	  case 2 : d2 = constant[arg[j][1]]; break;
	  case 3 : d2 = result[arg[j][1]];
	}

	switch (arg[j][2]) {
	  case 0 : result[j] = d1; break;
	  case 1 : result[j] = d1*d2; break;
	  case 2 : if (fabs(d2)>0.000001) {
		     result[j] = d1/d2;
		   } else {
		     if (reporg) repvalue = (int)d1;
		     result[j] = repvalue;
		   } break;
	  case 3 : result[j] = d1+d2; break;
	  case 4 : result[j] = d1-d2;
	}
      }

     output[i] = result[0];
    } 
  } 

  header->bitpix = -32;
  header->naxis1 = data[0].header.naxis1;
  header->naxis2 = data[0].header.naxis2;
  header->bscale = 1.0;
  header->bzero  = 0.0;
  header->card = NULL;

  return output;
}

/* ---------------------------------------------------------------------- */

void imcalc(
  char *cmd
)
{
  strarr  subexpr;
  char    outfile[100],expr[500];
  int     i,j,maxexp;
  int     arg[100][5]; /* Descriptor of the arguments to each expr.     
                          arg[*][0] = index to data for 1st argument.   
                          arg[*][1] = index to data for 2nd argument.   
                          arg[*][2] = type of operator (0=none,1=*,2=/,3=+,4=-) 
                          arg[*][3] = type of 1st argument (see analyse_expr)
			  arg[*][4] = type of 2nd argument              */
  float   constant[100];
  imdatatype  data[100];
  int     a1,a2,i1,i2;
  char    op;
  float   d1,d2;
  char    s1[100],s2[100];
  int     idbl=0,iim=0, maxdbl, maxim, status;
  hstruct outhdr; 
  float   *outdata = NULL;

  if (strstr(cmd,":=") == NULL) {
    puts("** Error: Argument must be of form  <result> := <expression>");
    return;
  }

  for (i=0; (cmd[i] != ' ') && (cmd[i] != ':'); i++) outfile[i] = cmd[i];
  outfile[i] = '\0';
  for (i=0; cmd[i] != '='; i++); 
  i++;
  for (j=0; cmd[i] != '\0'; i++) expr[j++] = cmd[i];
  expr[j] = '\0';

  parse(expr,subexpr);
  status = 1;
  outhdr.card = NULL;

  for (i=0; (subexpr[i][0] != '\0') && status; i++) {

    status = analyse_expr(subexpr[i],&a1,&a2,&op,&i1,&i2,&d1,&d2,s1,s2);

    if (status) {
      printf("[%o]: %s  %i %i\n",i,subexpr[i],a1,a2);

      arg[i][3] = a1;
      arg[i][4] = a2;

      switch (op) {
	case '\0': arg[i][2] = 0; break;
	case '*' : arg[i][2] = 1; break;
	case '/' : arg[i][2] = 2; break;
	case '+' : arg[i][2] = 3; break;
	case '-' : arg[i][2] = 4;
      } 

      switch (a1) {
	case 1 : arg[i][0] = iim; 
		 data[iim].image = floatfitsimage(&(data[iim].header),s1,FALSE); 
		 if (data[iim].image == NULL) {
		   printf("Error reading '%s'\n",s1);
		   maxim = iim; goto out;
		 }
		 iim++; break;
	case 2 : arg[i][0] = idbl; constant[idbl++] = d1; break; 
	case 3 : arg[i][0] = i1; 
      }

      switch (a2) {
	case 1 : arg[i][1] = iim; 
		 data[iim].image = floatfitsimage(&(data[iim].header),s2,FALSE); 
		 if (data[iim].image == NULL) {
		   printf("Error reading '%s'\n",s2);
		   maxim = iim; goto out;
		 }
		 iim++; break;
	case 2 : arg[i][1] = idbl; constant[idbl++] = d2; break; 
	case 3 : arg[i][1] = i2; 
      }
    } else {
      printf("  ** Error in expression '%s'\n",subexpr[i]);
      goto out;
    }
  }

  maxexp = i-1;
  maxim = iim-1;
  maxdbl = idbl-1;

  outdata = calc(data,constant,arg,maxexp,&outhdr); 
  addcard(&outhdr,"HISTORY",expr,H_COMM); 
  if (strlen(expr) > 70) addcard(&outhdr,"HISTORY",&(expr[69]),H_COMM);
  savefitsfile(&outhdr,outdata,-32,outfile); 

  freehdr(&outhdr); 
  free(outdata); 
out:
  for (i=maxim; i>=0; i--) free(data[i].image);
}

/* ==================================================================== */

float rb_getpix(
  float *buff,
  int   dx,int dy,
  float x,float y
)
{
  int ofs;
  float p;
  float fx,fy;
  int o1,o2,o3,o4;

  
  fx = x-floor(x);
  fy = y-floor(y);

  ofs = (int)x+(int)y*dx;
  o1 = ofs;
  if (x < dx-1) o2 = ofs+1 ; else o2 = ofs;
  if (y < dy-1) {
    o3 = o1+dx;
    o4 = o2+dx;
  } else {
    o3 = o1;
    o4 = o2;
  }

  p =  (1-fx)*(1-fy)*buff[o1]
      +( fx )*(1-fy)*buff[o2]
      +(1-fx)*( fy )*buff[o3]
      +( fx )*( fy )*buff[o4];
  return p; 
}

float *do_rebin(
  float *buff1,
  int   dx, int dy, int newdx, int newdy
)
{
  float *output;
  int   i,x,y;
  float x1,y1;

  output = (float *)malloc(sizeof(float)*newdx*newdy);

  for (i=0,y=0;y<newdy;y++)
    for (x=0;x<newdx;x++) {
      x1 = x*((float)dx/(float)newdx);
      y1 = y*((float)dy/(float)newdy);
      output[i++] = rb_getpix(buff1,dx,dy,x1,y1);
    }

  return output;
}

/* -------------------------------------------------------------------- */

void rebin(
  char *params
)
{
  static char inname[255] = "",outname[255] = "";
  char   tmps[255];
  static int  newdx,newdy;
  hstruct header1,header2;
  float *buff1;
  float *buff2;

  if (nargs(params)==4) {
    argn(params,1,inname);
    argn(params,2,tmps); newdx = atoi(tmps);
    argn(params,3,tmps); newdy = atoi(tmps);
    argn(params,4,outname);
  } else {
    printf("  Input image  :  "); cscanf("%s",inname);
    printf("  New X-res.   :  "); cscanf("%i",&newdx);
    printf("  New Y-res.   :  "); cscanf("%i",&newdy); 
    printf("  Output image :  "); cscanf("%s",outname);
  }

  buff1 = floatfitsimage(&header1,inname,TRUE);

  if (buff1 != NULL) {
    printf("\n  %s (%ix%i) -> %s (%ix%i)\n",inname,header1.naxis1,
                  header1.naxis2, outname,newdx,newdy);

    header2.bitpix = header1.bitpix;
    header2.naxis1 = newdx;
    header2.naxis2 = newdy;
    header2.bscale = 1;
    header2.bzero  = 0;
    sprintf(tmps,"REBIN %s (%ix%i)",inname,header1.naxis1,header1.naxis2);
    addcard(&header1,"HISTORY",tmps,H_COMM); 
    header2.card   = header1.card;

    buff2 = do_rebin(buff1,header1.naxis1,header1.naxis2,newdx,newdy);
    savefitsfile(&header2,buff2,-32,outname);

    free(buff1);
    free(buff2);
  } else
    puts("  ** Error reading input image.");

  freehdr(&header1);
}
 
/* ==================================================================== */

void rotate(
  char *params
)
{
  static float angle = 0, xc = 0, yc = 0;
  static char imname[255]="", outname[255] = "";
  char   tmps[100];
  hstruct hdr;
  int    indx,indy,outdx,outdy;
  float  *indata, *outdata;
  int    outsize = SAME;
  float  outxc,outyc;
  int    i,x,y;
  float  x1,y1,sa,ca,ysa,yca;

  if (getpar("ROTATE.OUTSIZE",tmps)) {
    if (strstr(tmps,"SAME")) outsize = SAME;
    if (strstr(tmps,"ALL")) outsize = ALL;
  }

  if (nargs(params)==5) {
    argn(params,1,imname);
    argn(params,2,tmps); xc = atof(tmps);
    argn(params,3,tmps); yc = atof(tmps);
    argn(params,4,tmps); angle = atof(tmps);
    argn(params,5,outname);
  } else {
    printf("  Input image :  "); cscanf("%s",imname);
    if (outsize == SAME) {
      printf("  X center    :  "); cscanf("%0.1f",&xc);
      printf("  Y center    :  "); cscanf("%0.1f",&yc);
    }
    printf("  Angle (degs):  "); cscanf("%0.3f",&angle);
    printf("  Output image:  "); cscanf("%s",outname);
  }

  indata = floatfitsimage(&hdr,imname,TRUE);

  if (indata != NULL) {
    indx = hdr.naxis1; indy = hdr.naxis2;
    ca = cos(angle*pi/180);  sa = sin(angle*pi/180);

    switch (outsize) {
      case ALL : sprintf(tmps, "Rotate: Angle=%0.3f deg, Outsize=ALL", angle);
		 outdx =  (int)rint(fabs(indx*ca) 
		                  + fabs(indy*sa));
		 outdy =  (int)rint(fabs(indx*sa)
		                  + fabs(indy*ca));
		 xc = indx / 2;     yc = indy / 2;
		 outxc = outdx / 2; outyc = outdy / 2;
	         break;

      case SAME : sprintf(tmps,
                 "Rotate: Angle=%0.3f deg, center=(%0.1f,%0.1f), Outsize=SAME",
		 angle,xc,yc);
		 outdx = indx; outdy = indy;
		 outxc = xc;   outyc = yc;
	         break;
    }

    printf("  %s\n",tmps);
    addcard(&hdr,"HISTORY",tmps,H_COMM);

    hdr.naxis1 = outdx;  hdr.naxis2 = outdy;  /* This is a bit dirty */
    outdata = (float *)malloc(sizeof(float)*outdx*outdy);

    for (i=0,y=0; y<outdy; y++) {
      ysa = (y-outyc)*sa;  yca = (y-outyc)*ca;

      for (x=0; x<outdx; x++) {
        x1 = (x-outxc)*ca + ysa + xc;
	y1 = yca - (x-outxc)*sa + yc;

	if (x1 >= 0 && y1>=0 && x1<indx && y1<indy)
          outdata[i++] = rb_getpix(indata,indx,indy,x1,y1);
	else
	  outdata[i++] = 0;
      }
    }

    savefitsfile(&hdr,outdata,-32,outname);
    free(indata);    
    free(outdata);
    freehdr(&hdr);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void flipx(
  char *params
)
{
  static  char imname[255] = "", outname[255] = "";
  float   *buff;
  hstruct hdr;
  int     x,y,offs;
  float   tmp;

  if (nargs(params) == 2) {
    argn(params,1,imname);
    argn(params,2,outname);
  } else {
    printf("  Input image :  "); cscanf("%s",imname);
    printf("  Output image:  "); cscanf("%s",outname);
  }

  buff = floatfitsimage(&hdr,imname,TRUE);
  if (buff != NULL) {
    addcard(&hdr,"HISTORY","FLIPX",H_COMM);

    for (y=0; y<hdr.naxis2; y++) {
      offs = y*hdr.naxis1;
      for (x=0; x < hdr.naxis1 / 2; x++) {
        tmp = buff[offs+x];
	buff[offs+x] = buff[offs+hdr.naxis1-x-1];
	buff[offs+hdr.naxis1-x-1] = tmp;
      }
    }

    savefitsfile(&hdr,buff,-32,outname);
    free(buff);
    freehdr(&hdr);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void flipy(
  char *params
)
{
  static  char imname[255] = "", outname[255] = "";
  float   *buff;
  hstruct hdr;
  int     x,y,ofs1,ofs2;
  float   tmp;

  if (nargs(params) == 2) {
    argn(params,1,imname);
    argn(params,2,outname);
  } else {
    printf("  Input image :  "); cscanf("%s",imname);
    printf("  Output image:  "); cscanf("%s",outname);
  }

  buff = floatfitsimage(&hdr,imname,TRUE);
  if (buff != NULL) {
    addcard(&hdr,"HISTORY","FLIPY",H_COMM);

    for (x=0; x<hdr.naxis1; x++) {
      ofs1 = x;  ofs2 = x+ hdr.naxis1*(hdr.naxis2-1);
      for (y=0; y < hdr.naxis2 / 2; y++) {
        tmp = buff[ofs1];
	buff[ofs1] = buff[ofs2];
	buff[ofs2] = tmp;
	ofs1 += hdr.naxis1;
	ofs2 -= hdr.naxis1;
      }
    }

    savefitsfile(&hdr,buff,-32,outname);
    free(buff);
    freehdr(&hdr);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void pixbin(
  char *params
)
{
  static char inname[255],outname[255];
  char  tmps[255];
  static int  nbin=1;
  float *buff1;
  float *buff2;
  int  dx,dy,x,y,ofs,ofs1;
  hstruct header1,header2;
  float p;


  if (nargs(params)==3) {
    argn(params,1,inname);
    argn(params,2,tmps); nbin = atoi(tmps);
    argn(params,3,outname);
  } else {
    printf("  Input image  :  "); cscanf("%s",inname);
    printf("  Bin size     :  "); cscanf("%i",&nbin); 
    printf("  Output image :  "); cscanf("%s",outname);
  }

  if (nbin == 0) {
    puts("  ** Bin size must be an integer value.");
  } else {
     buff1 = floatfitsimage(&header1,inname,TRUE);

     if (buff1 != NULL) {
       header2.naxis1 = header1.naxis1 / nbin;
       header2.naxis2 = header1.naxis2 / nbin;
       header2.bitpix = header1.bitpix;
       header2.bzero = 0;
       header2.bscale = 1;
       sprintf(tmps,"PIXBIN  %s, binsize = %i",inname,nbin);
       addcard(&header1,"HISTORY",tmps,H_COMM);
       header2.card  = header1.card;

       printf("  Binning %s (%ix%i) -> %s (%ix%i)\n",inname,header1.naxis1,
              header1.naxis2,outname,header2.naxis1,header2.naxis2);
       buff2 = (float *)malloc(header2.naxis1*header2.naxis2*sizeof(float));

       for (ofs=0,y=0;y<header2.naxis2;y++) 
         for (x=0;x<header2.naxis1;x++) {
           ofs1 = y*nbin*header1.naxis1 + x*nbin;

	   for (p=0,dy = 0; dy<nbin; dy++) {
             for (dx = 0; dx<nbin; dx++) p += buff1[ofs1+dx]; 
	     ofs1 += header1.naxis1;
           }
	   p /= (nbin*nbin);
	   buff2[ofs++] = (float)p;
	 }

       savefitsfile(&header2,buff2,-32,outname);

       free(buff1);
       free(buff2);
     } else
       puts("  ** Error reading input image.");

     freehdr(&header1);
  }
}

/* ==================================================================== */

void flat(
  char *params
)
{
  static char inname[255] = "",outname[255] = "",
              avgname[255] = "",flatname[255] = "";
  char tmps[255];
  char avgwin[50];
  float *avgim,*flatim,*inim;
  float *outim;
  hstruct h1,h2;
  int  i;
  float ffmean=0;

  avgwin[0] = '\0';
  getpar("FLAT.AVGWIN",avgwin);
  remspace(avgwin);

  if (nargs(params) == 3) {
    argn(params,1,inname);
    argn(params,2,flatname);
    argn(params,3,outname);
  } else {
    printf("  Input image     :  "); cscanf("%s",inname);
    printf("  FlatField image :  "); cscanf("%s",flatname);
    printf("  Output image    :  "); cscanf("%s",outname);
  }

  strcpy(avgname,flatname);
  strcat(avgname,avgwin);

  printf("  Averaging flatfield %s\n",avgname);
  avgim = floatfitsimage(&h1,avgname,FALSE);

  if (avgim != NULL) {
    for (i=0;i<h1.naxis1*h1.naxis2;i++) ffmean += avgim[i];
    ffmean /= i;
    free(avgim);

    inim = floatfitsimage(&h1,inname,TRUE);
    flatim = floatfitsimage(&h2,flatname,FALSE);

    if ((inim != NULL) && (flatim != NULL)) {
      if ((h1.naxis1==h2.naxis1) && (h1.naxis2==h2.naxis2)) {
        outim = (float *)malloc(sizeof(float)*h1.naxis1*h2.naxis2);
	printf("  Flatfield mean = %7.1f\n",ffmean);

	for (i=0; i<h1.naxis1*h1.naxis2; i++) {
	  if (flatim[i] > 0)
	    outim[i] = inim[i] / (flatim[i]/ffmean);
          else
	    outim[i] = inim[i];
	}

        h1.bscale = 1.0;
        h1.bzero = 0.0;
        sprintf(tmps,"FLATFIELD using %s",flatname);
        addcard(&h1,"HISTORY",tmps,H_COMM);
        savefitsfile(&h1,outim,-32,outname);
	free(outim);

      } else
        puts("  ** Error: Input and flatfield images not same size.");
    } else
      puts("  ** Error reading flatfield and/or input image.");

    if (inim != NULL) free(inim);
    if (flatim != NULL) free(flatim);
    freehdr(&h1);

  } else
    puts("  ** Error calculating flatfield-mean.");
}

/* ==================================================================== */

int getstat(
  int  nim,
  char *imname[],
  imcombtype combdata,
  float *xofs, float *yofs,
  float *scale,float *weight
)
{
  int i,ii;
  float *image;
  char tmps[10],s1[100],fullname[100];
  float avg[100];
  int  x1,x2,y1,y2;
  hstruct hdr;
  float  max,sum;

  getcorners(combdata.statwin,&x1,&y1,&x2,&y2); 

  for (i=0;i<nim;i++) {
    s1[0] = '\0';
    if (combdata.statwin[0] != '\0') {
      strcpy(s1,"[");
      itoa(x1+(int)xofs[i],tmps); strcat(s1,tmps); strcat(s1,":");
      itoa(x2+(int)xofs[i],tmps); strcat(s1,tmps); strcat(s1,",");
      itoa(y1+(int)yofs[i],tmps); strcat(s1,tmps); strcat(s1,":");
      itoa(y2+(int)yofs[i],tmps); strcat(s1,tmps); strcat(s1,"]");
    }

    strcpy(fullname,imname[i]);
    strcat(fullname,s1);
    image = floatfitsimage(&hdr,fullname,FALSE);

    for (sum = 0,ii=0;ii<hdr.naxis1*hdr.naxis2;ii++) sum+= image[ii];
    avg[i] = sum/(hdr.naxis1*hdr.naxis2);
    free(image);
  }

  max = avg[0];
  for (i=0;i<nim;i++) if (avg[i] > max) max = avg[i];
  if (max == 0) max = 1;

  switch (combdata.scale) {
    case TRUE : for (i=0;i<nim;i++) 
                  if (avg[i] > 1E-5) scale[i] = max/avg[i]; else scale[i] = 0;
		break;

    case FALSE: for (i=0; i<nim; i++) scale[i] = 1.0;
                break;
  }

  switch (combdata.weight) {
    case NONE    : for (i=0;i<nim;i++) weight[i] = 1; break;
    case AVERAGE : for (i=0;i<nim;i++) weight[i] = avg[i]/max; break;
  }

  return 1;
}

/* ==================================================================== */

void getimwin(
  hstruct hdr,
  int handle,
  int x1,int dx,int y1,int dy,
  float *buff
)
{
  int i,xx,x,y,buffsz;
  int psz;
  int yr1,yr2,xr1,xr2;
  void  *buff1;
  float *fbuff; 
  short *sbuff;
  int   *ibuff;
  int ofs1;

  psz = abs(hdr.bitpix / 8);

  for (i=0,y=y1;(y<0) && (y-y1 < dy) ;y++) for (x=0;x<dx;x++) buff[i++] = 0;
  if ((y1 < hdr.naxis2) && (y1+dy >=0)) {

    yr1 = (y1>0) ? y1 : 0;
    yr2 = (y1+dy < hdr.naxis2) ? y1+dy : hdr.naxis2-1;
    xr1 = (x1>0) ? x1 : 0;
    xr2 = (x1+dx < hdr.naxis1) ? x1+dx : hdr.naxis1-1;

    lseek(handle,80*hdr.ncards+ psz*hdr.naxis1*yr1, SEEK_SET);
    buffsz = psz*hdr.naxis1*(yr2-yr1+1);
    buff1 = malloc(buffsz);
    fbuff = sbuff = ibuff = buff1;
    read(handle,buff1,buffsz);

    for (y=yr1;y<yr2;y++) {
      ofs1 = (y-yr1)*hdr.naxis1;

      for (xx=0,x=x1;x<0;x++,xx++) buff[i++] = 0;
      if ((x1 < hdr.naxis1) && (x1+dx >= 0))
        for (x=xr1;x<xr2;x++,xx++) {
	  switch (hdr.bitpix) {
            case 16 :  buff[i++] = hdr.bzero + hdr.bscale*swap(sbuff[ofs1+x]); 
	               break;
            case 32 :  buff[i++] = hdr.bzero + hdr.bscale*iswap(ibuff[ofs1+x]); 
	               break;
            case -32:  buff[i++] = fswap(fbuff[ofs1+x]);
	               break;
          }
        }
      for (; xx<dx; xx++) buff[i++] = 0;
    }
    free(buff1);
  }

  for (; i<dx*dy; i++) buff[i] = 0;
  if (i > dx*dy) 
    printf(" ** Warning: Bad memory adressing [getimwin()] i=%i, max =%i.\n",
	    i,dx*dy);
}

/* ==================================================================== */

void cptobuff(
  float *input, float *output,
  int   dx, int dy,
  float xofs, float yofs,
  int   pixweight
)
{
  int x,y,i,j;

  if (pixweight == NEAREST) {
    i = j = 0;
    if (yofs > 0.5) i += (dx+1);
    if (xofs > 0.5) i++;
     
    for (y=0;y<dy;y++) {
      for (x=0;x<dx;x++)
        output[j++] = input[i++]; 
      i++;
    }
  } else
  if (pixweight == AVERAGE) {
    i = j = 0;

    for (y=0;y<dy;y++) {
      for (x=0;x<dx;x++,i++)
        output[j++] = ((1-xofs)*(1-yofs)* input[i]
	              +   xofs *(1-yofs)* input[i+1]
		      +(1-xofs)*   yofs * input[i+dx+1]
		      +   xofs *   yofs * input[i+dx+2]);
      i++;
    }
  }
}

/* ==================================================================== */

int reject(                         /* Sets rejected pixels to 0 */
  float *pixels,
  int npix,
  float sigma,
  int *used
)
{
  int nused,i;
  float variance,stdev,avg,f;

  for (avg=0,i=0;i<npix;i++) avg += pixels[i];
  avg /= npix;

  for (variance=0,i=0;i<npix;i++) {
    f = pixels[i]-avg;
    variance += f*f;
  }
  variance /= npix;
  stdev = sqrt(variance);

  f = stdev*sigma;

  for (nused=0,i=0;i<npix;i++) {
    if (fabs(pixels[i]-avg) > f) {
      pixels[i] = 0;
      used[i] = FALSE;
    } else {
      nused++;
      used[i] = TRUE;
    }
  }

  return nused;
}

/* ==================================================================== */

float maxpix(
  float *pixels,int npix
)
{
  int i;
  float max;

  max = pixels[0];
  for (i=0;i<npix;i++) if (pixels[i] > max) max = pixels[i];
  return max;
}

/* ==================================================================== */

float minpix(
  float *pixels,int npix
)
{
  int i;
  float min;

  min = pixels[0];
  for (i=0;i<npix;i++) if (pixels[i] < min) min = pixels[i];
  return min;
}

/* ==================================================================== */

void combbuff(
  float   *imbuff[],
  float   *scale,float *weight,
  int     nim,int nlines,
  imcombtype combdata,
  hstruct outhdr,
  float   *outimage
)
{
  float pixels[1000];
  int   used[1000];
  int dx,dy,j,ii,i,npix,nuse;
  float ff,f;

  dx = outhdr.naxis1; dy = nlines;
  npix = dx*dy;

  if (combdata.scale) {
    puts("  Scaling images..");
    for (ii=0;ii<nim;ii++) 
      for (i=0;i<npix;i++) imbuff[ii][i] = imbuff[ii][i]*scale[ii];
  }

  nuse = nim; 

  switch (combdata.combtype) {

    case MEDIAN : puts("  Combining median.");
                  for (i=0;i<npix;i++) {
                    for (ii=0;ii<nim;ii++) pixels[ii] = imbuff[ii][i];
		    if (combdata.reject == SIGMA) {
                      nuse = reject(pixels,nim,combdata.sigreject,used);
		      for (j=0,ii=0;ii<nim;ii++) 
		        if (used[ii]) pixels[j++] = pixels[ii];
		    }
		    outimage[i] = fmedian(pixels,nuse);
                  }
                  break;

    case AVERAGE: puts("  Combining average.");
                  ff = nim;
                  for (i=0;i<npix;i++) {
                    for (ii=0;ii<nim;ii++) pixels[ii] = imbuff[ii][i];
		    if (combdata.reject == SIGMA) {
		      nuse = reject(pixels,nim,combdata.sigreject,used);
		      for (ff=0,ii=0;ii<nim;ii++) ff += used[ii]*weight[ii];
		      if (ff < 1E-4) ff = nim;
		    }
		    for (f=0,ii=0;ii<nim;ii++) f+= weight[ii]*pixels[ii];
		    f /= ff;
                    outimage[i] = f;
                  }
                  break;

    case SUM    : puts("  Combining sum.");
                  for (i=0;i<npix;i++) {
                    for (ii=0;ii<nim;ii++) pixels[ii] = imbuff[ii][i];
		    if (combdata.reject == SIGMA)
		      nuse = reject(pixels,nim,combdata.sigreject,used);
		    for (f=0,ii=0;ii<nim;ii++) f+= weight[ii]*pixels[ii];
                    outimage[i] = f;
                  }
                  break;

    case C_MAX    : puts("  Combining max.");
                  for (i=0;i<npix;i++) {
                    for (ii=0;ii<nim;ii++) pixels[ii] = imbuff[ii][i];
		    if (combdata.reject == SIGMA) {
		      nuse = reject(pixels,nim,combdata.sigreject,used);
		      for (j=0,ii=0;ii<nim;ii++) 
		        if (used[ii]) pixels[j++] = pixels[ii];
	            }
		    outimage[i] = maxpix(pixels,nuse);
                  }
		  break;

    case C_MIN    : puts("  Combining min.");
                  for (i=0;i<npix;i++) {
                    for (ii=0;ii<nim;ii++) pixels[ii] = imbuff[ii][i];
		    if (combdata.reject == SIGMA) {
		      nuse = reject(pixels,nim,combdata.sigreject,used);
		      for (j=0,ii=0;ii<nim;ii++) 
		        if (used[ii]) pixels[j++] = pixels[ii];
	            }
		    outimage[i] = minpix(pixels,nuse);
                  }
                  break;
  }
}

/* ==================================================================== */

void do_comb(
  char *imlist,
  imcombtype combdata,
  char *outname
)
{
  char *ch, *imname[1000];
  float xofs[1000],yofs[1000];
  float *imbuff[1000];
  int  handle[1000];
  char tmps[1000],s1[1000];
  FILE *listfile;
  float *outimage;
  float *image;
  hstruct outhdr,imhdr[1000];
  float weight[1000],scale[1000];
  int  ok=1,i,ii,nim=0;
  int  xmin=0,xmax=0,ymin=0,ymax=0;
  int  nlines,buffsz,npixout;
  int  line;

  if ((listfile = fopen(imlist,"r")) != NULL) {
    ch = fgets(tmps,100,listfile);
    while (ch != NULL) {
      argn(tmps,1,s1);
      imname[nim] = (char *)malloc(strlen(s1)+1);
      strcpy(imname[nim],s1);
      argn(tmps,nargs(tmps)-1,s1); xofs[nim] = atof(s1);
      argn(tmps,nargs(tmps),s1); yofs[nim] = atof(s1);
      nim++;
      ch = fgets(tmps,100,listfile);
    }
    fclose(listfile);

/*    strcpy(s1,"@");
    strcat(s1,imlist);
    if ((nim = getimlst(s1,imname)) > 0) { */

    if (nim > 0) {
      outhdr.bitpix = -32;
      outhdr.bscale = 1.0;
      outhdr.bzero  = 0.0;

      for (i=0;i<nim;i++) {
        ii = getheader(&(imhdr[i]),imname[i],FALSE);
	if (ii <= 0) {
	  printf("  ** Error reading %s\n",imname[i]);
	  goto out;
	}
      }

      if (combdata.outsize == REFIMSIZE) {
        puts("  Sizing using reference image.");
	xmin = 0; xmax = imhdr[0].naxis1-1;
	ymin = 0; ymax = imhdr[0].naxis2-1;
      } else
      if (combdata.outsize == COVERALL) {
        puts("  Sizing using full area.");
	for (i=0;i<nim;i++) {
	  printf("%i %i %f %f\n",imhdr[i].naxis1,imhdr[i].naxis2,
	                         xofs[i],yofs[i]);
          if (imhdr[i].naxis1-xofs[i]-1 > xmax) 
	    xmax = (int)(imhdr[i].naxis1-xofs[i]-1);
	  if (-xofs[i] < xmin) xmin = (int)-xofs[i];
	  if (imhdr[i].naxis2-yofs[i]-1 > ymax) 
	    ymax = (int)(imhdr[i].naxis2-yofs[i]-1);
	  if (-yofs[i] < ymin) ymin = (int)-yofs[i];
	}
      } else
      if (combdata.outsize == COMMON) {
        puts("  Sizing using common area only.");
	ymax = xmax = 100000;
	ymin = xmin = -100000;

        for (i=0;i<nim;i++) {

	  if (imhdr[i].naxis1-xofs[i]-1 < xmax) 
	    xmax = (int)(imhdr[i].naxis1-xofs[i]-1);
	  if (-xofs[i] > xmin) xmin = (int)(-xofs[i]);

	  if (imhdr[i].naxis2-yofs[i]-1 < ymax) 
	    ymax = (int)(imhdr[i].naxis2-yofs[i]-1);
	  if (-yofs[i] > ymin) ymin = (int)(-yofs[i]);
	}

	if ((xmax < xmin) || (ymax < ymin)) {
	  puts("  ** Error: Images do not have sufficient area in common.");
          for (i=0;i<nim;i++) free(imname[i]); 
          return;
	}
      }

      outhdr.naxis1 = xmax-xmin+1;
      outhdr.naxis2 = ymax-ymin+1;
      outhdr.card = NULL;
      npixout = outhdr.naxis1*outhdr.naxis2;

      outimage = (float *)malloc(sizeof(float)*outhdr.naxis1*outhdr.naxis2);
      printf("  Output image dim. = %ix%i pixels.\n",
              outhdr.naxis1,outhdr.naxis2);

      if ((combdata.weight != NONE) || (combdata.scale))
        ok = getstat(nim,imname,combdata,xofs,yofs,scale,weight);
      else
        for (i=0;i<nim;i++) {
	  scale[i] = 1;
	  weight[i] = 1;
	}

      printf("  Weights: "); for (i=0;i<nim;i++) printf("%0.3f ",weight[i]);
      puts("");
      printf("  Scale  : "); for (i=0;i<nim;i++) printf("%0.3f ",scale[i]);
      puts("");

      if (combdata.reject == SIGMA)
        printf("  Rejecting pixels for sigma > %f times std. dev.\n",
	         combdata.sigreject);

      if (ok) {
        for (i=0;i<npixout;i++) outimage[i] = 0.;
	 
        buffsz = 1000000 / nim;

	if (buffsz > outhdr.naxis1*outhdr.naxis2*sizeof(float))
	  buffsz = outhdr.naxis1*outhdr.naxis2*sizeof(float);
	else
	  buffsz = (buffsz / (outhdr.naxis1*sizeof(float))) * (outhdr.naxis1*sizeof(float));
	nlines = buffsz / (sizeof(float)*outhdr.naxis1);

	for (i=0;i<nim;i++) {
	  imbuff[i] = (float *)malloc(buffsz);
	  for (ii=0;((imname[i][ii] != '\0') && (imname[i][ii] != '['));ii++)
	    tmps[ii] = imname[i][ii];
	  tmps[ii] = '\0';
	  handle[i] = open(tmps,O_RDONLY);
        }
	line = ymin;
	image = (float *)malloc(sizeof(float)*(nlines+1)*(outhdr.naxis1+1));

	ii = 0;
	do {
	  if (line+nlines > ymax) nlines = ymax-line+1;

	  for (i=0;i<nim;i++) {
  	    getimwin(imhdr[i],handle[i],
	             (int)floor(xofs[i])+(int)xmin,outhdr.naxis1+1,
	             line+(int)floor(yofs[i]),
		     nlines+1,image); 

            cptobuff(image,imbuff[i],outhdr.naxis1,nlines,
	             xofs[i]-floor(xofs[i]),
		     yofs[i]-floor(yofs[i]),
	             combdata.pixweight);
	  }

          combbuff(imbuff,scale,weight,nim,nlines,combdata,outhdr,image);
	  for (i=0;i<nlines*outhdr.naxis1;i++) outimage[ii++] = image[i]; 
	  line += nlines;
	} while (line < ymax);

	free(image);
	for (i=0;i<nim;i++) {
	  free(imbuff[i]);
	  close(handle[i]);
	}
	savefitsfile(&outhdr,outimage,-32,outname);
      } else
        puts("  Error ");
      free(outimage);
out:
      for (i=0;i<nim;i++) free(imname[i]); 
    }
  }
}

/* ==================================================================== */

void imcomb(
  char *params
)
{
  imcombtype imcombdata = { AVERAGE,NONE,3.0,NONE,FALSE,"",NEAREST,REFIMSIZE };
  static char imlist[255] = ""; 
  char  tmps[255];
  static char outname[255] = "";

  if (getpar("IMCOMB.COMBTYPE",tmps)) {
    if (strstr(tmps,"MEDIAN") == tmps) imcombdata.combtype = MEDIAN;
    if (strstr(tmps,"AVERAGE") == tmps) imcombdata.combtype = AVERAGE;
    if (strstr(tmps,"SUM") == tmps) imcombdata.combtype = SUM;
    if (strstr(tmps,"MAX") == tmps) imcombdata.combtype = C_MAX;
    if (strstr(tmps,"MIN") == tmps) imcombdata.combtype = C_MIN;
  }

  if (getpar("IMCOMB.REJECT",tmps)) {
    if (strstr(tmps,"NONE") == tmps) imcombdata.reject = NONE;
    if (strstr(tmps,"SIGMA") == tmps) imcombdata.reject = SIGMA;
  }

  if (getpar("IMCOMB.SIGREJECT",tmps)) imcombdata.sigreject = atof(tmps);

  if (getpar("IMCOMB.WEIGHT",tmps)) {
    if (strstr(tmps,"NONE") == tmps) imcombdata.weight = NONE;
    if (strstr(tmps,"AVERAGE") == tmps) imcombdata.weight = AVERAGE;
  }

  if (getpar("IMCOMB.SCALE",tmps)) 
    imcombdata.scale = (strstr(tmps,"YES") == tmps);

  if (getpar("IMCOMB.STATWIN",tmps)) strcpy(imcombdata.statwin,tmps);
  if (getpar("IMCOMB.IMLIST",tmps)) strcpy(imlist,tmps);
  if (getpar("IMCOMB.PIXWEIGHT",tmps)) {
    if (strstr(tmps,"AVERAGE") == tmps) imcombdata.pixweight = AVERAGE;
    if (strstr(tmps,"NEAREST") == tmps) imcombdata.pixweight = NEAREST;
  }
  if (getpar("IMCOMB.OUTSIZE",tmps)) {
    if (strstr(tmps,"COVERALL") == tmps) imcombdata.outsize = COVERALL;
    if (strstr(tmps,"REFIMSIZE") == tmps) imcombdata.outsize = REFIMSIZE;
    if (strstr(tmps,"COMMON") == tmps) imcombdata.outsize = COMMON;
  }

  if (nargs(params) == 2) {
    argn(params,1,imlist);
    argn(params,2,outname);
  } else {
    printf("  File with list of images :  "); cscanf("%s",imlist);
    printf("  Output image             :  "); cscanf("%s",outname);
  }

  do_comb(imlist,imcombdata,outname);
}

/* ==================================================================== */
