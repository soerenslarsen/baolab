int xfit(       /* Note: The user can modify the number of coefficients.   */
                /*       Returns the number of coefficients fitted.        */
		/*       Negative value returned indicates no fit was done */
		/*       -1 : Exit with X                                  */
		/*       -2 : Exit with I ("interrupt")                    */
  float *,      /* X values */
  float *,      /* Y values */
  int   ,       /* number of datapoints */
  float *a,     /* Coefficients */
  int   na,     /* number of coefficients */
  int   maxna,  /* Maximum number of coefficients allowed */
  char *title   /* Title to put on plot */
) ;
