#include "fitsutil.h"
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "baostr.h"
#include "baolab.h"
#include "wutil.h"

extern int median(int *, int);                     /* in baolab2.c */
extern float *do_convol(float *, hstruct *,
                        float *, int, int, float); /* in baolab2.c */
extern int selectspots(float *, float *, int *);   /* in baolab5.c */

/* ==================================================================== */

extern void findmax(
  long*,
  int,int,
  int,  
  float*, float*
);

static float getcount(
  int   mode,
  float *data,
  int   naxis1, int naxis2,
  float xc, float yc, 
  float r1, float r2,
  int  *npix
)
{
  int xx,yy,x,y,n;
  float retval,d;
  int *tmpbuff;

  n = 0; retval = 0;
  if (mode == MEDIAN) tmpbuff = (int *)malloc(4*sqr(2*(int)r2+2));

  for (yy=-(int)r2-1; yy<=(int)r2+1; yy++)
    for (xx=-(int)r2-1; xx<=(int)r2+1; xx++) {
      x = (int)xc+xx;
      y = (int)yc+yy;
      d = sqrt(sqr(x-xc)+sqr(y-yc));

      if ((d <= r2) && (d >= r1)) {
	switch (mode) {
	  case AVERAGE:
	  case SUM    : retval += (float)data[x+y*naxis1]; break;
	  case MEDIAN : tmpbuff[n] = (int)data[x+y*naxis1]; break;
	}
        n++;
      }
    }

  *npix = n;

  switch (mode) {
    case MEDIAN : retval = median(tmpbuff,n);
                  free(tmpbuff);
	          break;

    case AVERAGE: retval /= (float)n;
                  break;
  }

  return retval;
}

/* ==================================================================== */

void do_apphot(
  float *data,
  int   naxis1, int naxis2,
  float *starx, float *stary,
  int   nstars,
  FILE *outfile
)
{
  int i,n,nbgr;
  char  tmps[100];
  float aprad1 = 5, aprad2 = 10;
  float bkrad = 5;
  int   bkmode = AVERAGE;
  float apstep = 1.0;
  float aprad;
  float count,bkcount,mag;

  if (getpar("APPHOT.APRAD1",tmps)) aprad1 = atof(tmps);
  if (getpar("APPHOT.APRAD2",tmps)) aprad2 = atof(tmps);
  if (getpar("APPHOT.APSTEP",tmps)) apstep = atof(tmps);
  if (getpar("APPHOT.BKRAD",tmps)) bkrad = atof(tmps);
  if (getpar("APPHOT.BKMODE",tmps)) {
    bkcount = atof(tmps);
    if (bkcount > 0) bkmode = VALUE;
    if (strstr(tmps,"AVERAGE") == tmps) bkmode = AVERAGE; else
    if (strstr(tmps,"MEDIAN") == tmps) bkmode = MEDIAN; 
  }

  if (aprad1 > aprad2) {
    puts("  ** APPHOT error:  APRAD1 must be <= APRAD2");
    return;
  }

  if (apstep <= 0) {
    puts("  ** APPHOT error: APSTEP must be > 0");
    return;
  }

  printf("  APRAD1 = %0.1f, APRAD2 = %0.1f, APSTEP = %0.2f, BKRAD = %0.1f\n",
           aprad1,aprad2,apstep,bkrad);

  for (aprad = aprad1; aprad <= aprad2; aprad += apstep) {
    printf(" %7.3f",aprad);
    if (outfile != NULL) fprintf(outfile," %7.3f",aprad);
  }
  puts("");
  if (outfile != NULL) { fprintf(outfile,"\n"); fflush(outfile); }

  for (i=0; i<nstars; i++) {
    aprad = aprad1;
    do {
      count = getcount(SUM,data,naxis1,naxis2,starx[i],stary[i],-0.1,aprad,&n);
      if (bkmode != VALUE)
        bkcount = getcount(bkmode,data,naxis1,naxis2,starx[i],stary[i],
                          aprad, aprad+bkrad,&nbgr);
      count -= bkcount * (float)n;
      if (count < 1) count = 1;
      mag = -2.5 * log10(count);

      printf(" %7.3f",mag); fflush(stdout);
      if (outfile != NULL) { fprintf(outfile," %7.3f",mag); fflush(outfile); }
      aprad += apstep;
    } while (aprad <= aprad2);

    puts("");
    if (outfile != NULL) { fprintf(outfile,"\n"); fflush(outfile); }
  }
}

/* ==================================================================== */

/* int getcoolst(
  char *starlist,
  float **starx, float **stary
)
{
  FILE *starfile;
  int  i,nstars=0;
  char *ch;
  char s1[100],tmps[100];

  starfile = fopen(starlist,"r");
  if (starfile != NULL) {
    ch = fgets(tmps,100,starfile);
    while (ch != NULL) {
      nstars++;
      ch = fgets(tmps,100,starfile);
    }

    rewind(starfile);
    *starx = (float *)malloc(sizeof(float)*nstars);
    *stary = (float *)malloc(sizeof(float)*nstars);

    for (i=0; i<nstars; i++) {
      fgets(tmps,100,starfile);
      sglspc(tmps);
      argn(tmps,1,s1); (*starx)[i] = atof(s1);
      argn(tmps,2,s1); (*stary)[i] = atof(s1);
    }

    fclose(starfile);
  } 

  return nstars;
}
*/

/* ==================================================================== */

void apphot(char *params)
{
  char  tmps[100];
  static char imname[255] = "";
  static char starlist[255] = "";
  char   outname[255] = "";
  static float xoffs = 0, yoffs = 0;
  float *starx, *stary;
  int    i,nstars;
  float *data;
  hstruct hdr;
  FILE   *outfile = NULL;

  remeqspc(params);

  if (getpar("APPHOT.OUTPUT",tmps)) strcpy(outname,tmps);

/*  for (i=1; i<=nargs(params); i++)  {
    argn(params,i,tmps);
    if (strstr(tmps,"output=") == tmps) { n0++; strcpy(outname,tmps+7); }
  } */

  if (nargs(params) >= 2) {
    argn(params,1,imname);
    argn(params,2,starlist);

    if (nargs(params) > 3) {
      argn(params,3,tmps); xoffs = atof(tmps);
      argn(params,4,tmps); yoffs = atof(tmps);
    }
  } else {
    printf("  Input image :  "); cscanf("%s",imname);
    printf("  Star list   :  "); cscanf("%s",starlist);
    printf("  X offset    :  "); cscanf("%0.2f",&xoffs);
    printf("  Y offset    :  "); cscanf("%0.2f",&yoffs);
  }

  nstars = getcoolst(starlist,&starx,&stary);

  if (nstars > 0) {
    for (i=0; i<nstars; i++) {
      starx[i] += xoffs;
      stary[i] += yoffs;
    }

    printf("  Doing photometry on %i stars.\n",nstars);

    if (outname[0] != '\0')
      outfile = fopen(outname,"w");

    data = floatfitsimage(&hdr,imname,FALSE);
    if (data != NULL) {
      do_apphot(data,hdr.naxis1,hdr.naxis2,starx,stary,nstars,outfile);
      free(data);
    } else
      puts(IM_READ_ERR);

    free(starx);
    free(stary);
    if (outfile != NULL) fclose(outfile);

  } else
    puts("  ** Error: Could not read star list.");
}

/* ==================================================================== */

void mapphot(char *params)
{
  char  tmps[255],s1[100],imname[255];
  static char imlist[255] = "";
  static char starlist[255] = "";
  char   outname[255] = "";
  static float xoffs = 0, yoffs = 0;
  float *starx, *stary;
  float *starx1, *stary1;
  int    i,nstars;
  float *data;
  hstruct hdr;
  FILE   *imfile, *outfile = NULL;
  char   *ch;

  remeqspc(params);

  if (getpar("MAPPHOT.OUTPUT",tmps)) strcpy(outname,tmps);

/*  for (i=1; i<=nargs(params); i++)  {
    argn(params,i,tmps);
    if (strstr(tmps,"output=") == tmps) { n0++; strcpy(outname,tmps+7); }
  } */

  if (nargs(params) >= 2) {
    argn(params,1,imlist);
    argn(params,2,starlist);
  } else {
    printf("  List of images:  "); cscanf("%s",imlist);
    printf("  Star list     :  "); cscanf("%s",starlist);
  }

  nstars = getcoolst(starlist,&starx,&stary);

  if (nstars > 0) {
    starx1 = (float *)malloc(sizeof(float)*nstars);
    stary1 = (float *)malloc(sizeof(float)*nstars);

    if (outname[0] != '\0')
      outfile = fopen(outname,"w");

    imfile = fopen(imlist,"r");
    if (imfile != NULL) {
      printf("  Doing photometry on %i stars.\n",nstars);

      ch = fgets(tmps,255,imfile);

      while (ch != NULL) {
        argn(tmps,1,imname);
	argn(tmps,2,s1); xoffs = atof(s1);
	argn(tmps,3,s1); yoffs = atof(s1);
    
	for (i=0; i<nstars; i++) {
	  starx1[i] = starx[i]+xoffs;
	  stary1[i] = stary[i]+yoffs;
	}

	data = floatfitsimage(&hdr,imname,FALSE);
	if (data != NULL) {
	  printf("\n  %s : offs = (%0.2f,%0.2f)\n",imname,xoffs,yoffs);
	  if (outfile != NULL)
	    fprintf(outfile,"\n  %s : offs = (%0.2f,%0.2f)\n",imname,xoffs,yoffs);
	    
	  do_apphot(data,hdr.naxis1,hdr.naxis2,starx1,stary1,nstars,outfile);
	  free(data);
	} else
	  puts(IM_READ_ERR);

	ch = fgets(tmps,255,imfile);
      }
    } else
      puts("  ** Error: Could not read image list.");

    free(starx);
    free(stary);
    free(starx1);
    free(stary1);
    if (outfile != NULL) fclose(outfile);

  } else
    puts("  ** Error: Could not read star list.");
}

/* ==================================================================== */

void do_plotphot(
  float *imdata,
  int   imdx, int imdy,
  int   x, int y
)
{
  int wdx,wdy;
  float ap1 = 1, ap2 = 20.0, bkrad = 5.0;
  int  bkmode = AVERAGE;
  float apstep = 0.5;
  char  tmps[100];
  float *mags;
  float ap;
  int  i,nmag,n1,n,nbg;
  float count,bkcount;
  float min,max;
  int   x1,y1,x2,y2;

  if (getpar("PLOTPHOT.APRAD1",tmps)) ap1 = atof(tmps);
  if (getpar("PLOTPHOT.APRAD2",tmps)) ap2 = atof(tmps);
  if (getpar("PLOTPHOT.BKRAD",tmps))  bkrad = atof(tmps);
  if (getpar("PLOTPHOT.APSTEP",tmps)) apstep = atof(tmps);
  if (getpar("PLOTPHOT.BKMODE",tmps)) {
    bkcount = atof(tmps);
    if (bkcount > 0) bkmode = VALUE;
    if (strstr(tmps,"AVERAGE") == tmps) bkmode = AVERAGE; else
    if (strstr(tmps,"MEDIAN") == tmps) bkmode = MEDIAN; 
  }

  if (ap1 > ap2) {
    puts("  ** PLOTPHOT Error: APRAD1 must be <= APRAD2");
    return;
  }

  nmag = (int)((ap2 - ap1) / apstep);
  mags = (float *)malloc(sizeof(float)*(nmag+1));

  printf(" (x,y)center : (%i,%i)\n",x,y);
  
  ap = ap1; i = 0;
  do {
    count = getcount(SUM,imdata,imdx,imdy,(float)x,(float)y,-0.1,ap,&n);
    if (bkmode != VALUE)
      bkcount = getcount(bkmode,imdata,imdx,imdy,(float)x,(float)y,
                        ap, ap+bkrad,&nbg);
    count -= bkcount * (float)n;
    if (count < 0) count = 1;
    mags[i] = -2.5 * log10(count);

    printf("  %0.1f :  %0.3f\n",ap,mags[i]);

    if (i==0) { 
      min = mags[i]; max = mags[i]; 
    } else {
      if (mags[i] < min) min = mags[i];
      if (mags[i] > max) max = mags[i];
    }

    ap += apstep;
    i++;
  } while (ap <= ap2);
  n1 = i;

  puts("");

  wdx = width(WIN[PLOTWIN]);
  wdy = height(WIN[PLOTWIN]);

  XClearWindow(DISPLAY,WIN[PLOTWIN]);

  if (max==min) max = min+1;

  make_xaxis(WIN[PLOTWIN],GC1[PLOTWIN],ap1,ap2);
  make_yaxis(WIN[PLOTWIN],GC1[PLOTWIN],max,min);

  for (ap=ap1+apstep,i=1; i<n1; i++, ap+=apstep) {
    x1 = 50 + (int)((wdx-70) * ((ap-apstep)-ap1)/(ap2-ap1));
    x2 = 50 + (int)((wdx-70) * (ap-ap1)/(ap2-ap1));
    y1 = 20 + (int)((wdy-50) * (mags[i-1] - min)/(max-min));
    y2 = 20 + (int)((wdy-50) * (mags[i] - min)/(max-min));

    XDrawLine(DISPLAY,WIN[PLOTWIN],GC1[PLOTWIN],x1,y1,x2,y2);
  }

  XFlush(DISPLAY);
  free(mags);
}

/* ==================================================================== */

void plotphot(char *params)
{
  int    i;
  Window buttons[4],butwin;
  GC     butgc;
  XGCValues values;
  char   *buttxt[2] = {"Photometry","Quit"};
  int    quit = FALSE;
  XEvent event;
  XImage *ximg;
  int    wdx,wdy,x,y;
  int    imx,imy;
  float *imdata;
  hstruct hdr;

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }
  
  if (IMAGE->fname[0] == '\0') {
    puts(NO_IM_ERR);
    return;
  }

  imdata = floatfitsimage(&hdr,IMAGE->fname,FALSE);
  if (imdata == NULL) {
    puts(IM_READ_ERR);
    return;
  }

  if (PLOTWIN == -1) {
    if (wopen("BAOLab Plot 0",&(WIN[0]),&(GC1[0]),&(GC2[0]))) {
      PLOTWIN = 0;
      WEXIST[0] = 1;
    } else
      puts(CANT_OPEN_WIN);
  }

  if (PLOTWIN != -1) {
    if (IMAGE->mapped) {
      XSelectInput(DISPLAY,IMAGE->window, ButtonPressMask | ButtonReleaseMask |
				     Button1MotionMask |
		       Button3MotionMask | KeyPressMask);
      wdx = width(IMAGE->window);
      wdy = height(IMAGE->window);

      createbutwins(xpos(IMAGE->window),
                    ypos(IMAGE->window)+height(IMAGE->window)+10,
                    &butwin,buttons,2,&butgc);
      for (i=0; i<2; i++) drawbutwin(buttons[i],butgc,buttxt[i],FALSE);  

      x = 10; y = 10;
      ximg = XGetImage(DISPLAY,IMAGE->window,x-5,y-5,11,11,AllPlanes,ZPixmap);

      XGetGCValues(DISPLAY,IMAGE->gc,GCForeground,&values);
      setcolor(IMAGE->gc,"red");

      do {
	XNextEvent(DISPLAY,&event);

	if (event.xany.window == IMAGE->window) {
	  XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,ximg,
			 0,0,x-5,y-5,11,11);
	  XDestroyImage(ximg);

	  switch (event.type) {
	     case MotionNotify:
		     x = event.xmotion.x;
		     y = event.xmotion.y;
		    break;
	  }
	  if (x<5) x = 5;  if (x > wdx-6) x = wdx-6;
	  if (y<5) y = 5;  if (y > wdy-6) y = wdy-6;

	  ximg = XGetImage(DISPLAY,IMAGE->window,x-5,y-5,11,11,AllPlanes,ZPixmap);
	  cross2(IMAGE->window,IMAGE->gc,x,y,5);
	}

	for (i=0; i<2; i++)
	  if (event.xany.window == buttons[i])
	    switch (event.type) {
	      case Expose: 
		       drawbutwin(buttons[i],butgc,buttxt[i],FALSE); 
		       break;
	      case EnterNotify:
		       drawbutwin(buttons[i],butgc,buttxt[i],TRUE);
		       break;
	      case LeaveNotify:
		       drawbutwin(buttons[i],butgc,buttxt[i],FALSE);
		       break;
	      case ButtonPress:
		       switch (i) {
			 case 0 : if (IMAGE->zoom > 0) {
				    imx = x / IMAGE->zoom;
				    imy = y / IMAGE->zoom;
			          } else {
				    imx = -x * IMAGE->zoom;
				    imy = -y * IMAGE->zoom;
				  }
			          do_plotphot(imdata,hdr.naxis1,hdr.naxis2,
			                      imx,imy);
			          break;
			 case 1 : quit = TRUE; break;
		       }
		       break;
	    }
      } while (!quit);

      XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,ximg, 0,0,x-5,y-5,11,11);

      XFreeGC(DISPLAY,butgc);
      XDestroyWindow(DISPLAY,butwin);
      XChangeGC(DISPLAY,IMAGE->gc,GCForeground,&values);
      XDestroyImage(ximg);
      XFlush(DISPLAY);
    }
  }

  free(imdata);
}

/* ==================================================================== */

void corrcoor(
  float *imdata,
  int    imdx, int imdy,
  float *xarr, float *yarr,
  int    ndat
)
{
  int i;
  int boxsz = 10;
  char tmps[255];
  int   xx,yy;
  int   min;
  float p,Emi, Emxi, Emyi;

  if (getpar("MKSTARLIST.BOXSIZE",tmps)) boxsz = atoi(tmps);
  if (boxsz < 2) boxsz = 2;
  printf("  Using boxsize = %i pixels for centering.\n",boxsz);

  for (i=0; i<ndat; i++) {
    min = 100000;
    for (yy = (int)yarr[i] -boxsz/2; yy <= (int)yarr[i] +boxsz/2; yy++)
      for (xx = (int)xarr[i] -boxsz/2; xx <= (int)xarr[i] +boxsz/2; xx++) {
        if (imdata[xx+imdx*yy] < min) min = imdata[xx+imdx*yy];
      }

    Emi = 0; Emyi = Emxi = 0;
    for (yy = (int)yarr[i] -boxsz/2; yy <= (int)yarr[i] +boxsz/2; yy++) {
      for (xx = (int)xarr[i] -boxsz/2; xx <= (int)xarr[i] +boxsz/2; xx++) {
        p = imdata[xx+imdx*yy]-min;
        Emi  += p;
	Emxi += xx*p;
	Emyi += yy*p;
      }
    }
    
    xarr[i] = (Emi > 0) ? Emxi / Emi : xarr[i];
    yarr[i] = (Emi > 0) ? Emyi / Emi : yarr[i];
  }
}

/* ==================================================================== */

void mkstarlist(char *params)
{
  float  *imdata;
  hstruct hdr;
  float   xarr[1000],yarr[1000];
  int     i,ndat;
  static char outname[255] = "";
  FILE   *outfile;

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }
  
  if (IMAGE->fname[0] == '\0') {
    puts(NO_IM_ERR);
    return;
  }

  imdata = floatfitsimage(&hdr,IMAGE->fname,FALSE);
  if (imdata == NULL) {
    puts(IM_READ_ERR);
    return;
  }

  if (nargs(params) == 1) {
    argn(params,1,outname);
  } else {
    printf("  Output list name:  "); cscanf("%s",outname);
  }

  outfile = fopen(outname,"w");
  if (outfile == NULL) {
    puts(FILE_OPEN_ERR);
    return;
  }

  if (IMAGE->mapped) {
    
    if (selectspots(xarr,yarr,&ndat)) {
      corrcoor(imdata,hdr.naxis1,hdr.naxis2,xarr,yarr,ndat);
      puts("  Corrected coordinates: ");
      for (i=0; i<ndat; i++) {
        printf("%0.2f %0.2f\n",xarr[i],yarr[i]);
        fprintf(outfile,"%0.2f %0.2f\n",xarr[i],yarr[i]);
      }
    }
  }

  fclose(outfile);
  free(imdata);
}

/* ==================================================================== */

void freepsf(psftype psf)
{
  free(psf.data);
}

/* ==================================================================== */

int CW = 3;    /* Number of pixels to shift when cross-correlating */
               /* the PSF's from individual images.                */

static void rebinpsf(
  float *psf,
  int    dx, int dy, int binsz,
  float *psf1
)
{
  int i,x,y,xx,yy;

  for (i=0,y=0; y < binsz*dy; y++)
    for (x=0; x < binsz*dx; x++) {
      xx = x / binsz;
      yy = y / binsz;

      psf1[i] = psf[xx+yy*dx];
      i++;
    } 
}

static void crosscorrpsf(
  float *refdata, float *data1,
  int   dx, int dy, int psfbin,
  long  *sum
)
{
  int xx,yy,x,y,i;
  int ofs1,ofs2;
  float f;

  for (i=0,yy=-CW*psfbin; yy<=CW*psfbin; yy++) {
    for (xx=-CW*psfbin; xx<=CW*psfbin; xx++) {
      f = 0;
      sum[i] = 0;

      for (y=CW*psfbin; y<(dy-CW)*psfbin; y++) {
        ofs1 = y*dx*psfbin;
	ofs2 = ofs1 - yy*dx*psfbin - xx;

        for (x=CW*psfbin; x < (dx-CW)*psfbin; x++) {
	  f += (float)((long)refdata[ofs1+x] 
	             * (long)data1[ofs2+x]);
	}
      }
      sum[i] = (long)( f / 1000);
      i++;
    }
  }
}

static void addpsf(
  psftype psf,
  float  *data,
  float   maxx, float maxy
)
{
  int x,y,ofs1,ofs2;
  int binsz,dx,dy;

  binsz = psf.binsize;
  dx    = psf.dx;
  dy    = psf.dy;

  for (y=0; y<binsz*dy; y++) {
    ofs1 = y*binsz*dx;
    ofs2 = (int)(y+(CW-maxy)*binsz)*binsz*(dx+2*CW) + (int)((CW-maxx)*binsz);

    for (x=0; x<binsz*dx; x++) psf.data[ofs1+x] += (float)data[ofs2+x];
  }
}

static psftype createpsf(   /* Sky background subtraction not implemented */
  float *imdata,            /* yet!                                       */
  int    imdx, int imdy,
  float *xarr, float *yarr,
  int    nstars, int psfsz, int psfbin
)
{
  int i,x,y,x1,y1;
  int j,jmax;
  int npix;
  psftype psf;
  float *refdata, *tmpdata, *tmpdata1;
  long  *sum;
  float tot,max;
  float maxx,maxy;

  psf.dx = (psfsz / 2)*2 + 1;
  psf.dy = psf.dx;
  psf.binsize = psfbin;
  npix   = psf.dx * psf.dy;
  psf.data = (float *)malloc(sizeof(float)*npix*sqr(psfbin));
  for (i=0; i<npix*sqr(psfbin); i++) psf.data[i] = 0.0;

  tmpdata  = 
    (float *)malloc(sizeof(float)*(2*CW+psf.dx)*(2*CW+psf.dy));

  tmpdata1 = 
    (float *)malloc(sizeof(float)*(2*CW+psf.dx)*(2*CW+psf.dy)*sqr(psfbin));

  refdata  = 
    (float *)malloc(sizeof(float)*(2*CW+psf.dx)*(2*CW+psf.dy)*sqr(psfbin));

  sum      = 
    (long *)malloc(sizeof(long)*sqr(2*CW+psf.dx));

  y1 = x1 = psfsz / 2 + CW;
  max = 0; jmax = 0;

  for (j=0; j<nstars; j++) {
    tot = 0;
    for (i=0, y = (int)yarr[j]-y1; y<=(int)yarr[j]+y1; y++)
      for (x = (int)xarr[j]-x1; x<=(int)xarr[j]+x1; x++) {
	tmpdata[i] = imdata[x+imdx*y];
	tot += (float)tmpdata[i++];
      }

    if (tot > max) { 
      jmax = j; max = tot; 
      rebinpsf(tmpdata,psf.dx+2*CW,psf.dy+2*CW,psfbin,refdata);
    }
  }

  addpsf(psf,refdata,0.0,0.0); 

  for (j=0; j<nstars; j++) {
    if (j != jmax) {
      for (i=0, y = (int)yarr[j]-y1; y<=(int)yarr[j]+y1; y++)
	for (x = (int)xarr[j]-x1; x<=(int)xarr[j]+x1; x++)
          tmpdata[i++] = imdata[x+imdx*y];

      rebinpsf(tmpdata,psf.dx+2*CW,psf.dy+2*CW,psfbin,tmpdata1);
      crosscorrpsf(refdata,tmpdata1,psf.dx+2*CW,psf.dy+2*CW,psfbin,sum);

      /* baolab2 */ findmax(sum,psfbin*CW,psfbin*CW, FITMAX,&maxx,&maxy); 

      maxx /= 1.0*psfbin;
      maxy /= 1.0*psfbin;
      printf(" %0.2f %0.2f :  %0.2f  %0.2f\n",xarr[j],yarr[j],maxx,maxy);

      addpsf(psf,tmpdata1,maxx,maxy);           /* 'psf' contains all  */
                                                /* size information.   */
    }
  }

  free(tmpdata);
  free(tmpdata1);
  free(refdata);
  free(sum);

  return psf;
}

/* ==================================================================== */

static void maxpix(
  float *buff,
  hstruct *hdr,
  float   *posx, float *posy
)
{
  int x,y,offs;
  int max;

  max = buff[0];
  *posx = 0; *posy = 0;

  for (offs = 0,y=0; y<hdr->naxis2; y++)
    for (x=0; x<hdr->naxis1; x++) {
      if (buff[offs] > max) {
        *posx = x;
	*posy = y;
	max   = buff[offs];
      }
      offs++;
    }
}

/* -------------------------------------------------------------------- */

static void subtpsf(
  float *imdata,
  hstruct *hdr,
  psftype psf,
  float   posx, float posy
)
{
}

/* -------------------------------------------------------------------- */

static int locate(   /* Find stars in image */
                     /* using the psf.      */
		     /* NOT FINISHED YET - THIS IS COMPLICATED !!!  */
  float   *imdata,
  hstruct *hdr,
  psftype  psf,
  float   **xarr, float **yarr
)
{
  float *psfscl;
  long  *ldata;
  int   x,y,xx,yy,psfn,j,i,dx,dy;
  float s;
  float *buff;
  float fitx,fity,posx,posy;

  dx = (psf.dx / 2) * 2 + 1;
  dy = (psf.dy / 2) * 2 + 1;

  psfscl = (float *)malloc(sizeof(float)*psf.dx*psf.dy);
  ldata  = (long *)malloc(sizeof(long)*dx*dy);
  s = 0;

  puts("PSF: ");
  for (y=0; y<psf.dy; y++) {      /* Rebin the PSF to the image resolution */
    for (x=0; x<psf.dx; x++) {
      psfscl[x+y*psf.dx] = 0;

      for (yy=0; yy<psf.binsize; yy++)
        for (xx=0; xx<psf.binsize; xx++)
	  psfscl[x+y*psf.dx] += 
	     psf.data[x*psf.binsize + xx + 
	              (y*psf.binsize+yy) *psf.dx*psf.binsize];

      s += psfscl[x+y*psf.dx];
      printf("%0.1f ",psfscl[x+y*psf.dx]);
    }
    puts("");
  }

  psfn = psf.dx * psf.dy;
  for (i = 0; i<psfn; i++) psfscl[i] /= s;   /* Normalise PSF */

  puts("  Convolving image with PSF..");
  buff = (float *)do_convol(imdata,hdr,psfscl,psf.dx,psf.dy,1.0);
  puts("  Done.");

  for (i=0; i<25; i++) {         /* Just for testing: Find 25 "stars" */
    maxpix(buff,hdr,&posx,&posy);

    for (j=0, y = (int)posy-dy/2; y<= posy+dy/2; y++)
      for (x = (int)posx-dx/2; x<= posx+dx/2; x++)
        ldata[j++] = buff[x+y*hdr->naxis1];

    findmax(ldata,dx/2,dy/2,FITPOLY,&fitx,&fity);
    posx = posx+fitx;
    posy = posy+fity;
    subtpsf(imdata,hdr,psf,posx,posy);
  }

  free(buff);
  free(psfscl);
  free(ldata);
}

/* ==================================================================== */

void find(char *params)
{
  static  char imname[255] = "", psflist[255] = "", outname[255] = "";
  char    tmps[255];
  float  *imdata;
  hstruct hdr;
  int     nstars;
  float  *xarr, *yarr;
  psftype psf;
  int     psfsz = 10, psfbin = 2;

  float   tmp[10000];
  int     x,y,i;

  if (getpar("FIND.PSFSIZE",tmps)) psfsz = atoi(tmps);
  if (getpar("FIND.PSFBIN",tmps)) psfbin = atoi(tmps);

  if (nargs(params) == 3) {
    argn(params,1,imname);
    argn(params,2,psflist);
    argn(params,3,outname);
  } else {
    printf("  Image to locate stars in:  "); cscanf("%s",imname);
    printf("  File with PSF star list :  "); cscanf("%s",psflist);
    printf("  Output file             :  "); cscanf("%s",outname);
  }

  imdata = floatfitsimage(&hdr,imname,FALSE);
  if (imdata != NULL) {
    nstars = getcoolst(psflist,&xarr,&yarr);
    if (nstars > 0) {
      psf = createpsf(imdata,hdr.naxis1,hdr.naxis2,xarr,yarr,
                      nstars,psfsz,psfbin);

      for (i=0,y=0; y<psf.binsize*psf.dx; y++)
        for (x=0; x<psf.binsize*psf.dx; x++) {
	  tmp[i] = (float)psf.data[i];
	  i++;
	}

      free(xarr);
      free(yarr);

      nstars = locate(imdata,&hdr,psf,&xarr,&yarr);  /* Find stars in image */
                                                /* using the psf.      */
/*
      hdr.naxis1 = psf.dx*psf.binsize;
      hdr.naxis2 = psf.dy*psf.binsize;
      hdr.bitpix = 16;
      hdr.bscale = 1.0;
      hdr.bzero  = 0.0;
      hdr.card   = NULL;
      savefitsfile(&hdr,tmp,16,outname);
*/
        
      freepsf(psf);
    } 
    free(imdata);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */
