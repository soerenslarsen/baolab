#include <stdio.h>
#include <stdlib.h>
/*
#if defined(OS_Darwin)
  #include <sys/types.h>
  #include <sys/malloc.h>
#else
  #include <malloc.h>
#endif
*/
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xmu/Drawing.h>
#include  <math.h>

#define FALSE 0
#define TRUE  1

#define WUTIL_MAIN

Display *DISPLAY = NULL;

extern void itoa(int, char*);

/* ==================================================================== */

int wopen(
  char *title,
  Window  *_win,
  GC      *_gc1, GC *_gc2
)
{
  Window  win;
  GC      gc1,gc2;
  XGCValues gcval1,gcval2;
  int     screen,scrw,scrh;
  XSetWindowAttributes setattr;
  Font    font;

  XTextProperty winname;
  XSizeHints *size_hints;

  if (DISPLAY != NULL) {
    screen = DefaultScreen(DISPLAY);
    scrw = DisplayWidth(DISPLAY,screen);
    scrh = DisplayHeight(DISPLAY,screen);

    size_hints = XAllocSizeHints();
    size_hints->flags = PPosition | PSize | PMinSize;
    size_hints->min_width = 200;
    size_hints->min_height= 200;

    XStringListToTextProperty(&title,1,&winname);

    win = XCreateSimpleWindow(DISPLAY,XDefaultRootWindow(DISPLAY),0,0,
	       scrw/2, scrh/2,0,BlackPixel(DISPLAY,screen),
				WhitePixel(DISPLAY,screen));

    XSetWMProperties(DISPLAY,win,&winname,NULL,NULL,0,size_hints,
		     NULL,NULL);

    setattr.backing_store = Always;
    XChangeWindowAttributes(DISPLAY,win,CWBackingStore,&setattr);

    gcval1.foreground = BlackPixel(DISPLAY,screen);
    gcval1.background = WhitePixel(DISPLAY,screen);
    gcval1.line_width = 1;
    gc1 = XCreateGC(DISPLAY,win, (GCForeground | GCBackground | GCLineWidth),
		   &gcval1);

    gcval2.foreground = BlackPixel(DISPLAY,screen);
    gcval2.background = WhitePixel(DISPLAY,screen);
    gcval2.line_width = 2;
    gc2 = XCreateGC(DISPLAY,win, (GCForeground | GCBackground | GCLineWidth),
		   &gcval2);

    XSelectInput(DISPLAY,win,StructureNotifyMask | ExposureMask | ButtonPress);
    XMapWindow(DISPLAY,win); 

    font = XLoadFont(DISPLAY,"9x15");
    XSetFont(DISPLAY,gc1,font);
    XSetFont(DISPLAY,gc2,font);

    XFlush(DISPLAY);

    *_win = win;
    *_gc1 = gc1;
    *_gc2 = gc2;
    return 1;
  } else
    return 0;
}
   
/* ==================================================================== */

void wclose(
  Window  win,
  GC      gc1,
  GC      gc2
)
{
  XFreeGC(DISPLAY,gc1);
  XFreeGC(DISPLAY,gc2);
  XDestroyWindow(DISPLAY,win);
  XFlush(DISPLAY);
}

/* ==================================================================== */

void cross(
  Window win,
  GC     gc,
  int    x,int y,int s
)
{
  XDrawLine(DISPLAY,win,gc,x-s,y-s,x+s+1,y+s+1);
  XDrawLine(DISPLAY,win,gc,x-s,y+s,x+s+1,y-s-1);
  XFlush(DISPLAY);
}

/* ==================================================================== */

void cross2(
  Window win,
  GC     gc,
  int    x,int y,int s
)
{
  XDrawLine(DISPLAY,win,gc,x,y-s,x,y+s+1);
  XDrawLine(DISPLAY,win,gc,x-s,y,x+s+1,y);
  XFlush(DISPLAY);
}

/* ==================================================================== */

void box(
  Window win,
  GC     gc,
  int    x,int y,int s
)
{
  XDrawRectangle(DISPLAY,win,gc,x-s,y-s,2*s,2*s);
  XFlush(DISPLAY);
}

/* ==================================================================== */

int width(
  Window win
)
{
  XWindowAttributes winattr;

  XGetWindowAttributes(DISPLAY,win,&winattr);
  return winattr.width;
}

/* ==================================================================== */

int height(
  Window win
)
{
  XWindowAttributes winattr;

  XGetWindowAttributes(DISPLAY,win,&winattr);
  return winattr.height;
}

/* ==================================================================== */

int xpos(
  Window win
)
{
  XWindowAttributes winattr;

  XGetWindowAttributes(DISPLAY,win,&winattr);
  return winattr.x;
}

/* ==================================================================== */

int ypos(
  Window win
)
{
  XWindowAttributes winattr;

  XGetWindowAttributes(DISPLAY,win,&winattr);
  return winattr.y;
}

/* ==================================================================== */

void createbutwins(
  int    xpos,int ypos,
  Window *win,
  Window *butwin,
  int    nbut,
  GC    *gc
)
{
  int       bwidth,bheight;
  int       i,screen;
  XGCValues gcval;
  Window    root;
  Font      font;
  XSizeHints *size_hints;
  XTextProperty winname;
  char     *title = "BAOLab";


  screen  = DefaultScreen(DISPLAY);
  root    = RootWindow(DISPLAY,screen);
  *win = XCreateSimpleWindow(DISPLAY,root,xpos, ypos,
			      250,50,0,BlackPixel(DISPLAY,screen),
			      WhitePixel(DISPLAY,screen));
  size_hints = XAllocSizeHints();
  size_hints->flags = PPosition | PSize | PMinSize;
  size_hints->min_width = 150;
  size_hints->min_height= 40;
  XStringListToTextProperty(&title,1,&winname);
  XSetWMProperties(DISPLAY,*win,&winname,NULL,NULL,0,size_hints,
						     NULL,NULL);
  free(size_hints);
  XMapWindow(DISPLAY,*win);

  bwidth  = width(*win) / nbut;
  bheight = height(*win);

  for (i=0; i<nbut; i++) {
    butwin[i] = XCreateSimpleWindow(DISPLAY,*win,i*bwidth,0,bwidth,bheight,0,
                    BlackPixel(DISPLAY,screen),WhitePixel(DISPLAY,screen));
    XSelectInput(DISPLAY,butwin[i],StructureNotifyMask | ExposureMask |
                                   ButtonPressMask | KeyPressMask |
				   EnterWindowMask | LeaveWindowMask);
    XMapWindow(DISPLAY,butwin[i]);
  }

  gcval.foreground = BlackPixel(DISPLAY,screen);
  gcval.background = WhitePixel(DISPLAY,screen);
  gcval.line_width = 1;
  *gc = XCreateGC(DISPLAY,butwin[0], 
                 (GCForeground | GCBackground | GCLineWidth),
                       &gcval);

  font = XLoadFont(DISPLAY,"9x15");
  XSetFont(DISPLAY,*gc,font);
  XFlush(DISPLAY);
}

/* ==================================================================== */

void drawbutwin(
  Window win,
  GC     gc,
  char  *txt,
  int   active
)
{
  int screen;
  int wdx,wdy;

  screen = DefaultScreen(DISPLAY);
  wdx    = width(win);
  wdy    = height(win);

  XClearWindow(DISPLAY,win);
  XmuDrawRoundedRectangle(DISPLAY,win,gc,3,3,wdx-6,wdy-6,6,6);
  if (active) XmuDrawRoundedRectangle(DISPLAY,win,gc,6,6,wdx-12,wdy-12,6,6);

  XDrawString(DISPLAY,win,gc,10,23,txt,strlen(txt));
  XFlush(DISPLAY);

}

/* ==================================================================== */

void MakeButtons(
  Window butwin,
  Window *but1, Window *but2,
  GC     *butgc
)
{
  int wdx, wdy; 
  int bx1,bdx1, bx2, bdx2, by1, bdy1, by2, bdy2;
  int screen = XDefaultScreen(DISPLAY);
  XGCValues gcval;
  Font font;

  wdx = width(butwin);  wdy = height(butwin);
  bx1 = 0; bdx1 = wdx/2; by1 = 0; bdy1 = wdy;
  bx2 = wdx/2; bdx2 = wdx/2; by2 = 0; bdy2 = wdy;

  *but1 = XCreateSimpleWindow(DISPLAY,butwin,bx1,by1,bdx1,bdy1,0,
                 BlackPixel(DISPLAY,screen),WhitePixel(DISPLAY,screen));

  *but2 = XCreateSimpleWindow(DISPLAY,butwin,bx2,by2,bdx2,bdy2,0,
                 BlackPixel(DISPLAY,screen),WhitePixel(DISPLAY,screen));

  XSelectInput(DISPLAY,*but1,StructureNotifyMask | ExposureMask |
                             ButtonPressMask | KeyPressMask |
                             EnterWindowMask | LeaveWindowMask);
  XSelectInput(DISPLAY,*but2,StructureNotifyMask | ExposureMask |
                             ButtonPressMask | KeyPressMask |
                             EnterWindowMask | LeaveWindowMask);

  gcval.foreground = BlackPixel(DISPLAY,screen);
  gcval.background = WhitePixel(DISPLAY,screen);
  gcval.line_width = 1;
  *butgc = XCreateGC(DISPLAY,butwin, 
                     (GCForeground | GCBackground | GCLineWidth), &gcval);

  font = XLoadFont(DISPLAY,"9x15");
  XSetFont(DISPLAY,*butgc,font);

  XMapWindow(DISPLAY,*but1);
  XMapWindow(DISPLAY,*but2);
}

/* ==================================================================== */

void DrawButton(
  int    nr,
  Window win,
  GC     gc,
  int    active
)
{
  int dx,dy;
  char txt[10];

  dx = width(win);  dy = height(win);
  XClearWindow(DISPLAY,win);
  XmuDrawRoundedRectangle(DISPLAY,win,gc,3,3,dx-6,dy-6,6,6);
  if (active) XmuDrawRoundedRectangle(DISPLAY,win,gc,6,6,dx-12,dy-12,6,6);

  switch (nr) {
    case 1 : strcpy(txt,"Accept"); break;
    case 2 : strcpy(txt,"Cancel"); break;
  }

  XDrawString(DISPLAY,win,gc,10,23,txt,6);

}

/* ==================================================================== */

int xsm_box(
  Window  win,
  GC      gc,
  int    *_x, int *_y, 
  int *_dx, int *_dy
)
{
  int    quit = FALSE;
  XEvent event;
  int    button;
  int    x0, y0, x=*_x, y=*_y, dx=*_dx, dy=*_dy;
  Window butwin,root,w1,w2;
  Window but1,but2;
  int    screen;
  XTextProperty winname;
  XSizeHints   *size_hints;
  char   *title = "BAOLab";
  GC     butgc;
  int    result;
  XImage *im1, *im2, *im3, *im4;
  int    wdx,wdy;
  int    bx,by,bdx,bdy;
  int    wx,wy,px,py,keys_buts;

  XSelectInput(DISPLAY,win, ExposureMask | ButtonPressMask | 
               ButtonReleaseMask |  
               Button1MotionMask | Button3MotionMask | 
	       KeyPressMask | PointerMotionHintMask);

  wdx = width(win);
  wdy = height(win);

  screen = XDefaultScreen(DISPLAY);
  root   = RootWindow(DISPLAY,screen);
  butwin = XCreateSimpleWindow(DISPLAY,root,
                               xpos(win),ypos(win)+height(win),
			       150,40,0,
			       BlackPixel(DISPLAY,screen),
			       WhitePixel(DISPLAY,screen) );

  size_hints = XAllocSizeHints();
  size_hints->flags = PPosition | PSize | PMinSize;
  size_hints->min_width = 150;
  size_hints->min_height= 40;
  XStringListToTextProperty(&title,1,&winname);
  XSetWMProperties(DISPLAY,butwin,&winname,NULL,NULL,0,size_hints,
		                           NULL,NULL);
  free(size_hints); 
  XMapWindow(DISPLAY,butwin); 
  MakeButtons(butwin,&but1,&but2,&butgc);

  bx = x; by = y;  bdx = dx;  bdy = dy;
  im1 = XGetImage(DISPLAY,win,bx,      by,        bdx,1, AllPlanes,ZPixmap);
  im2 = XGetImage(DISPLAY,win,bx,      by+bdy-1 , bdx,1, AllPlanes,ZPixmap);
  im3 = XGetImage(DISPLAY,win,bx,      by,        1, bdy,AllPlanes,ZPixmap);
  im4 = XGetImage(DISPLAY,win,bx+bdx-1,by,        1, bdy,AllPlanes,ZPixmap);

  XDrawRectangle(DISPLAY,win,gc,x,y,dx-1,dy-1);

  do {
    XNextEvent(DISPLAY,&event);

    if ((event.xany.window == but1) || (event.xany.window == but2)) {
      switch (event.type) {
        case Expose:
	  if (event.xexpose.window == but1) DrawButton(1,but1,butgc,0);
	  if (event.xexpose.window == but2) DrawButton(2,but2,butgc,0);
	  break;

        case EnterNotify:
	  if (event.xany.window == but1) DrawButton(1,but1,butgc,1);
	  if (event.xany.window == but2) DrawButton(2,but2,butgc,1);
	  break;

        case LeaveNotify:
	  if (event.xany.window == but1) DrawButton(1,but1,butgc,0);
	  if (event.xany.window == but2) DrawButton(2,but2,butgc,0);
	  break; 
     
	case ButtonPress:
	  if (event.xbutton.window == but1) {
	    quit = TRUE; result = TRUE;
	  }
	  if (event.xbutton.window == but2) {
	    quit = TRUE; result = FALSE;
	  }
	  break;
      }
    }

    if (event.xany.window == win) {

      switch (event.type) {
        case ButtonPress:
	    button = event.xbutton.button;
	    if (button==3) {
	      x0 = x+dx/2;
	      y0 = y+dy/2;
	    }
          break;

	case MotionNotify:

	    XPutImage(DISPLAY,win,gc,im1,0,0,bx,      by,      bdx,1);
	    XPutImage(DISPLAY,win,gc,im2,0,0,bx,      by+bdy-1,bdx,1);
	    XPutImage(DISPLAY,win,gc,im3,0,0,bx,      by,     1,bdy);
	    XPutImage(DISPLAY,win,gc,im4,0,0,bx+bdx-1,by,     1,bdy);

	    XQueryPointer(DISPLAY,event.xmotion.window,
	                  &w1,&w2,&px,&py,&wx,&wy,&keys_buts);

            switch (button) {
	         case 3 : dx = 2*abs(wx - x0)+2;
                          dy = 2*abs(wy - y0)+2;
                          x = x0-dx/2;
			  y = y0-dy/2;
			  if (x<0) x = 0; if (y<0) y = 0;
			  if (x+dx > wdx) dx = wdx-x;
			  if (y+dy > wdy) dy = wdy-y;
                        break;

                 case 1 : x = wx-dx/2; if (x<0) x = 0; 
		          if (x+dx > wdx) x = wdx-dx;
		          y = wy-dy/2; if (y<0) y = 0;
		          if (y+dy > wdy) y = wdy-dy;
		        break;
            }

            XDestroyImage(im1);
            XDestroyImage(im2);
            XDestroyImage(im3);
            XDestroyImage(im4);

    /*	    bx = (x > 0) ? x : 0;   by = (y > 0) ? y : 0;
	    bdx = (bx+dx < wdx) ? dx+x-bx : wdx-x-1;
	    bdy = (by+dy < wdy) ? dy+y-by : wdy-y-1; */
	    bx = x; by = y; bdx = dx; bdy = dy;

  im1 = XGetImage(DISPLAY,win,bx,      by,        bdx,1, AllPlanes,ZPixmap);
  im2 = XGetImage(DISPLAY,win,bx,      by+bdy-1 , bdx,1, AllPlanes,ZPixmap);
  im3 = XGetImage(DISPLAY,win,bx,      by,        1, bdy,AllPlanes,ZPixmap);
  im4 = XGetImage(DISPLAY,win,bx+bdx-1,by,        1, bdy,AllPlanes,ZPixmap);

            XDrawRectangle(DISPLAY,win,gc,x,y,dx-1,dy-1);
	  break; 
      } 
    }


  } while (!quit);

  XPutImage(DISPLAY,win,gc,im1,0,0,bx,      by,      bdx,1);
  XPutImage(DISPLAY,win,gc,im2,0,0,bx,      by+bdy-1,bdx,1);
  XPutImage(DISPLAY,win,gc,im3,0,0,bx,      by,     1,bdy);
  XPutImage(DISPLAY,win,gc,im4,0,0,bx+bdx-1,by,     1,bdy);

  *_x = x;   *_y = y;
  *_dx = dx; *_dy = dy;

  XFreeGC(DISPLAY,butgc);

  XDestroyImage(im1);
  XDestroyImage(im2);
  XDestroyImage(im3);
  XDestroyImage(im4);

  XDestroyWindow(DISPLAY,butwin);
  XFlush(DISPLAY); 
  return result;
}

/* ==================================================================== */

void setcolor(
  GC gc,
  const char *name
)
{
  Colormap cmap;
  XColor   exact_def;

  cmap = DefaultColormap(DISPLAY,DefaultScreen(DISPLAY));
  XParseColor(DISPLAY,cmap,name,&exact_def);
  XAllocColor(DISPLAY,cmap,&exact_def);
  XSetForeground(DISPLAY,gc,exact_def.pixel);
}

/* ==================================================================== */

void make_xaxis(
  Window  win,
  GC      gc,
  float   lo, float hi
)
{
  float x,s,stepsz,marksz,marksz10;
  int   xx,nstep;
  char  txt[10];
  int   wdx,wdy;

  wdx = width(win);
  wdy = height(win);

  s = (hi-lo) / 10.0;
  stepsz = 0.1;
  while (stepsz < s) stepsz *= 10;
  marksz = stepsz / 10.0;
  marksz10 = stepsz;

  nstep = (int)((hi-lo)/stepsz);
  if (nstep == 1) stepsz /= 5; else
  if (nstep == 2) stepsz /= 2; else
  if (nstep == 9) stepsz *= 3; else
  if (nstep == 8) stepsz *= 2;

  XDrawLine(DISPLAY,win,gc,20,wdy-30,wdx-10,wdy-30); /* Draw the axis itself */

  x = ceil(lo/marksz)*marksz;   /* Set Marks on X-axis */
  do {
    xx = 50+(int)((x-lo)/(hi-lo)*(wdx-70));
    XDrawLine(DISPLAY,win,gc,xx,wdy-32,xx,wdy-27);
    x = x+marksz;  
  } while (x<hi);

  x = ceil(lo/marksz10)*marksz10;   /* Set Marks on X-axis */
  do {
    xx = 50+(int)((x-lo)/(hi-lo)*(wdx-70));
    XDrawLine(DISPLAY,win,gc,xx,wdy-32,xx,wdy-23);
    x = x+marksz10;  
  } while (x<hi);

  x = ceil(lo/stepsz)*stepsz;  /* Write some text indicating the interval */
  do {
    xx = 50+(int)((x-lo)/(hi-lo)*(wdx-70));
    itoa((int)(x+0.5),txt);
    XDrawLine(DISPLAY,win,gc,xx,wdy-32,xx,wdy-23);
    XDrawString(DISPLAY,win,gc,xx,wdy-10,txt,strlen(txt));
    x = x+stepsz;
  } while (x<hi);

  XFlush(DISPLAY);
}

/* ==================================================================== */

void make_yaxis(
/*
 * Draw a y-axis labeled from pmin to pmax. pmin may actually be greater
 * than pmax - but pmin is ALWAYS the value located nearest the x-axis.
 */

  Window  win,
  GC      gc,
  float   pmin,float pmax
)
{
  int nstep;
  float y, txtsp, pdiff;
  int yy,ndec;
  char txt[10],s1[10];
  int      wdx, wdy;
  float    ss;

  wdx = width(win);
  wdy = height(win);
  pdiff = pmax - pmin;

  ss = (pdiff > 0) ? 1.0 : -1.0;
  if (pdiff < 0) {
    pmax = -pmax;
    pmin = -pmin;
  }
  pdiff = fabs(pdiff);

  txtsp = 1;
  if (pdiff > 10) while (txtsp < pdiff/10) txtsp *= 10;
  if (pdiff <= 1) while (txtsp > pdiff) txtsp /= 10;
  nstep = (int)(pdiff / txtsp);

  if (nstep == 1) txtsp /= 5; else
  if (nstep == 2) txtsp /= 2; else
  if (nstep == 9) txtsp *= 3; else
  if (nstep == 8) txtsp *= 2;

  y = ceil(pmin/txtsp)*txtsp;   /* Set Marks on Y-axis */

  XDrawLine(DISPLAY,win,gc,50,10,50,wdy-10);

  XSetLineAttributes(DISPLAY,gc,1,LineOnOffDash,
		       CapButt,JoinRound); 
  ndec = (int)ceil(-log10(txtsp));
  sprintf(s1,"%%0.%if",ndec);

  do {
    yy = wdy-30-(int)(((wdy-50)*(y-pmin))/pdiff);
    XDrawLine(DISPLAY,win,gc,45,yy,wdx,yy);
    sprintf(txt,s1,ss*y);
/*    itoa((int)(ss*y),txt); */
    XDrawString(DISPLAY,win,gc,10,yy,txt,strlen(txt)); 
    y += txtsp;
  } while (y < pmax);

  XSetLineAttributes(DISPLAY,gc,1,LineSolid,
		       CapButt,JoinRound); 
  XFlush(DISPLAY);
}

