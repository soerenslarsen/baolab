void lsqlin(
  float *,      /*  x     -- X-values */
  float *,      /*  y     -- Y-values */
  float *,      /*  w     -- Weights  */
  float *,      /*  sigsq -- Errors squared  */
  int    ,      /*  n     -- Number of data points */
  float *,      /*  *a and *b -- return coefficients, y = a x + b  */
  float *
);
