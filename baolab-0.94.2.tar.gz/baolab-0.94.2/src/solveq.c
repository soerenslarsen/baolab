#include <math.h>

  void exchgrow(
    float m[4][5],
    int   i, int j
  )
  {
    int   x;
    float tmpr;

    for (x=0;x<=4;x++) {
      tmpr = m[i][x];
      m[i][x] = m[j][x];
      m[j][x] = tmpr;
    }
  }

  void mulrow(
    float m[4][5],
    int   i,
    float r
  )
  {
    int x;
    for (x=0;x<=4;x++) m[i][x] = m[i][x]*r;
  }

  void addrows(
    float m[4][5],
    int   i, int j,
    float r
  )
  {
    int x;
    for(x=0;x<=4;x++) m[i][x] = m[i][x]+r*m[j][x];
  }

  void rowreduce(   /* Solves 4 x 5 linear equation system */
    float m2[4][5]
  )
  {
    int y,column;

    for(column = 0; column<4; column++) {
      if (fabs(m2[column][column]) > 1E-100)       /* Lav initial-ettal */ 
        mulrow(m2,column,1.0/m2[column][column]);
      y = 0;

      while (y<column) {
        addrows(m2,y,column,-m2[y][column]);
        y++;
      }

      y = column+1;
      while (y<4) {
        addrows(m2,y,column,-m2[y][column]);
        y++;
      }
    }
  }

/* =================================================================== */

  void mulrow1(
    double *m,
    int    n, int row,
    double fact
  )
  {
    int x;

    for (x=0; x<=n; x++) m[(n+1)*row + x] *= fact;
  }

  void addrows1(
    double *m,
    int    n, int row1, int row2,
    double fact
  )
  {
    int x;

    for (x=0; x<=n; x++) 
      m[(n+1)*row1+x] += fact*m[(n+1)*row2+x];
  }

  void echelon(   /* Reduces n x n+1 matrix to echelon form */
    double *m,
    int    n
  )
  {
    int y,col;
    double d;

    for(col = 0; col<n; col++) {
      d = m[col*(n+1) + col];
      if (fabs(d) > 1E-100)       /* Lav initial-ettal */ 
        mulrow1(m,n,col,1.0/d);

      y = 0;
      while (y<col) {
        addrows1(m,n,y,col,-m[y*(n+1)+col]);
        y++;
      }

      y = col+1;
      while (y<n) {
        addrows1(m,n,y,col,-m[y*(n+1)+col]);
        y++;
      }
    }
  }
