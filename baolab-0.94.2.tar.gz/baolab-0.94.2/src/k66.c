#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* ====================================================================== */
/*                                                                        */
/* Compute a King model as in King, I. R. 1966, AJ 71, 64, and return     */
/* various derived quantities.                                            */
/*                                                                        */
/* These routines come with *no warranty whatsoever*. They were written   */
/* by Soeren Larsen and have been used in                                 */   
/* Larsen et al. 2002, AJ 124, 2615--2624.                                */
/* There is no guarantee that they will be suitable for any particular    */
/* purpose. There may be undiscovered bugs, some of which may seriously   */
/* compromise any scientific results.                                     */
/*                                                                        */
/* If these routines are helpful for your scientific work, a note in the  */
/* acknowledgements of any resulting publication would be much            */
/* appreciated.                                                           */
/*                                                                        */
/* ====================================================================== */

#define sqr(A) ((A)*(A))

/* ---------------------------------------------------------------------- */

double *calcphiw(
  double *w,
  double *phiw,
  double *vdisp,
  int   nw
) {
  int iw,j;
  int nsub;
  double eta, deta;
  double dw;
  double xx, xx2;

  nsub = 10;

  eta = 0.;
  xx = 0.;
  xx2 = 0;
  phiw[0] = 0;

  iw = 1;

  do {
    deta = (w[iw] - w[iw-1]) / nsub;
    while (fabs(eta - w[iw]) > deta/1e3) {
      xx += exp(-eta) * pow(eta,1.5) * deta;   
      xx2 += exp(-eta) * pow(eta,2.5) * deta;   
      eta += deta;
    }
    phiw[iw] = exp(w[iw]) * xx;
    vdisp[iw] = sqrt(0.4 * xx2 / xx);
/*    printf("%d %d\n",iw,nw); */
    iw++;
  } while (iw < nw);

  return phiw;
}

/* ---------------------------------------------------------------------- */

double kinterp(
  double *x,
  double *y,
  int n,
  double xx)
{
  int i,imin;
  double dmin,d;
  double d1, d2;
  double yy, y1, y2;

  if (xx < x[0]) return y[0];
  if (xx > x[n-1]) return y[n-1];

  i = 0;
  while (x[i] < xx) i++;
/*  printf("%d %d\n",i,n); */

  d1 = (xx - x[i-1]) / (x[i] - x[i-1]);
  d2 = 1 - d1;
  y1 = y[i-1];
  y2 = y[i];

  yy = (1-d1) * y1 + (1-d2)*y2;
  return yy;
}

/* ---------------------------------------------------------------------- */


void calc_r(
/*                                                                         */
/*  Integrate the Poisson equation directly in the form given in the King  */ 
/* paper. Not optimal, requires some interpolation etc.                    */
/* This is useful as a consistency check though.                           */
/*                                                                         */
  double *w,
  double *rhorel,
  double *rout,
  int n
) {
  double d2w_dr2, dw_dr, dw, dr;
  double d2r_dw2, dr_dw;
  double r,w1,rho;
  double w0;
  int   i;
  int   nn;
  double *rr, *dens, *ww;

  /* Make two passes through the integration of Poisson's equation.      */
  /* The first one only to determine the size of the arrays to contain   */
  /* the solutions.                                                      */

  for (i=0; i<2; i++) {
    if (i==1) {
      rr = (double *)malloc(sizeof(double)*nn);
      dens = (double *)malloc(sizeof(double)*nn);
      ww = (double *)malloc(sizeof(double)*nn);
    }
    nn = 0;

    w0 = w[n-1];
    dr = 0.01;
    r = dr;
    dw_dr = -6*r;
    w1 = w0 + dw_dr * dr;

    while (w1 > 0) {
      rho = kinterp(w,rhorel,n,w1);

      if (i==1) {
        rr[nn] = r;
	dens[nn] = rho;
	ww[nn] = -w1;
      }


      d2w_dr2 = -9 * rho - 2/r * dw_dr;
/*      if (i==0) printf("1: %0.3f %0.4f %0.3f %0.3f\n",r,w1,dw_dr,d2w_dr2); */
      dw_dr  +=  d2w_dr2 * dr;
      w1     +=  dw_dr * dr;
      r      +=  dr;
      nn++;

    }
  }
/*  for (i=0; i<nn; i++) printf("%0.3f %0.4f %0.2f\n",rr[i],dens[i],-ww[i]); */

  for (i=0; i<n; i++) rout[i] = kinterp(ww,rr,nn,-w[i]);

  free(rr);
  free(dens);
  free(ww);
}

/* ---------------------------------------------------------------------- */

void calc_r2(
/*                                                                         */
/* Integrate the inverted form of the Poisson equation. Initial            */
/* conditions are slightly more tricky because dr_dw is infinite at r=0.   */
/*                                                                         */
  double *w,
  double *rhorel,
  double *rout,
  int n
) {
  double d2r_dw2, dr_dw, dw_dr, dw, dr, r;
  double w0,w1;
  int    i;

  rout[n-1] = 0; 
  w0 = w[n-1];
  dw = w[n-2] - w[n-1];
  dr = 2*sqrt(-dw/6);
  r = dr;
  dw_dr = -6*r;
  dr_dw = 1/dw_dr;
  i  = n-2;
  w1 = w[i];

  while (i >= 0) {
    rout[i] = r; 
    dw = w[i] - w[i+1];
    d2r_dw2 = 9*rhorel[i] * pow(dr_dw,3) + 2/r * sqr(dr_dw); 
/*    printf("2: %0.3f %0.3f %0.3f %0.3f %0.3f %0.3f %0.3f\n",r,w[i],rhorel[i],dw,1/dr_dw,dr_dw,d2r_dw2); */
    dr_dw += d2r_dw2 * dw;
    dr     = dw * dr_dw;
    r += dr;
    i--;
  }
}

/* ---------------------------------------------------------------------- */

double project(   /* Return p = sigma(r=0) / rho(r=0) */
  double *r,
  double *rho,
  double *sigma,
  double *w,
  double *phiw,
  double *vdisp,
  double *vdispp,
  double *vdap,
  int    n,
  double *pvd
) {
  int i, j;
  double rr,r1,r2;
  double sig,dsig,ds;
  double vsq, vdmax;
  double vdp,vdpmax;
  double vdsum, dl, ltot;
  double vdamax;
  double p;

  /* Project density and velocity dispersion */

  vdpmax = 0.;
  vdmax = 0.;

  for (i=0; i<n; i++) {  /* R=0 at i=n */
    rr = r[i];
    j = 1;
    sig = 0;
    vdp = 0.;
/*    printf("%d\n",i); */

    while (r[j] >= rr && j<n) {  /* Only 3-d Radii greater than R(2d) are */
                                 /* relevant.                             */
      r2 = r[j-1];
      r1 = r[j];
      ds = sqrt(sqr(r2) - sqr(rr)) - sqrt(sqr(r1) - sqr(rr));
      dsig = ds * rho[j];
      sig += dsig;

      vdp += sqr(vdisp[j]) * dsig;

      j++;
    }

    sigma[i] = sig;
    if (sig > 0) vdispp[i] = sqrt(vdp / sig); else vdispp[i] = 0.;

    if (vdisp[i] > vdmax) vdmax = vdisp[i];
    if (vdispp[i] > vdpmax) vdpmax = vdispp[i];
  }

  /* Velocity dispersion in apertures */

  vdsum = 0.;
  vdamax = 0.;
  ltot = 0;

  for (i=n-2; i>=0; i--) {
    r1 = r[i+1];
    r2 = r[i];
    dl = (sqr(r2) - sqr(r1)) * sigma[i];
    ltot += dl;
    vdsum += vdispp[i] * vdispp[i] * dl;
    vdap[i] = sqrt(vdsum / ltot);
    if (vdap[i] > vdamax) vdamax = vdap[i];
  }
  vdap[n-1] = vdap[n-2];

  /* Normalize */

  p = 2 * sigma[n-1] / rho[n-1];
  if (pvd != NULL) (*pvd) = vdispp[n-1] / vdisp[n-1];

  for (i=0; i<n; i++) {
    sigma[i] /= sigma[n-1];
    vdisp[i] /= vdmax;
    vdispp[i] /= vdpmax;
    vdap[i] /= vdamax;
  }

  return p;
}

/* ---------------------------------------------------------------------- */

double vdslit(
  double w,           /* Slit width in units of core radius */
  double l,           /* Length */
  double *r,
  double *sigma,
  double *vdispp,
  int    n
) {
  int i;
  double r1, r2, dl;
  double da;
  double ltot,vdsum,vdavg;

  ltot = 0.0;
  vdsum = 0.0;

  for (i=n-2; i>=0; i--) {
    r1 = r[i+1];
    r2 = r[i];
    dl = (sqr(r2) - sqr(r1)) * sigma[i];

    if (r1 < w/2) 
      da = 1.0; 
    else if (r1 > l/2)
      da = 0.0;
    else 
      da = M_2_PI * asin((w/2)/r1);

    ltot += dl*da;
    vdsum += vdispp[i] * vdispp[i] * dl*da;
  }

  vdavg = sqrt(vdsum / ltot);
  return vdavg/vdispp[n-1];
}

/* ---------------------------------------------------------------------- */

double hlrp(
  double *r,
  double *sigma,
  int     nw
) {
  int i;
  double ltot,l;
  double dr;

  ltot = 0.0;
  for (i=nw-1; i>0; i--) {
    dr = r[i-1] - r[i];
    ltot += r[i] * sigma[i] * dr;
  }

  l  = 0.;
  for (i=nw-1; l < ltot/2; i--) {
    dr = r[i-1] - r[i];
    l += r[i] * sigma[i] * dr;
  }

  return r[i];
}

/* ---------------------------------------------------------------------- */

double hmr3d(
  double *r,
  double *rho,
  int     nw
) {
  int i;
  double mtot,m;
  double dr;

  mtot = 0.0;
  for (i=nw-1; i>0; i--) {
    dr = r[i-1] - r[i];
    mtot += sqr(r[i]) * rho[i] * dr;
  }

  m  = 0.;
  for (i=nw-1; m < mtot/2; i--) {
    dr = r[i-1] - r[i];
    m += sqr(r[i]) * rho[i] * dr;
  }

  return r[i];
}

/* ---------------------------------------------------------------------- */

double hwhm(
  double *r,
  double *sigma,
  int     nw
) {
  int i;
  double s0;
  double rh;

  s0 = sigma[nw-1];
  rh = kinterp(sigma,r,nw,s0/2);

  return rh;
}

/* ---------------------------------------------------------------------- */

double mu(
  double *r,
  double *rho,
  int     nw
) {
  int    i;
  double m,dr;

  m = 0;
  for (i=nw-1; i>0; i--) {
    dr = r[i-1] - r[i];
    m += 4*3.1415927*(rho[i] / rho[nw-1])*sqr(r[i])*dr;
  }

  return m;
}

/* ---------------------------------------------------------------------- */

double eb(   /* dimensionless binding energy */
  double *r,
  double *rho,
  double *w,
  int    nw
) {
  int    i;
  double rho0,rt,dr;
  double x1,x2;
  double energy;

  rho0 = rho[nw-1];
  rt   = r[0];

  x1 = x2 = 0.;

  for (i=nw-1; i>0; i--) {
    dr = r[i-1] - r[i];
    x1 += rho[i]/rho0 * sqr(r[i]) * dr;
    x2 += rho[i]/rho0 * sqr(r[i]) * w[i] * dr;
  }

  energy = 81/(2. * rt) * sqr(x1) + 4.5 * x2;
  return energy;
}
