#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"
#include "utils.h"
#include "polyfit.h"
#include "xfit.h"

int FITMODE = FITPOLY;

int YD_BINX = 100;   /* Bin size in X for the Y-distortion determination */
int YD_DY = 20;      /* Width of strips for Y-distortion determination   */
int YD_XMIN = 100;
int YD_XMAX = 2090;
int XD_BINX = 200;   /* Bin size in X for X-distortion det. */
int XD_DY = 1;
int WOBJ  = 5;       /* Width of object spectra in pixels  */
int CCRNGY = 3;
int CCRNGX = 3;
int DYFITORDER = 3;
int DXFITORDER = 2;
int YTRACEMETHOD = CCORR;
int XTRACEMETHOD = CCORR;

/* ======================================================================= */

static int getlst(
  char *fname,
  float *lst,
  int  ncol
) {
  FILE *file;
  char *ch, tmps[100], s1[100];
  int n,i;

  file = fopen(fname,"r");
  if (file == NULL) return 0;

  n = 0;
  while ((ch = fgets(tmps,255,file)) != NULL) {
    if (tmps[0] != '#') {
      for (i=1; i<=ncol; i++) {
	argn(tmps,i,s1);
	lst[n*ncol + i - 1] = atof(s1);
      }
      n++;
    }
  }

  return n;
}

/* ======================================================================= */

static void medcols(
  int x1,
  int x2,
  int y1,
  int y2,
  float *inimg,
  hstruct *hdr,
  float *sum
) {
  int x, y, yy, p;
  float *row;
  int ncols, i;

  ncols = x2 - x1 + 1;
  row = (float *)malloc(sizeof(float) * ncols);

  yy = 0;
  for (y=y1; y<=y2; y++) {
    p = hdr->naxis1 * y;
    i = 0;
    for (x=x1; x<=x2; x++) row[i++] = inimg[p + x];
    fsort(row, ncols);
    sum[yy] = row[ncols / 2];
    yy++;
  }

  free(row);
}

/* ======================================================================= */

static void medrows(
  int x1,
  int x2,
  int y1,
  int y2,
  float *inimg,
  hstruct *hdr,
  float *sum
) {
  int x, xx, y, p;
  float *col;
  int nrows, i;

  nrows = y2 - y1 + 1;
  col = (float *)malloc(sizeof(float) * nrows);

  xx = 0;
  for (x=x1; x<=x2; x++) {
    i = 0;
    for (y=y1; y<=y2; y++) {
      p = hdr->naxis1 * y;
      col[i++] = inimg[p + x];
    }
    fsort(col, nrows);
    sum[xx] = col[nrows / 2];
    xx++;
  }

  free(col);
}

/* ======================================================================= */

static float centroid(
  float *yy,
  int n
) {
  float fmin, ftot, fxtot;
  float xc;
  int x;

  fmin = yy[0];
  for (x=0; x<n; x++) if (yy[x] < fmin) fmin = yy[x];

  ftot = fxtot = 0.0;
  for (x=0; x<n; x++) {
    fxtot += (yy[x] - fmin) * x;
    ftot += (yy[x] - fmin);
  }
  xc = fxtot / ftot;

  return xc;
}

/* ======================================================================= */

static float fitmax(
  float *yy,
  int nx,
  int mode
) {
  int i, imax;
  float fmax;
  float *xx;
  float aa[3];

  xx = (float *)malloc(sizeof(float)*nx);
  for (i=0; i<nx; i++) xx[i] = i;

  switch (mode) {
    case FITMAX: 
            imax = 0;              /* Just find the highest-valued pixel */
            for (i=0; i<nx; i++)
              if (yy[i] > yy[imax]) imax = i;
            fmax = imax;
            break;

    case FITCENT:
            fmax = centroid(yy, nx);
            break;

    case FITPOLY:
/*            imax = 0;               find the highest-valued pixel
            for (i=0; i<nx; i++)
              if (yy[i] > yy[imax]) imax = i; */

            polyfit(xx,yy,nx,aa,2);
	    fmax = -aa[1]/(2*aa[2]);     /*  " -b / 2a " */

/*	    polyfit(xx+imax-2, yy+imax-2, 5, aa, 2);
	    fmax = -aa[1]/(2*aa[2]);

	    for (i=0; i<nx; i++) printf("%0.1f ",yy[i]);
	    printf(" - %d %0.1f %0.1f",imax,f1, fmax);
	    puts(""); */

	    if (fmax < 0) fmax = 0;
	    if (fmax > nx) fmax = nx;
	    break;
  }

  free(xx);

  return fmax;
}

/* ======================================================================= */

static float bestmatch(
  float *arr1,
  float *arr2,
  int   d1,
  int   d2,
  int   method
) {
  float cc[20], p;
  float xmax;
  float bkg1, bkg2;
  int  imax1, imax2;
  float fmax1, fmax2;
  int   i, dx, xx;
  int   npt;

  npt = d1 - d2 + 1;

  bkg1 = arr1[0];
  bkg2 = arr2[0];

  for (i=0; i<d1; i++) if (arr1[i] < bkg1) bkg1 = arr1[i];
  for (i=0; i<d2; i++) if (arr2[i] < bkg2) bkg2 = arr2[i];

  switch (method) {
    case CCORR :
      for (dx=0; dx<npt; dx++) {
        p = 0.0;
        for (xx=0; xx<d2; xx++)
          p += (arr1[xx+dx]-bkg1) * (arr2[xx]-bkg2);
        cc[dx] = p;
      }
      xmax = fitmax(cc, npt, FITMODE);
      break;

    case FITMAX:
      imax1 = imax2 = 0;     
      for (i=0; i<d1; i++) if (arr1[i] > arr1[imax1]) imax1 = i;
      for (i=0; i<d2; i++) if (arr2[i] > arr2[imax2]) imax2 = i;
      xmax = imax1 - imax2;
      break;

   case FITPOLY:
      fmax1 = fitmax(arr1,d1,FITPOLY);
      fmax2 = fitmax(arr2,d2,FITPOLY);
      xmax = fmax1 - fmax2;
      break;

   case FITCENT:
      fmax1 = fitmax(arr1,d1,FITCENT);
      fmax2 = fitmax(arr2,d2,FITCENT);
      xmax = fmax1 - fmax2;
      break;
  }

  return xmax;
}

/* ======================================================================= */

float *calc_ytran(
  float *inimg,
  hstruct *hdr,
  float *ylst,
  int *_ny,
  int fitorder,
  int tracemethod
) {
  float xref, xpos;
  float xmin,xmax;
  float *cref, *cpos;
  float *ylstok;
  float yref, ypos;
  float *xx, *yy;
  float *ycoeff;
  int   i,j, ix;
  int   nyok;
  int   nx, ny;
  int   nfit;
  int   x1,y1,x2,y2;
  int   y1ref;
  int   *porder;
  float dy;
  float a[100];
  char  title[100];

  ny     = (*_ny);
  nyok   = 0;
  nx     = hdr->naxis1 / YD_BINX;
  xx     = (float *)malloc(sizeof(float)*nx);
  yy     = (float *)malloc(sizeof(float)*nx);
  ylstok = (float *)malloc(sizeof(float)*2*ny);
  porder = (int *)malloc(sizeof(int)*nx);
  ycoeff = (float *)malloc(sizeof(float)*ny*(fitorder+1));

  cref = (float *)malloc(sizeof(float)*YD_DY);
  cpos = (float *)malloc(sizeof(float)*(YD_DY + 2*CCRNGY));

  if (YD_XMIN > 0) xmin = YD_XMIN; else xmin = 0;
  if (YD_XMAX > 0) xmax = YD_XMAX; else xmax = hdr->naxis1;
  if (xmax > hdr->naxis1) {
    printf(" ** Warning: YD_XMAX > NAXIS1. Setting XMAX = NAXIS1\n");
    xmax = hdr->naxis1;
  }

  for (i=0; i<ny; i++) { 
    xref = ylst[2*i];
    xx[0] = xref;
    yy[0] = 0.0;
    ix = 1;

    yref = ylst[2*i+1];
    x1 = (int)(xref - YD_BINX/2 + 0.5);
    x2 = x1 + YD_BINX - 1;
    y1ref = y1 = (int)(yref - YD_DY/2 + 0.5);
    y2 = y1 + YD_DY - 1;
    medcols(x1, x2, y1, y2, inimg, hdr, cref);

    ypos = ylst[2*i+1];
    xpos = xref - YD_BINX;
    while (xpos > YD_BINX+xmin) {
      x1 = (int)(xpos - YD_BINX/2 + 0.5);
      x2 = x1 + YD_BINX - 1;
      y1 = (int)(ypos - YD_DY/2 + 0.5 - CCRNGY);
      y2 = y1 + YD_DY + 2*CCRNGY - 1;
      medcols(x1, x2, y1, y2, inimg, hdr, cpos);

      dy = bestmatch(cpos, cref, YD_DY+2*CCRNGY, YD_DY, tracemethod) + y1 - y1ref;
      ypos = yref + dy;

      xx[ix] = xpos;  
      yy[ix] = dy;
      ix++;

      xpos -= YD_BINX;
    }

    ypos = ylst[2*i+1];
    xpos = xref + YD_BINX;
    while (xpos < xmax-YD_BINX) {

      x1 = (int)(xpos - YD_BINX/2 + 0.5);
      x2 = x1 + YD_BINX - 1;
      y1 = (int)(ypos - YD_DY/2 + 0.5 - CCRNGY);
      y2 = y1 + YD_DY + 2*CCRNGY - 1;
      medcols(x1, x2, y1, y2, inimg, hdr, cpos);

      dy = bestmatch(cpos, cref, YD_DY+2*CCRNGY, YD_DY, tracemethod) + y1 - y1ref;
      ypos = yref + dy;

      xx[ix] = xpos; 
      yy[ix] = dy;
      ix++;

      xpos += YD_BINX;
    }

    sprintf(title,"Y distortion fit, %i/%i, y=%0.1f",i+1,ny,yref);
    nfit = xfit(xx, yy, ix, a, fitorder, fitorder, title);

    if (nfit >= 0) {
      for (j=0; j<=fitorder; j++) ycoeff[nyok*(fitorder+1) + j] = a[j];
      ylstok[2*nyok] = ylst[2*i];
      ylstok[2*nyok+1] = ylst[2*i+1];
      printf("%0.2f %0.2f - ok\n",ylst[2*i],ylst[2*i+1]);
      nyok++;
    } else {
      switch (nfit) {
        case -1 : printf("%0.2f %0.2f - rejected\n",ylst[2*i],ylst[2*i+1]);
	          break;
        case -2 : puts(" ** Interrupted");
	          nyok = 0;
	          goto end;
		  break;
      }
    }
  }

  for (i=0; i<2*nyok; i++) ylst[i] = ylstok[i];

end:
  free(ylstok);
  free(yy);
  free(xx);
  free(porder);
  free(cpos);
  free(cref);

  (*_ny) = nyok;
  return ycoeff;
}

/* ======================================================================= */

float dytrans(
  float x,
  float y,
  float *ylst,
  float *ycoeff,
  int ny,
  int fitorder
) {
  int iy;
  int iy1, iy2;
  float dy;
  float yshift1, yshift2;
  float p;

  if (y < ylst[2*0 +1]) { iy1 = iy2 = 0; dy = 0.0;} else
  if (y > ylst[2*ny-1]) { iy1 = iy2 = ny-1; dy = 0.0;} else {
    iy = 1;
    while (y > ylst[2*iy+1]) iy++;
    iy1 = iy-1; iy2 = iy;
    dy = (y - ylst[2*iy1+1]) / (ylst[2*iy2+1] - ylst[2*iy1+1]);
  }

  yshift1 = polyval(x, ycoeff + iy1*(fitorder+1), fitorder);
  yshift2 = polyval(x, ycoeff + iy2*(fitorder+1), fitorder);

  p =   yshift1 * (1-dy) + yshift2 * dy;

/*  if (x ==1900  && (int)y % 10 == 0)
  printf("%0.1f %0.1f %0.1f %0.2f %0.2f %0.2f\n",
         y, ylst[2*iy1+1], ylst[2*iy2+1], yshift1, yshift2, p);  */

  return p;
}

/* ======================================================================= */

static float interp(
  float *img,
  hstruct *hdr,
  float x, 
  float y
) {
  int dx;
  float fx, fy;
  float p;
  int ofs;

  dx = hdr->naxis1;

  if ((x < 1) || (x > dx-2) || (y < 1) || (y > hdr->naxis2-2))
    p = 0.0;
  else {
    fx = x-floor(x);
    fy = y-floor(y);
    ofs = (int)x+(int)y*dx;
    p =  (1-fx)*(1-fy)*img[ofs]
	+( fx )*(1-fy)*img[ofs+1]
	+(1-fx)*( fy )*img[ofs+dx]
	+( fx )*( fy )*img[ofs+dx+1];
  }
  return p;
}

/* ======================================================================= */

float *do_ytran(
  float *inimg,
  hstruct *hdr,
  float *ylst,
  float *ycoeff,
  int   ny,
  int   fitorder,
  float xref,
  int   intp_order
) {
  float *outimg;
  int imdx, imdy;
  float dy;
  float *icoeff;
  float *fy, *fdy, *fdyref;
  int x, y, i;

  imdx = hdr->naxis1;
  imdy = hdr->naxis2;
  if (xref < 0 || xref > imdx) xref = imdx / 2;
  i = 0;

  outimg = (float *)malloc(sizeof(float)*imdx*imdy);
  icoeff = (float *)malloc(sizeof(float) * (intp_order+1));
  fy = (float *)malloc(sizeof(float)*ny);
  fdy = (float *)malloc(sizeof(float)*ny);
  fdyref = (float *)malloc(sizeof(float)*ny);

/*  for (y=0; y<imdy; y++) {
    dy_c = dytrans(xref, y, ylst, ycoeff, ny, fitorder);
    for (x=0; x<imdx; x++) {
      dy = dytrans(x, y, ylst, ycoeff, ny, fitorder) - dy_c;
      outimg[i++] = interp(inimg, hdr, x, y+dy);
    }
  } */

  for (i=0; i<ny; i++) 
    fdyref[i] = polyval(xref, ycoeff + i*(fitorder+1), fitorder);

  for (x=0; x<imdx; x++) {
    for (i=0; i<ny; i++) {
      fy[i] = ylst[2*i+1];
      fdy[i] = polyval(x, ycoeff + i*(fitorder+1), fitorder) - fdyref[i];
    }
    polyfit(fy, fdy, ny, icoeff, intp_order);

    for (y=0; y<imdy; y++) {
/*      dy_c = dytrans(xref, y, ylst, ycoeff, ny, fitorder);
      dy = dytrans(x, y, ylst, ycoeff, ny, fitorder) - dy_c; */
      dy = polyval(y, icoeff, intp_order);
      outimg[x + y*imdx] = interp(inimg, hdr, x, y+dy);
    }
  }

  free(fy);
  free(fdy);
  free(fdyref);
  free(icoeff);

  return outimg;
}

/* ======================================================================= */

float *calc_xtran(
  float *inimg,
  hstruct *hdr,
  float *xlst,
  int *_nx,
  int fitorder,
  int tracemethod
) {
  int i,j;
  int xref, y1, y2, yobj, y, x, xc;
  int x1,x2,x1ref;
  int ny,nx;
  int nxok;
  int iy;
  int nfit;
  float *xx, *yy;
  float *rref, *rpos;
  float dx;
  float a[100];
  float *xcoeff, *xlstok;
  char title[100];

  nx = (*_nx);

  rref = (float *)malloc(sizeof(float)*XD_BINX);
  rpos = (float *)malloc(sizeof(float)*(XD_BINX + 2*CCRNGX));
  xcoeff = (float *)malloc(sizeof(float)*nx*(fitorder+1));
  xlstok = (float *)malloc(sizeof(float)*4*nx);

  nxok = 0;
  for (i=0; i<nx; i++) {
    xref = (int)xlst[4*i];
    y1   = (int)xlst[4*i + 1];
    y2   = (int)xlst[4*i + 2];
    yobj = (int)xlst[4*i + 3];
    ny   = y2 - y1 + 1;

    yy = (float *)malloc(sizeof(float)*ny);
    xx = (float *)malloc(sizeof(float)*ny); 

    x = xref;
    x1ref = x1 = x - XD_BINX / 2;
    x2 = x1 + XD_BINX - 1;
    medrows(x1,x2,y1,y1+XD_DY-1,inimg,hdr,rref);

    xx[0] = y1;
    yy[0] = 0.0;
    iy = 1;
    y  = y1+XD_DY;
    xc = x;

    while (y < y2) {
      x1 = xc - XD_BINX / 2 - CCRNGX;
      x2 = x1 + XD_BINX - 1 + 2*CCRNGX;
      if ((abs(y - yobj) > WOBJ/2) && (abs(y+XD_DY-1 - yobj) > WOBJ/2)) {
	medrows(x1,x2,y,y+XD_DY-1,inimg,hdr,rpos);
	dx = bestmatch(rpos, rref, XD_BINX+2*CCRNGX, XD_BINX, tracemethod) + x1 - x1ref;
        xc = x + dx; 

/*	printf("%d %d %d %d %0.2f\n",x1,x2,y,xc,dx);  
	for (j=x1; j<=x2; j++) printf("%0.0f ",rpos[j-x1]);
	puts(""); */

	xx[iy] = y;
	yy[iy] = dx;
	iy++;
      }
      y += XD_DY;
    }

    sprintf(title,"X-distortion fit, %i/%i, x=%i",i+1,nx,xref);
    nfit = xfit(xx, yy, iy, a, fitorder, fitorder, title);

    if (nfit >= 0) {
      for (j=0; j<=fitorder; j++) xcoeff[nxok*(fitorder+1) + j] = a[j];
      xlstok[4*nxok] = xlst[4*i];
      xlstok[4*nxok+1] = xlst[4*i+1];
      xlstok[4*nxok+2] = xlst[4*i+2];
      xlstok[4*nxok+3] = xlst[4*i+3];
      printf("%0.1f %0.1f %0.f %0.1f - ok\n",
        xlst[4*i],xlst[4*i+1],xlst[4*i+2],xlst[4*i+3]);
      nxok++;
    } else {
      switch (nfit) {
        case -1 : printf("%0.1f %0.1f %0.f %0.1f - rejected\n",
                   xlst[4*i],xlst[4*i+1],xlst[4*i+2],xlst[4*i+3]);
                  break;
        case -2 : puts(" ** Interrupted");
	          nxok = 0;
		  goto end;
	          break;
      }
    }

    free(xx);
    free(yy); 
  }

end:

  for (i=0; i<4*nxok; i++) xlst[i] = xlstok[i];
  free(xlstok);

  (*_nx) = nxok;

  free(rref);
  free(rpos);

  return xcoeff;
}

/* ======================================================================= */

float *do_xtran(
  float *inimg,
  hstruct *hdr,
  float *xlst,
  float *xcoeff,
  int   nx,
  int   fitorder,
  int   extend
) {
  int xref, y, y1, y2, yref, x, xmin, xmax;
  float *dxfit, *xx, dx, dxmin, dxmax;
  float *dxlast;
  float a[100];
  float *outimg;
  int i, ndx;
  int order;

  dxfit = (float *)malloc(sizeof(float)*nx);
  dxlast = (float *)malloc(sizeof(float)*hdr->naxis1);
  xx = (float *)malloc(sizeof(float)*nx); 

  outimg = (float *)malloc(sizeof(float)*hdr->naxis1*hdr->naxis2);

  for (x=0; x<hdr->naxis1; x++) dxlast[x] = 0.0;

  for (y=0; y<hdr->naxis2; y++) {   

    ndx = 0;
    xmin = hdr->naxis1;
    xmax = 0;

    for (i=0; i<nx; i++) {
      xref = (int)xlst[4*i];
      y1   = (int)xlst[4*i + 1] - extend;
      y2   = (int)xlst[4*i + 2] + extend;
      yref   = (int)xlst[4*i + 3];

      if ((y >= y1) && (y <= y2)) {
	xx[ndx] = xref;
        dxfit[ndx] = polyval(y, xcoeff + i*(fitorder+1), fitorder)
	          -  polyval(yref, xcoeff + i*(fitorder+1), fitorder);
	if (xref < xmin) { xmin = xref; dxmin = dxfit[ndx]; }
	if (xref > xmax) { xmax = xref; dxmax = dxfit[ndx]; }
	ndx++;
      }
    } 

    for (x=0; x<hdr->naxis1; x++) {
      if (ndx == 0) dx = 0.0; else
      if (ndx == 1) dx = dxfit[0]; else {
        if (ndx < 4) order = 1; else order = 2;
        polyfit(xx,dxfit,ndx,a,order);
        if (x < xmin) dx = polyval(xmin,a,order); else
        if (x > xmax) dx = polyval(xmax,a,order); else 
	dx = polyval(x, a, order); 
      } 
      outimg[y*hdr->naxis1 + x] = interp(inimg,hdr,x+dx,y);  
    } 
  }

  free(dxfit);
  free(dxlast);
  free(xx); 

  return outimg;
}

/* ======================================================================= */

 void xydist(char *params) {

  float *inimg, *img2, *outimg;
  hstruct hdr;
  char  tmps[100];
  static char  inname[255] = "", outname[255] = "";
  static char  ylstnm[255] = "", xlstnm[255] = "";
  float ylst[1000], xlst[1000];
  float *ycoeff, *xcoeff;
  float xref = 1000;
  int  intp_order = 2;
  int   i, ny, nx;

  if (nargs(params) == 4) {
    argn(params,1,inname);
    argn(params,2,ylstnm);
    argn(params,3,xlstnm);
    argn(params,4,outname);
  } else {
    printf("  Input image   : "); cscanf("%s",inname);
    printf("  Y transf. list: "); cscanf("%s",ylstnm);
    printf("  X transf. list: "); cscanf("%s",xlstnm);
    printf("  Output image  : "); cscanf("%s",outname);
  }

  if (getpar("XYDIST.YD_BINX",tmps)) YD_BINX = atoi(tmps);
  if (getpar("XYDIST.YD_DY",tmps)) YD_DY = atoi(tmps);
  if (getpar("XYDIST.XD_BINX",tmps)) XD_BINX = atoi(tmps);
  if (getpar("XYDIST.XD_DY",tmps)) XD_DY = atoi(tmps);
  if (getpar("XYDIST.WOBJ",tmps)) WOBJ = atoi(tmps);
  if (getpar("XYDIST.CCRNGY",tmps)) CCRNGY = atoi(tmps);
  if (getpar("XYDIST.CCRNGX",tmps)) CCRNGX = atoi(tmps);
  if (getpar("XYDIST.DYFITORDER",tmps)) DYFITORDER = atoi(tmps);
  if (getpar("XYDIST.DXFITORDER",tmps)) DXFITORDER = atoi(tmps);
  if (getpar("XYDIST.XREF",tmps)) xref = atof(tmps);
  if (getpar("XYDIST.INTP_ORDER",tmps)) intp_order = atoi(tmps);

  inimg = floatfitsimage(&hdr,inname, 1);

  if (inimg == NULL) {
    puts(FILE_OPEN_ERR);
    return;
  }

  ny = getlst(ylstnm,ylst,2);
  nx = getlst(xlstnm,xlst,4);

  puts("Y distortion reference points read from file:");
  for (i=0; i<ny; i++) printf("%0.2f %0.2f\n",ylst[2*i],ylst[2*i+1]);

  puts("X distortion reference points read from file:");
  for (i=0; i<nx; i++) printf("%0.2f %0.2f %0.2f %0.2f\n",
    xlst[4*i],xlst[4*i+1],xlst[4*i+2],xlst[4*i+3]);

  puts("Calculating y transformation..");
  ycoeff = calc_ytran(inimg, &hdr, ylst, &ny, DYFITORDER, YTRACEMETHOD);

  puts("Y distortion reference points selected:");
  for (i=0; i<ny; i++) printf("%0.2f %0.2f\n",ylst[2*i],ylst[2*i+1]);

  puts("Doing y transformation..");
  img2 = do_ytran(inimg, &hdr, ylst, ycoeff, ny, DYFITORDER, xref, intp_order);  
  free(inimg);

  puts("Calculating x transformation..");
  xcoeff = calc_xtran(img2, &hdr, xlst, &nx,DXFITORDER, XTRACEMETHOD);

  puts("Doing x transformation..");
  outimg = do_xtran(img2, &hdr, xlst, xcoeff, nx, DXFITORDER, 0);

  free(img2); 

  savefitsfile(&hdr, outimg, -32, outname);
  
  free(xcoeff);
  free(ycoeff); 
  free(outimg); 
  freehdr(&hdr);
}

/* ======================================================================= */

void saveydist(
  float *ylst,
  float *ycoeff,
  int    ny,
  int    fitorder,
  char *outnm
) {
  FILE *file;
  int   i, j;
  float *tmpy;
  int   *order;

  file = fopen(outnm,"w");
  if (file == NULL) {
    printf("** Error saving data: Could not open %s\n",outnm);
    return;
  }

  tmpy = (float *)malloc(sizeof(float)*ny);
  order = (int *)malloc(sizeof(int)*ny);

  for (i=0; i<ny; i++) tmpy[i] = ylst[2*i+1];
  fsort2(tmpy,order,ny);

  fprintf(file,"BAOLAB/YDISTMAP transformation\n");
  fprintf(file,"ny= %d\n",ny);
  fprintf(file,"yfitorder= %d\n",fitorder);
  fprintf(file,"Y_coordinates=\n");
  for (i=0; i<ny; i++) 
    fprintf(file,"%0.2f %0.2f\n",ylst[2*order[i]],ylst[2*order[i]+1]);
  fprintf(file,"Y_coefficients=\n");
  for (i=0; i<ny; i++) {
    for (j=0; j<=fitorder; j++) 
      fprintf(file,"%e ",ycoeff[order[i]*(fitorder+1)+j]);
    fprintf(file,"\n");
  }

  free(tmpy);
  free(order);

  fclose(file);
}

/* ======================================================================= */

float *getydist(
  char *fname,
  float *ylst,
  int   *ny,
  int   *fitorder
) {
  FILE *file;
  char *ch, tmps[255], s1[100];
  float *ycoeff = NULL;
  int   i,j;

  file = fopen(fname,"r");

  if (file == NULL) {
    puts(CANT_OPEN_FILE);
    return NULL;
  }

  ch = fgets(tmps,255,file);

  if (!strncmp(tmps,"BAOLAB/YDISTMAP transformation",30)) {
    ch = fgets(tmps,255,file); argn(tmps,2,s1); (*ny) = atoi(s1);
    printf("ny= %d\n",(*ny));
    ch = fgets(tmps,255,file); argn(tmps,2,s1); (*fitorder) = atoi(s1);
    printf("yfitorder= %d\n",(*fitorder));
    ch = fgets(tmps,255,file);

    for (i=0; i<(*ny); i++) {
      ch = fgets(tmps,255,file); 
      argn(tmps,1,s1); ylst[2*i] = atof(s1);
      argn(tmps,2,s1); ylst[2*i+1] = atof(s1);
    }

    ycoeff = (float *)malloc(sizeof(float)*(*ny)*(*fitorder+1));

    ch = fgets(tmps,255,file);

    for (i=0; i<(*ny); i++) {
      ch = fgets(tmps,255,file);
      for (j=0; j<=(*fitorder); j++) {
        argn(tmps,j+1,s1); ycoeff[i*(*fitorder+1)+j] = atof(s1);
      }
    }
  } else {
    printf(" ** Error: %s is not a valid Y transformation solution\n",fname);
  }

  fclose(file);

  return ycoeff;
}

/* ======================================================================= */

void savexdist(
  float *xlst,
  float *xcoeff,
  int    nx,
  int    fitorder,
  char  *fname
) {
  FILE *file;
  int   i, j;

  file = fopen(fname,"w");
  if (file == NULL) {
    printf("** Error saving data: Could not open %s\n",fname);
    return;
  }

  fprintf(file,"BAOLAB/XDISTMAP transformation\n");
  fprintf(file,"nx= %d\n",nx);
  fprintf(file,"xfitorder= %d\n",fitorder);
  fprintf(file,"X_coordinates=\n");
  for (i=0; i<nx; i++) fprintf(file,"%0.2f %0.2f %0.2f %0.2f\n",
    xlst[4*i],xlst[4*i+1],xlst[4*i+2],xlst[4*i+3]);
  fprintf(file,"X_coefficients=\n");
  for (i=0; i<nx; i++) {
    for (j=0; j<=fitorder; j++) fprintf(file,"%e ",xcoeff[i*(fitorder+1)+j]);
    fprintf(file,"\n");
  }

  fclose(file);
}

/* ======================================================================= */

float *getxdist(
  char *fname,
  float *xlst,
  int   *nx,
  int   *fitorder
) {
  FILE *file;
  char *ch, tmps[255], s1[100];
  float *xcoeff = NULL;
  int   i,j;

  file = fopen(fname,"r");

  if (file == NULL) {
    puts(CANT_OPEN_FILE);
    return NULL;
  }

  ch = fgets(tmps,255,file);

  if (!strncmp(tmps,"BAOLAB/XDISTMAP transformation",30)) {
    ch = fgets(tmps,255,file); argn(tmps,2,s1); (*nx) = atoi(s1);
    printf("nx= %d\n",(*nx));
    ch = fgets(tmps,255,file); argn(tmps,2,s1); (*fitorder) = atoi(s1);
    printf("xfitorder= %d\n",(*fitorder));
    ch = fgets(tmps,255,file);

    for (i=0; i<(*nx); i++) {
      ch = fgets(tmps,255,file); 
      argn(tmps,1,s1); xlst[4*i] = atof(s1);
      argn(tmps,2,s1); xlst[4*i+1] = atof(s1);
      argn(tmps,3,s1); xlst[4*i+2] = atof(s1);
      argn(tmps,4,s1); xlst[4*i+3] = atof(s1);
    }

    xcoeff = (float *)malloc(sizeof(float)*(*nx)*(*fitorder+1));

    ch = fgets(tmps,255,file);

    for (i=0; i<(*nx); i++) {
      ch = fgets(tmps,255,file);
      for (j=0; j<=(*fitorder); j++) {
        argn(tmps,j+1,s1); xcoeff[i*(*fitorder+1)+j] = atof(s1);
      }
    }
  } else {
    printf(" ** Error: %s is not a valid X transformation solution\n",fname);
  }

  fclose(file);

  return xcoeff;
}

/* ======================================================================= */

void ydistmap(char *params) {
  static char inname[255] = "", ylstnm[255] = "", outnm[255] = "";
  char  tmps[100];
  float *inimg, *ycoeff;
  float ylst[1000];
  hstruct hdr;
  int    i,ny;

  if (nargs(params) == 3) {
    argn(params,1,inname);
    argn(params,2,ylstnm);
    argn(params,3,outnm);
  } else {
    printf("  Input image   : "); cscanf("%s",inname);
    printf("  Y transf. file: "); cscanf("%s",ylstnm);
    printf("  Output file   : "); cscanf("%s",outnm);
  }

  if (getpar("YDISTMAP.YD_BINX",tmps)) YD_BINX = atoi(tmps);
  if (getpar("YDISTMAP.YD_DY",tmps)) YD_DY = atoi(tmps);
  if (getpar("YDISTMAP.YD_XMIN",tmps)) YD_XMIN = atoi(tmps);
  if (getpar("YDISTMAP.YD_XMAX",tmps)) YD_XMAX = atoi(tmps);
  if (getpar("YDISTMAP.CCRNGY",tmps)) CCRNGY = atoi(tmps);
  if (getpar("YDISTMAP.DYFITORDER",tmps)) DYFITORDER = atoi(tmps);
  if (getpar("YDISTMAP.YTRACEMETHOD",tmps)) {
    if (strstr(tmps,"CCORR") != NULL) YTRACEMETHOD = CCORR; else
    if (strstr(tmps,"FITCENT") != NULL) YTRACEMETHOD = FITCENT; else
    if (strstr(tmps,"FITPOLY") != NULL) YTRACEMETHOD = FITPOLY; else
    if (strstr(tmps,"FITMAX") != NULL) YTRACEMETHOD = FITMAX; 
  }

  inimg = floatfitsimage(&hdr,inname, 0);

  if (inimg == NULL) {
    puts(FILE_OPEN_ERR);
    return;
  }

  ny = getlst(ylstnm,ylst,2);
  puts("Y distortion reference points read from file:");
  for (i=0; i<ny; i++) printf("%0.2f %0.2f\n",ylst[2*i],ylst[2*i+1]);

  puts("Calculating y transformation..");
  ycoeff = calc_ytran(inimg, &hdr, ylst, &ny, DYFITORDER, YTRACEMETHOD);

  puts("Y distortion reference points selected:");
  for (i=0; i<ny; i++) printf("%0.2f %0.2f\n",ylst[2*i],ylst[2*i+1]);

  if (ny > 0) saveydist(ylst,ycoeff,ny,DYFITORDER,outnm);

  free(inimg);
  free(ycoeff);
  freehdr(&hdr);
}

/* --------------------------------------------------------------------- */

void ydistapp(char *params) {
  static char inname[255] = "", ylstnm[255] = "", outnm[255] = "";
  float *ycoeff, ylst[1000];
  int   ny, fitorder;
  float *inimg, *outimg;
  float xref = 1000;
  int   intp_order = 2;
  char tmps[255];
  hstruct hdr;
  int   i, j;

  if (nargs(params) == 3) {
    argn(params,1,inname);
    argn(params,2,ylstnm);
    argn(params,3,outnm);
  } else {
    printf("  Input image   : "); cscanf("%s",inname);
    printf("  Y transf. file: "); cscanf("%s",ylstnm);
    printf("  Output image  : "); cscanf("%s",outnm);
  }

  if (getpar("YDISTAPP.XREF",tmps)) xref = atof(tmps);
  if (getpar("YDISTAPP.INTP_ORDER",tmps)) intp_order = atoi(tmps);

  ycoeff = getydist(ylstnm,ylst,&ny,&fitorder);

  for (i=0; i<ny; i++) {
    printf("%0.2f ",ylst[2*i+1]);
    for (j=0; j<=fitorder; j++) printf("%e ",ycoeff[i*(fitorder+1)+j]);
    puts("");
  }

  if (ycoeff == NULL) {
    return;
  } 

  inimg = floatfitsimage(&hdr,inname,1);
  if (inimg == NULL) {
    puts(FILE_OPEN_ERR);
    return;
  }

  puts("Doing y transformation..");
  outimg = do_ytran(inimg, &hdr, ylst, ycoeff, ny, fitorder, xref, intp_order);  
  free(inimg);

  addcard(&hdr,"COMMENT","Corrected for Y-distortion by BAOLAB / YDISTAPPL",H_COMM);

  hdr.bitpix = -32;
  savefitsfile(&hdr,outimg, -32, outnm);

  free(outimg);
  freehdr(&hdr);
}

/* --------------------------------------------------------------------- */

void xdistmap(char *params) {
  static char inname[255] = "", xlstnm[255] = "", outnm[255] = "";
  char   tmps[100];
  float *inimg;
  hstruct hdr;
  int     nx;
  float   xlst[1000], *xcoeff;

  if (nargs(params) == 3) {
    argn(params,1,inname);
    argn(params,2,xlstnm);
    argn(params,3,outnm);
  } else {
    printf("  Input image   : "); cscanf("%s",inname);
    printf("  X transf. file: "); cscanf("%s",xlstnm);
    printf("  Output file   : "); cscanf("%s",outnm);
  }

  if (getpar("XDISTMAP.XD_BINX",tmps)) XD_BINX = atoi(tmps);
  if (getpar("XDISTMAP.XD_DY",tmps)) XD_DY = atoi(tmps);
  if (getpar("XDISTMAP.CCRNGX",tmps)) CCRNGX = atoi(tmps);
  if (getpar("XDISTMAP.DXFITORDER",tmps)) DXFITORDER = atoi(tmps);
  if (getpar("XDISTMAP.XTRACEMETOD",tmps)) {
    if (strstr(tmps,"CCORR") != NULL) XTRACEMETHOD = CCORR; else
    if (strstr(tmps,"FITCENT") != NULL) XTRACEMETHOD = FITCENT; else
    if (strstr(tmps,"FITPOLY") != NULL) XTRACEMETHOD = FITPOLY; else
    if (strstr(tmps,"FITMAX") != NULL) XTRACEMETHOD = FITMAX; 
  }

  inimg = floatfitsimage(&hdr,inname, 0);

  if (inimg == NULL) {
    puts(FILE_OPEN_ERR);
    return;
  }

  nx = getlst(xlstnm,xlst,4);
  xcoeff = calc_xtran(inimg, &hdr, xlst, &nx, DXFITORDER, XTRACEMETHOD);
  free(inimg);
  freehdr(&hdr);

  if (nx > 0) savexdist(xlst,xcoeff,nx,DXFITORDER,outnm);
}

/* --------------------------------------------------------------------- */

void xdistapp(char *params) {
  static char inname[255] = "", xlstnm[255] = "", outnm[255] = "";
  char   tmps[255];
  float *xcoeff, xlst[1000];
  int   nx, fitorder;
  int   extend = 0;
  float *inimg, *outimg;
  hstruct hdr;

  if (nargs(params) == 3) {
    argn(params,1,inname);
    argn(params,2,xlstnm);
    argn(params,3,outnm);
  } else {
    printf("  Input image   : "); cscanf("%s",inname);
    printf("  X transf. file: "); cscanf("%s",xlstnm);
    printf("  Output image  : "); cscanf("%s",outnm);
  }

  if (getpar("XDISTAPP.EXTEND",tmps)) extend = atoi(tmps);

  xcoeff = getxdist(xlstnm,xlst,&nx,&fitorder);

  if (xcoeff == NULL) {
    return;
  } 

  inimg = floatfitsimage(&hdr,inname,1);
  if (inimg == NULL) {
    puts(FILE_OPEN_ERR);
    return;
  }

  puts("Doing x transformation..");
  outimg = do_xtran(inimg, &hdr, xlst, xcoeff, nx, fitorder, extend);
  free(inimg);

  addcard(&hdr,"COMMENT","Corrected for X-distortion by BAOLAB / XDISTAPPL",H_COMM);

  hdr.bitpix = -32;
  savefitsfile(&hdr,outimg, -32, outnm);

  free(outimg);
  freehdr(&hdr);
}

/* ======================================================================= */
