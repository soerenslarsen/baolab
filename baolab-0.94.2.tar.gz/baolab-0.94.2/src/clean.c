#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"

static void do_clean(
  char *imname,
  float xc,
  float yc,
  float rad1,
  float dr,
  float nsigma,
  float niter,
  char *outname
) {
  float *im;
  float *dst;
  char tmps[100];
  hstruct hdr;
  int x,y;
  int r;
  float d;
  int i,n,it;
  float sum,avg,v,sdev;

  if (rad1 < 0) { puts("  ** Error: Radius < 0"); return; }
  if (dr < 1) { puts("  ** Error: Deltar(Radius) < 1"); return; }
  if (nsigma < 0) nsigma = 0.0;
  if (niter < 1) niter = 1;

  im = floatfitsimage(&hdr,imname,TRUE);
  if (im != NULL) {
    for (it=0; it<niter; it++) {
      for (r=(int)rad1; r<(int)(rad1+dr); r++) {
	n = 0;
	sum = avg = v = sdev = 0.0;

	/* Calculate average */
	for (y=(int)yc-r-1; y<=(int)yc+r+1; y++)  
	  for (x=(int)xc-r-1; x<=(int)xc+r+1; x++) {
	    d = sqrt(sqr(x-xc) + sqr(y-yc));
	    if (d >= r && d<r+1 && x>=0 && y>=0 && 
		x<hdr.naxis1 && y<hdr.naxis2) {
	      n++;
	      sum += im[x+y*hdr.naxis1];
	    }
	  }

        if (n>0) {
	  avg = sum/n;

	  /* Calculate standard deviation */
	  for (y=(int)yc-r-1; y<=(int)yc+r+1; y++)  
	    for (x=(int)xc-r-1; x<=(int)xc+r+1; x++) {
	      d = sqrt(sqr(x-xc) + sqr(y-yc));
	      if (d >= r && d<r+1 && x>=0 && y>=0 && 
		  x<hdr.naxis1 && y<hdr.naxis2) {
		v += sqr(im[x+y*hdr.naxis1]-avg);
	      }
	    }
	  sdev = sqrt(v/n);

	  /* Reject */
	  for (y=(int)yc-r-1; y<=(int)yc+r+1; y++)  
	    for (x=(int)xc-r-1; x<=(int)xc+r+1; x++) {
	      d = sqrt(sqr(x-xc) + sqr(y-yc));
	      if (d >= r && d<r+1 && x>=0 && y>=0 && 
		  x<hdr.naxis1 && y<hdr.naxis2) {
		if (fabs(im[x+y*hdr.naxis1] - avg) > sdev*nsigma)
		  im[x+y*hdr.naxis1] = avg;
	      }
	    }
        }
      }
    }

    n = hdr.naxis1*hdr.naxis2;
    dst = (float *)malloc(sizeof(float)*n);
    for (i=0; i<n; i++) dst[i] = im[i];

    sprintf(tmps,"CLEAN %s: R=[%0.1f:%0.1f]",imname,rad1,rad1+dr);
    addcard(&hdr,"HISTORY",tmps,H_COMM);
    sprintf(tmps,"CLEAN: (x,y) = (%0.1f,%0.1f)",xc,yc);
    addcard(&hdr,"HISTORY",tmps,H_COMM);
    savefitsfile(&hdr,dst,-32,outname);
    freehdr(&hdr);
    free(im);
  } else
    puts(IM_READ_ERR);
}

/*                                                                         */
/* ======================================================================= */
/*                                                                         */

void clean(char *params)
{
  static char imname[255] = "",
              outname[255] = "";
  static float  xc = 0.0, yc=0.0;
  float   rad1=1.0, dr = 10.0;
  char   tmps[255];
  float  nsigma = 2.0; /* sigma */
  int    niter = 2;

  if (getpar("CLEAN.NSIGMA",tmps)) nsigma = atof(tmps);
  if (getpar("CLEAN.NITER",tmps)) niter = atoi(tmps);
  if (getpar("CLEAN.RADIUS",tmps)) rad1 = atoi(tmps);
  if (getpar("CLEAN.DELTAR",tmps)) dr = atoi(tmps);

  if (rad1 < 0) { puts("  ** Error: Radius < 0"); return; }
  if (dr < 1) { puts("  ** Error: Deltar(Radius) < 1"); return; }

  if (nargs(params) == 4) {
    argn(params,1,imname);
    argn(params,2,tmps); xc = atof(tmps);
    argn(params,3,tmps); yc = atof(tmps);
    argn(params,4,outname);
  } else {
    printf("  Source    :  "); cscanf("%s",imname);
    printf("  Xcenter   :  "); cscanf("%0.1f",&xc);
    printf("  Ycenter   :  "); cscanf("%0.1f",&yc);
    printf("  Output    :  "); cscanf("%s",outname);
  }

  do_clean(imname,xc,yc,rad1,dr,nsigma,niter,outname);
 }
