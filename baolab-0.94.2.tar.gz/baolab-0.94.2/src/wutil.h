#ifndef WUTIL_MAIN

extern int wopen(                                                            
  char*,
  Window* ,                                
  GC*, GC*
);

extern void wclose(
  Window,
  GC, GC
);

extern void cross(
  Window,
  GC,
  int, int, int
);

extern void cross2(
  Window,
  GC,
  int, int, int
);

extern void box(
  Window,
  GC,
  int, int, int
);

extern int width(
  Window
);

extern int height(
  Window
);

extern int xpos(
  Window
);

extern int ypos(
  Window
);

extern void createbutwins(
  int, int,
  Window*,
  Window*,
  int,
  GC*
);

extern void drawbutwin(
  Window,
  GC,
  char*,
  int
);

extern void MakeButtons(
  Window,
  Window*, Window*,
  GC*
);

extern void DrawButton(
  int,
  Window,
  GC,
  int
);

extern int xsm_box(
  Window,
  GC,
  int*, int*,
  int*, int*
);

extern void setcolor(
  GC, const char*
);

extern void make_xaxis(
  Window,
  GC,
  float, float
);

extern void make_yaxis(
  Window,
  GC,
  float, float
);

#endif
