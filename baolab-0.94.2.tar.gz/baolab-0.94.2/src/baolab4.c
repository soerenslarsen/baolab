#include "fitsutil.h"
#include <sys/wait.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/Xmu/Drawing.h>
#include "baostr.h"
#include "baolab.h"
#include "wutil.h"

extern int do_display(char *, int, int, float *, float *);

XImage *O_im1, *O_im2, *O_im3, *O_im4;
int    O_bx, O_by, O_bdx, O_bdy;
int    O_wdx, O_wdy;

/* ==================================================================== */

void showcmd() {
  puts("  ** Commands: ");
  puts("  q = quit.");
  puts("  n = Next image.");
  puts("  p = Previous image.");
  puts("  l = Show image list.");
  puts("  Button1 = Move box.");
  puts("  Button3 = Size box.");
  puts("  ? = This list.");
}

/* -------------------------------------------------------------------- */

void HandleImMotion(
  Window win,
  GC     gc,
  int    button,
  int    *_x0, int *_y0,
  int    *_x,  int *_y,
  int    *_dx, int *_dy,
  XEvent event
)
{
   int x,y,x0,y0,dx,dy;
   int xx,yy;

   x = *_x;    y = *_y;
   x0 = *_x0; y0 = *_y0;
   dx = *_dx; dy = *_dy;

   xx = (x>0) ? x : 0;
   yy = (y>0) ? y : 0;

   XPutImage(DISPLAY,win,gc,O_im1,0,0,O_bx,      O_by,      O_bdx,1);
   XPutImage(DISPLAY,win,gc,O_im2,0,0,O_bx,      O_by+O_bdy-1,O_bdx,1);
   XPutImage(DISPLAY,win,gc,O_im3,0,0,O_bx,      O_by,     1,O_bdy);
   XPutImage(DISPLAY,win,gc,O_im4,0,0,O_bx+O_bdx-1,O_by,     1,O_bdy);

   switch (button) {
     case 3 : dx = 2*abs(event.xmotion.x - x0)+2;
	      dy = 2*abs(event.xmotion.y - y0)+2;
	      x = x0-dx/2;
	      y = y0-dy/2;
	      break;

     case 1 : x = event.xmotion.x-dx/2;  
	      y = event.xmotion.y-dy/2;
	      break;
   }

   XDestroyImage(O_im1);
   XDestroyImage(O_im2);
   XDestroyImage(O_im3);
   XDestroyImage(O_im4);

   O_bx = (x > 0) ? x : 0;   O_by = (y > 0) ? y : 0;
   O_bdx = (O_bx+dx < O_wdx) ? dx+x-O_bx : O_wdx-x-1;
   O_bdy = (O_by+dy < O_wdy) ? dy+y-O_by : O_wdy-y-1;

   O_im1 = XGetImage(DISPLAY,win,O_bx,      O_by,        O_bdx,1, 
                       AllPlanes,ZPixmap);
   O_im2 = XGetImage(DISPLAY,win,O_bx,      O_by+O_bdy-1 , O_bdx,1, 
                       AllPlanes,ZPixmap);
   O_im3 = XGetImage(DISPLAY,win,O_bx,      O_by,        1, O_bdy,
                       AllPlanes,ZPixmap);
   O_im4 = XGetImage(DISPLAY,win,O_bx+O_bdx-1,O_by,        1, O_bdy,
                       AllPlanes,ZPixmap);

   XDrawRectangle(DISPLAY,win,gc,x,y,dx-1,dy-1);

   *_x = x; *_y = y; *_x0 = x0; *_y0 = y0; *_dx = dx; *_dy = dy;
}

/* ==================================================================== */

void HandleKeyEvent(
  XEvent event,
  char  *imlist[],
  int    nim,
  int   *quit, int *im
)
{
   char tmps[80];
   int  n,i;
   KeySym keysym;
   XComposeStatus compose;

   tmps[0] = '\0';
   n = XLookupString(&(event.xkey),tmps,80,&keysym,&compose);
   if (keysym > XK_space) {
     switch (tmps[0]) {
       case 'h' :
       case '?' : showcmd(); break;

       case 'q' : *quit = 1; break;

       case 'l' : for (i=0;i<nim;i++) 
		    if (i==(*im))
		      printf("  ->%s\n",imlist[i]);
		    else
		      printf("    %s\n",imlist[i]);
		  break;

       case 'n' : if ((*im) < nim-1) (*im)++; else {
		    puts("  ** No more images.");
		    break;
		  }
       case 'p' : if (tmps[0]=='p') { 
		    if ((*im)>0) (*im)--; else {
		      puts("  ** No previos images.");
		      break;
		    }
		  }
     }
   }
}

/* ==================================================================== */

void mkbuttons(
  Window parentwin,
  Window *but1, Window *but2, Window *but3, Window *but4,
  GC     *gc
)
{
  XWindowAttributes winattr;
  int dx,dy;
  int screen;
  XGCValues gcval;
  Font  font;

  screen = DefaultScreen(DISPLAY);
  XGetWindowAttributes(DISPLAY,parentwin,&winattr);
  dx = winattr.width;
  dy = winattr.height;

  *but1 = XCreateSimpleWindow(DISPLAY,parentwin,0,0,dx/4,dy,0,
               BlackPixel(DISPLAY,screen),WhitePixel(DISPLAY,screen));

  *but2 = XCreateSimpleWindow(DISPLAY,parentwin,dx/4,0,dx/4,dy,0,
               BlackPixel(DISPLAY,screen),WhitePixel(DISPLAY,screen));

  *but3 = XCreateSimpleWindow(DISPLAY,parentwin,2*dx/4,0,dx/4,dy,0,
               BlackPixel(DISPLAY,screen),WhitePixel(DISPLAY,screen));

  *but4 = XCreateSimpleWindow(DISPLAY,parentwin,3*dx/4,0,dx/4,dy,0,
               BlackPixel(DISPLAY,screen),WhitePixel(DISPLAY,screen));

  XSelectInput(DISPLAY,*but1,StructureNotifyMask | ExposureMask | 
                             ButtonPressMask | KeyPressMask |
			     EnterWindowMask | LeaveWindowMask);
  XSelectInput(DISPLAY,*but2,StructureNotifyMask | ExposureMask | 
                             ButtonPressMask | KeyPressMask |
			     EnterWindowMask | LeaveWindowMask);
  XSelectInput(DISPLAY,*but3,StructureNotifyMask | ExposureMask | 
                             ButtonPressMask | KeyPressMask |
			     EnterWindowMask | LeaveWindowMask);
  XSelectInput(DISPLAY,*but4,StructureNotifyMask | ExposureMask | 
                             ButtonPressMask | KeyPressMask |
			     EnterWindowMask | LeaveWindowMask);

  gcval.foreground = BlackPixel(DISPLAY,screen);
  gcval.background = WhitePixel(DISPLAY,screen);
  gcval.line_width = 1;
  *gc = XCreateGC(DISPLAY,*but1, (GCForeground | GCBackground | GCLineWidth), 
                       &gcval);

  font = XLoadFont(DISPLAY,"9x15");
  XSetFont(DISPLAY,*gc,font);
}

/* ==================================================================== */

void ReconfigureWindows( Window mainwin, Window butwin )
{
  XWindowChanges winch;
  XWindowAttributes winattr;
  int screen;

  screen = DefaultScreen(DISPLAY);

  XGetWindowAttributes(DISPLAY,mainwin,&winattr);
  winch.y = 5; winch.x = 5;
  winch.width = winattr.width - 14;  
  winch.height = winattr.height - 14;
  XConfigureWindow(DISPLAY,butwin, CWWidth | CWHeight | CWY | CWX, &winch);
}

/* ==================================================================== */

void ReconfigureButtons(
  Window parentwin,
  Window but1, Window but2, Window but3, Window but4
)
{
  XWindowChanges winch;
  XWindowAttributes winattr;
  int dx,dy,screen;

  screen = DefaultScreen(DISPLAY);
  XGetWindowAttributes(DISPLAY,parentwin,&winattr);
  dx = winattr.width;
  dy = winattr.height;

  winch.width = dx/4; winch.x = 0;
  winch.height = dy;

  XConfigureWindow(DISPLAY,but1,CWWidth | CWHeight | CWX , &winch);
  winch.width = dx/4; winch.x = dx/4;
  XConfigureWindow(DISPLAY,but2,CWWidth | CWHeight | CWX , &winch);
  winch.width = dx/4; winch.x = 2*dx/4;
  XConfigureWindow(DISPLAY,but3,CWWidth | CWHeight | CWX , &winch);
  winch.width = dx/4; winch.x = 3*dx/4;
  XConfigureWindow(DISPLAY,but4,CWWidth | CWHeight | CWX , &winch);
}

/* ==================================================================== */

void drawbutton(
  int n,
  Window win,
  GC  gc,
  int status
)
{
  XWindowAttributes winattr;
  int dx,dy;
  int screen;
  char txt[10];

  screen = DefaultScreen(DISPLAY);
  XGetWindowAttributes(DISPLAY,win,&winattr);
  dx = winattr.width;
  dy = winattr.height;

  XClearWindow(DISPLAY,win);
  XmuDrawRoundedRectangle(DISPLAY,win,gc,3,3,dx-6,dy-6,6,6);
  if (status==1)
    XmuDrawRoundedRectangle(DISPLAY,win,gc,6,6,dx-12,dy-12,6,6);

  switch (n) {
    case 1 : strcpy(txt,"Done"); break;
    case 2 : strcpy(txt,"Next"); break;
    case 3 : strcpy(txt,"Prev"); break;
    case 4 : strcpy(txt,"Mark"); break;
  }

  XDrawString(DISPLAY,win,gc,10,23,txt,4); 
}

void mark_image(
  char *imname,
  int   x, int y,
  int   dx,int dy,
  FILE *outfile
)
{
  printf("  %s (%i,%i) (%i,%i)\n",imname,dx,dy,x,y);
  fprintf(outfile,"%s %i %i %i %i\n",imname,dx,dy,x,y);
}

/* ==================================================================== */

int ofs_mainwin(
  char  *imlist[],
  int    nim,
  int    zoom,
  char  *outname  /* Output file for storage of offsets */
)
{
  Window   mainwin,butwin;
  Window   but1,but2,but3,but4;
  int      screen;
  int      quit,xx,yy;
  int      im=0;
  XEvent   event;
  GC       butgc;
  XGCValues gcval;
  unsigned short ii;

  char    *title = "Offset control panel";
  XTextProperty winname;
  XSizeHints *size_hints;
  int      x=0,y=0,x0,y0,dx=25,dy=25;
  int      button;
  FILE    *outfile;
  float   locut=0,hicut=1000;

  outfile = fopen(outname,"w");
  if (outfile == NULL) { puts("  ** Error opening output file."); return 0; }

  if (do_display(imlist[0],1,TRUE,&locut,&hicut)) {

    screen = DefaultScreen(DISPLAY);

    mainwin = XCreateSimpleWindow(DISPLAY,RootWindow(DISPLAY,screen),
			      xpos(IMAGE->window), 
			      ypos(IMAGE->window)+height(IMAGE->window), 
			      300,50,0,
			      BlackPixel(DISPLAY,screen),
			      WhitePixel(DISPLAY,screen)); 

    butwin = XCreateSimpleWindow(DISPLAY,mainwin,5,5,286,36,2,
				BlackPixel(DISPLAY,screen),
				WhitePixel(DISPLAY,screen));

    mkbuttons(butwin,&but1,&but2,&but3,&but4,&butgc);

    size_hints = XAllocSizeHints();
    size_hints->flags = PPosition | PSize | PMinSize;
    size_hints->min_width = 300;
    size_hints->min_height= 50;

    XStringListToTextProperty(&title,1,&winname);
    XSetWMProperties(DISPLAY,mainwin,&winname,NULL,NULL,0,size_hints,
		     NULL,NULL);
    free(size_hints);

    XSelectInput(DISPLAY,mainwin,StructureNotifyMask | ExposureMask | 
				 KeyPressMask);
    XSelectInput(DISPLAY,butwin,StructureNotifyMask | ExposureMask |
			     ButtonPressMask | KeyPressMask);
    XSelectInput(DISPLAY,IMAGE->window,StructureNotifyMask | ExposureMask |
                           ButtonPressMask | Button1MotionMask |
                           Button3MotionMask | KeyPressMask);

    XMapWindow(DISPLAY,mainwin);
    XMapWindow(DISPLAY,butwin);
    XMapWindow(DISPLAY,but1); XMapWindow(DISPLAY,but2); 
    XMapWindow(DISPLAY,but3); XMapWindow(DISPLAY,but4);

    quit = 0;
    O_wdx = width(IMAGE->window);
    O_wdy = height(IMAGE->window);
    O_bx = x;  O_by = y;
    O_bdx = dx; O_bdy = dy;

    O_im1 = XGetImage(DISPLAY,IMAGE->window,O_bx,      O_by,        O_bdx,1, 
                       AllPlanes,ZPixmap);
    O_im2 = XGetImage(DISPLAY,IMAGE->window,O_bx,      O_by+O_bdy-1 , O_bdx,1, 
                       AllPlanes,ZPixmap);
    O_im3 = XGetImage(DISPLAY,IMAGE->window,O_bx,      O_by,        1, O_bdy,
                       AllPlanes,ZPixmap);
    O_im4 = XGetImage(DISPLAY,IMAGE->window,O_bx+O_bdx-1,O_by,        1, O_bdy,
                       AllPlanes,ZPixmap);

    XGetGCValues(DISPLAY,IMAGE->gc,GCForeground,&gcval);
    setcolor(IMAGE->gc,"red");
    XDrawRectangle(DISPLAY,IMAGE->window,IMAGE->gc,x,y,dx-1,dy-1);

    do {
      XNextEvent(DISPLAY,&event);

      switch (event.type) {
	case ConfigureNotify:
	     if (event.xany.window == mainwin) {
	       ReconfigureWindows(mainwin,butwin);
               ReconfigureButtons(butwin,but1,but2,but3,but4);
	     }
	     break;

	case EnterNotify :
	     if (event.xany.window == but1) { drawbutton(1,but1,butgc,1); }
	     if (event.xany.window == but2) { drawbutton(2,but2,butgc,1); }
	     if (event.xany.window == but3) { drawbutton(3,but3,butgc,1); }
	     if (event.xany.window == but4) { drawbutton(4,but4,butgc,1); }
	     break;
	 
	case LeaveNotify :
	     if (event.xany.window == but1) { drawbutton(1,but1,butgc,0); }
	     if (event.xany.window == but2) { drawbutton(2,but2,butgc,0); }
	     if (event.xany.window == but3) { drawbutton(3,but3,butgc,0); }
	     if (event.xany.window == but4) { drawbutton(4,but4,butgc,0); }
	     break;
	
	case Expose : 
	     if (event.xexpose.window == but1) drawbutton(1,but1,butgc,0);
	     if (event.xexpose.window == but2) drawbutton(2,but2,butgc,0);
	     if (event.xexpose.window == but3) drawbutton(3,but3,butgc,0);
	     if (event.xexpose.window == but4) drawbutton(4,but4,butgc,0);
	   break;

	case ButtonPress:
	case KeyPress: 
	    ii = im;
	    if (event.type==KeyPress)
	      HandleKeyEvent(event,imlist,nim,&quit,&im);
	    else {
	      if (event.xbutton.window == mainwin) { break; } else
	      if (event.xbutton.window == IMAGE->window) { 
		button = event.xbutton.button;
		if (button==3) {
		  x0 = x+dx/2;
		  y0 = y+dy/2;
		}
		break;
	      } else
	      if (event.xbutton.window == but1) quit = 1;
	      ii = im;
	      if (event.xbutton.window == but2)
		if (im == nim-1) puts("  ** No more images."); else im++;
	      if (event.xbutton.window == but3)
		if (im == 0) puts("  ** No previous images."); else im--;
	      if (event.xbutton.window == but4) 
		mark_image(imlist[im],x,y,dx,dy,outfile);
	    }

	    if (im != ii) {
	      printf("  Loading image [%s]..\n",imlist[im]);
	      do_display(imlist[im],1,TRUE,&locut,&hicut);

   XDestroyImage(O_im1);
   XDestroyImage(O_im2);
   XDestroyImage(O_im3);
   XDestroyImage(O_im4);

   O_im1 = XGetImage(DISPLAY,IMAGE->window,O_bx,      O_by,        O_bdx,1, 
                       AllPlanes,ZPixmap);
   O_im2 = XGetImage(DISPLAY,IMAGE->window,O_bx,      O_by+O_bdy-1 , O_bdx,1, 
                       AllPlanes,ZPixmap);
   O_im3 = XGetImage(DISPLAY,IMAGE->window,O_bx,      O_by,        1, O_bdy,
                       AllPlanes,ZPixmap);
   O_im4 = XGetImage(DISPLAY,IMAGE->window,O_bx+O_bdx-1,O_by,        1, O_bdy,
                       AllPlanes,ZPixmap);

              XDrawRectangle(DISPLAY,IMAGE->window,IMAGE->gc,x,y,dx-1,dy-1);
	    }
	  break;

	case MotionNotify :
	    if (event.xmotion.window == IMAGE->window) {
	      HandleImMotion(IMAGE->window,IMAGE->gc,button,
	                      &x0,&y0,&x,&y,&dx,&dy,event);
	    }
	  break;
      }	         
    } while (!quit);

    xx = (x>0) ? x : 0;
    yy = (y>0) ? y : 0;

    XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,
               O_im1,0,0,O_bx,      O_by,      O_bdx,1);
    XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,
               O_im2,0,0,O_bx,      O_by+O_bdy-1,O_bdx,1);
    XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,
               O_im3,0,0,O_bx,      O_by,     1,O_bdy);
    XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,
               O_im4,0,0,O_bx+O_bdx-1,O_by,     1,O_bdy);

    XDestroyImage(O_im1);
    XDestroyImage(O_im2);
    XDestroyImage(O_im3);
    XDestroyImage(O_im4);

    XDestroyWindow(DISPLAY,mainwin);
    XChangeGC(DISPLAY,IMAGE->gc,GCForeground,&gcval);
    XFlush(DISPLAY);
  }

  fclose(outfile);
}

/* ==================================================================== */

static void sumy(
  short *image,
  int   imdx, int imdy,
  int   x1, int y1, int x2, int y2,
  int   *buff
)
{
  int x,y,offs;

  for (x=x1; x<=x2; x++) {
    buff[x-x1] = 0;
    offs = x + y1*imdx;
    for (y=y1; y<=y2; y++,offs+=imdx) buff[x-x1] += image[offs];
  }
}

/* -------------------------------------------------------------------- */

static void sumx(
  short *image,
  int   imdx, int imdy,
  int   x1, int y1, int x2, int y2,
  int   *buff
)
{
  int x,y,offs;

  for (y=y1; y<=y2; y++) {
    buff[y-y1] = 0;
    offs = y*imdx + x1;
    for (x=x1; x<=x2; x++) buff[y-y1] += image[offs++];
  }
}
   
/* ==================================================================== */

static void pre_correlate(
  char *imlist[],
  int   nim,
  char *outname
) 
{
  FILE *file; 
  char tmps[255],refim[255],s1[100];
  char *ch;
  int  boxdx,boxdy,xref,yref;
  int  *xbuff,*ybuff,*xrefbuff,*yrefbuff;
  int  maxx,maxy;
  float max,sum;
  int  x,y;
  int  dx,dy;
  short *imdata;
  hstruct hdr;
  int  i;

  file = fopen(outname,"r+");
  if (file != NULL) {
    do {
      ch = fgets(tmps,255,file);
      if (ch != NULL) {
        sglspc(tmps);
	argn(tmps,1,refim);
	argn(tmps,2,s1); boxdx = atoi(s1);
	argn(tmps,3,s1); boxdy = atoi(s1);
	argn(tmps,nargs(tmps)-1,s1); xref = atoi(s1);
	argn(tmps,nargs(tmps),s1); yref = atoi(s1);
      }
    } while (ch != NULL);

    imdata = shortfitsimage(&hdr,refim,FALSE);
    if (imdata != NULL) {
      printf("  Reference: %s, %ix%i+%i+%i\n",refim,boxdx,boxdy,xref,yref);
      xrefbuff = (int *)malloc(4*boxdx);
      yrefbuff = (int *)malloc(4*boxdy);

      sumx(imdata,hdr.naxis1,hdr.naxis2,xref, yref, 
                                        xref+boxdx, yref+boxdy, yrefbuff);
      sumy(imdata,hdr.naxis1,hdr.naxis2,xref, yref,
                                        xref+boxdx, yref+boxdy, xrefbuff);
      free(imdata);
      rewind(file);

      fprintf(file,"%s %i %i %i %i\n",refim,boxdx,boxdy,xref,yref);
      for (i=0; i<nim; i++) {
	if (strcmp(imlist[i],refim)) {  /* Don't store the reference twice */
	  imdata = shortfitsimage(&hdr,imlist[i],FALSE);
	  if (imdata != NULL) {
	    printf("  %s ",imlist[i]); fflush(stdout);
	    xbuff = (int *)malloc(4*hdr.naxis1);
	    ybuff = (int *)malloc(4*hdr.naxis2);

	    sumx(imdata,hdr.naxis1,hdr.naxis2,0,0,hdr.naxis1-1,
	                                          hdr.naxis2-1,ybuff);
	    sumy(imdata,hdr.naxis1,hdr.naxis2,0,0,hdr.naxis1-1,
	                                          hdr.naxis2-1,xbuff);

	    free(imdata);

	    max = 0; maxx = 0; maxy = 0;
            for (dx=0; dx<hdr.naxis1-boxdx; dx++) {
	      sum = 0;
	      for (x=0; x<boxdx; x++) 
	        sum += (float)xrefbuff[x] * (float)xbuff[x+dx];
              if (sum > max) {
	        max = sum;
		maxx = dx;
	      }
	    }

	    max = 0;
	    for (dy=0; dy<hdr.naxis2-boxdy; dy++) {
	      sum = 0;
	      for (y=0; y<boxdy; y++)
	        sum += (float)yrefbuff[y] * (float)ybuff[y+dy];
	      if (sum > max) {
	        max = sum;
		maxy = dy;
	      }
	    }

	    printf(" %i %i %i %i\n",boxdx,boxdy,maxx,maxy);
	    fprintf(file,"%s %i %i %i %i\n",imlist[i],
	                boxdx,boxdy,maxx,maxy);

            free(xbuff);
	    free(ybuff);
	  } else
	    printf("  Warning: Error reading %s - continuing..\n",imlist[i]);
	}
      }

      fclose(file);
      free(xrefbuff);
      free(yrefbuff);
    }
  } else
    puts(CANT_OPEN_FILE);
}

/* ==================================================================== */

void setoffset(char *params)
{
  char *imlist[1000];  /* Array containg names of images to combine. */
  static char outname[255] = "", listname[255] = "";
  char tmps[100];
  int  i,nim;
  int  automode = FALSE;

  if (getpar("OFFS.AUTO",tmps)) automode = !(strcmp(upcstr(tmps),"YES"));

  if (nargs(params) == 2) {    /* a bit tricky - remember TRUE = 1 */
    argn(params,1,listname);
    nim = getoffslist(listname,imlist,NULL,NULL);
    argn(params,2,outname);
  } else {
    printf("  List of images :  "); cscanf("%s",listname);
    nim = getoffslist(listname,imlist,NULL,NULL);
    if (nim > 0) printf("  Output file    :  "); cscanf("%s",outname);
  }

  if (nim > 0) ofs_mainwin(imlist,nim,1,outname);

  if (automode) {
    puts("  ** Pre-correlating images..");
    pre_correlate(imlist,nim,outname);
  }

  for (i=0;i<nim;i++) free(imlist[i]);
}

/* ==================================================================== */
