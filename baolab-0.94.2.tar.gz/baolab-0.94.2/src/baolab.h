#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
/*
#if defined(OS_Darwin)
  #include <sys/types.h> 
  #include <sys/malloc.h> 
#else
  #include <malloc.h> 
#endif
*/
#include <math.h>
#include <fcntl.h>

#define VERSION "0.94.2"

#define MAXWIN 25
#define NO_IM_ERR "  ** Error: No image."
#define CANT_OPEN_FILE "  ** Error: Cannot open file."
#define WIN_DONT_EXIST "  ** Error: Window does not exist."
#define CANT_OPEN_WIN  "  ** Error: Unable to open window."
#define NO_IMAGE_WINS  "  ** Error: No image window."
#define FILE_OPEN_ERR  "  ** Error opening file."
#define IM_READ_ERR    "  ** Error reading image."

#define T_BYTE 1      /* Definitions for tiff-conversion */
#define T_ASCII 2
#define T_SHORT 3
#define T_LONG  4

#define cscanf(A,B) if (bscanf( (A) , (B) ) == CTRL_C) return
#define sqr(A) ((A)*(A))
#define sgn(A) (A >= 0 ? 1 : -1)
#ifndef rint
  #define rint(X) floor((X)+0.5)
#endif

typedef struct {
            int    dx,dy,binsize;
            float *data;
        } psftype;

typedef struct {
            float  *image;
	    hstruct header; 
        } imdatatype;

#ifdef  X_H
typedef struct _imstruct {
            int     nr;
            Window  window;
	    Window  palwin;
            GC      gc;
	    char    fname[256];
	    int     zoom;
	    int     mapped;
            unsigned char tff[4096];
	    char    tffname[255];
	    float   locut,hicut;
	    struct _imstruct *next;
	    struct _imstruct *prev;
        } imstruct;
#endif

typedef struct _alias {
  char *alias;
  char *meaning;
  int  active;
} aliasstruct;

typedef struct {
  char *name[255];
  char *value[255];
  int  nparams;
} paramstruct;

typedef struct {
  float annulus;
  float dannulus;
  float thresh;
  float epadu;
  float ron;
  float sigma;
  int   niter;
  float fwhm;
  float rgrow;
  int   psftype;
  int   psfdim;
  char  psfname[255];
} cosmicstruct;

typedef struct {
  int   rezx, rezy;
  float fwhm;
  float rdnoise;
  float epadu;
  float backgr;
  float zpoint;
  float bias;
  int   pnoise;
  int   psftype;
  float fwhm2, psfweight;
  float psfrad;
  int   verbose;
  char  psffile[255];
} mksynthstruct;

typedef struct {
  float fwhmpsfx;
  float fwhmpsfy;
  float pangle;
  float fwhmobjx;
  float fwhmobjy;
  float objangle;
  float index;
  int psftype;
  int objtype;
  int bitpix;
  float radius;
  char  objfile[255];
  char  psffile[255];
} mkpsfstruct;

typedef struct {
  int   fitrad;
  float centerrad;
  float xcentre, ycentre;
  int   maxciter;
  int   centermethod;
  float cleanrad;
  float ctresh;
  int   shape;
  float index;
  int   elliptical;
  int   usedk;
  float epadu;
  float ron;
  float fwhmmax;
  float ftol;
  float eftol;
/*  float ampltol; */
  float fwhmtol;
  char  resimage[255];
  int   keeplog;
  int   calcerr;
  int   correrr;
  int   replace;
  int   verbose;
  int   fitsec[4];
  char  logname[255];
  FILE *logfile;
  int   logmode;
  float *weights;
  float *diffkernel;
  char  dkname[255];
  int   dimdk;
  float flux;
  float bkg;
  float chsq0;
  float bknoise;
  char  comment[255];
  float datamin;
  float datamax;
} ishapestruct;

#ifdef BAOLAB_MAIN
  extern Display *DISPLAY;
  Window WIN[MAXWIN];
  GC     GC1[MAXWIN], GC2[MAXWIN];
  int    PLOTWIN = -1;
  int    WEXIST[MAXWIN];
  aliasstruct aliases[255]; 
  paramstruct PARAMS;

  int    COLRES = 0;
  int    TRUECOL = 0;
  int    DEPTH = 0;
  int    PIXELSZ = 0;
  long   PIXELS[256];
  unsigned short PAL[128][3];
  imstruct *IMAGE;
  char   CFGFILE[256] = "";
#else
  #ifdef X_H
    extern Display *DISPLAY;
    extern Window WIN[MAXWIN];
    extern GC GC1[MAXWIN], GC2[MAXWIN];
    extern imstruct *IMAGE;
  #endif

  extern int PLOTWIN;
  extern int WEXIST[MAXWIN];
  extern int COLRES;
  extern int TRUECOL;
  extern int DEPTH;
  extern int PIXELSZ;
  extern long PIXELS[256];
  extern unsigned short PAL[128][3];

  extern int getpar(char *, char *);
  extern int getimlst(char *, char**);
  extern int getoffslist(
    char *,    /* Name of the file */
    char**,    /* Array to contain image names */
    float *,   /* Array to contain x values */
    float *    /* Array to contain y values */
  );
  extern paramstruct PARAMS;
#endif

typedef struct {
            int combtype;
	    int reject;
	    float sigreject;
	    int weight;
	    int scale;
	    char statwin[100];
	    int  pixweight;
	    int  outsize;
	} imcombtype;

#define pi 3.14159265359

#define FALSE 0
#define TRUE 1
#define YES 1
#define NO 0
#define MEDIAN 1
#define AVERAGE 2
#define SUM 3
#define C_MAX 4
#define C_MIN 5
#define VALUE 6 

#define NONE 6
#define SIGMA 7
#define NEAREST 8

#define COVERALL 9
#define REFIMSIZE 10
#define COMMON 11

#define FITMAX 12
#define FITPOLY 13
#define FITRPOLY 14
#define FITNONE 15
#define FITCENT 16
#define CCORR   17

#define ALL 15
#define SAME 16
#define NOEMPTY 17

#define SCALE 18
#define PROB 19

/* PSF types: */

#define GAUSS 1
#define GAUSS2 2
#define MOFFAT15 3
#define MOFFAT25 4
#define LORENZ   5
#define USER     6
#define DELTA    7
#define HUBBLE   8
#define LUGGER   9
#define KING5    10
#define KING15   11
#define KING30   12
#define KING100  13
#define KINGn    14
#define MOFFATn  15
#define KINGx    16
#define MOFFATx  17
#define EXPN     18
#define EFF10    19
#define EFF15    20
#define EFF25    21
#define EFFn     22
#define EFFx     23
#define EFFCn10  24
#define EFFCn15  25
#define EFFCn25  26
#define EFFCx10  27
#define EFFCx15  28
#define EFFCx25  29
#define KINGt    30
#define SERSICx  31
#define SERSICn  32

#define CONST 1

#define CTRL_C 3
#define CTRL_M 13

