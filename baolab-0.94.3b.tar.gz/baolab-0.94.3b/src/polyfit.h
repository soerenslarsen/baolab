extern float polyval(
  float,        /*  x            */
  float *,      /*  coefficients */
  int           /*  order        */
);

extern int polyfit(
  float *,    /* Sampling points */
  float *,    /* Data values     */
  int   ,    /* Number of sampling points / data values */
  float *,    /* Fitted coefficients */
  int        /* degree of polynomium */
);
