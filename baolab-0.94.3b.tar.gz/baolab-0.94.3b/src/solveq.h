#ifndef SOLVEQ_MAIN

extern void echelon(
  double *,
  int 
);

#endif
