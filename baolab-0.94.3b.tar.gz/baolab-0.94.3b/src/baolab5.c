#include "fitsutil.h"
#include <sys/wait.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include "baostr.h"
#include "baolab.h"
#include "wutil.h"

/* extern void fit(float *, float *, int, int, float *);  */
/* obsolete; was in fit.c                                 */

/* ==================================================================== */

void printpix(
  hstruct *hdr,
  float   *buff,
  int      x, int y,
  imstruct imwin
)
{
  int xx;
  int yy;
  float pix;

  if (imwin.zoom > 0) {
    xx = x/imwin.zoom;
    yy = y/imwin.zoom;
  } else {
    xx = -x*imwin.zoom;
    yy = -y*imwin.zoom;
  }

  pix = buff[hdr->naxis1*yy+xx];
  if (fabs(pix) > 1)
    printf("  (%i,%i) : %0.1f \n",xx,yy,pix); 
  else
    printf("  (%i,%i) : %0.2e \n",xx,yy,pix); 
}

/* ==================================================================== */

void xrdpix(char *params)
{
  XEvent event;
  int    quit = FALSE;
  int    n,x,y,zoom = IMAGE->zoom;
  int    z = (zoom > 0) ? zoom : 1;
  XGCValues gcval;
  hstruct hdr;
  KeySym  keysym;
  XComposeStatus compose;
  char    tmps[80];
  float  *buff;
  XImage *ximg;
  int    wdx,wdy;

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }
  
  if (IMAGE->fname[0] == '\0') {
    puts(NO_IM_ERR);
    return;
  }

  ximg = XGetImage(DISPLAY,IMAGE->window,5,5,11,11,AllPlanes,ZPixmap);
  wdx = width(IMAGE->window);
  wdy = height(IMAGE->window);

  if (IMAGE->mapped) {
    if ((buff = floatfitsimage(&hdr,IMAGE->fname,FALSE)) != NULL) {
      XSelectInput(DISPLAY,IMAGE->window, ButtonPressMask | ButtonReleaseMask |
                                     Button1MotionMask |
				     Button3MotionMask | KeyPressMask);

      XGetGCValues(DISPLAY,IMAGE->gc,GCForeground,&gcval);
      setcolor(IMAGE->gc,"red");

      x = 10; y = 10;
      ximg = XGetImage(DISPLAY,IMAGE->window,x-5,y-5,11,11,AllPlanes,ZPixmap);
      cross2(IMAGE->window,IMAGE->gc,x,y,5);

      do {
        XNextEvent(DISPLAY,&event);
        XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,ximg,
		       0,0,x-5,y-5,11,11);
        XDestroyImage(ximg);

	switch (event.type) {
	  case ButtonRelease:
		 if (event.xbutton.button == 3) quit = TRUE;
		 if (event.xbutton.button == 1) {
		   x = event.xbutton.x;
		   y = event.xbutton.y;
		   printpix(&hdr,buff,x,y,*IMAGE);
		 }
		 break;

           case KeyPress:
	           tmps[0] = '\0';
		   n = XLookupString(&(event.xkey),tmps,80,&keysym,&compose);
		   switch (keysym) {
		     case XK_Left :  if (x>z) x -= z; 
		                     printpix(&hdr,buff,x,y,*IMAGE);
		                     break;

		     case XK_Right:  if (x<(hdr.naxis1-1)*z) x += z; 
		                     printpix(&hdr,buff,x,y,*IMAGE);
		                     break;

		     case XK_Up   :  if (y>z) y -= z; 
		                     printpix(&hdr,buff,x,y,*IMAGE);
		                     break;

		     case XK_Down :  if (y<(hdr.naxis2-1)*z) y += z; 
		                     printpix(&hdr,buff,x,y,*IMAGE);
		                     break;

		     case XK_Escape: quit = TRUE;
		                     break;
		   }

                  break; 

	   case MotionNotify:
		   x = event.xmotion.x;
		   y = event.xmotion.y;
		  break;
	}
	if (x<5) x = 5;  if (x > wdx-6) x = wdx-6;
	if (y<5) y = 5;  if (y > wdy-6) y = wdy-6;

        ximg = XGetImage(DISPLAY,IMAGE->window,x-5,y-5,11,11,AllPlanes,ZPixmap);
        cross2(IMAGE->window,IMAGE->gc,x,y,5);
      } while (!quit);

      XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,ximg,
	      0,0,x-5,y-5,11,11);
      XDestroyImage(ximg);
      XChangeGC(DISPLAY,IMAGE->gc,GCForeground,&gcval);
      XFlush(DISPLAY);
      free(buff);

    } else
      puts("  ** Error reading file.");
  } else
    puts(NO_IM_ERR);
}

/* ==================================================================== */

void xstat(char *params)
{
  int    x,y,dx,dy;
  float  *buff;
  hstruct hdr;
  int    x1,y1,x2,y2;
  int    i,npix;
  float  f,sum,avg,stdev,varians,min,max;
  XGCValues gcval;

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }
  
  if (IMAGE->fname[0] == '\0') {
    puts(NO_IM_ERR);
    return;
  }

  if (IMAGE->mapped) {
    x = 20; y = 20;
    dx = 20; dy = 20;

    XGetGCValues(DISPLAY,IMAGE->gc,GCForeground,&gcval);
    setcolor(IMAGE->gc,"red");

    if (xsm_box(IMAGE->window,IMAGE->gc,&x,&y,&dx,&dy)) {
      buff = floatfitsimage(&hdr,IMAGE->fname,FALSE);

      if (buff != NULL) {
        if (IMAGE->zoom > 0) {
          x1 = x/IMAGE->zoom;       y1 = y/IMAGE->zoom;
	  x2 = (x+dx)/IMAGE->zoom;  y2 = (y+dy)/IMAGE->zoom;
	} else {
	  x1 = -x*IMAGE->zoom;      y1 = -y*IMAGE->zoom;
	  x2 = -(x+dx)*IMAGE->zoom; y2 = -(y+dy)*IMAGE->zoom;
	}

        npix = (x2-x1+1)*(y2-y1+1);

	min = 100000; max = -100000; sum = 0;

	for (y=y1;y<=y2;y++) {
	  i = y*hdr.naxis1 + x1;
	  for (x=x1; x<=x2; x++) {
	    if (buff[i] < min) min = buff[i];
	    if (buff[i] > max) max = buff[i];
	    sum += buff[i];
	    i++;
	  }
	}
	avg = sum/npix;
	
	printf("  xstat output: \n");
        printf("   No. of pixels = %6i\n",npix);
        printf("   Min. value    = %7.1f\n",min);
        printf("   Max. value    = %7.1f\n",max);
        printf("   Avg. value    = %7.1f\n",avg);
        printf("   Sum           = %8.0f\n",sum);

	varians = 0;
	for (y=y1; y<=y2; y++) {
	  i = y*hdr.naxis1+ x1;
	  for (x=x1; x<=x2; x++) {
	    f = buff[i] - avg;
	    varians += f*f;
	    i++;
	  }
	}

	varians /= npix;
	stdev = sqrt(varians);

        printf("   Variance      = %8.2f\n",varians);
        printf("   Std. dev.     = %8.2f\n",stdev);

        free(buff);
      } else
        puts("  ** Error opening image.");
    }
    XChangeGC(DISPLAY,IMAGE->gc,GCForeground,&gcval);
  } else
    puts(NO_IM_ERR);
}

/* ==================================================================== */

void plottff(char *params)
{
  int wdx,wdy;
  XPoint points[256];
  int i;

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }

  if (PLOTWIN == -1) {
    if (wopen("BAOLab Plot 0",&(WIN[0]),&(GC1[0]),&(GC2[0]))) {
      PLOTWIN = 0;
      WEXIST[0] = 1;
    } else {
      puts(CANT_OPEN_WIN);
      return;
    }
  }

  if (PLOTWIN >= 0) {
    XClearWindow(DISPLAY,WIN[PLOTWIN]);
    wdx = width(WIN[PLOTWIN]);
    wdy = height(WIN[PLOTWIN]);

    XDrawLine(DISPLAY,WIN[PLOTWIN],GC1[PLOTWIN],30,wdy-30,wdx-20,wdy-30);
    XDrawLine(DISPLAY,WIN[PLOTWIN],GC1[PLOTWIN],50,10,50,wdy-10);

    for (i=0;i<256;i++) {
      points[i].x = 50+(int)(i*(wdx-60.0)/256.0);
      points[i].y = wdy-30-(int)(IMAGE->tff[16*i]*(wdy-40.0)/256.0);
    }

    XDrawLines(DISPLAY,WIN[PLOTWIN],GC1[PLOTWIN],
               points, 256, CoordModeOrigin);

    XFlush(DISPLAY);
  }
}

/* ==================================================================== */

int tobmp(
  char *fname,
  float locut, float hicut,
  unsigned char *tff,
  char *bmpname
)
{
  int    handle,i,n1,n,nsave;
  unsigned int  fsize,npix,imdx,imdy;
  unsigned char buff[100000];
  hstruct  hdr;
  float   *imbuff;
  float   diff;
  int     result = FALSE;

/*  umask(0); */
  if ((handle = creat(bmpname,0666)) > 0) {
    printf("  Converting to BMP.  %s  ->  %s\n",fname,bmpname);

    imbuff = floatfitsimage(&hdr,fname,FALSE);
    if (imbuff != NULL) {

      imdx = hdr.naxis1;
      imdy = hdr.naxis2;
      npix = imdx*imdy;
      fsize = 1078+npix;

      buff[0] = 66;     /* First two bytes: Windows BMP-logo */
      buff[1] = 77;

      buff[2] = (unsigned char)(fsize & 0X000000FF);         /* File size */
      buff[3] = (unsigned char)((fsize & 0X0000FF00) >> 8);
      buff[4] = (unsigned char)((fsize & 0X00FF0000) >> 16);
      buff[5] = (unsigned char)((fsize & 0XFF000000) >> 24);

      for (i=6;i<=9;i++) buff[i] = 0;

      buff[10] = 54;                      /* Position of image data in file */
      buff[11] = 4;
      buff[12] = buff[13] = 0;

      buff[14] = 40;                      /* This I could'nt figure out.  */
      buff[15] = buff[16] = buff[17] = 0;

      buff[18] = (unsigned char)(imdx & 0X000000FF);    /* Image width */
      buff[19] = (unsigned char)((imdx & 0X0000FF00) >> 8);
      buff[20] = (unsigned char)((imdx & 0X00FF0000) >> 16);
      buff[21] = (unsigned char)((imdx & 0XFF000000) >> 24);

      buff[22] = (unsigned char)(imdy & 0X000000FF);    /* Image height */
      buff[23] = (unsigned char)((imdy & 0X0000FF00) >> 8);
      buff[24] = (unsigned char)((imdy & 0X00FF0000) >> 16);
      buff[25] = (unsigned char)((imdy & 0XFF000000) >> 24);

      buff[26] = 1;                            /* No. of color planes */
      buff[27] = 0;

      buff[28] = 8;                            /* Bits per pixel.     */
      buff[29] = buff[30] = buff[31] = 0;

      for (i=32;i<=53;i++) buff[i] = 0;

      for (i=0;i<=255;i++) {                   /* Palette. */
        buff[54+4*i] = (unsigned char)i;       /* B */
        buff[55+4*i] = (unsigned char)i;       /* G */
        buff[56+4*i] = (unsigned char)i;       /* R */
        buff[57+4*i] = 0;
      }

      write(handle,buff,1078);                 /* Save header. */

      n = n1 = 0;
      diff = hicut - locut;

      do {
        nsave = npix-n;
	if (nsave > 100000) nsave = 100000;
	n += nsave;

	for (i=0; i < nsave; i++) {
	  if (imbuff[n1] <= locut) buff[i] = tff[0]; else
	  if (imbuff[n1] >= hicut) buff[i] = tff[4095]; else
	/* ... Calculate value between locut and hicut ... */
	  buff[i] = tff[(short)(4095.0*(imbuff[n1]-locut)/diff)];
	  n1++;
        }

	write(handle,buff,nsave);
      } while (n < npix);

      free(imbuff);
      result = TRUE;
    } else
      puts(IM_READ_ERR);

    close(handle);
  } else
    puts(FILE_OPEN_ERR);

  return result;
}

/* ==================================================================== */

void xsavebmp(char *params)
{
  static char bmpfile[255] = "";

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }

  if (IMAGE->fname[0] == '\0') {
    puts(NO_IM_ERR);
    return;
  }

  if (nargs(params) == 1) {
    argn(params,1,bmpfile);
  } else {
    printf("  Save BMP-file as:  "); cscanf("%s",bmpfile);
  }
    
  tobmp(IMAGE->fname,IMAGE->locut,IMAGE->hicut,IMAGE->tff,bmpfile);
}

/* ==================================================================== */

void addtag(
  unsigned char *tbuff,
  int   offs,
  short tag, short type,
  int   length,
  int   value
)
{
  tbuff[offs]    = (unsigned char)(tag & 0X00FF);
  tbuff[offs+1]  = (unsigned char)((tag & 0XFF00) >> 8);

  tbuff[offs+2]  = (unsigned char)(type & 0X00FF);
  tbuff[offs+3]  = (unsigned char)((type & 0XFF00) >> 8);

  tbuff[offs+4]  = (unsigned char)(length & 0X000000FF);
  tbuff[offs+5]  = (unsigned char)((length & 0X0000FF00) >> 8);
  tbuff[offs+6]  = (unsigned char)((length & 0X00FF0000) >> 16);
  tbuff[offs+7]  = (unsigned char)((length & 0XFF000000) >> 24);

  tbuff[offs+8]  = (unsigned char)(value & 0X000000FF);
  tbuff[offs+9]  = (unsigned char)((value & 0X0000FF00) >> 8);
  tbuff[offs+10] = (unsigned char)((value & 0X00FF0000) >> 16);
  tbuff[offs+11] = (unsigned char)((value & 0XFF000000) >> 24);

/*  for (n=0; n<12; n++) printf("%3i ",(int)tbuff[offs+n]);
  puts(""); */
}

/* ==================================================================== */

void  addgrayresp(
  unsigned char *tbuff,
  int  offs
)
{
  int i,value;

  for (i=0;i<255;i++) {
    value = (1000*i) / 255;
    tbuff[offs+2*i]   = (unsigned char)(value & 0X00FF);
    tbuff[offs+2*i+1] = (unsigned char)((value & 0XFF00) >> 8);
  }
}

/* ==================================================================== */

int totiff(
  char *fname,
  float locut, float hicut,
  unsigned char *tff,
  int   flipy,
  char *tiffname
)
{
  int handle,imdx,imdy;
  int result = FALSE;
  unsigned char *tbuff;
  unsigned char hbuff[1000];
  float  *imbuff;
  hstruct hdr;
  int     i,j,npix;
  int     x, y;
  float   diff;

  imbuff = floatfitsimage(&hdr,fname,FALSE);

  if (imbuff != NULL) {

    imdx = hdr.naxis1;
    imdy = hdr.naxis2;
    npix = imdx*imdy;

/*    umask(022); */
    if ((handle = creat(tiffname,0666)) > 0) {

      tbuff = (char *)malloc(sizeof(char)*npix);

      for (i=0; i<1000; i++) hbuff[i] = 0;

      hbuff[0] = 0X49;   /* We will use Least Significant Byte first */
      hbuff[1] = 0X49;   /* This will simplify things slightly.      */

      hbuff[2] = 42;     /* TIFF version number */
      hbuff[3] = 0;     

      hbuff[4] = 8;     /* First (and only..) IFD at offset 8 */
      hbuff[5] = 0;
      hbuff[6] = 0;
      hbuff[7] = 0;      

      hbuff[8] = 12;         /* Number of tags in IFD */
      hbuff[9] = 0;

      addtag(hbuff,10,256,T_SHORT,1,imdx);      /* Image width  */
      addtag(hbuff,22,257,T_SHORT,1,imdy);      /* Image height */
      addtag(hbuff,34,258,T_SHORT,1,8);         /* BitsPrSample     */
      addtag(hbuff,46,259,T_SHORT,1,1);         /* Compression = none   */
      addtag(hbuff,58,262,T_SHORT,1,0);         /* PhotometricInterpre-  */
      						/* tation (0=black)     */
      addtag(hbuff,70,273,T_SHORT,1,1000);      /* Offset of image data */
      addtag(hbuff,82,274,T_SHORT,1,1);         /* Orientation.       */
      addtag(hbuff,94,277,T_SHORT,1,1);        /* SamplesPrPixel   */
      addtag(hbuff,106,279,T_LONG, 1,npix);     /* StripByteCounts  */
      addtag(hbuff,118,284,T_SHORT,1,1);        /* PlanarConfiguration */
      addtag(hbuff,130,290,T_SHORT,1,3);        /* GrayResponseUnit =   */
                                                /* 1/1000 unit.         */
      addtag(hbuff,142,291,T_SHORT,256,158);    /* Offset of Gray-    */
      						/* ResponseCurve.     */
      hbuff[154] = 0;        /* No more tags */
      hbuff[155] = 0;
      hbuff[156] = 0;
      hbuff[157] = 0;

      addgrayresp(hbuff,158);
      write(handle,hbuff,1000);

      i = j = 0;
      diff = hicut - locut;

      for (y=0; y<hdr.naxis2; y++) 
        for (x=0; x<hdr.naxis1; x++)  {
	  if (flipy) 
	    i = x + (hdr.naxis2 - y - 1)*hdr.naxis1;
          else
	    i = j;

          if (imbuff[j] <= locut) tbuff[i] = 255-tff[0]; else
          if (imbuff[j] >= hicut) tbuff[i] = 255-tff[4095]; else
	  /* ... Calculate value between locut and hicut ... */
          tbuff[i] = 255-tff[(short)(4095.0*(imbuff[j]-locut)/diff)];
          j++;
        }

      write(handle,tbuff,npix);

      free(tbuff);
      close(handle);
    } else
      puts(FILE_OPEN_ERR); 

    free(imbuff);
  } else
      puts(IM_READ_ERR);

  return result;
}

/* ==================================================================== */

void xsavetiff(char *params)
{
  static char tifffile[255] = "";
  char   tmps[255];
  int    flipy = NO;

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }

  if (IMAGE->fname[0] == '\0') {
    puts(NO_IM_ERR);
    return;
  }

  if (nargs(params) == 1) {
    argn(params,1,tifffile);
  } else {
    printf("  Save tiff-file as:  "); cscanf("%s",tifffile);
  }

  if (getpar("XSAVETIFF.FLIPY",tmps))
     flipy = (strstr(tmps,"YES") != NULL);
    
  totiff(IMAGE->fname,IMAGE->locut,IMAGE->hicut,IMAGE->tff,flipy,tifffile);
  printf("  Done saving %s -> %s\n",IMAGE->fname,tifffile);
}

/* ==================================================================== */

void do_replace(
  char *image,
  int  x1, int y1, int x2, int y2,
  float  value
)
{
  hstruct hdr;
  float  *data;
  int    x,y,i;
  char   tmps[100];

  printf("  Replacing %s [%i:%i,%i:%i] with value %0.2f\n",
            image,x1,x2,y1,y2,value);

  data = floatfitsimage(&hdr,image,TRUE);
  if (data != NULL) {
    if (x1 >= 0 && y1 >= 0 && x2 >= x1 && y2 >= y1 && 
        y2 < hdr.naxis2 && x2 < hdr.naxis1) {

      for (y=y1; y<=y2; y++) {
        i = y*hdr.naxis1;
	for (x=x1; x<=x2; x++) data[i+x] = value;
      }

      sprintf(tmps,"Replaced [%i:%i,%i:%i] with %0.2f",x1,x2,y1,y2,value);
      addcard(&hdr,"HISTORY",tmps,H_COMM);
      savefitsfile(&hdr,data,-32,image);
    } else
      puts("  Error: Illegal image section.");
    freehdr(&hdr);
    free(data);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void imrep(char *params)
{
  static char image[255] = "";
  static int x1=0, y1=0, x2=10, y2=10;
  static float value = 0;
  char tmps[100];

  if (nargs(params) == 6) {
    argn(params,1,image);
    argn(params,2,tmps); x1 = atoi(tmps);
    argn(params,3,tmps); x2 = atoi(tmps);
    argn(params,4,tmps); y1 = atoi(tmps);
    argn(params,5,tmps); y2 = atoi(tmps);
    argn(params,6,tmps); value = atof(tmps);
  } else {
    printf("  Image                :  "); cscanf("%s",image);
    sprintf(tmps,"%i %i %i %i",x1,x2,y1,y2);
    printf("  Section (x1 x2 y1 y2):  "); cscanf("%s",tmps);
    sscanf(tmps,"%i %i %i %i",&x1,&x2,&y1,&y2);
    printf("  Value                :  "); cscanf("%f",&value);
  }

  do_replace(image,x1,y1,x2,y2,value);
}

/* ==================================================================== */

void ximrep(char *params) 
{
  static float value=0.0;
  int    x,y,dx,dy;
  int    x1,y1,x2,y2;
  XGCValues gcval;

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }

  if (IMAGE->fname[0] == '\0') {
    puts(NO_IM_ERR);
    return;
  }

  x = 10; y = 10; dx = 10; dy = 10;
  XGetGCValues(DISPLAY,IMAGE->gc,GCForeground,&gcval);
  setcolor(IMAGE->gc,"red");

  if (xsm_box(IMAGE->window, IMAGE->gc, &x, &y, &dx, &dy)) {
    printf("  Replacement value:  "); cscanf("%0.2f",&value);
    if (IMAGE->zoom > 0) {
      x1 = x/IMAGE->zoom;       y1 = y/IMAGE->zoom;
      x2 = (x+dx)/IMAGE->zoom;  y2 = (y+dy)/IMAGE->zoom;
    } else {
      x1 = -x*IMAGE->zoom;      y1 = -y*IMAGE->zoom;
      x2 = -(x+dx)*IMAGE->zoom; y2 = -(y+dy)*IMAGE->zoom;
    }
    do_replace(IMAGE->fname,x1,y1,x2,y2,value);
  }
  XChangeGC(DISPLAY,IMAGE->gc,GCForeground,&gcval);
}

/* ==================================================================== */

void blink(char *params)
{
}

/* ==================================================================== */

int selectspots(
  float *xarr, float *yarr,
  int   *ndat
)
{
  int    i;
  Window buttons[4],butwin;
  GC     butgc;
  XGCValues values;
  char   *buttxt[3] = {"Select","Accept","Quit"};
  int    result, quit = FALSE;
  XEvent event;
  XImage *ximg;
  XImage *bkgr[100];
  int    wdx,wdy,x,y;
  int    imx,imy;

  XSelectInput(DISPLAY,IMAGE->window, ButtonPressMask | ButtonReleaseMask |
				 Button1MotionMask |
		   Button3MotionMask | KeyPressMask);
  wdx = width(IMAGE->window);
  wdy = height(IMAGE->window);

  createbutwins(xpos(IMAGE->window),ypos(IMAGE->window)+wdy+10,
                &butwin,buttons,3,&butgc);
  for (i=0; i<3; i++) drawbutwin(buttons[i],butgc,buttxt[i],FALSE);  

  x = 10; y = 10; *ndat = 0;
  ximg = XGetImage(DISPLAY,IMAGE->window,x-5,y-5,11,11,AllPlanes,ZPixmap);

  XGetGCValues(DISPLAY,IMAGE->gc,GCForeground,&values);
  setcolor(IMAGE->gc,"red");

  do {
    XNextEvent(DISPLAY,&event);

    if (event.xany.window == IMAGE->window) {
      XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,ximg,
		     0,0,x-5,y-5,11,11);
      XDestroyImage(ximg);

      switch (event.type) {
/*         case KeyPress:
		 tmps[0] = '\0';
		 n = XLookupString(&(event.xkey),tmps,80,&keysym,&compose);
		 switch (keysym) {
		   case XK_Left :  if (x>z) x -= z; 
				   break;

		   case XK_Right:  if (x<(hdr.naxis1-1)*z) x += z; 
				   break;

		   case XK_Up   :  if (y>z) y -= z; 
				   break;

		   case XK_Down :  if (y<(hdr.naxis2-1)*z) y += z; 
				   break;
		 } 

		break; */

	 case MotionNotify:
		 x = event.xmotion.x;
		 y = event.xmotion.y;
		break;
      }
      if (x<5) x = 5;  if (x > wdx-6) x = wdx-6;
      if (y<5) y = 5;  if (y > wdy-6) y = wdy-6;

      ximg = XGetImage(DISPLAY,IMAGE->window,x-5,y-5,11,11,AllPlanes,ZPixmap);
      cross2(IMAGE->window,IMAGE->gc,x,y,5);
    }

    for (i=0; i<3; i++)
      if (event.xany.window == buttons[i])
	switch (event.type) {
	  case Expose: 
		   drawbutwin(buttons[i],butgc,buttxt[i],FALSE); 
		   break;
	  case EnterNotify:
		   drawbutwin(buttons[i],butgc,buttxt[i],TRUE);
		   break;
	  case LeaveNotify:
		   drawbutwin(buttons[i],butgc,buttxt[i],FALSE);
		   break;
	  case ButtonPress:
		   switch (i) {
		     case 0 : if (IMAGE->zoom > 0) {
		                xarr[*ndat] = (1.0*x) / IMAGE->zoom;
				yarr[*ndat] = (1.0*y) / IMAGE->zoom;
		              } else {
			        xarr[*ndat] = (-1.0*x) * IMAGE->zoom;
				yarr[*ndat] = (-1.0*y) * IMAGE->zoom;
			      }
			      imx = (int)xarr[*ndat];
			      imy = (int)yarr[*ndat];
		              printf(" (x,y) = (%i,%i)\n",imx,imy); 
                              XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,ximg,
		                   0,0,x-5,y-5,11,11);
                              XDestroyImage(ximg);
			      bkgr[*ndat] = XGetImage(DISPLAY,IMAGE->window,
			               x-5,y-5, 11,11,AllPlanes,ZPixmap);
			      setcolor(IMAGE->gc,"green");
			      box(IMAGE->window,IMAGE->gc,x,y,5);
			      box(IMAGE->window,IMAGE->gc,x,y,4);
			      box(IMAGE->window,IMAGE->gc,x,y,3);

                              ximg = XGetImage(DISPLAY,IMAGE->window,x-5,y-5,
			                       11,11,AllPlanes,ZPixmap);
			      setcolor(IMAGE->gc,"red");
                              cross2(IMAGE->window,IMAGE->gc,x,y,5);
			      (*ndat)++;
		              break;
		     case 1 : result = TRUE; quit = TRUE; break;
		     case 2 : result = FALSE; quit = TRUE; break;
		   }
		   break;
	}
      
  } while (!quit);

  XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,ximg, 0,0,x-5,y-5,11,11);

  for (i=0; i<(*ndat); i++) {
    if (IMAGE->zoom > 0) {
      imx = (int)(xarr[i] * IMAGE->zoom);
      imy = (int)(yarr[i] * IMAGE->zoom);
    } else {
      imx = (int)(-xarr[i] / IMAGE->zoom);
      imy = (int)(-yarr[i] / IMAGE->zoom);
    }
    XPutImage(DISPLAY,IMAGE->window,IMAGE->gc,bkgr[i],0,0,
              imx-5,imy-5,11,11);
    XDestroyImage(bkgr[i]);
    xarr[i] = rint(xarr[i]);
    yarr[i] = rint(yarr[i]);
  }

  XFreeGC(DISPLAY,butgc);
  XDestroyWindow(DISPLAY,butwin);
  XChangeGC(DISPLAY,IMAGE->gc,GCForeground,&values);
  XDestroyImage(ximg);
  XFlush(DISPLAY);
  return result;
}

/* ==================================================================== */

int FDX, FDY, FORDER;

float fitfunc(float a, float *p)
{
  int i,ii,j;
  int x,y;
  float f;

  i = (int)a;
  y = i / FDX;
  x = i % FDX;

/*  printf("%i  = %i,%i:  ",i,x,y); */

  f = 0; ii = 0;
  for (i=0; i<=FORDER; i++)
    for (j=0; j<=i; j++) {
/*      printf("%0.3f ",p[ii]);  */
      f += p[ii++] * pow((float)x, (float)j) * pow((float)y,(float)(i-j));
    }

/*  puts("");  */
  return f;
}

/* ==================================================================== */

void mkimage(
  char *outname,
  int  dx, int dy, int order,
  float *p
)
{
  hstruct hdr;
  int     j,offs,i,ii,x,y;
  short  *buff;
  float   f;

  buff = (short *)malloc(2*dx*dy);
  hdr.card = NULL;
  hdr.naxis1 = dx;
  hdr.naxis2 = dy;
  hdr.bitpix = 16;
  hdr.bscale = 1.0;
  hdr.bzero  = 0.0;
  addcard(&hdr,"HISTORY","Artifical flatfield",H_COMM);

  for ( offs=0, y=0; y<dy; y++)
    for (x=0; x<dx; x++) {
      f = 0; ii = 0;
      for (i=0; i<=order; i++)
        for (j=0; j<=i; j++)
          f +=  p[ii++] 
	      * pow((float)x, (float)j) 
	      * pow((float)y,(float)(i-j));

      buff[offs++] = (short)f; 
    }

  savefitsfile(&hdr,buff,16,outname);
  free(buff);
  freehdr(&hdr);
}

/* ==================================================================== */

void xmkflat(char *params)
{
  int   boxsz = 3;
  float x[100],y[100];
  float p[100],data[100],pos[100];
  int   xx,yy;
  int   ndat;
  static int degree = 1;
  static char  outname[255] = "";
  char   tmps[100];
  int    n,j,i,nvar;
  float  *image;
  hstruct hdr;

  puts("** Sorry, this task is no longer available.");
  puts("** The IMFIT package in IRAF contains many better tasks, e.g. IMSURFIT");
  puts("Bye");
  return;

  if (getpar("XMKFLAT.BOXSIZE",tmps)) boxsz = atoi(tmps);

  if (IMAGE == NULL) {
    puts(NO_IMAGE_WINS);
    return;
  }
  
  if (IMAGE->fname[0] == '\0') {
    puts(NO_IM_ERR);
    return;
  }

  if (IMAGE->mapped) {
    puts("  Select points for fitting..");
    if (selectspots(x,y,&ndat)) {
      printf("  %i points selected.\n",ndat);

      if (nargs(params) == 2) {
        argn(params,1,outname);
	argn(params,2,tmps); degree = atoi(tmps);
      } else {
        printf("  Degree of polynomial:  "); cscanf("%i",&degree);
	printf("  Output image        :  "); cscanf("%s",outname);
      }

      printf("  Reading image '%s'\n",IMAGE->fname);
      image = floatfitsimage(&hdr,IMAGE->fname,FALSE);

      if (image != NULL) {
        for (nvar=0, i=0; i<=degree; i++) nvar += (i+1);
        for (i=0; i<100; i++) p[i] = 0;

        for (i=0; i<ndat; i++) {
          pos[i]  = hdr.naxis1*y[i] + x[i];
	  data[i] = 0;
	  n = 0;
	  for (yy = -boxsz / 2; yy<=boxsz / 2; yy++)
	    for (xx = -boxsz / 2; xx<=boxsz / 2; xx++) {
	      j = (int)pos[i] + hdr.naxis1 * yy + xx;
              data[i] += image[j];
	      n++;
	    }
	  data[i] /= n;
	  p[0] += data[i];
        }

	p[0] /= ndat;
        FDX    = hdr.naxis1;
	FDY    = hdr.naxis2;
	FORDER = degree;

	printf("  Fitting %i variables.\n",nvar);
	printf("  Start guess : "); 
	for (i=0; i<nvar; i++) printf("%6.3f ",p[i]);
	puts("");

/*	fit(data,pos,ndat,nvar,p); */

	printf("  Final values: "); 
	for (i=0; i<nvar; i++) printf("%6.3f ",p[i]);
	puts("");

	mkimage(outname,FDX,FDY,degree,p);
	free(image);
      } else
        puts(IM_READ_ERR);
    }
  } else {
    puts(NO_IM_ERR);
    return;
  }
}

/* ==================================================================== */
