#ifndef TRUE
  #define TRUE 1
#endif

#ifndef FALSE
  #define FALSE 0
#endif

#ifdef UTILS_MAIN

  #define NPX 10000
  int   PX[NPX];        /* Used in Poisson noise generator */
  int   IPXMAX;

  float GAUSSDATA[6000];
  int   GINDEX = 0;
  int   MAXG;

  float GAUSSDATA2[10000];
  int   GINDEX2 = 0;
  int   MAXG2;

  float FW2, W2;

#else

  #define NPX 10000
  extern int   PX[NPX];        /* Used in Poisson noise generator */
  extern int   IPXMAX;

  extern float GAUSSDATA[6000];
  extern int   GINDEX;
  extern int   MAXG;

  extern float GAUSSDATA2[10000];
  extern int   GINDEX2;
  extern int   MAXG2;

  extern double nrand();
  extern float gauss(float);
  extern void initgauss();
  extern float grand();

  extern int prand();

  extern float grandvn();

  extern void pinit(
           float     /*  mu  */
         );

  extern float poisson(
           float,    /*  mu   - mean */
	   int       /*  x           */
         );

  extern float gauss2(    /* Polar gaussian distribution w. 2 components */
           float,    /* r    -  value */
	   float,    /* fw2  -  Secondary fwhm in units of primary */
	   float     /* w    -  Weight of secondary gauss profile */
	 );

  extern void initgauss2(
           float,    /* fw2  - Secondary fwhm  (primary = 1) */
	   float     /* w    - Weight of secondary gauss profile */
         );

  extern float grand2();

  extern int getcoolst(
           char *,
           float **, 
	   float **
         );

  extern int getstarlst(
           char *,        /* Name */
           float **,      /* X coordinates */
	   float **,      /* Y coordinates */
	   float **       /* Magnitudes    */
	 );

  extern char *datestr(
    char *                /* String to store the date in */
  );

  extern char *username(
    char *
  );

  extern float *fsort(
    float *,
    int
  );

  extern float *fsort2(
    float *,
    int *,
    int
  );

#endif
