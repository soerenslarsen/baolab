#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"
#include "utils.h"

void syntpsf(float *, int, float, int *);
void initpsf(float *, int, float *);

/* ==================================================================== */

static void make_header(
  hstruct *hdr,
  mksynthstruct par,
  int nstars
) {

  char tmps[255];

  hdr->card = NULL;
  hdr->naxis1 = par.rezx;
  hdr->naxis2 = par.rezy;
  hdr->bitpix = -32;
  hdr->bscale = 1.0;
  hdr->bzero  = 0.0;

#define ADDC addcard(hdr,"COMMENT",tmps,H_COMM)

  addcard(hdr,"COMMENT","Artificial image by BAOLAB",H_COMM);
  sprintf(tmps,"%i artificial stars",nstars);      ADDC;
  sprintf(tmps,"FWHM      = %0.2f pixels",par.fwhm);      ADDC;
  sprintf(tmps,"RDNOISE   = %0.2f e-",par.rdnoise);   ADDC;
  sprintf(tmps,"EPADU     = %0.2f e-/ADU",par.epadu);     ADDC;
  sprintf(tmps,"BACKGR    = %0.2f e-/pixel",par.backgr);    ADDC;
  sprintf(tmps,"ZPOINT    = %0.2f e-",par.zpoint);    ADDC;
  sprintf(tmps,"BIAS      = %0.2f ADU/pixel",par.bias);      ADDC; 
  sprintf(tmps,"PSFRAD    = %0.2f",par.psfrad);    ADDC;

  switch (par.psftype) {
    case GAUSS    : sprintf(tmps,"PSF       = GAUSS"); break;
    case GAUSS2   : sprintf(tmps,"PSF       = GAUSS2"); break;
    case EFF15    : sprintf(tmps,"PSF       = EFF15"); break;
    case EFF25    : sprintf(tmps,"PSF       = EFF25"); break;
    case MOFFAT15 : sprintf(tmps,"PSF       = MOFFAT15"); break;
    case MOFFAT25 : sprintf(tmps,"PSF       = MOFFAT25"); break;
    case LORENZ   : sprintf(tmps,"PSF       = LORENZ"); break;
    case LUGGER   : sprintf(tmps,"PSF       = LUGGER"); break;
    case USER     : sprintf(tmps,"PSF       = USER"); break;
    case SCALE    : sprintf(tmps,"PSF       = SCALED GAUSSIAN"); break;
  }
  addcard(hdr,"COMMENT",tmps,H_COMM);

  sprintf(tmps,"FWHM2     = %0.2f",par.fwhm2);     ADDC;
  sprintf(tmps,"PSFWEIGHT = %0.2f",par.psfweight); ADDC;

}

/* ==================================================================== */

static void mkrandlst(
  int   nstars,    /* Number of stars */
  float mfaint,    /* Faint limit */
  float mbright,   /* Bright limit */
  float mstep,
  int   rezx,
  int   rezy,
  float *x,        /* X positions */
  float *y,        /* Y positions */
  float *mag,      /* Magnitutes */
  char  *outfile
) {

  float m,sum = 0;
  int   j,i,nm,ntot=0;
  FILE *file;

  for (m=mbright; m<=mfaint-mstep; m+=mstep) 
    sum += exp(m-mbright);

  for (m=mbright; m<=mfaint-mstep; m+=mstep) {
    nm = (int)(nstars*exp(m-mbright)/sum);

    for (i=0; (i<nm) && (ntot<nstars); i++,ntot++) {
      x[ntot] = rezx*nrand();
      y[ntot] = rezy*nrand();
      mag[ntot] = mstep*nrand() + m;
    }

    if (m > mfaint-mstep*2) {
      while (ntot < nstars) {
        x[ntot] = rezx*nrand();
        y[ntot] = rezy*nrand();
        mag[ntot] = mstep*nrand() + m;
	ntot++; i++;
      }
    }

    printf("  %i stars in magnitude interval [%0.1f .. %0.1f]\n",i,m,m+mstep);

  }

  file = fopen(outfile,"w");
  if (file != NULL) {
    for (j=0; j<ntot; j++) fprintf(file,"%8.2f %8.2f %7.3f\n",x[j],y[j],mag[j]);
    fclose(file);
  } else
    puts("  ** Error writing output list.");
}

/* ==================================================================== */

/*  static int getstarlst(
  char *name,
  float **x,
  float **y,
  float **mag
) {

  FILE *file;
  int i,n = 0;
  int ok = TRUE;
  char tmps[255],s1[100];
  char *ch;

  file = fopen(name,"r");
  if (file != NULL) {
    ch = fgets(tmps,255,file);

    while (ch != NULL) {
      n++;
      if (nargs(tmps) < 3) {
        printf("  ** Error at line %i in star list: Too few arguments\n",n);
	printf("  >> %s \n",tmps);
	ok = FALSE;
      }
      ch = fgets(tmps,255,file);
    }

    if (ok) {
      rewind(file);
      (*x) = malloc(n*sizeof(float));
      (*y) = malloc(n*sizeof(float));
      (*mag) = malloc(n*sizeof(float));

      for (i=0; i<n; i++) {
        fgets(tmps,255,file);
	argn(tmps,1,s1); (*x)[i] = atof(s1);
	argn(tmps,2,s1); (*y)[i] = atof(s1);
	argn(tmps,3,s1); (*mag)[i] = atof(s1);
      }
    }


    fclose(file);
  }

  if (!ok) n = 0;
  return n;
}
*/

/* ==================================================================== */

static float *get_user_psf(
  char *psffile,
  int *_dx,
  int *_dy
) {
  float *tmp, *hpsf;
  hstruct hdr;
  int hrdx,hrdy,n,i,ix,iy;
  float sum = 0.0;

  tmp = floatfitsimage(&hdr,psffile,FALSE);
  if (tmp == NULL) return NULL;
  hrdx = (hdr.naxis1 / 10) * 10;
  hrdy = (hdr.naxis2 / 10) * 10;

  if ((hdr.naxis1 != hrdx) || (hdr.naxis2 != hrdy)) {
    printf("  ** PSF warning: %i x %i array will be truncated to %i x %i pixels\n",
	    hdr.naxis1,hdr.naxis2,
	    (hdr.naxis1 / 10)*10, (hdr.naxis2 / 10)*10 );
  }
  hrdx += 20;
  hrdy += 20;
  hpsf = (float *)malloc(sizeof(float)*hrdx*hrdy); 
  n =  hrdx*hrdy;
  for (i=0; i<n; i++) hpsf[i] = 0.0;
  i = 0;

  for (iy=10; iy<hrdy-10; iy++)
    for (ix=10; ix<hrdx-10; ix++)
      hpsf[ix + iy*hrdx] = tmp[ix-10 + (iy-10)*hdr.naxis1];
  free(tmp);

  *_dx = hrdx / 10;
  *_dy = hrdy / 10;

  for (i=0; i<n; i++) {
   if (hpsf[i] < 0) hpsf[i] = 0;
   sum += hpsf[i];
  }
  for (i=0; i<n; i++) hpsf[i] /= sum;

  return hpsf;
}

/* ==================================================================== */
 
static float *create_hirez_psf(
  mksynthstruct par,
  int  *_dx,
  int  *_dy
) {

  int   n,i;
  int   dx,dy,hrdx,hrdy;
  int   ix,iy;
  float phys_x, phys_y;
  float z;
  float *hpsf;
  float sum = 0.0;

  if (par.psftype == USER) {
    hpsf = get_user_psf(par.psffile,_dx,_dy);
  } else {

    i = par.psfrad*par.fwhm;
    dx = dy = (i/2)*2 + 2;    /* Allow for 0's along the edge of the PSF */
    hrdx = dx * 10;
    hrdy = dy * 10;
    *_dx = dx;
    *_dy = dy;

    hpsf = (float *)malloc(sizeof(float)*dx*dy*100);

    n = 0;
    for (iy = 0; iy<dy*10; iy++)
      for (ix = 0; ix<dx*10; ix++) {
	phys_x = (ix/10.0) - dx/2 + 0.5;
	phys_y = (iy/10.0) - dy/2 + 0.5;

	switch (par.psftype) {
	  case GAUSS : 
		       hpsf[n] = exp(-2.77*( pow(phys_x/par.fwhm,2)
					    +pow(phys_y/par.fwhm,2) )) ; 
		       break;

	  case GAUSS2: 
		       hpsf[n] = 
		  (1-par.psfweight)*exp(-2.77*(pow(phys_x/par.fwhm,2) 
					     + pow(phys_y/par.fwhm, 2)))
	       +     par.psfweight*exp(-2.77*(pow(phys_x/(par.fwhm2*par.fwhm),2) 
					+ pow(phys_y/(par.fwhm2*par.fwhm),2)));
		       break;

	  case EFF15:    
	  case MOFFAT15: 
		       z = pow(2.0*0.77*phys_x/par.fwhm,2) 
			 + pow(2.0*0.77*phys_y/par.fwhm,2);
		       hpsf[n] = 1.0/pow(1 + z,1.5);
		       break;

	  case EFF25:    
	  case MOFFAT25: 
		       z = pow(2.0*0.57*phys_x/par.fwhm,2) 
			 + pow(2.0*0.57*phys_y/par.fwhm,2);
		       hpsf[n] = 1.0/pow(1 + z,2.5);
		       break;

          case LUGGER:
                       z = pow(2.0*(phys_x/par.fwhm)/0.89,2)
		         + pow(2.0*(phys_y/par.fwhm)/0.89,2);
                       hpsf[n] = 1.0/pow(1 + z,0.9);
                       break;

	  case LORENZ:
		       z = pow(2.0*phys_x/par.fwhm,2) 
			 + pow(2.0*phys_y/par.fwhm,2);
		       hpsf[n] = 1.0/(1 + z);
		       break;
	}

	sum += hpsf[n];
	n++;
    }

    for (iy=0; iy<10; iy++)             /* Fill out edge rows and columns */
      for (ix=0 ; ix<hrdx; ix++) {      /* with 0's                       */
	hpsf[ix+hrdx*iy] = 0.0;
	hpsf[ix+hrdx*(hrdy-iy-1)] = 0.0;
      }

    for (iy=0; iy<hrdy; iy++)
      for (ix=0; ix<10; ix++) {
	hpsf[ix+hrdx*iy] = 0.0;
	hpsf[hrdx-ix-1+hrdx*iy] = 0.0;
      }

    for (i=0; i<n; i++) hpsf[i] /= sum;
  }

  return hpsf;
}

/* ==================================================================== */

void rebin_psf(
  int *hirez_data,
  int sx,
  int sy,
  float xc, float yc,
  int *data
) {

  int x,y;
  int xh,yh,xx,yy;
  int i,n,nn,npix;

  i = 0;
  npix = sx*sy*100;

  for (y=0; y<sy; y++)
    for (x=0; x<sx; x++) {
      n = 0;
      xh = (x-xc)*10;
      yh = (y-yc)*10+1;

      for (yy = yh; yy<yh+10; yy++) {
	nn = yy*sx*10;
        for (xx = xh; xx<xh+10; xx++)
	  if (xx+nn>=0 && xx+nn<npix) n += hirez_data[xx+nn];
      }

      data[i++] = n;
    }
}

/* ==================================================================== */

static void scalepsf(
  int rezx,
  int rezy,
  int *data,
  float fracx,
  float fracy,
  float fwhm,
  float fwhm2,
  float w2,
  float flux
) {

  float *fdata;
  int i,x,y;
  float xc = (rezx / 2) + fracx;
  float yc = (rezy / 2) + fracy;
  float x1,y1, sum = 0.0;

  fdata = (float *)malloc(sizeof(float)*rezx*rezy);
  for (i = 0; i<rezx*rezy; i++) fdata[i] = 0.0;

  for (y = 0; y<rezy; y++)
    for (x = 0; x<rezx; x++) {
      x1 = x+1.0-xc;  y1 = y+1.0-yc;
      sum += fdata[x+rezx*y] =
    (1-w2)*exp(-2.77*(pow(x1/fwhm,2) + pow(y1/fwhm, 2)))
  +     w2*exp(-2.77*(pow(x1/(fwhm2*fwhm),2) + pow(y1/(fwhm2*fwhm),2)));

    }

  for (i=0; i<rezx*rezy; i++) data[i] = rint(fdata[i]*flux/sum);
  free(fdata);
}

/* ==================================================================== */

static void do_mksynth(
  mksynthstruct par,
  int   nstars,
  float *x,
  float *y,
  float *mag,
  char  *outname
) {

  hstruct hdr;
/*  short  *buff; */
  float  *fbuff;
  int     j,i,npix;
  int     sx,sy;
  int     xx,yy,y1,x1;
  int    *hirez_data,*star;
  float  *accarr, *hirez_psf;
  float   flux;
  float   plimit, skycnt;
  float   bkg;

  make_header(&hdr,par,nstars);
/*  initgauss(); */

  npix = par.rezx*par.rezy;
/*  buff = (short *)malloc(sizeof(short)*npix); */
  fbuff = (float *)malloc(sizeof(float)*npix);  

  if (par.verbose) puts("  Setting up background..");
/*  bkg = par.backgr*par.epadu; */

  bkg = par.backgr;
  plimit = 20.;         /* Limit for Poisson vs. Gaussian noise */

  if (bkg <= plimit) pinit(bkg);   /* Use Poisson noise generator for low */
                                   /* background levels.                  */

  if ((par.rdnoise < 1e-5) && (bkg < 1e-5))
    for (i=0; i<npix; i++) {        
      fbuff[i] = par.bias * par.epadu;
    } 
  else
    for (i=0; i<npix; i++) {        /* Create noisy background */
      if (bkg <= plimit) {
        skycnt = prand();
      } else {
        skycnt = bkg + grandvn()*sqrt(bkg);
	if (skycnt < 0) skycnt = 0.;
      } 
/*      fbuff[i] = par.bias * par.epadu + par.rdnoise*grandvn()
        + bkg + grandvn()*sqrt(bkg); */
      fbuff[i] = par.bias * par.epadu + par.rdnoise*grandvn() + skycnt;
    }
 
/* Initialize various arrays for the psf : */

  if (par.psftype == SCALE) {
    sx = sy = par.fwhm * par.psfrad * 2;
  } else {
    hirez_psf = create_hirez_psf(par,&sx,&sy);
    if (hirez_psf == NULL) {
      puts("  ** Error creating PSF.");
      return;
    }
    accarr = (float *)malloc(sizeof(float)*sx*sy*100);
    initpsf( hirez_psf, sx*sy*100, accarr); 
    hirez_data = (int *)malloc(sizeof(int)*sx*sy*100);
  } 

/* In any case, allocate the array to contain the low-resolution PSF: */
  star = (int *)malloc(sizeof(int)*sx*sy);

  for (i=0; i<nstars; i++) {      /* Add the stars one by one.           */

    flux = par.zpoint*pow(10.0,-0.4*mag[i]);
    if (par.pnoise) {
      if (flux <= plimit) {
        pinit(flux);
	flux = prand();
      } else
        flux += grandvn()*sqrt(flux);
    }

    /* Generate the psf and store in data array: */

    if (par.psftype == SCALE) {
      scalepsf(sx,sy,star,x[i]-floor(x[i]),y[i]-floor(y[i]),
               par.fwhm,par.fwhm2,par.psfweight,flux);
    } else {
      syntpsf(accarr,sx*sy*100,flux,hirez_data);
      rebin_psf(hirez_data,sx,sy,x[i]-floor(x[i]),y[i]-floor(y[i]),star);
    }

    x1 = (int)floor(x[i]-sx/2);
    y1 = (int)floor(y[i]-sy/2);

    for (j=0, yy = y1; yy < y1+sy; yy++)
      for (xx = x1; xx < x1+sx; xx++) {
        if ((yy>=0) && (xx>=0) && (yy<par.rezy) && (xx<par.rezx))
          fbuff[par.rezx*yy+xx] += star[j];
	j++;
      }

    if (par.verbose) {
      putchar(CTRL_M); printf("  %i stars added..",i+1); fflush(stdout);
    }
  }

  if (par.verbose) puts("");

  for (i=0; i<npix; i++) fbuff[i] /= par.epadu;
/*  }
    p = fbuff[i]/par.epadu;
    if (p<32768)
      buff[i] = (short)rint(p);
    else
      buff[i] = 32767;
  } */

  savefitsfile(&hdr,fbuff,-32,outname);
  freehdr(&hdr);
/*  free(buff); */
  free(fbuff);
  free(star);
  if (par.psftype != SCALE) {
    free(hirez_data);
    free(accarr);
    free(hirez_psf);
  }
}

/* ==================================================================== */

void mksynth(char *params)
{
  static char outname[255] = "";
  static char starfile[255] = "";
  char tmps[100];
  int magrandom = TRUE;
  static int nstars = 100;
  mksynthstruct par = {100,100,2.0,0.0,1.0,0.0,
                       100.0,100.0,FALSE,GAUSS2,1.0,0.0,3.0,TRUE,""};
  static float mbright = 0, mfaint = 10;
  float mstep = 1.0;
  float *x, *y, *mag;
  int   i, ok = TRUE;

  if (getpar("MKSYNTH.REZX",tmps)) par.rezx = atoi(tmps);
  if (getpar("MKSYNTH.REZY",tmps)) par.rezy = atoi(tmps);
  if (getpar("MKSYNTH.NSTARS",tmps)) nstars = atoi(tmps);
  if (getpar("MKSYNTH.RANDOM",tmps)) magrandom = (strstr(tmps,"YES") != NULL);
  if (getpar("MKSYNTH.MAGBRIGHT",tmps)) mbright = atof(tmps);
  if (getpar("MKSYNTH.MAGFAINT",tmps)) mfaint = atof(tmps);
  if (getpar("MKSYNTH.MAGSTEP",tmps)) mstep = atof(tmps);
  if (getpar("MKSYNTH.FWHM",tmps)) par.fwhm = atof(tmps);
  if (getpar("MKSYNTH.EPADU",tmps)) par.epadu = atof(tmps);
  if (getpar("MKSYNTH.RDNOISE",tmps)) par.rdnoise = atof(tmps);
  if (getpar("MKSYNTH.BACKGR",tmps)) par.backgr = atof(tmps);
  if (getpar("MKSYNTH.ZPOINT",tmps)) par.zpoint = atof(tmps);
  if (getpar("MKSYNTH.BIAS",tmps)) par.bias = atof(tmps);
  if (getpar("MKSYNTH.PHOTNOISE",tmps)) par.pnoise = (strstr(tmps,"YES") != NULL);
  if (getpar("MKSYNTH.FWHM2",tmps)) par.fwhm2 = atof(tmps);
  if (getpar("MKSYNTH.PSFWEIGHT",tmps)) par.psfweight = atof(tmps);
  if (getpar("MKSYNTH.PSFRAD",tmps)) par.psfrad = atof(tmps);
  if (getpar("MKSYNTH.PSFTYPE",tmps)) {
    if (strstr(tmps,"GAUSS") != NULL) par.psftype = GAUSS;
    if (strstr(tmps,"GAUSS2") != NULL) par.psftype = GAUSS2;
    if (strstr(tmps,"EFF15") != NULL) par.psftype = EFF15;
    if (strstr(tmps,"EFF25") != NULL) par.psftype = EFF25;
    if (strstr(tmps,"MOFFAT15") != NULL) par.psftype = MOFFAT15;
    if (strstr(tmps,"MOFFAT25") != NULL) par.psftype = MOFFAT25;
    if (strstr(tmps,"LORENZ") != NULL) par.psftype = LORENZ;
    if (strstr(tmps,"LUGGER") != NULL) par.psftype = LUGGER;
    if (strstr(tmps,"USER") != NULL) par.psftype = USER;
    if (strstr(tmps,"SCALE") != NULL) par.psftype = SCALE;
  }

  if (getpar("MKSYNTH.VERBOSE",tmps)) par.verbose= (strstr(tmps,"YES") != NULL);
  if (getpar("MKSYNTH.PSFFILE",tmps)) strcpy(par.psffile,tmps);

  if (nargs(params) == 3) {
    if (magrandom) {
/*      argn(params,1,tmps); nstars = atoi(tmps);
      argn(params,2,tmps); mfaint = atof(tmps);
      argn(params,3,tmps); mbright = atof(tmps);  */
      argn(params,1,starfile); 
      argn(params,2,tmps); par.fwhm = atof(tmps);
      argn(params,3,outname);
    } else {
      argn(params,1,starfile);
      argn(params,2,tmps); par.fwhm = atof(tmps);
      argn(params,3,outname);
    }
  } else if (nargs(params) == 2) {
    if (magrandom) {
/*      argn(params,1,tmps); nstars = atoi(tmps);
      argn(params,2,tmps); mfaint = atof(tmps);
      argn(params,3,tmps); mbright = atof(tmps);  */
      argn(params,1,starfile); 
      argn(params,2,outname);
    } else {
      argn(params,1,starfile);
      argn(params,2,outname);
    }
  } else {

    if (magrandom) { 
/*      printf("  Number of stars  :  "); cscanf("%i",&nstars); 
      printf("  Faint limit      :  "); cscanf("%0.2f",&mfaint);
      printf("  Bright limit     :  "); cscanf("%0.2f",&mbright); */
      printf("  Write list to    :  "); cscanf("%s",starfile);
    } else {
      printf("  File with stars  :  "); cscanf("%s",starfile);
    }

/*    printf("  FWHM of profile  :  "); cscanf("%0.2f",&(par.fwhm)); */
    printf("  Output image     :  "); cscanf("%s",outname);
  }

  puts("  -----------------------------");

  printf("\n  Generating synthetic image..\n");
  printf("  Resolution       = %i x %i pixels\n",par.rezx,par.rezy);
  printf("  Stars read from  : "); 
    if (magrandom) {
      puts("Randomly generated"); 
      printf("  Faint limit      = %0.2f\n",mfaint);
      printf("  Bright limit     = %0.2f\n",mbright);
    } else 
      puts(starfile);

  printf("  Read out noise   = %0.2f e-\n",par.rdnoise);
  printf("  Conversion factor= %0.2f\n",par.epadu);
  printf("  Background level = %0.0f e-\n",par.backgr);
  printf("  BIAS level       = %0.0f ADU   \n",par.bias);
  printf("  Psftype          = "); 
  switch (par.psftype) {
    case GAUSS    : puts("GAUSS"); break;
    case GAUSS2   : puts("GAUSS2"); break;
    case EFF15    : puts("EFF15"); break;
    case EFF25    : puts("EFF25"); break;
    case MOFFAT15 : puts("MOFFAT15"); break;
    case MOFFAT25 : puts("MOFFAT25"); break;
    case LORENZ   : puts("LORENZ"); break;
    case LUGGER   : puts("LUGGER"); break;
    case USER     : puts("USER"); break;
    case SCALE    : puts("SCALE"); break;
  }
  if (par.psftype == USER)
    printf("  Psf file         = %s\n",par.psffile);
  else {
    printf("  FWHM             = %0.2f\n",par.fwhm);
    printf("  Psf rad          = %0.1f\n",par.psfrad);
  }

  if (magrandom) {
    x   = (float *)malloc(sizeof(float)*nstars);
    y   = (float *)malloc(sizeof(float)*nstars);
    mag = (float *)malloc(sizeof(float)*nstars);
    mkrandlst(nstars,mfaint,mbright,mstep,par.rezx,par.rezy,x,y,mag,starfile);
  } else {
    nstars = getstarlst(starfile,&x,&y,&mag);
    ok = (nstars > 0);
    if (ok) printf("  %i stars read from input file.\n",nstars);
  }

  if (ok) { 
    do_mksynth(par,nstars,x,y,mag,outname);
    free(x); free(y); free(mag);
  }
}

