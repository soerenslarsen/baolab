/* ====================================================================== 

  Carry out King (1962, AJ 67, 471) or King (1966, AJ 71, 64) model fits to 
  images of globular clusters. No sub-sampling of images is performed, so 
  the cluster profiles should be reasonably well resolved.

  This subroutine has been imported from the stand-alone programme kfit2d.c
  (formerly fit2d.c).

  Some work remains to be done in order to give it a look-and-feel similar
  to that of ISHAPE, particularly in terms of the output and log files.

  To do:
    - Output most important parameters and the fit results to the output
      FITS files (model and residuals).
    - Estimate errors. This is a bit hard because the minimisation criterion
      is not actually chi-square.

  The code should also be checked carefully for memory leaks.

  Soeren S. Larsen
  (s.s.larsen@astro-uu.nl)

   ====================================================================== */

#include "fitsutil.h"
#include "baolab.h"
#include "neldmead.h"
#include "utils.h"
#include "k66.h"
#include "convol.h"

#define sqr(A) ((A)*(A))
#define PI 3.1415926

float FITTOL  = 0.001;
int FITXY   = 0;
int KINGVER = 62;
int NW      = 200;
float BKG   = 0;
int BKGMODE = 3;
int FITBKG  = 1;
int NOFIT   = 0;
int FITPA   = 0;
int FITAB   = 0;
int USEPSF = 0;
int KEEPLOG = 0;
FILE *logfile = NULL;

/* ====================================================================== */

float calc_k66(
  float w0,
  double *r,
  double *sigma,
  int   nw,
  float *_m,
  float *_hmr
) {
  double *phiw, *w, *vdisp;
  double *rhorel;
  double *vdispp, *vdap;
  float   p,m, hmr;
  int     i;

  phiw   = (double *)malloc(sizeof(double) * nw);
  vdisp  = (double *)malloc(sizeof(double) * nw);
  w      = (double *)malloc(sizeof(double) * nw);
  rhorel = (double *)malloc(sizeof(double) * nw);
  vdispp = (double *)malloc(sizeof(double) * nw);
  vdap   = (double *)malloc(sizeof(double) * nw);

  for (i=0; i<nw; i++) w[i] = w0*i/(nw-1);
  calcphiw(w, phiw, vdisp, nw);
  for (i=0; i<nw; i++) rhorel[i] = phiw[i] / phiw[nw-1];

  calc_r2(w, rhorel, r, nw);
  p = (float)project(r,rhorel,sigma,w,phiw,vdisp,vdispp,vdap,nw,NULL);
  if (_m != NULL) {
    m = (float)mu(r,rhorel,nw);
    *_m = m;
  }

  if (_hmr != NULL) {
    hmr = (float)hmr3d(r, rhorel, nw);
    *_hmr = hmr;
  }

  free(phiw);
  free(vdisp);
  free(w);
  free(rhorel);
  free(vdispp);
  free(vdap);

  return p;
}

/* ====================================================================== */

float k66(
  float r,
  float rc,
  double *kr,
  double *ksig,
  int     nw
) {
  int   i;
  int   i1, i2;
  float f,f1,f2;
  float rr,dr1;
  float s;

  rr = r / rc;

  if (rr < kr[nw-1]) 
    s = ksig[nw-1]; else
  if (rr > kr[0]) 
    s = 0.; else {
    i1 = 0;
    i2 = nw-1;
    i = nw/2;
    f1 = kr[i1] - rr;
    f2 = kr[i2] - rr;
    f  = kr[i] - rr;

    while (i2 - i1 > 1) {
      if (sgn(f) == sgn(f1)) {
        i1 = i;
	f1 = f;
      } else {
        i2 = i;
	f2 = f;
      }
      i  = (i1 + i2) / 2;
      f = kr[i] - rr;
    }
/*    s = ksig[i2]; */
    dr1 = (kr[i1] - rr) / (kr[i1] - kr[i2]);
    s = ksig[i2] * dr1 + ksig[i1] * (1-dr1);

/*    printf("%0.3f %i %i %0.3f %0.3f %0.4f %0.4f %0.4f\n",rr, i1,i2, kr[i1], kr[i2], ksig[i1], ksig[i2],s);  */
  }

  return s;
}

/* ====================================================================== */

float k62(
  float r,
  float rc,
  float c
) {
  float f,f1,f2;

  if (r < rc*c) {
    f1 = sqrt(1 + sqr(r/rc));
    f2 = sqrt(1 + sqr(c));
    f = sqr(1/f1 - 1/f2);
  } else
    f = 0.;

  return f;
}

/* ====================================================================== */

float getbkg(
  hstruct *hdr,
  float   *img,
  float    xc,
  float    yc,
  float    annulu,
  float    dannulu
) {
  int i, x, y, nbkg;
  float r1sq, r2sq, rsq;
  float sum;

  r1sq = sqr(annulu);
  r2sq = sqr(annulu + dannulu);
  sum = 0.0;
  nbkg = 0;
  i = 0;

  for (y=0; y<hdr->naxis2; y++)
    for (x=0; x<hdr->naxis1; x++) {
      rsq = sqr(x-xc) + sqr(y-yc);
      if (rsq >= r1sq && rsq <= r2sq) {
        sum += img[i];
	nbkg++;
      }
      i++;
    }
  return sum/nbkg;
}

/* ====================================================================== */

float *kgetobj(
  hstruct *hdr, 
  float   *img, 
  float    xc, 
  float    yc, 
  float    fitrad, 
  float   *xco, 
  float   *yco, 
  hstruct *ohdr
) {
  int i, x, y, x1, y1, x2, y2;
  float *obj;

  x1 = (int)floor(xc - fitrad);
  x2 = (int)ceil(xc + fitrad);
  y1 = (int)floor(yc - fitrad);
  y2 = (int)ceil(yc + fitrad);

  ohdr->naxis1 = x2 - x1 + 1;
  ohdr->naxis2 = y2 - y1 + 1;
  *xco = xc - x1;
  *yco = yc - y1;

  obj = (float *)malloc(sizeof(float)*ohdr->naxis1*ohdr->naxis2);

  for (i=0, y=y1; y<=y2; y++)
    for (x=x1; x<=x2; x++)
      obj[i++] = img[x + y*hdr->naxis1];

  return obj;
}

/* ====================================================================== */

float rms(
  hstruct *hdr,
  float   *img,
  float    xc,
  float    yc,
  float    fitrad,
  float    rc,
  float    c,
  float    sbc,
  float    ab,
  float    pa,
  float   *model,
  float   *_rt,
  float   *psf,
  int      dpsf, 
  float    dxc,
  float    dyc
) {
  int i, j, x, y, npix, nsum;
  float r,k,diff, avg;
  float dsq, tmpf;
  float *karr;
  float  rt;
  double *kr, *ksig;
  float  *kp2, *pp2, *rp2;
  float  sa, ca;
  float  cx, cy, cxy;
  float  dx, dy;
  int    np2;
  int    nw;

  /* ==========    If KINGVER==66 then calculate a King model ========= */

  if (KINGVER == 66) {
    nw = NW;
    kr   = (double *)malloc(sizeof(double)*nw);
    ksig = (double *)malloc(sizeof(double)*nw);
    calc_k66(c, kr, ksig, nw, NULL, NULL);
    rt = rc * kr[0];
  } else {
    rt = rc * c;
  }

  /* ============    Generate a 2-d image of the King model  ========== */

  npix = hdr->naxis1 * hdr->naxis2;
  karr = (float *)malloc(sizeof(float)*npix);
  i = 0;

  sa = sin(pa*PI/180.);
  ca = cos(pa*PI/180.);
  cx = sqrt(sqr(ca) + sqr(sa/ab));
  cy = sqrt(sqr(sa) + sqr(ca/ab));
  cxy = 2*ca*sa - 2*ca*sa/sqr(ab);

  for (y=0; y<hdr->naxis2; y++)
    for (x=0; x<hdr->naxis1; x++) {
/*      r = sqrt(sqr(x-xc) + sqr(y-yc)); */
      dx = x-xc;
      dy = y-yc;
      r = sqrt(sqr(cx*dx) + sqr(cy*dy) + cxy*dx*dy);
      if (r < fitrad+10) {
	switch (KINGVER) {
          case 62 : k = sbc * k62(r, rc, c); break;
          case 66 : k = sbc * k66(r, rc, kr, ksig, nw); break;
        }
	karr[i] = k;
	if (k < 0) {
	  printf("ERROR, King profile shouldn't be negative!\n");
	  if (KEEPLOG)
	    fprintf(logfile,"ERROR, King profile shouldn't be negative!\n");
        }
/*        diff += img[i] - k; 
	nsum++; */
      } else
        karr[i] = 0.;
      i++;
    }

  /* =============== Convolve with PSF (optional) ================ */

  if (psf != NULL) {
    np2 = 0;
    kp2 = mkp2arr(hdr->naxis1, hdr->naxis2, karr, &np2);
    pp2 = mkp2arr(dpsf, dpsf, psf, &np2);
    rp2 = (float *)malloc(sizeof(float)*np2*np2);
    convol(np2, kp2, pp2, rp2); 

/*    j = 0;
    tmpf = 0;
    for (i=0; i<np2*np2; i++)  {
      if (rp2[i] < 0) { 
        j++;
	if (rp2[i] < tmpf) tmpf = rp2[i];
      }
    }
    if (j>0) 
      printf("** Warning - rp2 has %i negative pixels, min=%0.3e\n",j,tmpf); */

    getp2arr(np2, rp2, hdr->naxis1, hdr->naxis2, karr);


    free(rp2);
    free(pp2);
    free(kp2);
  }

  /* ============  Set pixel values beyond fitrad to -1  =========== */
  /* ============  and calculate background, if desired  =========== */

  nsum = 0;
  diff = 0.0;
  i    = 0;

  for (y=0; y<hdr->naxis2; y++)
    for (x=0; x<hdr->naxis1; x++) {
      r = sqrt(sqr(x-xc) + sqr(y-yc));
      if (r < fitrad) { 
        if (karr[i] < 0) karr[i] = 0;
        diff += img[i] - karr[i]; 
	nsum++; 
      } else
        karr[i] = -1;
      i++;
    }

  if (FITBKG) avg = diff / nsum; else avg = BKG;

  /* ===========   Finally, calculate RMS for model pixels >= 0 ======= */

  dsq = 0.0;
  for (i=0; i<npix; i++) 
    if (karr[i] >= 0) 
      dsq += sqr((img[i] - karr[i]) - avg);

  dsq /= nsum;

  if (model != NULL) {
    for (i=0; i<npix; i++) {
      tmpf = karr[i];
      model[i] = (tmpf > 0) ? tmpf : 0;
    }
  }

  printf("rc=%0.2f c=%0.2f sbc=%0.2f xc=%0.2f yc=%0.2f ab=%0.2f pa=%0.1f bkg=%0.2e rms=%0.2e\n",
    rc,rt/rc,sbc,xc+dxc,yc+dyc,ab,pa,avg,dsq);

  if (KEEPLOG)
    fprintf(logfile,"rc=%0.2f c=%0.2f sbc=%0.2f xc=%0.2f yc=%0.2f ab=%0.2f pa=%0.1f bkg=%0.2e rms=%0.2e\n",
    rc,rt/rc,sbc,xc+dxc,yc+dyc,ab,pa,avg,dsq);

  free(karr);

  if (KINGVER == 66) {
    free(kr);
    free(ksig);
  }

  *_rt = rt;

  return dsq;
}

/* ====================================================================== */

hstruct *MF_HDR;
float   *MF_IMG;
float   MF_FITRAD;
float   MF_RT;
int     MF_NFIT;
float   *MF_PSF;
int     MF_DPSF;
float   MF_PAR[10];
float   MF_DXC;
float   MF_DYC;

float minfunc(
  float *p
) {
  float f;
  float rt;

  int   ip;
  float xc, yc, rc, c, sbc, ab, pa;

  ip = 0;
  rc = fabs(p[ip++]);
  c  = p[ip++];
  sbc = p[ip++];

  if (c < 1.5) {
    printf("Warning: c<1.5 (%0.2f), setting it to 1.5\n",c);
    if (KEEPLOG) 
      fprintf(logfile,"Warning: c<1.5 (%0.2f), setting it to 1.5\n",c);
    c = 1.5;
  }

  if (FITXY) {
    xc = p[ip++];
    yc = p[ip++];
  } else {
    xc = MF_PAR[3];
    yc = MF_PAR[4];
  }
  
  if (FITAB)
    ab = fabs(p[ip++]);
  else
    ab = MF_PAR[5];

  if (FITPA)
    pa = p[ip++];
  else
    pa = MF_PAR[6];

  f = rms(MF_HDR, MF_IMG, xc, yc, MF_FITRAD, rc, c, sbc, ab, pa, NULL, &rt,MF_PSF,MF_DPSF, MF_DXC, MF_DYC);
  MF_RT = rt;

  return f;
}

/* ====================================================================== */

void fitking(
  hstruct *hdr,
  float   *img,
  float    *_xc,
  float    *_yc,
  float   fitrad,
  float  *_rc,
  float  *_c,
  float  *_sbc,
  float  *_ab,
  float  *_pa,
  float  *psf,
  hstruct *phdr,
  float  dxc,
  float  dyc
) {
  float p[MP][NP];
  float tmp[10];
  float y[MP];
  int   ip,i,j,nfit,nw;
  float rc, c, rt, re;
  float ab, pa;
  double *kr, *ksig;
  float  pp,r1,m,hmr;
  int    ixc, iyc, iab, ipa;

  MF_HDR = hdr;
  MF_IMG = img;
  MF_FITRAD = fitrad;

  MF_PSF  = psf;
  MF_DPSF = phdr->naxis1;

  MF_PAR[0] = *_rc;
  MF_PAR[1] = *_c;
  MF_PAR[2] = *_sbc;
  MF_PAR[3] = *_xc;
  MF_PAR[4] = *_yc;
  MF_PAR[5] = *_ab;
  MF_PAR[6] = *_pa;
  
  MF_DXC = dxc;
  MF_DYC = dyc;

  ip = 0;
  p[0][ip++] = *_rc; 
  p[0][ip++] = *_c;   
  p[0][ip++] = *_sbc;

  if (FITXY) {
    ixc = ip;
    p[0][ip++] = *_xc;
    iyc = ip;
    p[0][ip++] = *_yc;
  }

  if (FITAB) {
    iab = ip;
    p[0][ip++] = *_ab;
  }

  if (FITPA) {
    ipa = ip;
    p[0][ip++] = *_pa;
  }

  nfit = ip;
  MF_NFIT = nfit;

  for (i=0; i<nfit; i++) {
    for (j=1; j<=nfit; j++) {
      p[j][i] = p[0][i];
      if (j==i+1) {
        if (i < 3) p[j][i] = 1.5*p[0][i]; 
	if (FITXY) {
	  if (i == ixc) p[j][i] = p[0][i] + 3; 
	  if (i == iyc) p[j][i] = p[0][i] + 3; 
	}
	if (FITAB && i == iab) p[j][i] = p[0][i]*0.8; 
        if (FITPA && i == ipa) p[j][i] = p[0][i] + 45.;
      } 
    }
  }

  for (i=0; i<=nfit; i++) {
    for (j=0; j<nfit; j++) tmp[j] = p[i][j];
    y[i] = minfunc(tmp);
  }

  i = neldermead(p,y,nfit,FITTOL,&minfunc);

  /* Restart amoeba */
  puts("Restarting amoeba..");
  if (KEEPLOG)
    fprintf(logfile,"Restarting amoeba..\n");

  for (i=0; i<nfit; i++) 
    for (j=1; j<=nfit; j++) {
      if (i < 3) {
        if (j==i+1) {
          p[j][i] = p[0][i] * 1.2;
        } else 
          p[j][i] = p[0][i] / 1.2;
      }
      if (FITXY) {
        if ((i == ixc) || (i == iyc)) {
          if (j==i+1) 
            p[j][i] += 0.5; 
          else
            p[j][i] -= 0.5; 
        }
      }
      if (i==iab && FITAB) {
        if (j==i+1) 
	  p[j][i] *= 1.05;
	else
	  p[j][i] /= 1.05;
      }
      if (i==ipa && FITPA) {
        if (j==i+1) 
	  p[j][i] += PI/16;
	else
	  p[j][i] -= PI/16;
      }
    }

  for (i=0; i<=nfit; i++) {
    for (j=0; j<nfit; j++) tmp[j] = p[i][j];
    y[i] = minfunc(tmp);
  }

  i = neldermead(p,y,nfit,FITTOL,&minfunc);

  rc = p[0][0];
  c  = p[0][1];

  switch (KINGVER) {
    case 62 : rt = rc * c;
              re = 0.547 * rc * pow(rt/rc, 0.486);
	      break;
    case 66 : nw = NW;
              kr   = (double *)malloc(sizeof(double)*nw);
              ksig = (double *)malloc(sizeof(double)*nw);
              pp = calc_k66(c, kr, ksig, nw, &m, &hmr);
	      re = rc * hlrp(kr, ksig, nw);
	      r1 = rc * hwhm(kr, ksig, nw);
              rt = rc * kr[0];
	      free(kr);
	      free(ksig);
	      break;
  } 

  printf("RC (A)   = %0.2f\n",fabs(rc));
  printf("Conc     = %0.1f\n",fabs(rt/rc));
  printf("RT (A)   = %0.1f\n",fabs(rt));
  printf("Reff (A) = %0.2f\n",fabs(re));
  printf("SBC      = %0.1f\n",p[0][2]);
  if (KINGVER == 66) {
    printf("Rh (A)   = %0.2f\n",fabs(hmr*rc));
    printf("HWHM (A) = %0.2f\n",fabs(r1));
    printf("P        = %0.2f\n",pp);
    printf("MU       = %0.2f\n",m);
    printf("W        = %0.2f\n",c);
  }

  *_rc  = rc;
  *_c   = c;
  *_sbc = p[0][2];

  if (FITXY) {
    *_xc = p[0][ixc];
    *_yc = p[0][iyc];
  }
  printf("XC       = %0.2f\n",*_xc+dxc);
  printf("YC       = %0.2f\n",*_yc+dyc);

  if (FITAB) *_ab = p[0][iab];
  if (FITPA) *_pa = p[0][ipa];

  printf("B/A      = %0.2f\n",*_ab);
  printf("PA       = %0.2f deg\n",*_pa); 

  printf("Reff (2D)= %0.2f\n",fabs(re) * 0.5*(1+(*_ab)));

/*  if (KINGVER==66)
    printf("Rh (2D)  = %0.2f\n",fabs(hmr*rc)*0.5*(1+(*_ab))); */

  if (KEEPLOG) {
    fprintf(logfile,"RC (A)   = %0.2f\n",fabs(rc));
    fprintf(logfile,"Conc     = %0.1f\n",fabs(rt/rc));
    fprintf(logfile,"RT (A)   = %0.1f\n",fabs(rt));
    fprintf(logfile,"Reff (A) = %0.2f\n",fabs(re));
    fprintf(logfile,"SBC      = %0.1f\n",p[0][2]);
    if (KINGVER == 66) {
      fprintf(logfile,"Rh (A)   = %0.2f\n",fabs(hmr*rc));
      fprintf(logfile,"HWHM (A) = %0.2f\n",fabs(r1));
      fprintf(logfile,"P        = %0.2f\n",pp);
      fprintf(logfile,"MU       = %0.2f\n",m);
      fprintf(logfile,"W        = %0.2f\n",c);
    }

    fprintf(logfile,"XC       = %0.2f\n",*_xc+dxc);
    fprintf(logfile,"YC       = %0.2f\n",*_yc+dyc);

    fprintf(logfile,"B/A      = %0.2f\n",*_ab);
    fprintf(logfile,"PA       = %0.2f deg\n",*_pa); 

    fprintf(logfile,"Reff (2D)= %0.2f\n",fabs(re) * 0.5*(1+(*_ab)));
  }
}

/* ====================================================================== */

/* void showhlp() {
  puts("");
  puts("Syntax:  kfit2d <image> <x> <y>  [options]");
  puts("");
  puts("  A King (1962,1966) profile will be fitted to the object found at");
  puts("position (x,y) in a FITS file (image). While a correction for the");
  puts("point-spread function (psf) can be included, this code assumes that");
  puts("the cluster profiles are reasonably well resolved (core radii of");
  puts("several pixels or more). No subsampling of the images is performed.");
  puts("For more compact objects, use of the ISHAPE task in the BAOLAB");
  puts("package is recommended.");
  puts("");
  puts("  Various options are available to control the fitting process:");
  puts("");
  puts("  -h           : Show this help text.");
  puts("  rname=<file> : Store the residuals in a file.");
  puts("  mname=<file> : Store the best-fitting model in a file.");
  puts("  psf=<file>   : Convolve the King profile with a user-defined psf.");
  puts("                 The psf must be stored in a standard 2-D fits file, at");
  puts("                 the same sampling as the input image (i.e. no sub-sampling).");
  puts("  annulu=<float>: ");
  puts("  dannulu=<float>: ");
  puts("                 Measure the background in an annulus starting at annulu pixels");
  puts("                 from the centre, dannulu pixels wide.");
  puts("  rc0=<float>  : Initial guess for the core radius (in pixels)");
  puts("  sb0=<float>  : Initial guess for the central surface brightness (counts/pixel)");
  puts("  c0=<float>   : Initial guess for the concentration parameter (rt/rc)");
  puts("  ab0=<float>  : Initial guess for the minor/major axis ratio");
  puts("  pa0=<float>  : Initial guess for the position angle in degrees with ");
  puts("                 respect to the image x-axis.");
  puts("  fitrad=<float>: Fitting radius (in pixels)");
  puts("  -k66         : Fit King (1966) style dynamical models (recommended)");
  puts("  -k62         : Fit King (1962) style analytical models");
  puts("  nw=<int>     : Number of sampling points for King (1966) profiles.");
  puts("  bkg=<float>  : User specified value for the background.");
  puts("  -nofit       : Do not fit any parameters, but allow storage of residual");
  puts("                 and model images");
  puts("  -fitpa       : Fit the position angle (default = keep fixed).");
  puts("  -fitab       : Fit the minor/major axis ratio (default = keep fixed).");
  puts("  -fitxy       : Allow the centroid of the profile to shift during the fit ");
  puts("                 (default = keep fixed).");
  puts("");
}
*/

/* ====================================================================== */

void kfit2d(char *params) {
  static char imname[255] = "";
  char psfnam[255];
  char logname[255] = "";
  char s1[100],s2[100],s3[100],tmps[255];
  hstruct hdr, ohdr;
  hstruct phdr;
  float *img, *model, *res, *obj;
  float *psf;
  static float  xc = 0., yc = 0.;
  float  dxc, dyc, xco, yco;
  float  rpsf, rc, c, sbc, tmpf, rmax;
  float  pa, ab;
  float  sb0 = -1;
  float  rc0 = 5.0;
  float  c0 = 30.0;
  float  pa0 = 0.0;
  float  ab0 = 1.0;
  float  rt;
  float MAXFITRAD = 100.0;
  float padding = 10.0;
  float annulu = -1.;
  float dannulu = 100.;
  char  mname[255];
  char  rname[255];
  int   i,xx,yy;
  float psum;

  mname[0] = '\0';
  rname[0] = '\0';
  psfnam[0] = '\0';

  if (getpar("KFIT2D.RNAME",tmps)) strcpy(rname,tmps);
  if (getpar("KFIT2D.MNAME",tmps)) strcpy(mname,tmps);
  if (getpar("KFIT2D.PSF",tmps)) strcpy(psfnam,tmps);
  if (getpar("KFIT2D.USEPSF",tmps)) 
    USEPSF = (strstr(tmps,"YES") != NULL); 
    
  if (getpar("KFIT2D.ANNULUS",tmps)) annulu = atof(tmps);
  if (getpar("KFIT2D.DANNULUS",tmps)) dannulu = atof(tmps);
  if (getpar("KFIT2D.ITMAX",tmps)) ITMAX = atof(tmps);
  if (getpar("KFIT2D.RC0",tmps)) rc0 = atof(tmps);
  if (getpar("KFIT2D.SB0",tmps)) sb0 = atof(tmps);
  if (getpar("KFIT2D.C0",tmps)) c0 = atof(tmps);
  if (getpar("KFIT2D.AB0",tmps)) ab0 = atof(tmps);
  if (getpar("KFIT2D.PA0",tmps)) pa0 = atof(tmps);
  if (getpar("KFIT2D.FITRAD",tmps)) MAXFITRAD = atof(tmps);
  if (getpar("KFIT2D.FTOL",tmps)) FITTOL = atof(tmps);
  if (getpar("KFIT2D.KINGVER",tmps)) {
    if (strstr(tmps,"K66") == tmps) KINGVER = 66;
    if (strstr(tmps,"K62") == tmps) KINGVER = 62;
  }
  if (getpar("KFIT2D.DOFIT",tmps))
    NOFIT = (strstr(tmps,"NO") != NULL); 
  if (getpar("KFIT2D.FITPA",tmps))
    FITPA = (strstr(tmps,"YES") != NULL); 
  if (getpar("KFIT2D.FITAB",tmps))
    FITAB = (strstr(tmps,"YES") != NULL); 
  if (getpar("KFIT2D.NW",tmps)) NW = atoi(tmps);
  if (getpar("KFIT2D.BKGMODE",tmps)) {
    if (strstr(tmps,"FIT") == tmps) BKGMODE = 1;
    if (strstr(tmps,"ANNULUS") == tmps) BKGMODE = 2;
    if (strstr(tmps,"USER") == tmps) BKGMODE = 3;
  }
  if (getpar("KFIT2D.BKGVAL",tmps)) {
    BKG = atof(tmps);
  }
  if (getpar("KFIT2D.FITXY",tmps))
    FITXY = (strstr(tmps,"YES") != NULL); 
  if (getpar("KFIT2D.KEEPLOG",tmps)) 
    KEEPLOG = (strstr(tmps,"YES") != NULL);

  if (getpar("KFIT2D.LOGFILE",tmps)) strcpy(logname,tmps);


  if (nargs(params) == 3) {
    argn(params,1,imname);
    argn(params,2,tmps); xc = atof(tmps);
    argn(params,3,tmps); yc = atof(tmps);
  } else {
    printf("  Input image    : "); cscanf("%s",imname);
    printf("  X coordinate   : "); cscanf("%0.2f",&xc);
    printf("  Y coordinate   : "); cscanf("%0.2f",&yc);
  }

  if (KEEPLOG) {
    logfile = fopen(logname,"a");
  }

  username(s1);
  datestr(s2);
  gethostname(s3,100);
  printf("*** BAOLAB %s/KFIT2D [%s %s] %s@%s %s\n",VERSION, __DATE__,__TIME__,s1,s3,s2);
  printf("Fitting object at (%0.2f,%0.2f) in %s\n",xc,yc,imname);

  if (KEEPLOG) {
    fprintf(logfile,"*** BAOLAB %s/KFIT2D [%s %s] %s@%s %s\n",VERSION, __DATE__,__TIME__,s1,s3,s2);
    fprintf(logfile,"Fitting object at (%0.2f,%0.2f) in %s\n",xc,yc,imname);

    fprintf(logfile,"Parameter settings:\n");
    fprintf(logfile,"  RNAME = %s\n",rname);
    fprintf(logfile,"  MNAME = %s\n",mname);
    fprintf(logfile,"  USEPSF = %s\n",USEPSF ? "YES" : "NO");
    fprintf(logfile,"  PSF = %s\n",psfnam);
    fprintf(logfile,"  FITRAD = %0.1f\n",MAXFITRAD);
    fprintf(logfile,"  ANNULUS = %0.1f\n",annulu);
    fprintf(logfile,"  DANNULUS = %0.1f\n",dannulu);
    fprintf(logfile,"  ITMAX = %i\n",ITMAX);
    fprintf(logfile,"  FTOL = %0.2e\n",FITTOL);
    fprintf(logfile,"  RC0 = %0.2f\n",rc0);
    fprintf(logfile,"  SB0 = %0.2f\n",sb0);
    fprintf(logfile,"  C0 = %0.2f\n",c0);
    fprintf(logfile,"  AB0 = %0.2f\n",ab0);
    fprintf(logfile,"  PA0 = %0.2f\n",pa0);
    fprintf(logfile,"  KINGVER = ");
      if (KINGVER==62) fprintf(logfile,"K62\n"); else fprintf(logfile,"K66\n");
    fprintf(logfile,"  DOFIT = %s\n", NOFIT ? "NO" : "YES");
    fprintf(logfile,"  FITPA = %s\n", FITPA ? "YES" : "NO");
    fprintf(logfile,"  FITAB = %s\n", FITAB ? "YES" : "NO");
    fprintf(logfile,"  NW = %i\n", NW);
    fprintf(logfile,"  BKGMODE = ");
    switch (BKGMODE) {
      case 1: fprintf(logfile,"FIT\n"); break;
      case 2: fprintf(logfile,"ANNULUS\n"); break;
      case 3: fprintf(logfile,"USER\n"); break;
    }
    fprintf(logfile,"  BKGVAL = %0.2e\n",BKG);
    fprintf(logfile,"  FITXY = %s\n", FITXY ? "YES" : "NO");
    fprintf(logfile,"  KEEPLOG = %s\n", KEEPLOG ? "YES" : "NO");
    fprintf(logfile,"  LOGFILE = %s\n", logname);
    fprintf(logfile,"\n");
  }

  img = floatfitsimage(&hdr,imname,0);

  if (img == NULL) {
    puts("  ** Error reading input image - aborting.");
    if (KEEPLOG) {
      fprintf(logfile,"  ** Error reading input image - aborting.\n");
      fclose(logfile);
    }
    return;
  }

  psf = NULL;
  rpsf = padding;
  if (USEPSF) {
    if (psfnam[0] != '\0') {
      psf = floatfitsimage(&phdr,psfnam,0);
      if (psf == NULL) {
	puts(" ** Error reading PSF - aborting.");
	if (KEEPLOG) {
	  fprintf(logfile," ** Error reading PSF - aborting.\n");
          fclose(logfile);
        }
	free(img);
	return;
      } 
    }
    rpsf = phdr.naxis1 / 2;
  }

  rmax = MAXFITRAD + rpsf;
  if (xc < rmax || xc > hdr.naxis1-rmax-1 || yc < rmax || yc > hdr.naxis2-rmax-1) {
    puts("  ** Error: object too close to edge of image - aborting.");
    printf("            Distance must be > FITRAD+R(PSF)=%i pixels.\n",(int)rmax);
    if (KEEPLOG) {
      fprintf(logfile,"  ** Error: object too close to edge of image - aborting.\n");
      fprintf(logfile,"            Distance must be > FITRAD+R(PSF)=%i pixels.\n",(int)rmax);
      fclose(logfile);
    }
    free(img);
    return;
  }

  if (KINGVER==66) {
    tmpf = log10(c0);
    c = -0.175 
       + 2.307*tmpf 
       + 6.122*pow(tmpf,2) 
       - 4.328*pow(tmpf,3) 
       + 0.892*pow(tmpf,4);
  } else
    c = c0;

  rc = rc0;
  ab = ab0;
  pa = pa0;

  switch (BKGMODE) {
    case 1: FITBKG = 1;
            printf("Fitting background level.\n");
	    if (KEEPLOG)
              fprintf(logfile,"Fitting background level.\n");
	    break;
    case 2: BKG = getbkg(&hdr,img,xc,yc,annulu,dannulu);
            FITBKG = 0;
            printf("Background (%0.1f < r < %0.1f) = %0.2e\n",annulu,annulu+dannulu,BKG);
	    if (KEEPLOG)
              fprintf(logfile,"Background (%0.1f < r < %0.1f) = %0.2e\n",annulu,annulu+dannulu,BKG);
	    break;
    case 3: FITBKG = 0; break;
  }

  if (sb0 > 0)
    sbc = sb0;
  else
    sbc = getbkg(&hdr,img,xc,yc,0,2) - BKG;

  ohdr = hdr;
  obj = kgetobj(&hdr, img, xc, yc, MAXFITRAD+rpsf, &xco, &yco, &ohdr);
  dxc = xc - xco;
  dyc = yc - yco;

  if (!NOFIT) fitking(&ohdr,obj,&xco,&yco,MAXFITRAD,&rc,&c,&sbc,&ab,&pa,psf,&phdr,dxc,dyc);

  model = (float *)malloc(sizeof(float)*ohdr.naxis1*ohdr.naxis2);
  res   = (float *)malloc(sizeof(float)*ohdr.naxis1*ohdr.naxis2);

  tmpf = 
    rms(&ohdr, obj, xco, yco, MAXFITRAD, fabs(rc), c, sbc, ab, pa, model, &rt, psf, phdr.naxis1,dxc,dyc);
  for (i=0; i<ohdr.naxis1*ohdr.naxis2; i++)
    res[i] = obj[i] - model[i];

  if (mname[0] != '\0') savefitsfile(&ohdr, model, -32, mname);
  if (rname[0] != '\0') savefitsfile(&ohdr, res, -32, rname);

  free(img);
  free(model);
  free(res);
  free(obj);

  if (KEEPLOG) fclose(logfile);
}
