#include <stdlib.h>
#include <math.h>

float polyval(
  float x,
  float *a,
  int   porder
) {
  int j;
  float p;

  p = 0.0;
  for (j=0; j<=porder; j++) p += a[j] * pow(x,j);
  return p;
}

int polyfit(
  float *x,    /* Sampling points */
  float *y,    /* Data values     */
  int   nx,    /* Number of sampling points / data values */
  float *a,    /* Fitted coefficients */
  int   na     /* degree of polynomium */
) {
  int i,j;
  double *Exn, *Exny;
  double *m;

  Exn  = (double *)malloc(sizeof(double)*(2*na+1));
  Exny = (double *)malloc(sizeof(double)*(na+1));
  m    = (double *)malloc(sizeof(double)*(na+1)*(na+2));

  for (j=0; j<=2*na; j++) {
    Exn[j] = 0.0;
    for (i=0; i<nx; i++) Exn[j] += pow(x[i],j);
  }

  for (j=0; j<=na; j++) {
    Exny[j] = 0.0;
    for (i=0; i<nx; i++) Exny[j] += y[i]*pow(x[i],j);
  }

  for (j=0; j<=na; j++) {
    for (i=0; i<=na; i++) m[j*(na+2) + i] = Exn[i+j];
    m[j*(na+2) + na + 1] = Exny[j];
  }

  echelon(m,na+1);

  for (j=0; j<=na; j++) a[j] = m[j*(na+2) + na + 1];

  free(m);
  free(Exny);
  free(Exn);

  return 1;
}
