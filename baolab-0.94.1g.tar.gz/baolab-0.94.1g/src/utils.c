#define UTILS_MAIN

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <pwd.h>
/*
#include <sys/types.h>
#if defined(OS_Darwin)
  #include <sys/malloc.h>
#else
  #include <malloc.h>
#endif
*/
#include "baostr.h"
#include "utils.h"

/* ============================================================= */

double nrand() {
/* Normalised random number in the interval 0 < x < 1 */

  int i1, i2, mod;
  int small_rand_max = 0;
  double f;

#ifdef RAND_MAX
  small_rand_max = (RAND_MAX < 2e9);
#else
  small_rand_max = 1;
#endif

  if (small_rand_max) {
    mod = 32768/2;

    i1 = rand() % mod;
    i2 = rand() % mod; 
    f = (i1 + i2/(double)mod)/((double)mod);
  } else 
    f = rand()/(double)RAND_MAX;
  
  return f;
}

/* ==================================================================== */

double nfac(int i) {

  int j;
  double n;

  if (i < 2) {
    return 1.;
  } else {
    n = 1.;
    for (j=2; j<=i; j++) n *= j;
    return n;
  }
}

/* ============================================================= */

float poisson(float mu, int x) {
  return exp(-mu)*pow(mu,x)/nfac(x);
}

int prand() {   
  /* Return random number drawn from Poissonian distribution */

  int i;

/*  i = IPXMAX*(rand()*1.0/RAND_MAX); */

  i = IPXMAX*nrand();
/*  printf("%i %i\n",i,IPXMAX); */
  return PX[i];
}

void pinit(float mu) {
  /* Initialise for Poissonian distribution with mean mu */

  float xmin,xmax;
  float px;
  int   ip,i,x,nx;

  if (mu > 0) {
    xmin = mu - 10*sqrt(mu);
    xmax = mu + 10*sqrt(mu);
    if (xmin < 0) xmin = 0;
    if (xmax < 10) xmax = 10;

    ip = 0;
    for (x=xmin; x<xmax; x++) {
      px = poisson(mu, x);
      nx = px*NPX;
      for (i=0; i<nx; i++) PX[ip++] = x;
      if (ip > NPX) {
        puts(" ** Overflow error in pinit **");
	printf(" ** Mu = %0.2e, x = %i, px=%0.2e **\n",mu, x, px);
      }
    }
    IPXMAX = ip-1;
  } else {
    for (i=0; i<NPX; i++) PX[i] = 0;
    IPXMAX = NPX-1;
  }
/*  printf("IPXMAX = %i\n",IPXMAX); */
}

/* ============================================================= */

float gauss(float x) {
  return exp(-x*x/2);
}

/* void initgauss() {

  float x0,x,y;
  int   j,i,n = 0;
  float dx = 0;
  float data[5100];

  x0 = rand()*0.0005/RAND_MAX;
  for (x=x0; x<6 ; n++,x+=dx) {
    y = gauss(x);
    dx = 0.0005/y;
    data[n] = x;
  }

  dx = 0;
  for (x=x0-0.0005; x>-6; n++,x-=dx) {
    y = gauss(x);
    dx = 0.0005/y;
    data[n] = x;
  }

  for (i=0; i<n; i++) {
    do {
      j = (int)(n*(rand()*1.0/RAND_MAX));
    } while (data[j] < -99);

    GAUSSDATA[i] = data[j];
    data[j] = -100;
  }

  MAXG = n-1;
} */


/* float grand() {
  float f;

  f = GAUSSDATA[GINDEX++];
  if (GINDEX > MAXG) {
    GINDEX = 0;
    initgauss();
  }
  return f;
} */

/* ============================================================= */

float grandvn() {
  /* Random number drawn from Gaussian distribution with mean 0 and */
  /* sigma=1.0, using von Neumann's method. Does not require        */
  /* initialization.                                                */

  double M, a, b, u, v;

  do {
    a = -10.; b = 10.;
    M = 1.01;
    u = a + (b-a)*nrand();
    v = M * nrand();
  } while (v >= exp(-u*u/2));

  return u;
}

/* ============================================================= */

float gauss2(float r, float fw2, float w) {
  return r*((1-w)*exp(-r*r/2) + w*exp(-r*r/(2*fw2*fw2)));
}

void initgauss2(float fw2, float w) {
  float r0,r,y;
  int   j,i,n = 0;
  float dr = 0, l;
  float data[10000];

  l = (fw2 > 1) ? fw2 : 1;

  dr = 0.0;
  r0 = 0.007 + nrand()*0.01;
  for (r = r0; (r<10*l) && (n<10000); r+=dr,n++) {
    data[n] = r;
    y = gauss2(r,fw2,w);
    dr = 0.0003/y;
  }


  for (i=0; i<n; i++) {
    do {
      j = (int)(n*nrand());
    } while (data[j] < -99);

    GAUSSDATA2[i] = data[j];
    data[j] = -100;
  }

  FW2 = fw2;
  W2 = w;
  MAXG2 = n-1;
}

float grand2() {
  float f;

  f = GAUSSDATA2[GINDEX2++];
  if (GINDEX2 > MAXG2) {
    GINDEX2 = 0;
    initgauss2(FW2,W2);
  }
  return f;
}

/* ==================================================================== */

int getcoolst(
  char *starlist,
  float **starx, float **stary
)
{
  FILE *starfile;
  int  i,nstars=0;
  char *ch;
  char s1[100],tmps[100];

  starfile = fopen(starlist,"r");
  if (starfile != NULL) {
    ch = fgets(tmps,100,starfile);
    while (ch != NULL) {
      nstars++;
      ch = fgets(tmps,100,starfile);
    }

    rewind(starfile);
    *starx = (float *)malloc(sizeof(float)*nstars);
    *stary = (float *)malloc(sizeof(float)*nstars);

    for (i=0; i<nstars; i++) {
      fgets(tmps,100,starfile);
      sglspc(tmps);
      argn(tmps,1,s1); (*starx)[i] = atof(s1);
      argn(tmps,2,s1); (*stary)[i] = atof(s1);
    }

    fclose(starfile);
  } 

  return nstars;
}

/* ============================================================= */

int getstarlst(
  char *name,
  float **x,
  float **y,
  float **mag
) {

  FILE *file;
  int i,n = 0;
  int ok = TRUE;
  char tmps[255],s1[100];
  char *ch;

  file = fopen(name,"r");
  if (file != NULL) {
    ch = fgets(tmps,255,file);

    while (ch != NULL) {
      n++;
      if (nargs(tmps) < 3) {
        printf("  ** Error at line %i in star list: Too few arguments\n",n);
	printf("  >> %s \n",tmps);
	ok = FALSE;
      }
      ch = fgets(tmps,255,file);
    }

    if (ok) {
      rewind(file);
      (*x) = malloc(n*sizeof(float));
      (*y) = malloc(n*sizeof(float));
      (*mag) = malloc(n*sizeof(float));

      for (i=0; i<n; i++) {
        fgets(tmps,255,file);
	argn(tmps,1,s1); (*x)[i] = atof(s1);
	argn(tmps,2,s1); (*y)[i] = atof(s1);
	argn(tmps,3,s1); (*mag)[i] = atof(s1);
      }
    }


    fclose(file);
  }

  if (!ok) n = 0;
  return n;
}

/* ============================================================= */

  char *datestr(
    char *s
  ) {
    time_t timep;

     time(&timep);
     sprintf(s,"%s",ctime(&timep));    
     return s;
  }

/* ============================================================= */

  char *username(
    char *s
  ) {
    uid_t uid;
    struct passwd *pwent;

    uid = getuid();
    pwent = getpwuid(uid);
    strcpy(s,pwent->pw_name);
    return s;
  }

/* ============================================================= */

float *fsort(
  float *arr,
  int n
) {
  int i,j,imin;
  float tmp;

  for (i=0; i<n; i++) {
    imin = i;
    for (j=i; j<n; j++) if (arr[j] < arr[imin]) imin=j;
    if (imin != i) {
      tmp = arr[i];
      arr[i] = arr[imin];
      arr[imin] = tmp;
    }
  }

  return arr;
}

/* ============================================================= */

float *fsort2(
  float *arr,
  int *order,
  int n
) {
  int i,j,imin;
  float tmp;
  int   tmpi;

  for (i=0; i<n; i++) order[i] = i;

  for (i=0; i<n; i++) {
    imin = i;
    for (j=i; j<n; j++) if (arr[j] < arr[imin]) imin=j;
    if (imin != i) {
      tmp = arr[i];
      tmpi = order[i];
      arr[i] = arr[imin];
      order[i] = order[imin];
      arr[imin] = tmp;
      order[imin] = tmpi;
    }
  }

  return arr;
}
