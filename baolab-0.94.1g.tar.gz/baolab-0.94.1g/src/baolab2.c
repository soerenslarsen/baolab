#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"

extern void echelon(double *, int);   /* in solveq.c */

float *readfilter(
  char *name,
  int  *dx, int *dy
)
{
  FILE *file;
  float *filter;
  char  s[50], tmps[1000],*ch;
  int   i,x,y;

  file = fopen(name,"r");

  if (file != NULL) {
    *dy = *dx = 0;

    do {
      ch = fgets(tmps,1000,file);
      if (ch != NULL) {
        (*dy)++;
	sglspc(tmps);
	*dx = (nargs(tmps) > *dx) ? nargs(tmps) : *dx;
      }
    } while (ch!=NULL);

    rewind(file);
    filter = (float *)malloc(sizeof(float)*(*dx)*(*dy));

    for (i=0,y=1;y<=*dy;y++) {
      fgets(tmps,1000,file); 
      sglspc(tmps);
      for (x=1;x<=*dx;x++) {
	argn(tmps,x,s); 
        filter[i++] = atof(s); 
      }
    }
    fclose(file);

  } else
    filter = NULL;

  return filter;
}

/* -------------------------------------------------------------------- */

float *do_convol(
  float   *inbuff,
  hstruct *inhdr,
  float   *filter,
  int      fdx, int fdy,
  float    scl
)
{
  int    markint,ncon,ofs1,npix,fofs;
  float *outbuff;
  int    xx,yy,x,y;
  float  sum;

  npix = inhdr->naxis1*inhdr->naxis2;
  outbuff = (float *)malloc(sizeof(float)*npix);

  if (outbuff == NULL) {
    puts("  ** Error allocating memory");
    return NULL;
  }

  markint = (npix-inhdr->naxis1*fdy-inhdr->naxis2*fdx)/50+1;
  if (markint==0) markint=1;
  ncon = 0;

  printf("  <==================================================>");
  fflush(stdout);
  putchar(CTRL_M); printf("  <");

  for (ofs1=0;ofs1<npix;ofs1++) outbuff[ofs1] = inbuff[ofs1];      

  for (y=fdy/2;y<inhdr->naxis2-fdy/2;y++)
    for (x=fdx/2;x<inhdr->naxis1-fdx/2;x++) {
      ofs1 = (y-fdy/2)*inhdr->naxis1+x-fdx/2;
      sum  = 0.0;
      ncon++;

      if (ncon % markint == 0) {
	putc('*',stdout);
	fflush(stdout);
      }

      for (fofs=0,yy=0;yy<fdy;yy++) {    /* Convolve pixel at (x,y) */
	for (xx=0;xx<fdx;xx++)
	  sum += filter[fofs++]*inbuff[ofs1+xx];
	ofs1 += inhdr->naxis1;
      }

      sum *= scl;
      outbuff[y*inhdr->naxis1+x] = sum;
    }

  return outbuff;
}

/* -------------------------------------------------------------------- */

void convolve( char *params )
{
  static char infile[255] = "", outfile[255] = "", fltname[255] = "";
  char  tmps[255];
  float *inbuff,*outbuff;
  float *filter;
  float scl = 1.0;
  hstruct inhdr,outhdr;
  int   fdx,fdy;
  float defscl=1.0;

  if (getpar("CONVOL.DEFSCL",tmps)) defscl = atof(tmps); 
  if (defscl==0) defscl = 1.0;

  if ((nargs(params) == 3 ) || (nargs(params) == 4)) {
    argn(params,1,infile);
    argn(params,2,fltname);
    argn(params,nargs(params),outfile);
    if (nargs(params)==4) {
      argn(params,3,tmps);
      scl = atof(tmps);
    } else
      scl = defscl;
  } else {
    scl = defscl;
    printf("  Image to convolve   :  "); cscanf("%s",infile);
    printf("  File with filter    :  "); cscanf("%s",fltname);
    printf("  Scale factor        :  "); cscanf("%5.3f",&scl); 
    printf("  Output image        :  "); cscanf("%s",outfile);
  }

  filter = readfilter(fltname,&fdx,&fdy);
  if (filter != NULL) {
    inbuff = floatfitsimage(&inhdr,infile,TRUE);
    if (inbuff != NULL) {

      printf("  Using %i x %i filter.\n",fdx,fdy);
      outhdr = inhdr;
      outhdr.bscale = 1.0;
      outhdr.bzero = 0.0;
      sprintf(tmps,"Convolved '%s' with filter '%s'",infile,fltname);
      addcard(&outhdr,"HISTORY",tmps,H_COMM);

      outbuff = do_convol(inbuff,&inhdr,filter,fdx,fdy,scl);

      savefitsfile(&outhdr,outbuff,-32,outfile);
      free(inbuff);
      free(outbuff);
      printf("\n  Finished!\n");
    } else
      puts("  ** Error reading input file.");

    free(filter);
    freehdr(&inhdr);

  } else
    puts("  ** Error reading filter file.");
}

/* ==================================================================== */

int median(
  int *data,
  int n
)
{
  int *data1;
  int j,i,tmp,min,nmin;

  data1 = (int *)malloc(sizeof(int)*n);
  if (data1 == NULL) puts("  ** Error allocating memory");
  for (i=0; i<n; i++) data1[i] = data[i];

  for (i=0; i<n; i++) {

    min = data1[i];
    nmin = i;

    for (j=i; j<n; j++) if (data1[j] < min) { nmin = j; min = data1[j]; }
    tmp = data1[i];
    data1[i] = data1[nmin];
    data1[nmin] = tmp;
  }

  tmp = data1[n/2];
  free(data1);
  return tmp;
}

/* -------------------------------------------------------------------- */

float fmedian(
  float *data,
  int n
)
{
  float *data1;
  int j,i,nmin;
  float tmp,min;

  data1 = (float *)malloc(sizeof(float)*n);
  if (data1 == NULL) puts("  ** Error allocating memory");
  for (i=0; i<n; i++) data1[i] = data[i];

  for (i=0; i<n; i++) {

    min = data1[i];
    nmin = i;

    for (j=i; j<n; j++) if (data1[j] < min) { nmin = j; min = data1[j]; }
    tmp = data1[i];
    data1[i] = data1[nmin];
    data1[nmin] = tmp;
  }

  tmp = data1[n/2];
  free(data1);
  return tmp;
}

/* -------------------------------------------------------------------- */

float fmedian_clip(
  float *data,
  int n,
  float lsigma, float hsigma
)
{
  float *data1;
  int n1;
  int i;
  float vsum = 0.0, sigma;
  float m1,m2;

  m1 = fmedian(data,n);
  for (i=0; i<n; i++) vsum += sqr(m1-data[i]);
  sigma = sqrt(vsum/n);

  data1 = (float *)malloc(sizeof(float)*n);
  if (data1 == NULL) puts("  ** Error allocating memory");

  for (i=0, n1=0; i<n; i++) {
    if ((data[i] > m1-lsigma*sigma) && (data[i] < m1+hsigma*sigma))
      data1[n1++] = data[i];
  }

  m2 = fmedian(data1,n1);

  free(data1);
  return m2;
}

/* -------------------------------------------------------------------- */

float *do_mfilter(
  float *image,
  int   imdx, int imdy,
  int   xw, int yw,
  int   clip,
  float lsigma, float hsigma
)
{
  float *mdata;
  float *outdata;
  int i,ofs,ofs0;
  int x,y,xx,yy;
  int markint,ncon;

  mdata = (float *)malloc(sizeof(float)*xw*yw);
  outdata = (float *)malloc(sizeof(float)*imdx*imdy);

  for (i=0; i<imdx*imdy; i++) outdata[i] = image[i];

  markint = (imdx*imdy-imdx*yw-imdy*xw)/50+1;
  if (markint==0) markint=1;
  ncon = 0;

  printf("  <==================================================>");
  fflush(stdout);
  putchar(CTRL_M); printf("  <");

  for (y = yw/2; y<imdy-yw/2; y++) {
    ofs0 = y*imdx;

    for (x = xw/2; x<imdx-xw/2; x++) {
      ncon++;
      if (ncon % markint == 0) { putchar('*'); fflush(stdout); }

      ofs = (y-yw/2)*imdx + x-xw/2;
      i = 0;
      for (yy=0; yy<yw; yy++) {
        for (xx=0; xx<xw; xx++) mdata[i++] = image[ofs+xx];
        ofs += imdx;
      }
      if (clip)
	outdata[ofs0+x] = fmedian_clip(mdata,xw*yw, lsigma, hsigma);
      else
        outdata[ofs0+x] = fmedian(mdata,xw*yw);
    }
  }

  free(mdata);
  printf("\n  Finished!\n");
  return outdata;
}

/* -------------------------------------------------------------------- */

void mfilter(char *params)
{
  static char inname[255] = "",outname[255]="";
  char   tmps[255];
  static int xw = 3,yw = 3;
  float *inimage;
  float lsigma = 3.0, hsigma = 3.0;
  int   clip = FALSE;
  float *outimage;
  hstruct h1;

  if (getpar("MFILTER.CLIP",tmps)) clip = (strstr(tmps,"YES") != NULL);
  if (getpar("MFILTER.LSIGMA",tmps)) lsigma = atof(tmps);
  if (getpar("MFILTER.HSIGMA",tmps)) hsigma = atof(tmps);

  if (nargs(params) == 4) {
    argn(params,1,inname);
    argn(params,2,tmps);  xw = atoi(tmps);
    argn(params,3,tmps);  yw = atoi(tmps);
    argn(params,4,outname);
  } else {
    printf("  Input file    :  "); cscanf("%s",inname);
    printf("  Filter width  :  "); cscanf("%i",&xw); 
    printf("  Filter height :  "); cscanf("%i",&yw); 
    printf("  Output file   :  "); cscanf("%s",outname);
  }

  inimage = floatfitsimage(&h1,inname,TRUE);
  if (inimage != NULL) {
    outimage = do_mfilter(inimage,h1.naxis1,h1.naxis2,xw,yw,
				   clip, lsigma, hsigma);

    h1.bscale = 1.0;
    h1.bzero  = 0.0;
    sprintf(tmps,"Median filter (%ix%i)",xw,yw);
    addcard(&h1,"HISTORY",tmps,H_COMM);
    savefitsfile(&h1,outimage,-32,outname);
    free(outimage);

  } else
    puts(" ** Error reading input image.");

  freehdr(&h1);
}

/* ==================================================================== */

float *getusrpsf(
  char *psfname,
  int  *psfdx, int *psfdy
)
{
  float *psf;
  int   i,n;
  float sum;

  psf = readfilter(psfname,psfdx,psfdy);
  if (psf != NULL)  {
    n = (*psfdx)*(*psfdy);
    for (sum=0,i=0;i<n;i++) sum+=psf[i];
    for (i=0;i<n;i++) psf[i] /= sum;
  }

  return psf;
}

/* -------------------------------------------------------------------- */

float *mkpsf(
  float fwhm1, float fwhm2, float psforient, float psfminval,
  int  *psfdx, int *psfdy
)
{
  int x,y,xx,yy,j,i,n;
  int cutx, cuty = 0;
  float x1,y1,sum,maxx,maxy;
  float *tmppsf,*psf;

  psforient = psforient*pi/180.0;

  (*psfdx) = (fwhm1>fwhm2) ? 1+2*(int)fwhm1 : 1+2*(int)fwhm2;
  if (*psfdx < 5) (*psfdx) = 5;
  (*psfdy) = (*psfdx);

  tmppsf = (float *)malloc(4*(*psfdy)*(*psfdx));
  yy = xx = (*psfdx) / 2; 
  cutx = xx;

  maxy = 0;
  for (sum=0,i=0,y=-yy;y<=yy;y++) {
    maxx = 0;
    for (x=-xx;x<=xx;x++) {
      x1 = cos(psforient)*x - sin(psforient)*y;
      y1 = cos(psforient)*y + sin(psforient)*x;

      sum += tmppsf[i++] = exp(-2.77*(pow(x1/fwhm1,2) + pow(y1/fwhm2,2)) );
      if (tmppsf[i-1] > maxx) maxx = tmppsf[i-1];
      if (x > 0) 
        if ((tmppsf[i-1] > psfminval) && (xx-x < cutx)) cutx = xx-x;
    }
    if ((maxx < psfminval) && (y < 0)) cuty++;
  }

  n = i;
  psf = (float *)malloc(4*(*psfdx-2*cutx)*(*psfdy-2*cuty));

  for (sum=0,j=0,yy=cuty;yy<(*psfdy)-cuty;yy++) {
    for (xx=cutx;xx<(*psfdx)-cutx;xx++) {
      sum += psf[j++] = tmppsf[xx+yy*(*psfdx)]; 
    }
  }

  for (i=0;i<j;i++) psf[i] /= sum;

  (*psfdx) -= 2*cutx;
  (*psfdy) -= 2*cuty;
  free(tmppsf);
  return psf;
}

/* -------------------------------------------------------------------- */

short *do_decon(
  float *c,
  int   naxis1, int naxis2,
  float *psf,
  int   psfdx, int psfdy, int nit,
  float bkgr, float maxeff
)
{
  float *cj,*bj,*bj1;
  int   dx,dy,it,i,npix;
  short *result;
  int   ipix,icon,intmark;
  int   ofs,ofs1,ofspsf;
  int   xx,yy;
  float f;

  if (bkgr < 1) bkgr = 1;
  if (maxeff < bkgr) maxeff = bkgr;

  npix = naxis1*naxis2;
  cj  = (float *)malloc(4*npix);
  bj  = (float *)malloc(4*npix);
  bj1 = (float *)malloc(4*npix);

  for (i=0;i<npix;i++) bj[i] = bj1[i] = cj[i] = c[i];

  icon = npix-naxis1*psfdy-naxis2*psfdx;
  intmark = icon/50+1;
  puts("");
  printf("  Deconvolving using %ix%i psf, bkgr=%4.1f, maxeff=%4.1f\n",
         psfdx,psfdy,bkgr,maxeff);

  for(it=1;it<=nit;it++) {
    putchar(CTRL_M); 
    printf("              <==================================================>");
    putchar(CTRL_M);
    printf("  It= %2ia/%2i  <",it,nit); fflush(stdout);

    for (ipix=0,yy=psfdy/2;yy<naxis2-psfdy/2;yy++)
      for (xx=psfdx/2;xx<naxis1-psfdx/2;xx++) {
        ipix++;
	ofs  = yy*naxis1+xx;               /* Offset in image for this pixel */
	ofs1 = (yy-psfdy/2)*naxis1+xx-psfdx/2; /* Offset for 1st PSF pixel */
	ofspsf = 0;                        /* Offset in the PSF itself     */
	cj[ofs] = 0;

	if (ipix % intmark == 0) { putchar('*'); fflush(stdout); }

        for(ofspsf=0,dy = 0; dy<psfdy; dy++) {
	  for(dx = 0; dx<psfdx; dx++) {
	    cj[ofs] += bj[ofs1+dx]*psf[ofspsf++];
	  }
	  ofs1 += naxis1;
        }
      }

    putchar(CTRL_M); 
    printf("              <==================================================>");
    putchar(CTRL_M);
    printf("  It= %2ib/%2i  <",it,nit); fflush(stdout);

    for (ipix=0,yy=psfdy/2;yy<naxis2-psfdy/2;yy++)
      for (xx=psfdx/2;xx<naxis1-psfdx/2;xx++) {
        ipix++;
	ofs  = yy*naxis1+xx;               /* Offset in image for this pixel */
	ofs1 = (yy+psfdy/2)*naxis1+xx+psfdx/2; /* Offset for 1st PSF pixel */
	ofspsf = 0;                        /* Offset in the PSF itself     */
	bj1[ofs] = 0;

	if (ipix % intmark == 0) { putchar('*'); fflush(stdout); }

        for(ofspsf=0,dy = 0; dy<psfdy; dy++) {
	  for(dx = 0; dx<psfdx; dx++) {
	    if (cj[ofs1-dx] >= 1.0)
	      bj1[ofs] += psf[ofspsf++]*c[ofs1-dx]/cj[ofs1-dx];
	  }
	  ofs1 -= naxis1;
        }
	
	bj1[ofs] *= bj[ofs];
      }

    for (i=0;i<npix;i++) {
      if (c[i] >= maxeff) bj[i] = bj1[i]; else
      if (c[i] <= bkgr) bj[i] = c[i]; else {
	f = (c[i]-bkgr) / (maxeff-bkgr);
        bj[i] = c[i]*(1-f) + bj1[i]*f;
      }
    }
  }

  free(cj); free(bj1); 
  result = (short *)malloc(2*npix);

  for (i=0;i<npix;i++) 
    if ((bj[i] < 32768.0) && (bj[i] > -32768.0))
      result[i] = (short)bj[i];
    else
      result[i] = 32767;

  free(bj);
  puts("");
  puts("  Finished!");

  return result;
}

/* -------------------------------------------------------------------- */

void richlucy(char *params)
{
  static char    inname[255] = "",outname[255] = "";
  static char    psfname[255] = "";
  char    tmps[255];
  static  float  fwhm1=1,fwhm2=1;
  float   psforient = 0, psfminval = 0.01;
  int     iter=10;
  int     usrpsf=0;
  float   bkgr=0,maxeff=0;
  float  *c;
  float  *psf;
  short  *output;
  int     psfdx,psfdy;
  hstruct header;
  int     nexpect;
  
  if (getpar("RICHLUCY.PSFORIENT",tmps)) psforient = atof(tmps); 
  if (getpar("RICHLUCY.BKGR",tmps)) bkgr = (int)atof(tmps); 
  if (getpar("RICHLUCY.MAXEFF",tmps)) maxeff = (int)atof(tmps);
  if (getpar("RICHLUCY.USRPSF",tmps)) usrpsf= (strstr(tmps,"YES") != NULL);
  if (getpar("RICHLUCY.PSFMINVAL",tmps)) psfminval = atof(tmps);
  if (getpar("RICHLUCY.ITER",tmps)) {
    iter = atoi(tmps);
    if (iter==0) iter = 10;
  }

  if (psfminval==0) psfminval = 0.01;
  remeqspc(params);

  nexpect = (usrpsf) ? 3 : 4;

  if (nargs(params) == nexpect) {
    argn(params,1,inname);
    if (usrpsf) {
      argn(params,2,psfname);
      argn(params,3,outname);
    } else {
      argn(params,2,tmps); fwhm1 = atof(tmps);
      argn(params,3,tmps); fwhm2 = atof(tmps);
      argn(params,4,outname);
    }
  } else {
    printf("  Input file :  "); cscanf("%s",inname); 
    if (usrpsf) {
      printf("  PSF file   :  "); cscanf("%s",psfname); 
    } else {
      printf("  Fwhm 1     :  "); cscanf("%0.2f",&fwhm1);
      printf("  Fwhm 2     :  "); cscanf("%0.2f",&fwhm2);
    }
    printf("  Output file :  "); cscanf("%s",outname); 
  }

  /* -------  Now do the calculations  ------- */

  if (usrpsf) 
    psf = (float*)getusrpsf(psfname,&psfdx,&psfdy);
  else {
    if ((fwhm1 < 0.1) || (fwhm2 < 0.1)) {
      puts("  ** Error: Illegal PSF.");
      return;
    }
    psf = (float*)mkpsf(fwhm1,fwhm2,psforient,psfminval,&psfdx,&psfdy);
  }

  if (psf != NULL) {
    c = floatfitsimage(&header,inname,TRUE);
    if (c != NULL) {
      output = (short*)do_decon(c,header.naxis1,header.naxis2,
                                psf,psfdx,psfdy,iter,bkgr,maxeff);
      if (output != NULL) {
        if (usrpsf)
          sprintf(tmps,"Deconvolved using R-L. User psf = '%s'",psfname);
	else
	  sprintf(tmps,"Deconvolved using R-L. FWHM = (%0.2fx%0.2f)",
	            fwhm1,fwhm2);
        addcard(&header,"HISTORY",tmps,H_COMM);
        savefitsfile(&header,output,16,outname);
	free(output);
      }

      free(c);

    } else
      puts("  ** Error reading input image.");

    free(psf);
    freehdr(&header);

  } else
    puts("  ** Error making PSF.");
}
/* ==================================================================== */

void findmax_flt(
  float *sum,
  int  dx, int dy,
  int  method,
  float *maxx, float *maxy
)
{
  int x,y,i, imax;

  double Ex4,Ex2y2,Ex3,Ex2y,Ex2,Ex2z,
         Ey4,Exy2,Ey3,Ey2,Ey2z,
         Exy,Ex,Exz,
         Ey,Eyz,
         Ez;
  double xx,yy,zz;

  double M[100];
  double a,b,c,d,e;


  switch (method) {
    case FITNONE: 
	    *maxx = 0;
	    *maxy = 0;
	    break;

    case FITMAX :
	    *maxx = -dx; *maxy = -dy;
	    imax = 0;

	    for (y=-dy,i=0;y<=dy;y++)
	      for (x=-dx; x<= dx; x++) {
		if (sum[i] > sum[imax]) {
		  imax = i;
		  *maxx = (float)x;
		  *maxy = (float)y;
		}
		i++;
	      }
	    break;

    case FITPOLY:
    case FITRPOLY:
            Ex4 = Ex2y2 = Ex3 = Ex2y = Ex2 = Ex2z = Ey4 = Exy2 = Ey3 = Ey2 = 
            Ey2z = Exy = Ex = Exz = Eyz = Ey = Ez = 0;

            for(i = 0, y = -dy ; y<=dy ; y++)
              for(x = -dx ; x<=dx ; x++) {
		xx = x; yy = y;
		zz = sum[i];

		Ex4     +=  pow(xx,4);
		Ex2y2   +=  pow(xx*yy,2);
		Ex3     +=  pow(xx,3);
		Ex2y    +=  yy*xx*xx;
		Ex2     +=  pow(xx,2);
		Ex2z    +=  zz*xx*xx;
		Ey4     +=  pow(yy,4);
		Exy2    +=  xx*yy*yy;
		Ey3     +=  pow(yy,3);
		Ey2     +=  yy*yy;
		Ey2z    +=  zz*yy*yy;
		Exy     +=  xx*yy;
		Ex      +=  xx;
		Exz     +=  xx*zz;
		Ey      +=  yy;
		Eyz     +=  yy*zz;
		Ez      +=  zz;

		i++;
	      }

	    M[0] = Ex4;  M[1] = Ex2y2; M[2] = Ex3; 
	    M[3] = Ex2y; M[4]= Ex2;    M[5] = Ex2z;

	    M[6] = Ex2y2; M[7] = Ey4;   M[8] = Exy2; 
	    M[9] = Ey3;   M[10] = Ey2;  M[11] = Ey2z;

	    M[12] = Ex3;  M[13] = Exy2;  M[14] = Ex2;  
	    M[15] = Exy;  M[16] = Ex;    M[17] = Exz;

	    M[18] = Ex2y; M[19] = Ey3;   M[20] = Exy;  
	    M[21] = Ey2;  M[22] = Ey;    M[23] = Eyz;

	    M[24] = Ex2;  M[25] = Ey2;   M[26] = Ex;   
	    M[27] = Ey;   M[28] = i;     M[29] = Ez;

	    echelon(M,5);

	    a = M[5];
	    b = M[11];
	    c = M[17];
	    d = M[23];
	    e = M[29];

	    *maxx = (float) -c/(2*a);
	    *maxy = (float) -d/(2*b);

	    if (method == FITRPOLY) {
	      *maxx = floor(0.5+(*maxx));
	      *maxy = floor(0.5+(*maxy));
	    }

            break;
  }
}

/* ==================================================================== */

void findmax(
  long *sum,
  int  dx, int dy,
  int  method,
  float *maxx, float *maxy
)
{
  int x,y,i,imax;

  double Ex4,Ex2y2,Ex3,Ex2y,Ex2,Ex2z,
         Ey4,Exy2,Ey3,Ey2,Ey2z,
         Exy,Ex,Exz,
         Ey,Eyz,
         Ez;
  double xx,yy,zz;

  double M[100];
  double a,b,c,d,e;


  switch (method) {
    case FITNONE: 
	    *maxx = 0;
	    *maxy = 0;
	    break;

    case FITMAX :
	    *maxx = -dx; *maxy = -dy;
	    imax = 0;

	    for (y=-dy,i=0;y<=dy;y++)
	      for (x=-dx; x<= dx; x++) {
		if (sum[i] > sum[imax]) {
		  imax = i;
		  *maxx = (float)x;
		  *maxy = (float)y;
		}
		i++;
	      }
	    break;

    case FITPOLY:
    case FITRPOLY:
            Ex4 = Ex2y2 = Ex3 = Ex2y = Ex2 = Ex2z = Ey4 = Exy2 = Ey3 = Ey2 = 
            Ey2z = Exy = Ex = Exz = Eyz = Ey = Ez = 0;

            for(i = 0, y = -dy ; y<=dy ; y++)
              for(x = -dx ; x<=dx ; x++) {
		xx = x; yy = y;
		zz = sum[i];

		Ex4     +=  pow(xx,4);
		Ex2y2   +=  pow(xx*yy,2);
		Ex3     +=  pow(xx,3);
		Ex2y    +=  yy*xx*xx;
		Ex2     +=  pow(xx,2);
		Ex2z    +=  zz*xx*xx;
		Ey4     +=  pow(yy,4);
		Exy2    +=  xx*yy*yy;
		Ey3     +=  pow(yy,3);
		Ey2     +=  yy*yy;
		Ey2z    +=  zz*yy*yy;
		Exy     +=  xx*yy;
		Ex      +=  xx;
		Exz     +=  xx*zz;
		Ey      +=  yy;
		Eyz     +=  yy*zz;
		Ez      +=  zz;

		i++;
	      }

	    M[0] = Ex4;  M[1] = Ex2y2; M[2] = Ex3; 
	    M[3] = Ex2y; M[4]= Ex2;    M[5] = Ex2z;

	    M[6] = Ex2y2; M[7] = Ey4;   M[8] = Exy2; 
	    M[9] = Ey3;   M[10] = Ey2;  M[11] = Ey2z;

	    M[12] = Ex3;  M[13] = Exy2;  M[14] = Ex2;  
	    M[15] = Exy;  M[16] = Ex;    M[17] = Exz;

	    M[18] = Ex2y; M[19] = Ey3;   M[20] = Exy;  
	    M[21] = Ey2;  M[22] = Ey;    M[23] = Eyz;

	    M[24] = Ex2;  M[25] = Ey2;   M[26] = Ex;   
	    M[27] = Ey;   M[28] = i;     M[29] = Ez;

	    echelon(M,5);

	    a = M[5];
	    b = M[11];
	    c = M[17];
	    d = M[23];
	    e = M[29];

	    *maxx = (float) -c/(2*a);
	    *maxy = (float) -d/(2*b);

	    if (method == FITRPOLY) {
	      *maxx = floor(0.5+(*maxx));
	      *maxy = floor(0.5+(*maxy));
	    }

            break;
  }
}

/* ==================================================================== */

void do_corr(
  char *imlist[],
  int  *x0,  int *y0,
  int  nim, int ref, int boxdx, int boxdy, int dx, int dy,
  char *corrname,
  int  fitmethod
)
{
  int ii,i,x1,x2,y1,y2,xx,yy;
  int boxx,boxy,i1,i2;
  FILE *outfile;
  short *im1,*im2;
  hstruct hdr1,hdr2;
  long    *sum[1000];
  long    s;
  float   maxx,maxy;

  puts("  ** Now cross-correlating images...");

  outfile = fopen(corrname,"w");

  if (outfile != NULL) {
    im1 = shortfitsimage(&hdr1,imlist[ref],FALSE);
    printf("  Reference image = %s\n",imlist[ref]);
    fprintf(outfile,"%s  %f %f\n",imlist[ref],0.0,0.0);

    for (i=0;i<nim;i++) if (i != ref) {
      im2 = shortfitsimage(&hdr2,imlist[i],FALSE);
      sum[i] = (long *)malloc(sizeof(long)*(2*dx+1)*(2*dy+1));
      ii = 0;

      for (yy=-dy; yy<=dy; yy++) {
        for (xx=-dx; xx<=dx; xx++) {
	  s = 0;
	  x1 = x0[ref];  y1 = y0[ref];
	  x2 = x0[i]+xx; y2 = y0[i]+yy;

          for (boxy=0;boxy<boxdy;boxy++) {
	    i1 = hdr1.naxis1*(y1+boxy) + x1;
	    i2 = hdr2.naxis1*(y2+boxy) + x2;
            for (boxx=0;boxx<boxdx;boxx++) s += (long)(im1[i1++]*im2[i2++]);
	  }

	  sum[i][ii++] = s;
	}
      } 

      free(im2);
      findmax(sum[i],dx,dy,fitmethod,&maxx,&maxy); 
      fprintf(outfile,"%s  %f %f\n",imlist[i],
                                    maxx+(float)(x0[i]-x0[ref]),
				    maxy+(float)(y0[i]-y0[ref]));
      printf("  %s  %f %f\n",imlist[i],
                                    maxx+(float)(x0[i]-x0[ref]),
				    maxy+(float)(y0[i]-y0[ref])); 
    }

    fclose(outfile);
    free(im1);
    for (i=0;i<nim;i++) if (i != ref) free(sum[i]);

  } else
    puts("  ** Error opening output file.");
}

/* -------------------------------------------------------------------- */

void crosscorr( char *params)
{
  int boxdx=0,boxdy=0;
  static int dx = 0,dy = 0;
  int defdx=10, defdy=10;
  int ok,i,x,nim,ref,setbox=1;
  static char offsname[255] = "", corrname[255] = "", refname[255] = "";
  char tmps[255],s1[100];
  char *imlist[1000];
  int  x0[1000],y0[1000];
  FILE *offsfile;
  char *p;
  int  fitmethod = FITMAX;

  remeqspc(params); refname[0] = '\0';

  if (getpar("CROSS.FITMETHOD",tmps)) {
    if (strstr(tmps,"MAX") == tmps) fitmethod = FITMAX; else
    if (strstr(tmps,"POLY") == tmps) fitmethod = FITPOLY; else 
    if (strstr(tmps,"RPOLY") == tmps) fitmethod = FITRPOLY; else {
      printf("  Illegal parameter: CROSS.FITMETHOD = %s. Using MAX.\n",tmps);
      fitmethod = FITMAX;
    }
  }

  if (getpar("CROSS.BOXDX",tmps)) defdx = atoi(tmps);
  if (getpar("CROSS.BOXDY",tmps)) defdy = atoi(tmps);
  if (getpar("CROSS.REF",tmps)) strcpy(refname,tmps);

  if ((boxdx>0) && (boxdy>0)) setbox = 0;

  if (nargs(params) == 4) {
    argn(params,1,offsname);
    argn(params,2,tmps); dx = atoi(tmps);
    argn(params,3,tmps); dy = atoi(tmps);
    argn(params,4,corrname);
  } else {
    printf("  Input list   :  "); cscanf("%s",offsname);
    printf("  X range      :  "); cscanf("%i",&dx); 
    printf("  Y range      :  "); cscanf("%i",&dy);
    printf("  Output list  :  "); cscanf("%s",corrname);
  }

  offsfile = fopen(offsname,"r");
  if (offsfile != NULL) {
    nim = 0;
    p = fgets(tmps,255,offsfile);

    while (p != NULL) {
      argn(tmps,1,s1);
      imlist[nim] = (char *)malloc(strlen(s1)+1);
      strcpy(imlist[nim],s1);

      if (nargs(tmps) >= 3) {
        argn(tmps,nargs(tmps)-1,s1); x0[nim] = atoi(s1);
        argn(tmps,nargs(tmps),s1);   y0[nim] = atoi(s1);
	 
	if (setbox) {
	  if (nargs(tmps) >= 5) {
	    argn(tmps,2,s1); x = atoi(s1); if (x>boxdx) boxdx = x;
	    argn(tmps,3,s1); x = atoi(s1); if (x>boxdy) boxdy = x;
	  }
	}

        nim++;
        p = fgets(tmps,255,offsfile);
      } else {
        puts("  ** Error: Missing offset estimate(s).");
	p = NULL;
	for (i=0;i<nim;i++) free(imlist[i]);
	nim = 0;
      } 
    }

    fclose(offsfile);

    if (nim>1) {
      if (refname[0] == '\0') {
        strcpy(refname,imlist[0]);
        printf("  Reference image :  "); cscanf("%s",refname);
      }

      ok = 0;
      for (i=0;i<nim;i++) 
        if (strcmp(imlist[i],refname) == 0) { ok = 1; ref = i; }

      if (ok) {
        if ((boxdx==0) || (boxdy==0)) {
	  printf("  ** Warning: No box size specified. Using default values.");
	  boxdx = defdx; boxdy = defdy;
	}
        do_corr(imlist,x0,y0,nim,ref,boxdx,boxdy,dx,dy,corrname,fitmethod);
      } else 
        puts("  ** Error: Reference image does not match anything in list.");
    }

  } else
    puts("  ** Error reading offset list.");
}

/* ==================================================================== */
