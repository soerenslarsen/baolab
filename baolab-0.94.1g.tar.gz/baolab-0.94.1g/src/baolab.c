/* ====================================================================
 *
 *   Image analysis program, developed by Soeren Larsen (s.larsen@astro.ru.nl)
 *
 *   BAOLAB derives its name from Boserup Amateur Observatory, Denmark.
 *
 *   First version: Some time in 1994
 *
 *   Revisions:
 *      0.4.*  :  Improved line editing functions.
 *      0.5.*  :  FITS header editing functions + neg. zoom
 *      0.6.*  :  TIFF conversion + imrep + CTRL-C break from tasks,
 *                image rotation, help debugging,
 *      0.7.*  :  Aperture photometry functions.
 *      0.70.1 :  Fixed bug that caused imcombine routine to sometimes crash.
 *      0.71   :  Added '%' parameters in scripts + print command.
 *                Added " " syntax for arguments containing spaces.
 *                Added alias functions.
 *                Added ".blrc" execution at startup time.
 *      0.72   :  C++ compatibility.
 *      0.75   :  Added Pre-cross-correlation utility.
 *                Increased maximum number of images to be cross-correlated
 *                from 100 to 1000. 
 *      0.76   :  Added arrow-key history function (+ CTRL_P & CTRL_N for
 *                terminals without arrow keys).
 *                Added upward scrolling capability in help text. 
 *      0.77   :  Modified the parameter-passing mechanism so that all
 *                parameters in baolab.par can also be specified at the
 *                commandline.
 *                Added 'lpar' command.
 *      0.78   :  Added 'mksynth' utility.          (some time in 1995)
 *      0.80   :  More general approach to PSF generation  (22.01.1997)
 *                including user-defined PSFs. Various general bugfixes
 *                and improvements. Fixed inverted grayscale TIFF error.
 *                Fixed obscure bug in bscanf.
 *      0.81   :  Added 'mkcmppsf' utility.                (08.12.1997)
 *                CTRL-C break handler..
 *                Bugfixes...
 *      0.82   :  Added 'ishape' utility.                  (11.01.1998)
 *      0.83   :  Various bugfixes and improvements, 
 *                mostly to ishape                         (14.01.1999)
 *      0.84   :  Improved FFT routines                    (15.01.1999)
 *      0.90   :  Implementation of other than 16-bit
 *                integer FITS images.                     (23.03.2000)
 *      0.91   :  Support for 24-bit displays (experimental)
 *      0.92   :  Support for diffusion kernel in ishape   (23.05.2000)
 *                Added 'cosmic' task                      (30.05.2000)
 *                King and Moffat index fits in ishape     (28.11.2000)
 *                Added check for EOF in bscanf            (19.05.2001)
 *      0.93   :  Tasks to correct x- and y-distortion in 
 *                2-d multislit spectra                    (18.09.2001)
 *      0.93.2 :  Various bugfixes.                        ( Apr  2002)
 *      0.93.6 :  Added EFF profiles + updated doc         ( Dec  2003)
 *      0.93.7 :  More realistic modelling of low count
 *                levels in MKSYNTH (Poisson vs Gaussian)  ( Oct  2004)
 *      0.93.8 :  Fixed ISHAPE bugs that caused slow computation
 *                time for large PSFs even if fitrad is small (Apr 2005)
 *      0.93.8b:  Modified Gaussian random number generator   (Apr 2005)
 *      0.93.9 :  Error estimation in ISHAPE               (June 2005)
 *      0.93.9a:  Option to specify parameter file at command line (Dec 2005)
 *      0.93.9c:  Modified Ishape to avoid re-reading image for every
 *                new source when using coordinate list    (Oct 2006)
 *      0.93.10:  Faster FFT routine in CONVOLVE           (Sep 2007)
 *      0.93.10c: Various cleaning-up                      (Sep 2007)
 *      0.93.10d: Fixed bugs in MKSYNTH related to RANDOM=YES (Dec 2007)
 *      0.93.10e: Changed MKSYNTH to accept 2 positional arguments
 *                (starlist, image) instead of 3           (Feb 2008)
 *                Fixed Poisson-noise related errors in mksynth
 *      0.93.10f: One more round of X11-related fixes
 *      0.93.11 : KINGt/KINGx model options in mkcmppsf,
 *                Fixed KINGt-related bug in ishape        (Jun 2008)
 *      0.93.11a: Modified random number generation to work properly
 *                on machines where RAND_MAX is small
 *      0.93.11b: Better handling of PSFs<fitrad in ishape
 *                Fixed error causing offset of 1 pixel for objects
 *                near edge of image in mksynth            (Jun 2008)
 *      0.94    : Added KFIT2D task                        (Dec 2008)
 *      0.94a   : Added DEFAULT option for ISHAPE.RESIMAGE (Feb 2009)
 *      0.94.1  : Added EFFC models in ISHAPE              (Feb 2009)
 *      0.94.1a : Replaced ioctl() with tcgetattr() in baostr.c
 *                                                         (Nov 2010)
 *      0.94.1b : Improved memory allocation handling in kfit2d (Nov 2010)
 *      0.94.1c : Added output of background level in ishape (Jul 2011)
 *      0.94.1f : Fixed various string-related bugs that somehow did 
 *                not cause problems earlier               (Sep 2018)
 *      0.94.1g : Fixed bug that sometimes caused ishape to crash
 *                when estimating errors.                  (Sep 2019)
 *
 * ====================================================================
 */

/*  BAOLAB_MAIN is used in baolab.h */
#define BAOLAB_MAIN

#include "fitsutil.h"
#include <sys/wait.h>
#include <signal.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "baostr.h"
#include "baolab.h"
#include "wutil.h"
#include "convol.h"

#include ".extern_proc"  /* Automatically generated by make */
/* #include "arch.h" */

void pwd( void );
int interp(char *);
extern void freecol( long *);                                /* in baolab3.c */
extern int openimagewin(imstruct *, char *, int, int, int);  /* in baolab3.c */


/* ==================================================================== */

void pwd() {
  char tmps[255];

  getcwd(tmps,255);
  printf("  PWD is %s\n",tmps);
}

/* ==================================================================== */

void cd(char *params)
{
  char tmps[255];

  argn(params,1,tmps);

  if (chdir(tmps) == 0)
    pwd();
  else
    printf("  ** Error: Could not cd to '%s'\n",tmps);
}

/* ==================================================================== */

void expandname(char *name)
{
  char *ch;
  char tmps[100];
  int  i;

  ch = getenv("BLPATH");
  if (ch == NULL) tmps[0] = '\0'; else {
    strcpy(tmps,ch);
    for (i=0;tmps[i] != '\0';i++); 
    if (tmps[i-1] != '/') { tmps[i] = '/'; tmps[i+1] = '\0'; }
  }

  strcat(tmps,name);
  strcpy(name,tmps);
}

/* ==================================================================== */

void paramstr(        /* Gets the parameters part of a string */
  char *inp, char *outp
)
{
  int i=0,j=0;

  do i++; while ((inp[i] != ' ') && (inp[i] != '\0'));
  if (inp[i] != '\0') {
    i++;
    do outp[j++] = inp[i++]; while (inp[i] != '\0'); 
  }
  outp[j] = inp[i];
}

/* ==================================================================== */

int getimlst(     /* Returns the number of entires read. */
  char *params,
  char *imlist[]
)
{
  int  i,ii=0;
  char tmps[100],s1[100],s2[100];
  FILE *file;
  void *p;
  char *j;

  for (i=1;i<=nargs(params);i++) {
    argn(params,i,tmps);
    if (strchr(tmps,'@') == NULL) {
      imlist[ii] = (char *)malloc(strlen(tmps)+1);
      strcpy(imlist[ii++],tmps);
    } else {
      file = fopen(tmps+1,"r");

      if (file != NULL) {
	p = fgets(s1,100,file);

        while (p != NULL) {
	  argn(s1,1,s2);
	  imlist[ii] = (char *)malloc(strlen(s2)+1);
          if ((j = strchr(s2,'\n')) != NULL) *j = '\0';
	  strcpy(imlist[ii++],s2);
	  p = fgets(s1,100,file);
	} 
        fclose(file);
      } else
        printf("  ** Error: Could not open file [%s]\n",tmps+1);
    }
  }
  return ii;
}

/* ==================================================================== */

int getoffslist(
  char *filename,
  char *imlist[],
  float *x,
  float *y
)
{
  FILE *file;
  char *ch;
  char tmps[1000],s1[255];
  int  n = 0;

  if ((file = fopen(filename,"r")) != NULL) {
    while ((ch = fgets(tmps,1000,file)) != NULL) {
      argn(tmps,1,s1);
      imlist[n] = (char *)malloc(strlen(s1)+1);
      strcpy(imlist[n],s1);
      if ((x != NULL) && (y != NULL)) {
        argn(tmps,2,s1); x[n] = atof(s1);
	argn(tmps,3,s1); y[n] = atof(s1);
      }
      n++;
    }

    fclose(file);
    return n;
  } else
    return 0;
}

/* ==================================================================== */

int getpar(             /* Get value of parameter keywd from parameter file */
                        /* Returns 1 if successfull, 0 otherwise.           */
  char *keywd, char *value
)
{
  char filename[255],tmps[255],s1[100];
  char *ch;
  FILE *file;
  int  i,result=0;

  value[0] = '\0';

  if (CFGFILE[0] == '\0') {
    strcpy(filename,"baolab.par");     /* First search in baolab.par */
    expandname(filename);              
  } else
    strcpy(filename,CFGFILE);

  file = fopen(filename,"r");
  if (file != NULL) {
    do {
      ch = fgets(tmps,255,file);
    } while ((ch != NULL) && (strstr(tmps,keywd) != tmps));
    fclose(file);

    if (strstr(tmps,keywd) == tmps) {
      argn(tmps,2,s1);
      if ((s1[0] == ':') || (s1[0] == '=')) 
        argn(tmps,3,value);
      else
        strcpy(value,s1);
      sglspc(value);
      result = 1;
    }
  }

                      /* Now search for parameters specified at the */
		      /* command line. These will overwrite.        */

  for (i=0; i<PARAMS.nparams; i++) {
    if (strstr(PARAMS.name[i],keywd) == PARAMS.name[i]) {
      strcpy(value,PARAMS.value[i]);
      result = 1;
    }
  }

  return result;
}

/* ==================================================================== */

int execscr(char *params)
{
  FILE *file;
  char fname[255];
  char cmd[2048];
  char s1[2048];
  int result=2;

  if (nargs(params) >= 1) {
    argn(params,1,fname);
    file = fopen(fname,"r");

    if (file == NULL) {
      expandname(fname);
      file = fopen(fname,"r");
    }

    if (file != NULL) {
      while (fgets(cmd,2048,file) != NULL) { 
	sglspc(cmd);
	paramstr(params,s1);
	if (cmd[0] != '$') insargs(cmd,s1);

	if ((cmd[0] != '\0') && (cmd[0] != '#'))
	  if (interp(cmd) != 0) 
	    printf(" ** Warning: Unknown command : [%s]\n",cmd);
	result = 0;
      }
      fclose(file); 
    }
  }

  return result;
}

/* ==================================================================== */

void callsh(char *cmd1)
{
  char s1[10],s2[10];
  char *args[4], *envp[10];
  char cmd[2048];
  pid_t pid = 0;
  int  p1,p2;
  int  status;

  strcpy(cmd,cmd1);   /* Make a working copy of the command string */
                      /* so we dont destroy the original one.      */

  strcpy(s1,"/bin/csh"); args[0] = s1;
  strcpy(s2,"-c");  args[1] = s2; 
/*  strcpy(s1,"/bin/csh"); args[0] = s1;
  strcpy(s2,"-c");  args[1] = s2; */
  sglspc(cmd);
  args[2] = cmd;
  args[3] = NULL;
  envp[0] = NULL;

  p1  = getpid();
  pid = fork();
  p2  = getpid();

  if (p1 == p2) waitpid(pid,&status,0);

  if (p1 != p2) {
    execve("/bin/sh",args,envp);
    exit(0);
  }
}

/* ==================================================================== */

void xinfo ( char *params ) {

  if (DISPLAY == NULL) {
    puts("  No X display available.");
    return;
  }

  puts("  X information:");
  printf("  Display name = %s\n",getenv("DISPLAY"));
  printf("  Resolution = %i x %i pixels \n",
       DisplayWidth(DISPLAY,DefaultScreen(DISPLAY)),
       DisplayHeight(DISPLAY,DefaultScreen(DISPLAY)) );
  printf("  Display depth = %i planes\n",
       DisplayPlanes(DISPLAY,DefaultScreen(DISPLAY)) );
}

/* ==================================================================== */

void iminfo (char *params) {

  if (IMAGE == NULL) {
    puts(" ** No active image window.");
    return;
  }

  printf("  Image name  : %s\n",IMAGE->fname);
  printf("  Zoom        = %i\n",IMAGE->zoom);
  printf("  TFF         : %s\n",IMAGE->tffname);
  printf("  Locut,Hicut = %0.1f, %0.1f\n",IMAGE->locut,IMAGE->hicut);
}

/* ==================================================================== */

int openwin() {
  int nr = 0;
  int result = 2;
  char s1[100],s2[10];

  while (WEXIST[nr] == 1 && nr<MAXWIN) nr++;
  if (nr<MAXWIN) {
    strcpy(s1,"BAOLab Plot ");
    itoa(nr,s2);
    strcat(s1,s2);

    if ( wopen(s1, &(WIN[nr]), &(GC1[nr]),&(GC2[nr])) ) {
      WEXIST[nr] = 1;
      PLOTWIN = nr;
      result = 0;
    }
  }
  return result;
}

/* ==================================================================== */

void closewin(char *params)
{
  int wnr,i;
  char tmps[80];

  if (nargs(params) == 1) wnr = atoi(params); else {
    printf("  Close window no. :  "); bgets(tmps); wnr = atoi(tmps);
  }

  if (WEXIST[wnr] == 1) {
    wclose(WIN[wnr],GC1[wnr],GC2[wnr]);
    WEXIST[wnr] = 0;

    if (wnr == PLOTWIN) {
      PLOTWIN = -1;
      i = 0;
      while (i<MAXWIN && WEXIST[i] == 0) i++;

      if (i<MAXWIN) {
	PLOTWIN = i;
	printf("  Closed window #%i. Now using #%i for output\n",wnr,PLOTWIN);
      } else
	printf("  Closed window #%i. No output windows\n",wnr); 
    }
  } else
    puts(WIN_DONT_EXIST);
}

/* ==================================================================== */

void mkemptywin(char *params)
{
  imstruct *tmpwin;
  char tmps[20],title[50];
  int  found,i,nr;

  if (params[0] != '\0') printf("  Option [%s] ignored.\n",params);
  if (DISPLAY == NULL) {
    puts("  ** No graphics output possible.");
    return;
  }

  nr = 0;
  if (IMAGE != NULL) {
    do {                    /* Find the lowest number that is not used */
      found = FALSE;
      tmpwin = IMAGE; 
      while (tmpwin->prev != NULL) tmpwin = tmpwin->prev;
      while (tmpwin != NULL) {
        if (tmpwin->nr == nr) found = TRUE;
	tmpwin = tmpwin->next;
      }
      if (found) nr++;
    } while (found);
  }

  tmpwin = (imstruct *)malloc(sizeof(imstruct));
  for (i=0; i<4096; i++) tmpwin->tff[i] = i/16;             /* Make TFF */
  strcpy(tmpwin->tffname,"lin");
  strcpy(tmpwin->fname,"");
  tmpwin->zoom = 1;
  tmpwin->nr = nr;
  tmpwin->next = NULL;

  strcpy(title,"BAOImage ");
  itoa(tmpwin->nr,tmps);
  strcat(title,tmps);

  if (openimagewin(tmpwin,title,200,200,1)) {
    if (IMAGE==NULL) {
      tmpwin->prev = NULL;
      tmpwin->mapped = TRUE;
    } else {
      while (IMAGE->next != NULL) IMAGE = IMAGE->next;
      tmpwin->prev = IMAGE;
      tmpwin->mapped = TRUE;
      IMAGE->next = tmpwin;
    }
    IMAGE = tmpwin;
  } else {
    puts(CANT_OPEN_WIN);
    free(tmpwin);
  }
}

/* ==================================================================== */

void imset(char *params)
{
  int nr;
  char tmps[20];
  imstruct *tmpwin;

  if (IMAGE != NULL) {
    if (nargs(params) > 0) {
      argn(params,1,tmps);
      nr = atoi(tmps);
    } else {
      printf("  Select image window no. "); bgets(tmps);
      nr = atoi(tmps);
    }

    tmpwin = IMAGE;
    while (tmpwin->prev != NULL) tmpwin = tmpwin->prev;
    while (tmpwin->next != NULL && tmpwin->nr != nr) tmpwin = tmpwin->next;

    if (tmpwin->nr == nr) {
      IMAGE = tmpwin;
      printf("  ** Using image window #%i for output.\n",IMAGE->nr);
    } else 
      printf(WIN_DONT_EXIST);
  } else
    puts(NO_IMAGE_WINS);
}

/* ==================================================================== */

void setwin(char *params) 
{
  int wnr;
  char tmps[80];

  if (nargs(params) == 1) wnr = atoi(params); else {
    printf("  Select window:  "); bgets(tmps); wnr = atoi(tmps);
  }

  if (WEXIST[wnr] == 1) {
    PLOTWIN = wnr;
    printf("  Selected window #%i for output.\n",PLOTWIN);
  } else
    puts(WIN_DONT_EXIST);
}

/* ==================================================================== */

void alias(char *params)
{
  static char meaning[255] = "", _alias[255] = "";
  int  i;

  if (nargs(params) == 2) {
    argn(params,1,_alias);
    argn(params,2,meaning);
  } else {
    printf("  Alias  :  "); cscanf("%s",_alias);
    printf("  Meaning:  "); cscanf("%s",meaning);
  }

  i = 0;
  while (aliases[i].active && (i<255)) i++;
  if (i < 255) {
    aliases[i].meaning = (char *)malloc(strlen(meaning)+1);
    aliases[i].alias = (char *)malloc(strlen(_alias)+1);
    strcpy(aliases[i].meaning,meaning);
    strcpy(aliases[i].alias,_alias);
    aliases[i].active = TRUE;
  } else
    puts("** Error: Too many aliases");
}

/* ==================================================================== */

void unalias(char *params)
{
  int i,found = FALSE;
  static char alias[255] = "";

  if (nargs(params) == 1) 
    argn(params,1,alias);
  else {
    printf("  Unalias:  "); cscanf("%s",alias); 
  }

  for (i=0; i<255; i++)
    if (aliases[i].active) 
      if (strcmp(alias,aliases[i].alias) == 0) {
        free(aliases[i].alias);
	free(aliases[i].meaning);
	aliases[i].active = FALSE;
	found = TRUE;
      }

  if (found)
    printf("  %s unaliased.\n",alias);
  else
    printf("  ** Error: %s - no such alias\n",alias);
}

/* ==================================================================== */

void listaliases(char *params)
{
  int i;

  puts("Aliases:");
  for (i=0; i<255; i++) 
    if (aliases[i].active) {
      printf("  %s : %s\n",aliases[i].alias,aliases[i].meaning);
    }
}

/* ==================================================================== */

void global(
  char *params
) {
  char tmps[255];

  if (nargs(params) == 0) puts("  Updated global parameters.");

  F_DATATYPE = D_DEFAULT;

  if (getpar("GLOBAL.SAVETYPE",tmps)) {
    if (strstr(tmps,"FLOAT") == tmps) F_DATATYPE = D_FLOAT;
    if (strstr(tmps,"SHORT") == tmps) F_DATATYPE = D_SHORT;
    if (strstr(tmps,"LONG") == tmps) F_DATATYPE = D_LONGINT;
  }

  if (getpar("GLOBAL.EXTVAL",tmps)) F_EXTVAL = atof(tmps);
}

/* ==================================================================== */

void initvar() {
  int i;
  char *name;

  for (i=0;i<128;i++) {
    PAL[i][0] = 
    PAL[i][1] = 
    PAL[i][2] = 512*i;
  }

  IMAGE = NULL;

  name = NULL;
  DISPLAY = XOpenDisplay(name); 
  if (DISPLAY == NULL) {
    if (name == NULL)
      printf("  ** Warning: Could not open connection to display \n");
    else
      printf("  ** Warning: Could not open connection to display %s\n",name);
    puts("              No graphics output possible.");
  }

  for (i=0; i<255; i++) aliases[i].active = FALSE;

  PARAMS.nparams = 0;
  global("silent");
}

/* ==================================================================== */

void handler() {
  char tmps[10];
  printf(" !! Do you really want to quit BAOLAB (y/n)? ");
  strcpy(tmps,"n");
  bscanf("%s",tmps);
  if (tmps[0] == 'y' || tmps[0] == 'Y') {
    puts("  Very well, good-bye then.");
    exit(0);
  }
  puts(" Continuing..");
}

void initintr() {

  struct sigaction action,old_action;
  action.sa_handler = &handler;
/*  action.sa_mask = SIGINT; */
  action.sa_flags = 0; 
  
  sigaction(SIGINT,&action,&old_action);
}

/* ==================================================================== */

void listpars(char *params) {

  char body[255],tmps[255],s1[255],s2[255];
  int i,j,found = FALSE;

  argn(params,1,body);

  for (i=0; (strstr(FNAMES[i],"NO_MORE") == NULL); i++) {
    argn(FNAMES[i],1,tmps);
    if (strstr(body,tmps) == body) {
      upcstr(tmps);
      found = TRUE;
      for (j=2; j<=nargs(FNAMES[i]); j++) {
        argn(FNAMES[i],j,s1);
	printf("  %s.%s : ",tmps,s1);

	strcpy(s2,tmps); strcat(s2,"."); strcat(s2,s1);
	if (getpar(s2,s1))
	  puts(s1);
	else
	  puts("<INDEF>");
      }
    }
  }

  if (!found) {
    puts("  ** Error: No such command.");
  }
}

/* ==================================================================== */

void test(char *params) {
  char tmps[100];
  float test[1000], *test1;
  float f;
  int   i,x, y, dimx, dimy, dim;

/*  getpar("TEST.PARAM",tmps);
  puts(tmps);
  puts(params);
  printf("%i\n",nargs(params)); */

  dimx = 6; dimy=4; f = 0.0;
  for (y=0; y<dimy; y++)
    for (x=0; x<dimx; x++) { test[x+dimx*y] = f; f += 1.0; }

  for (y=0,i=0; y<dimy; y++) {
    for (x=0; x<dimx; x++) printf("%3.0f ",test[i++]);
    puts("");
  }

  dim = 10;
  test1 = mkp2arr(dimx, dimy, test, &dim);
  for (y=0,i=0; y<dim; y++) {
    for (x=0; x<dim; x++) printf("%3.0f ",test1[i++]);
    puts("");
  }

  for (i=0; i<dimx*dimy; i++) test[i] = 0;
  getp2arr(dim, test1, dimx, dimy, test);
  for (y=0,i=0; y<dimy; y++) {
    for (x=0; x<dimx; x++) printf("%3.0f ",test[i++]);
    puts("");
  }
  
  puts("Waiting..");
  free(test1);
/*  gets(tmps);  */
}

/* ==================================================================== */

static void get_optional_params(
  char *body, 
  char *pstr
)
{
  char tmps[2048],s2[2048],s1[2048],body1[2048]; 
  int i,j,i1,i2;
  int quote = FALSE;

  strcpy(body1,body);
  upcstr(body1);

  strcpy(tmps,pstr);           
  remeqspc(tmps);
  PARAMS.nparams = 0;

  for (i=0; i<strlen(tmps); i++) {
    if (tmps[i] == '"') quote = !quote;
    if (quote) 
      if (tmps[i] == ' ') tmps[i] = 1;
  }

  for (i=0,j=0; i<nargs(tmps); i++) {
    argn(tmps,i+1,s2);

    if ((strchr(s2,'=') != NULL) && (strstr(s2,":=") == NULL)) {
      for (i2=0; s2[i2] != '='; i2++) s1[i2] = s2[i2];
      s1[i2] = '\0';
      if (strchr(s1,'.') == NULL) {
        PARAMS.name[j] = (char *)malloc(i2+2+strlen(body1));
	strcpy(PARAMS.name[j],body1);
	strcat(PARAMS.name[j],".");
	strcat(PARAMS.name[j],upcstr(s1));
      } else {
        PARAMS.name[j] = (char *)malloc(i2+1);
        strcpy(PARAMS.name[j],upcstr(s1));
      }

      i2++;
      for (i1=0; s2[i2] != '\0'; i2++) {
	if (s2[i2] != '"') {
	  s1[i1] = s2[i2];
	  if (s1[i1] == 1) s1[i1] = ' ';
	  i1++;
	}
      }
      s1[i1] = '\0';
      PARAMS.value[j] = (char *)malloc(i1+1);
      strcpy(PARAMS.value[j],s1);

      PARAMS.nparams++;
      j++;
    }
  }
}

/* -------------------------------------------------------------------- */

static void rm_optional_params(char *pstr) {

  char tmps[2048];
  int  i,firsteq=0,lastch;
  int  inside = FALSE;

  i = strlen(pstr);

  while (i>0) {        /* Find first occurrence of "=" which is not ":=" */
                       /* Also, occurrences inside quotes are ignored.   */
    i--;
    if (!inside)
      if ((pstr[i] == '=') && (pstr[i-1] != ':')) firsteq = i;
    if (pstr[i] == '"') inside = (!inside);
  }

  if (firsteq>0) {
    i = firsteq-1;       /* Find last character of ordinary parameters */
    while ((pstr[i] == ' ') && (i>0)) i--;
    while ((pstr[i] != ' ') && (i>0)) i--;
    lastch = i;

    strncpy(tmps,pstr,lastch); tmps[lastch] = '\0';
    strcpy(pstr,tmps);
  }
}

/* -------------------------------------------------------------------- */

int interp(char *cmd)
{
  int  result = 1;
  int  i;
  char pstr[2048];
  char tmps[2048],body[2048];

  argn(cmd,1,body);
  paramstr(cmd,pstr);

  for (i=0; i<255; i++)
    if (aliases[i].active) 
      if (strcmp(body,aliases[i].alias) == 0) {
        strcpy(cmd,aliases[i].meaning);
	strcat(cmd," ");
	strcat(cmd,pstr);
	argn(cmd,1,body);
	paramstr(cmd,pstr);
      }

  /* Search for command-line modifications to hidden parameters */
  /* and place them in PARAMS structure.                        */

  for (i=0; (strstr(FNAMES[i],"NO_MORE") == NULL); i++) {
    argn(FNAMES[i],1,tmps);
    if (strstr(body,tmps) == body) strcpy(body,tmps);
  }

  get_optional_params(body,pstr);
  rm_optional_params(pstr);

  /* First, here are some special tasks that don't fit into the */
  /* general scheme.                                            */

  if (strstr(body,"?") == body) { result=0; showhlp(pstr); }
  if (strstr(body,"quit") == body) result = 3;
  if (strstr(body,"ciao") == body) result = 3;
  if (strstr(body,"HALT") == body) { exit(0); }  /* Quit immediately */
  if (strstr(body,"exit") == body) result = 3;
  if (strstr(body,"bye") == body) result = 3;
  if (strstr(body,"exec") == body) { result= (execscr(pstr)==0) ? 0 : 2; }
  if (strstr(body,"wopen") == body) { result = openwin(); }
  if (strstr(body,"pwd") == body) { result = 0; pwd(); }
/*  if (strstr(body,"ls") == body) { result = 0; callsh(cmd); } */
/*  if (strstr(body,"$") == body) { callsh(cmd+1); result=0; } */
  if (strstr(body,"ls") == body) { result = 0; system(cmd); } 
  if (strstr(body,"$") == body) { system(cmd+1); result=0; } 
  if (strstr(body,"print") == body) { result=0; puts(pstr); }

#include ".extern_call"  /* Generated from the file BLFUNCS at make-time */

  for (i=0; i<PARAMS.nparams; i++) {
    free(PARAMS.name[i]);
    free(PARAMS.value[i]);
  }
  PARAMS.nparams = 0;

  return result;
}

/* ==================================================================== */

int main( int argc, char *argv[] ) {

   char tmps[2048],cmd[2048];
   char lastcmd[25][2048];
   int  ch, i,maxcmd=0,actcmd=0;
   int  EXIT = FALSE;

   for (i=0; i<argc; i++) {
     if (!strncmp(argv[i],"cfg=",4)) {
       strcpy(CFGFILE,argv[i]+4);
       printf("** Using non-default parameter file: %s\n",CFGFILE);
     }
   }

   for (i=0;i<MAXWIN;i++) WEXIST[i] = 0;
   initvar();
   initintr();

   puts("");
   printf("                     Welcome to BAOlab for %s ver. %s\n",ARCH,VERSION);
   puts("");
   puts("         - An image reduction and analysis utility for FITS-images.");
   puts("                         Developed by Soeren S. Larsen.            ");
   puts("               Type 'help' or 'help -s' for a list of commands or  ");
   puts("                  'help <command>' for help on single topics.      ");
   puts("");

   execscr(".blrc");
   cmd[0] = '\0';

   do {
     actcmd = maxcmd+1;

     do {
       if (PLOTWIN >= 0) printf("[%i]",PLOTWIN); else printf("[ ]");
       if (IMAGE != NULL) printf("[%i]",IMAGE->nr); else printf("[ ]");
       printf(">> ");
       ch = bscanf("%s %x 14 16 328 336 ",cmd);

       switch (ch) {
         case ARROW_UP :
	 case CTRL_P   :
           if (actcmd>1) strcpy(cmd,lastcmd[--actcmd]);
           bputch(CTRL_M);
           clreol();
	   break;

	 case ARROW_DOWN :
	 case CTRL_N     :
           if (actcmd<=maxcmd) 
	     strcpy(cmd,lastcmd[++actcmd]); 
	   else 
	     cmd[0] = '\0';
           bputch(CTRL_M);
           clreol();
       }
     } while ((ch != 10) && (ch != CTRL_C) && (ch != CTRL_D));

     if (ch == CTRL_D) {             /* End-of-file - does not work for */
                                     /* keyboard input !!               */
       EXIT = TRUE;
     } else if (ch == CTRL_C) {             /* CONTROL-C Pressed */
       puts(" ** Interrupted.");
       cmd[0] = '\0';
     } else {                        /* Analyze the text entered */
       sglspc(cmd);

       if (strstr(cmd,"history") == cmd) {     /* Special case: "history" */
	 for (i=1;i<=maxcmd;i++) printf("  %i: %s\n",i,lastcmd[i]);
	 printf("Enter number: "); bgets(cmd);
	 i = atoi(cmd);
	 
	 if ((i<1) || (i>maxcmd))
	   cmd[0] = '\0';
	 else {
	   strcpy(cmd,lastcmd[i]);
	 }
       } else                                 /* Special case: "!" mechanism */

       if (strchr(cmd,'#') == cmd) {          /* # - Do nothing */
	   cmd[0] = '\0';
       } else
       
       if (strchr(cmd,'!') == cmd) {          /* !-History mechanism */
	 i = maxcmd;
	 if (strstr(cmd,"!!") == NULL)
	   while ((strstr(lastcmd[i],cmd+1) != lastcmd[i]) && (i >= 0)) i--;

	 if (i >= 0) {
	   strcpy(cmd,lastcmd[i]); 
	 } else {
	   cmd[0] = '\0';
	   puts("  ** No match");
	 }
       } else
       
       if (cmd[0] != '\0') {                  /* Finally: plain command */
	 if (maxcmd > 22) 
	   for (i=0;i<23;i++) strcpy(lastcmd[i],lastcmd[i+1]);
	 else
	   maxcmd++;
	 strcpy(lastcmd[maxcmd],cmd);

	 switch (interp(cmd)) {
	   case 0 : break;
	   case 1 : puts("**Error: Unknown command."); break;
	   case 2 : puts("**Error executing command."); break;
	   case 3 : EXIT = TRUE;
	   default: puts("");
	 }

	 cmd[0] = '\0';

       }
     }
   } while (!EXIT);

   for (i=0; i<255; i++)
     if (aliases[i].active) {
       free(aliases[i].alias);
       free(aliases[i].meaning);
     }

   for (i=0; i<MAXWIN; i++) if (WEXIST[i]) wclose(WIN[i],GC1[i],GC2[i]);
   if (COLRES) freecol(PIXELS);

   while (IMAGE != NULL) {
     itoa(IMAGE->nr,tmps);
     imclose(tmps);
   }
}
