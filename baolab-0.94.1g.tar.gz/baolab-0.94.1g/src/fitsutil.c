/* ====================================================================== */
/*                                                                        */
/*          Subroutines for handling FITS-files.                          */
/*                                                                        */
/* ====================================================================== */

#define FITS_UTIL_MAIN
#define TRUE 1
#define FALSE 0

#include <stdio.h>
#include "fitsutil.h"
#include <math.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
/*
#if defined(OS_Darwin)
  #include <sys/types.h>
  #include <sys/malloc.h>
#else
  #include <malloc.h>
#endif
*/
#include <stdlib.h>
#include "baostr.h"
#include "byteorder.h"

int F_DATATYPE = D_DEFAULT;
float F_EXTVAL   = 0;
float F_OFFSET   = 0;      /* Should be 0 except for debugging purposes */

/* ====================================================================== */

short swap(short x) 
{
/* #if defined(ARCHITECTURE_Linux) || defined(ARCHITECTURE_OSF1) */
  short xlo,xhi;

  if (byteorder() == BO_LITTLE_ENDIAN) {
    xlo = x & 0X00FF;
    xhi = x & 0XFF00;

    x = ((xlo << 8) & 0XFF00) | ((xhi >> 8) & 0X00FF); 
  }
/* #endif  */
  return x;
}

float fswap(float x) 
{
/* #if defined(ARCHITECTURE_Linux) || defined(ARCHITECTURE_OSF1) */
  int   *xx;
  int   x1,x2,x3,x4;

  if (byteorder() == BO_LITTLE_ENDIAN) {

    xx = &x;
    x1 = (*xx) & 0X000000FF;
    x2 = (*xx) & 0X0000FF00;
    x3 = (*xx) & 0X00FF0000;
    x4 = (*xx) & 0XFF000000;

    (*xx) = ((x1 << 24) & 0XFF000000) | 
	    ((x2 << 8)  & 0X00FF0000) |
	    ((x3 >> 8)  & 0X0000FF00) |
	    ((x4 >> 24) & 0X000000FF);  
  }
/* #endif */
  return x;
}


int iswap(int x) 
{
/* #if defined(ARCHITECTURE_Linux) || defined(ARCHITECTURE_OSF1) */
  int   *xx;
  int   x1,x2,x3,x4;

  if (byteorder() == BO_LITTLE_ENDIAN) {

    xx = &x;
    x1 = (*xx) & 0X000000FF;
    x2 = (*xx) & 0X0000FF00;
    x3 = (*xx) & 0X00FF0000;
    x4 = (*xx) & 0XFF000000;

    (*xx) = ((x1 << 24) & 0XFF000000) | 
	    ((x2 << 8)  & 0X00FF0000) |
	    ((x3 >> 8)  & 0X0000FF00) |
	    ((x4 >> 24) & 0X000000FF); 
  }
/* #endif */
  return x;
}

/* ====================================================================== */

void wrendcard(int handle) /* Write the END-card */
{
  char card[80];
  int  i;

  for (i=0;i<80;i++) card[i] = ' ';
  card[0] = 'E'; card[1] = 'N';  card[2] = 'D';
    
  write(handle,card,80);
}

/* ====================================================================== */

void wrempcard(int handle)  /* Write an empty card */
{
  char card[80];
  int i;

  for (i=0;i<80;i++) card[i] = ' ';
  write(handle,card,80);
}

/* ====================================================================== */

void wrtxtcard(
/* Write an ASCII-string card */
  char *txt,
  char *value,
  int  handle
)
{
  int i;
  char card[80];

  for (i=0; i<80; i++) card[i] = ' ';
  for (i=0; (txt[i] != '\0') && (i<8); i++) card[i] = txt[i];
  card[8] = '=';
  card[10] = '\'';

  for (i=11; (value[i-11] != '\0') && (i < 29); i++) card[i] = value[i-11];
  for (;i<19;i++); card[i] = '\'';

  write(handle,card,80);
}

/* ====================================================================== */

void wrcard(
/* Used by wrfltcard, wrintcard, wrboolcard  */
  char *txt,
  char *value,
  int   handle
)
{
  int i,l;
  char card[80];

  for (i=0; i<80; i++) card[i] = ' ';
  for (i=0; (txt[i] != '\0') && (i<8); i++) card[i] = txt[i];
  card[8] = '=';

  for (l=0; value[l] != '\0'; l++);
  for (i=30-l; i<30; i++) card[i] = value[i-30+l];

  write(handle,card,80);
}

/* ====================================================================== */

void wrfltcard(
/* Write a REAL-value card */
  char *txt,
  float value,
  int   handle
) 
{
  char str[30];
  
  ftoa(value,str);
  wrcard(txt,str,handle);
}

/* ====================================================================== */

void wrboolcard(
/* Write a BOOLEAN (T/F) card */
  char *txt,
  int   value,
  int   handle
) 
{
  switch (value) {
    case 1 : wrcard(txt,"T",handle); break;
    default: wrcard(txt,"F",handle);
  } 
}

/* ====================================================================== */

void wrintcard(char *txt,int value,int handle)  /* Write an INTEGER card */
{
  char str[30];

  itoa(value,str);
  wrcard(txt,str,handle);
}

/* ====================================================================== */

int mknewfile(hstruct *header, char *filename)   
/* Write a primitive FITS-header */
{
  int     n,i,handle;
  cardstruct *tmpcard;
  float   bscale, bzero;

  if (header->bitpix < 0) {
    bscale = 1.0;
    bzero = 0.0;
  } else {
    bscale = header->bscale;
    bzero = header->bzero;
  }

/*  i = umask(0); */
  handle = creat(filename,0666);
  if (handle > 0) {
    wrboolcard("SIMPLE",1,handle);
    wrintcard("BITPIX",(*header).bitpix,handle);
    wrintcard("NAXIS",2,handle);   
    wrintcard("NAXIS1",(*header).naxis1,handle);
    wrintcard("NAXIS2",(*header).naxis2,handle);
    wrfltcard("BSCALE",bscale,handle);
    wrfltcard("BZERO",bzero,handle);

    n = 7;

    if (header->card != NULL) {
      tmpcard = header->card;
      while (tmpcard->prev != NULL) tmpcard = tmpcard->prev;
      while (tmpcard != NULL) {
        if (memcmp(tmpcard->image,"SIMPLE ",7) &&
	    memcmp(tmpcard->image,"NAXIS ",6)  &&
	    memcmp(tmpcard->image,"NAXIS1 ",7) &&
	    memcmp(tmpcard->image,"NAXIS2 ",7) &&
	    memcmp(tmpcard->image,"BSCALE ",7) &&
	    memcmp(tmpcard->image,"BZERO ",6)  &&
	    memcmp(tmpcard->image,"BITPIX ",7) &&
	    memcmp(tmpcard->image,"END ",4)  ) {
          write(handle,tmpcard->image,80);
	  n++;
	}
        tmpcard = tmpcard->next;
      }
    }

    wrendcard(handle);
    n++;

    for (i=n; (i % 36) != 0; i++) wrempcard(handle);
  }
  return handle;
}

/* ====================================================================== */

void freehdr(hstruct *header)
{
  cardstruct *tmpcard;

  while (header->card != NULL) {
    tmpcard = header->card;
    header->card = header->card->next;
    free(tmpcard);
  }
}

/* ====================================================================== */

int getheader(   /* Get data from FITS-header */
  hstruct *header,
  char	  *filename,
  int     detailed
)
{
  int i,handle;
  char card[80];
  char keywd[10],datastr[30];
  char actualname[255];
  int  laest,end;
  cardstruct *tmpcard;

  for (i=0;(filename[i] != '\0') && (filename[i] != '[');i++)
    actualname[i] = filename[i];
  actualname[i] = '\0';

  handle = open(actualname,O_RDONLY); 
  end = 0;
  header->card = NULL;

  if (handle>0) {
    header->bscale = 1.0;
    header->bzero  = 0.0;
    header->ncards = 0;
    header->bitpix = 0;
    header->naxis1 = 0;
    header->naxis2 = 0;

    if (detailed) {
      header->card = (cardstruct *)malloc(sizeof(cardstruct)); 
      header->card->prev = NULL;
      header->card->next = NULL;
      tmpcard = NULL;
    }

    do {
      laest = read(handle,card,80); 

      if (detailed) {
	memcpy(header->card->image,card,80); 
	tmpcard = (cardstruct *)malloc(sizeof(cardstruct));
	tmpcard->prev = header->card;
	header->card->next = tmpcard;
	tmpcard->next = NULL;
	header->card = tmpcard;
      }

      for(i=0; (i<8) && (card[i] != ' '); i++) keywd[i] = card[i];
      keywd[i] = '\0';
      for(i=10;i<30;i++) datastr[i-10] = card[i];
      datastr[i-10] = '\0';
      header->ncards++;

      if (!strcmp(keywd,"END")) end = TRUE;
      if (!strcmp(keywd,"NAXIS")) header->naxis = atoi(datastr);
      if (!strcmp(keywd,"NAXIS1")) header->naxis1 = atoi(datastr);
      if (!strcmp(keywd,"NAXIS2")) header->naxis2 = atoi(datastr);
      if (!strcmp(keywd,"BITPIX")) header->bitpix = atoi(datastr);
      if (!strcmp(keywd,"BSCALE")) header->bscale = atof(datastr);
      if (!strcmp(keywd,"BZERO"))  header->bzero  = atof(datastr);
      
    } while ((!end) && (laest > 0));

    if (header->naxis == 1) header->naxis2 = 1;

    header->nused = header->ncards;

    if ((*header).ncards % 36 > 0) 
       (*header).ncards += 36-((*header).ncards % 36);
    if (laest==0) handle = -1;  

    if (detailed) if (tmpcard != NULL) {
      header->card = tmpcard->prev;
      header->card->next = NULL;
      free(tmpcard);

      while (header->card->prev != NULL)
        header->card = header->card->prev;
    }
    close(handle);
  }

  if (header->naxis1 > 0 &&
      header->naxis2 > 0) 
      /* && header->bitpix > 0) */
    return(handle);
  else
    return -1;
}

/* ====================================================================== */

void addcard(
  hstruct *header,
  char    *txt,
  void    *value,
  int     vtype
)
{
  char card[80];
  char tmps[80];
  int  i,l;
  int   *tmpint = (int *)value; 
  float *tmpflt = (float *)value;
  char  *tmptxt = (char *)value;
  cardstruct *tmpcard, *newcard;

  for (i=0; i<80; i++) card[i] = ' ';
  for (i=0; (txt[i] != '\0') && (i<8); i++) card[i] = txt[i];
  if (vtype != H_COMM) card[8] = '=';

  switch (vtype) {
    case H_INT   :  itoa(*tmpint,tmps);
    case H_FLOAT :  if (vtype == H_FLOAT) ftoa(*tmpflt,tmps);
    case H_BOOL  :  if (vtype == H_BOOL) {
		      if (*tmpint) strcpy(tmps,"T"); else strcpy(tmps,"F");
                    }

                    for (l=0; tmps[l] != '\0'; l++);
                    for (i=30-l; i<30; i++) card[i] = tmps[i-30+l];
                    break;

    case H_ASCII :  card[10] = '\'';
                    for (i=11; (tmptxt[i-11] != '\0') && (i < 29); i++) 
                      card[i] = tmptxt[i-11];
                    for (;i<19;i++); 
		    card[i] = '\'';
		    break;

    case H_COMM  :  for (i=9; (tmptxt[i-9] != '\0') && (i < 79); i++)
                      card[i] = tmptxt[i-9];
		    break;
  }

  newcard = NULL;

  if (vtype != H_COMM) {  /* Check if this card already exists */
    tmpcard = header->card;
    while (tmpcard != NULL) {
      if (strncmp(tmpcard->image, card, 8) == 0) newcard = tmpcard;
      tmpcard = tmpcard->next;
    }
  }

  if (newcard == NULL) {
    tmpcard = header->card;
    newcard = (cardstruct *)malloc(sizeof(cardstruct));

    if (header->card != NULL) {
      while (tmpcard->next != NULL) tmpcard = tmpcard->next;
    }

    newcard->prev = tmpcard;
    newcard->next = NULL;
    header->ncards++;

    if (header->card == NULL)
      header->card = newcard;
    else
      tmpcard->next = newcard;
  }

  memcpy(newcard->image,card,80);
}

/* ====================================================================== */

float *getimdata(  /* Get image data from FITS-file */
  hstruct *header,
  char    *filename
)
{
  float   *fbuffer;
  short   *sbuffer;
  int     *ibuffer;
  float   *outbuff;
  int      i,laest,buffsize,handle;
  int      pixsz;

  handle = open(filename,O_RDONLY); 
  lseek(handle,F_OFFSET + 80*(*header).ncards,SEEK_SET);
  pixsz = abs(header->bitpix/8);
/*  printf("  Pixel size = %i\n",header->bitpix); */

  buffsize = (*header).naxis1 * (*header).naxis2 * pixsz;
  outbuff = NULL;

  switch (header->bitpix) {
    case  16: sbuffer = (short *)malloc(buffsize);
              laest = read(handle,sbuffer,buffsize);
              if (laest==buffsize) {
                outbuff = (float *)malloc(header->naxis1 * header->naxis2 *
	                                  sizeof(float));
                for (i=0;i<buffsize/pixsz;i++) 
		  outbuff[i] = (float)swap(sbuffer[i]); 
              }
	      free(sbuffer);
	      break;

    case  32: ibuffer = (int *)malloc(buffsize);
              laest = read(handle,ibuffer,buffsize);
              if (laest==buffsize) {
                outbuff = (float *)malloc(header->naxis1 * header->naxis2 *
	                                  sizeof(float));
                for (i=0;i<buffsize/pixsz;i++) 
		  outbuff[i] = (float)iswap(ibuffer[i]); 
              }
	      free(ibuffer);
	      break;

    case -32: fbuffer = (float *)malloc(buffsize);
              laest = read(handle,fbuffer,buffsize);
              if (laest==buffsize) {
                outbuff = (float *)malloc(header->naxis1 * header->naxis2 *
	                                  sizeof(float));
                for (i=0;i<buffsize/pixsz;i++) outbuff[i] = fswap(fbuffer[i]); 
              }
	      free(fbuffer);
              break;
  }

  close(handle);
  return outbuff;
}

/* ====================================================================== */

int next_num(
  char *s,
  int  *i
)
{
  int n = 0,j;
  char tmps[10];
  int sgn=1;

  while (((s[*i] < '0') || (s[*i] > '9')) && 
         (s[*i] != '\0') &&
	 (s[*i] != '-')     ) (*i)++;

  if (s[*i] != '\0') {
    j = 0;
    if (s[*i] == '-') { sgn = -1; (*i)++; }
    while ((s[*i] >= '0') && (s[*i] <= '9')) tmps[j++] = s[(*i)++];
    tmps[j] = '\0';
    n = sgn*atoi(tmps);
  } else
    *i = -1;

  return n;
}

/* ====================================================================== */

int getcorners(

/* Returns 1 (TRUE) if a corner specification is found in the filename */
/* and 0 (FALSE) if not.                                               */

  char *name,
  int  *x1, int *y1, int *x2, int *y2
)
{
  int i=0;
  int result = 0;

  while ((name[i] != '[') && (name[i] != '\0')) i++;
  if (name[i] == '[') {
    *x1 = next_num(name,&i);
    if (i != -1) *x2 = next_num(name,&i); else *x2 = 0;
    if (i != -1) *y1 = next_num(name,&i); else *y1 = 0;
    if (i != -1) *y2 = next_num(name,&i); else *y2 = 0;
    if (i != -1) result = 1;
  }

  return result;
}

/* ====================================================================== */

float *readfitsfile(
  hstruct *header,
  char *filename,
  int  detailed
)

/* Read a FITS file.                                                 */
/* Returns a pointer to the image data.                              */
/* Header returns header information, such as naxis1, naxis2 etc.    */
/* (see fitsutil.inc, where hstruct is defined.)                     */
/*								     */
/* The filename is more than a filename - it may also contain an     */
/* extension that specifies which part of the image to read.         */
/* The format is like this:					     */
/*   actualname[x1:x2,y1:y2]                                         */
/*  where "actualname" is the true name of the file, and the text    */
/* in the brackets specifies the window to be read.                  */
/*  If you are familiar with IRAF, this syntax should be well-known. */
/* 								     */

{
  int buffsz,laest,i,handle;
  int   pixsz;
  float *fbuffer;
  short *sbuffer;
  int   *ibuffer;
  float *outdata;
  char actualname[255];
  int  x,y,dx,dy,x1,y1,x2,y2;
  int  cut;
  int  ofs1,ofs2;

  for (i=0;(filename[i] != '\0') && (filename[i] != '[');i++)
    actualname[i] = filename[i];
  actualname[i] = '\0';
  cut = getcorners(filename,&x1,&y1,&x2,&y2);

  if ((handle=getheader(header,actualname,detailed))>0) {
    if (cut) {
      dx = x2-x1+1;
      dy = y2-y1+1;
      pixsz = abs(header->bitpix/8);

      handle = open(actualname,O_RDONLY); 
      lseek(handle,
          F_OFFSET + 80* header->ncards+ pixsz*header->naxis1*((y1>0) ? y1 : 0),
	    SEEK_SET);
      buffsz = header->naxis1 * 
                ((y2<header->naxis2) ? dy : header->naxis2-y1);

      outdata = (float *)malloc(dx*dy*sizeof(float));
      ofs2 = 0;

      switch (header->bitpix) {

        case  16: sbuffer = (short *)malloc(pixsz*buffsz);
	          laest = read(handle,sbuffer,pixsz*buffsz); 
		  for (y = y1; y<=y2; y++) {
		    ofs1 = (y-((y1>=0) ? y1 : 0))*header->naxis1;
		    for (x = x1; x<= x2; x++) {
		      outdata[ofs2++] = ((x>=0) && (x<header->naxis1) &&
					 (y>=0) && (y<header->naxis2)) ?
					  swap(sbuffer[ofs1+x]) : F_EXTVAL;
		    }
		  }
		  free(sbuffer);
		  break;

        case  32: ibuffer = (int *)malloc(pixsz*buffsz);
	          laest = read(handle,ibuffer,pixsz*buffsz); 
		  for (y = y1; y<=y2; y++) {
		    ofs1 = (y-((y1>=0) ? y1 : 0))*header->naxis1;
		    for (x = x1; x<= x2; x++) {
		      outdata[ofs2++] = ((x>=0) && (x<header->naxis1) &&
					 (y>=0) && (y<header->naxis2)) ?
					  iswap(ibuffer[ofs1+x]) : F_EXTVAL;
		    }
		  }
                  free(ibuffer);
		  break;

        case -32: fbuffer = (float *)malloc(pixsz*buffsz);
	          laest = read(handle,fbuffer,pixsz*buffsz);
		  for (y = y1; y<=y2; y++) {
		    ofs1 = (y-((y1>=0) ? y1 : 0))*header->naxis1;
		    for (x = x1; x<= x2; x++) {
		      outdata[ofs2++] = ((x>=0) && (x<header->naxis1) &&
					 (y>=0) && (y<header->naxis2)) ?
					  fswap(fbuffer[ofs1+x]) : F_EXTVAL;
		    }
		  }
                  free(fbuffer);
		  break;
      }


      header->naxis1 = dx;
      header->naxis2 = dy;
      close(handle);

    } else
      outdata = getimdata(header,actualname);
  }
  else
    outdata = NULL;

  return outdata;
}

/* ====================================================================== */

float *floatfitsimage(
  hstruct *header,
  char *filename,
  int  detailed
)
{
  float *buff;
  float *fbuff = NULL;
  int   i,npix;

  buff = readfitsfile(header,filename,detailed);
  if (buff != NULL) {
    npix = header->naxis1 * header->naxis2;
    fbuff = (float *)malloc(sizeof(float)*npix);

    if (fbuff != NULL)
      for (i=0; i<npix; i++)
        fbuff[i] = (header->bscale * buff[i]) + header->bzero;
    else
      puts("  ** Error allocating memory.");

    free(buff);
  }

  return fbuff;
}

/* ====================================================================== */

short *shortfitsimage(
  hstruct *header,
  char *filename,
  int  detailed
)
{
  float *buff;
  short *sbuff;
  int   i,npix;

  sbuff = NULL;
  buff = readfitsfile(header,filename,detailed);
  npix = header->naxis1 * header->naxis2; 

  if (buff != NULL) {
    sbuff = (short*)malloc(npix*sizeof(short));
    for (i=0;i<npix;i++)
      sbuff[i] = (short)((header->bscale * buff[i]) + header->bzero);
    header->bscale = 1.0;
    header->bzero = 0.0;
    free(buff);
  }

  return sbuff;
}

/* ====================================================================== */

void savefitsfile(
  hstruct *header,
  void    *data,
  int      bitpix,
  char    *filename
)
{
  int buffsize,i,handle,npix;
  int   pixsz;
  short nulbuff[2880];
  short *sbuffer, *sdata;
  int   *ibuffer, *idata;
  float *fbuffer, *fdata;
  float *buffer;
  char actualname[255];

  for (i=0;(filename[i] != '\0') && (filename[i] != '[');i++)
    actualname[i] = filename[i];
  actualname[i] = '\0';

  fdata = idata = sdata = data;
  npix = header->naxis1 * header->naxis2;
  buffer = (float *)malloc(npix*sizeof(float));

  switch (bitpix) {
    case  16: for (i=0; i<npix; i++) buffer[i] = (float)sdata[i]; break;
    case  32: for (i=0; i<npix; i++) buffer[i] = (float)idata[i]; break;
    case -32: for (i=0; i<npix; i++) buffer[i] = (float)fdata[i]; break;
  }

  if (F_DATATYPE != D_DEFAULT) header->bitpix = F_DATATYPE;

  if ((handle=mknewfile(header,actualname)) > 0) {
    pixsz = abs(header->bitpix / 8);
    buffsize = (*header).naxis1 * (*header).naxis2 * pixsz;

    switch (header->bitpix) {
      case  16 : sbuffer = (short *)malloc(2*npix);
                 for (i=0; i<npix; i++) sbuffer[i] = (short)buffer[i];
                 for (i=0;i<buffsize / pixsz; i++) 
                    sbuffer[i] = swap(sbuffer[i]);
                 write(handle,sbuffer,buffsize);
		 free(sbuffer);
                 break;

      case  32 : ibuffer = (int *)malloc(4*npix);
                 for (i=0; i<npix; i++) ibuffer[i] = (int)buffer[i];
                 for (i=0;i<buffsize / pixsz; i++) 
                    ibuffer[i] = iswap(ibuffer[i]);
                 write(handle,ibuffer,buffsize);
		 free(ibuffer);
                 break;

      case -32 : fbuffer = buffer;
                 for (i=0;i<buffsize / pixsz; i++) 
                    fbuffer[i] = fswap(fbuffer[i]);
                 write(handle,fbuffer,buffsize);
                 break;
    }

    if ((buffsize % 2880) > 0) {
      for(i=0;i<2880- buffsize % 2880;i++) nulbuff[i] = 0;
      write(handle,nulbuff,2880-buffsize % 2880);
    }

    close(handle);
  }

  free(buffer);
}

/* ====================================================================== */

short *readlnx(char *filename)
{
  char lnxdata[47520];
  short *wdata = NULL;
  int  i,j,laest,handle;
  unsigned char b1,b2,b3;
  unsigned short s1,s2;


  handle = open(filename,O_RDONLY);
  if (handle > 0) {
    laest = read(handle,lnxdata,47520);
    if (laest==47520) {
      wdata = (short *)malloc(63360);
      i = 0; j = 0;
      do {
        b1 = lnxdata[i++];
        b2 = lnxdata[i++];
        b3 = lnxdata[i++];

        s1 = (unsigned short)b1 | ((unsigned short)b2 & 0X000F) << 8;
        s2 = (unsigned short)b3 | ((unsigned short)b2 & 0X00F0) << 4;

        wdata[j++] = s1;
        wdata[j++] = s2;

      } while (i<47520);
    }   
    close(handle);
  }

  return wdata;
}

