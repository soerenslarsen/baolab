#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"
#include "utils.h"

extern int calctff( char *, unsigned char *);   /* in baolab3.c */
extern int tobmp(char *, float, float, 
                unsigned char *, char *);       /* in baolab5.c */
extern int totiff(char *, float, float,
                unsigned char *, int, char *);       /* in baolab5.c */

/* ==================================================================== */

void hlist(char *params) 
{
  static char filename[255] = "";
  hstruct hdr;
  cardstruct *card;
  char   tmps[100];
  int    i;
  int    shownr = YES;

  if (getpar("HLIST.SHOWNR",tmps)) {
    if (strstr(tmps,"NO") != NULL) shownr = NO;
  }

  if (nargs(params) == 1) argn(params,1,filename);
  else {
    printf("  List header of:  "); cscanf("%s",filename);
  }

  if (getheader(&hdr,filename,TRUE)) {
    if (hdr.card != NULL) {
      card = hdr.card;
      while (card->prev != NULL) card = card->prev;

      printf("  Listing header of %s\n\n",filename);
      i = 0;

      while (card != NULL) {
        memcpy(tmps,card->image,80);
	switch (shownr) {
	  case YES: tmps[75] = '\0';
	            printf("%03i:%s\n",i++,tmps);
		    break;

	  case NO : tmps[80] = '\0';
	            puts(tmps);
        }
        card = card->next;
      }

      puts("");
      printf("  %i card images in header.\n",hdr.nused); 
    }
    freehdr(&hdr);

  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void hinsert(char *params)
{
  static char keyword[20] = "";
  static char type[10] = "CHAR";
  static char filename[255] = "";
  static char value[255] = "";
  char tmps[255];
  hstruct header;
  float tmpflt;
  int   n, i, nread, pos1, pos0, buffsz, tmpint;
  int   handle, hsize,ncard0;
  char *buff;
  struct stat fileinfo;
  cardstruct *tmpcard;

  if (nargs(params) == 4) {
    argn(params,1,filename); 
    argn(params,2,keyword);
    argn(params,3,value);
    argn(params,4,type);
  } else {
    printf("  Filename  :  "); cscanf("%s",filename);
    printf("  Keyword   :  "); cscanf("%s",keyword);
    printf("  Value     :  "); cscanf("%s",value);
    printf("  Type      :  "); cscanf("%s",type);
  }

  if (getheader(&header,filename,TRUE)) {
    upcstr(type);
    ncard0 = header.nused;

    if (strstr(type,"CHAR") == type) 
      addcard(&header,keyword,value,H_ASCII);
    else
    if (strstr(type,"INT") == type) {
      tmpint = atoi(value);
      addcard(&header,keyword,&tmpint,H_INT);
    } else
    if (strstr(type,"REAL") == type) {
      tmpflt = atof(value);
      addcard(&header,keyword,&tmpflt,H_FLOAT);
    } else
    if (strstr(type,"BOOL") == type) {
      if (value[0] == 'T') tmpint = TRUE; else tmpint = FALSE;
      addcard(&header,keyword,&tmpint,H_BOOL);
    } else
    if (strstr(type,"COMM") == type) {
      addcard(&header,keyword,value,H_COMM);
    } else {
      puts("  ** Error: Invalid type. Valid types are CHAR, INT, REAL, BOOL, COMM");
      return;
    }
      
    puts("  Adding new card.");
    handle = open(filename,O_RDWR);

    if (handle == 0)  {
      puts(IM_READ_ERR);
      return;
    }

    if (ncard0 % 36 == 0) {
      puts("  Reorganising image - must insert new block."); 
      stat(filename,&fileinfo);
      printf("  Old file size = %i bytes. New size = %i bytes.\n",
              fileinfo.st_size,fileinfo.st_size+2880);

      hsize = (ncard0 / 36) * 2880;
      buffsz = fileinfo.st_size - hsize;
      if (buffsz > 250000) buffsz = 250000;
      buff = (char *)malloc(buffsz);

      pos1 = fileinfo.st_size-buffsz;
      pos0 = fileinfo.st_size;

      do {
        nread = pos0 - pos1;

        lseek(handle,pos1,SEEK_SET);
	read(handle,buff,nread);
	lseek(handle,pos1+2880,SEEK_SET);
	write(handle,buff,nread);
	pos0 = pos1;
	pos1 -= buffsz;

	if (pos1 < hsize) pos1 = hsize;

      } while (pos0 > hsize);

      free(buff);
    }

    lseek(handle,0,SEEK_SET);
    tmpcard = header.card;
    while (tmpcard->prev != NULL) tmpcard = tmpcard->prev;

    i = 0;
    while (tmpcard != NULL) {
      if (memcmp(tmpcard->image,"END ",4))
        write(handle,tmpcard->image,80);
      i++;
      tmpcard = tmpcard->next;
    }

    wrendcard(handle);

    for (n=0;n<80;n++) tmps[n] = ' ';
    while (i % 36 != 0) {
      write(handle,tmps,80);
      i++;
    }

    close(handle);
    freehdr(&header);

  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void hdel(char *params)
{
  static char filename[255] = "";
  static int ndel = 0;
  char tmps[100];
  hstruct hdr;
  cardstruct *card;
  int   handle,i;
  struct stat fileinfo;
  char  *buff;
  int   hsize,nread,ntot,nbytes;
  int   confirm = TRUE;

  if (getpar("HDEL.CONFIRM",tmps)) 
    if (strstr(tmps,"NO") != NULL) confirm = FALSE;

  if (nargs(params) == 2) {
    argn(params,1,filename);
    argn(params,2,tmps); ndel = atoi(tmps);
  } else {
    printf("  Filename :  "); cscanf("%s",filename);
    printf("  Delete nr:  "); cscanf("%i",&ndel);
  }

  if (getheader(&hdr,filename,TRUE)) {
    if (ndel < hdr.nused && ndel >= 0) {
      card = hdr.card;
      while (card->prev != NULL) card = card->prev;
      i = 0;
      while (i<ndel) { card = card->next; i++; }

      if (memcmp(card->image,"END ",4)    != 0 &&
          memcmp(card->image,"SIMPLE ",7) != 0 &&
	  memcmp(card->image,"BITPIX ",7) != 0 &&
	  memcmp(card->image,"NAXIS ",6)  != 0 &&
	  memcmp(card->image,"NAXIS1 ",7) != 0 &&
	  memcmp(card->image,"NAXIS2 ",7)) {
	
	if (confirm) {
          memcpy(tmps,card->image,80); tmps[79] = '\0';
	  puts(tmps);
	  printf("Delete this card? (y/n) "); fflush(stdout);
	  do
	    i = bgetchar();
	  while (i != 'n' && i != 'y');

	  if (i=='n') {
	    puts(" NO"); 
	    freehdr(&hdr);
	    return;
	  } else
	    puts(" YES");
        }

        handle = open(filename,O_RDWR);
        while (card->prev != NULL) card = card->prev;
	i = 0;

	do {
	  if (i != ndel) write(handle,card->image,80);
	  card = card->next;
	  i++;
	} while (i < hdr.nused);

	wrempcard(handle);

	if ((hdr.nused-1) % 36 == 0) {   /* One block less now */
          puts("  Reorganizing image - must remove block.");
          stat(filename,&fileinfo);
          printf("  Old file size = %i bytes. New size = %i bytes.\n",
              fileinfo.st_size,fileinfo.st_size-2880);

	  buff = (char *)malloc(100000);
	  hsize = (hdr.ncards / 36) * 2880;
	  ntot = fileinfo.st_size - hsize;
	  nread = 0;

	  do {
	    nbytes = ntot-nread;
	    if (nbytes > 100000) nbytes = 100000;
	    lseek(handle,hsize+nread,SEEK_SET);
	    read(handle,buff,nbytes);

            lseek(handle,hsize+nread-2880,SEEK_SET);
	    write(handle,buff,nbytes);

	    nread += nbytes;
	  } while (nread < ntot);

	  ftruncate(handle, fileinfo.st_size-2880);
	  free(buff);
	}

        close(handle);

      } else
	puts("  Foo! You can't delete that card.");
    } else
      puts("  Error: Number out of range.");

    freehdr(&hdr);

  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void savebmp(char *params)
{
  static char fname[255] = "", bmpname[255] = "";
  static char tffname[100] = "lin";
  char   tmps[100];
  static float locut = 0;
  static float hicut = 4095;
  unsigned char tff[4096];
  int    i;
  
  if (nargs(params) >= 4) {
    argn(params,1,fname);
    argn(params,2,tmps); locut = atof(tmps);
    argn(params,3,tmps); hicut = atof(tmps);
    argn(params,4,bmpname);

    i = 5; 
    if (nargs(params) > 4) strcpy(tffname,"");
    while (i <= nargs(params)) {
      argn(params,i,tmps);
      strcat(tffname,tmps);
      strcat(tffname," ");
      i++;
    }

  } else {
    printf("  FITS-file to convert:  "); cscanf("%s",fname);
    printf("  Locut               :  "); cscanf("%0.2f",&locut);
    printf("  Hicut               :  "); cscanf("%0.2f",&hicut);
    printf("  Name of BMP-file    :  "); cscanf("%s",bmpname);
    printf("  Tff to use          :  "); cscanf("%s",tffname);
  }

  if (calctff(tffname,tff)) 
    tobmp(fname,locut,hicut,tff,bmpname);
}

/* ==================================================================== */

void savetiff(char *params)
{
  static char fname[255] = "", tiffname[255] = "";
  static char tffname[100] = "lin";
  char   tmps[100];
  static float locut = 0;
  static float hicut = 4095;
  unsigned char tff[4096];
  int    i;
  int    flipy = NO;
  
  if (nargs(params) >= 4) {
    argn(params,1,fname);
    argn(params,2,tmps); locut = atof(tmps);
    argn(params,3,tmps); hicut = atof(tmps);
    argn(params,4,tiffname);

    i = 5; 
    if (nargs(params) > 4) strcpy(tffname,"");
    while (i <= nargs(params)) {
      argn(params,i,tmps);
      strcat(tffname,tmps);
      strcat(tffname," ");
      i++;
    }

  } else {
    printf("  FITS-file to convert:  "); cscanf("%s",fname);
    printf("  Locut               :  "); cscanf("%0.2f",&locut);
    printf("  Hicut               :  "); cscanf("%0.2f",&hicut);
    printf("  Name of tiff-file   :  "); cscanf("%s",tiffname);
    printf("  Tff to use          :  "); cscanf("%s",tffname);
  }

  if (getpar("SAVETIFF.FLIPY",tmps))
    flipy = (strstr(tmps,"YES") != NULL);

  if (calctff(tffname,tff)) 
    totiff(fname,locut,hicut,tff,flipy,tiffname);
}

/* ==================================================================== */

void imcopy(char *params)
{
  static char source[255] = "", dest[255] = "";
  hstruct hdr;
  char    tmps[100];
  float  *data;

  if (nargs(params) == 2) {
    argn(params,1,source);
    argn(params,2,dest);
  } else {
    printf("  Copy from :  "); cscanf("%s",source);
    printf("  Copy to   :  "); cscanf("%s",dest);
  }

  data = floatfitsimage(&hdr,source,TRUE);
  if (data != NULL) {
    strcpy(tmps,"Copy from "); strcat(tmps,source);
    addcard(&hdr,"HISTORY",tmps,H_COMM);
    savefitsfile(&hdr,data,-32,dest);
    free(data);
    freehdr(&hdr);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void getclippars(
  char *params, char *fname,
  float  *limit, float *value
)
{
  char tmps[100];

  if (nargs(params) == 3) {
    argn(params,1,fname);
    argn(params,2,tmps); *limit = atof(tmps);
    argn(params,3,tmps); *value = atof(tmps);
  } else {
    printf("  Filename: "); cscanf("%s",fname);
    printf("  Limit   : "); cscanf("%0.2f",limit);
    printf("  Value   : "); cscanf("%0.2f",value);
  }
}

/* ==================================================================== */

void clipabove(char *params)
{
  static float limit=4095, value = 4095;
  static char fname[255] = "";
  char tmps[100];
  float *data;
  hstruct hdr;
  int     i,npix;

  getclippars(params,fname,&limit,&value);
  data = floatfitsimage(&hdr,fname,TRUE);

  if (data != NULL) {
    sprintf(tmps,"Clipping above %i to %i",limit,value);
    addcard(&hdr,"HISTORY",tmps,H_COMM);
    npix = hdr.naxis1 * hdr.naxis2;

    for (i=0; i<npix; i++)
      if (data[i] > limit) data[i] = value;

    savefitsfile(&hdr,data,-32,fname);
    freehdr(&hdr);
  } else
    puts(IM_READ_ERR);
}
 
/* ==================================================================== */

void clipbelow(char *params)
{
  static float limit=0, value = 0;
  static char fname[255] = "";
  char tmps[100];
  float *data;
  hstruct hdr;
  int     i,npix;

  getclippars(params,fname,&limit,&value);
  data = floatfitsimage(&hdr,fname,TRUE);

  if (data != NULL) {
    sprintf(tmps,"Clipping below %i to %i",limit,value);
    addcard(&hdr,"HISTORY",tmps,H_COMM);
    npix = hdr.naxis1 * hdr.naxis2;

    for (i=0; i<npix; i++)
      if (data[i] < limit) data[i] = value;

    savefitsfile(&hdr,data,-32,fname);
    freehdr(&hdr);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void mkgrad(char *params)
{
  static char imname[255] = "";
  static int imdx=192, imdy = 165;
  static float offs = 1000;
  static float xgrad = 0, ygrad = 0;

  int i,x,y;
  char tmps[100];
  float *imbuff;
  hstruct hdr;

  if (nargs(params) == 6) {
    argn(params,1,imname);
    argn(params,2,tmps); imdx = atoi(tmps);
    argn(params,3,tmps); imdy = atoi(tmps);
    argn(params,4,tmps); offs = atof(tmps);
    argn(params,5,tmps); xgrad = atof(tmps);
    argn(params,6,tmps); ygrad = atof(tmps);
  } else {
    printf("  Image name:  "); cscanf("%s",imname);
    printf("  Image dx  :  "); cscanf("%i",&imdx);
    printf("  Image dy  :  "); cscanf("%i",&imdy);
    printf("  Offset    :  "); cscanf("%0.1f",&offs);
    printf("  X gradient:  "); cscanf("%0.3f",&xgrad);
    printf("  Y gradient:  "); cscanf("%0.3f",&ygrad);
  }

  imbuff = (float *)malloc(sizeof(float)*imdx*imdy);
  hdr.card = NULL;
  hdr.naxis1 = imdx;
  hdr.naxis2 = imdy;
  hdr.bitpix = -32;
  hdr.bscale = 1.0;
  hdr.bzero  = 0.0;

  for (i=0,y=0; y<imdy; y++) 
    for (x=0; x<imdx; x++) {
      imbuff[i++] = offs + x*xgrad + y*ygrad;
    }

  savefitsfile(&hdr,imbuff,-32,imname);
  free(imbuff);
}

/* ==================================================================== */

void remspot(char *params)
{
  float maxdev = 100;
  static char imname[255] = "";
  static char outname[255] = "";
  char tmps[100];
  hstruct hdr;
  float  *image,*buff1;
  int    offs,i,xx,yy,x,y;
  int    nsubst=0,p,max,min;

  if (getpar("REMSPOT.MAXDEV",tmps)) maxdev = atof(tmps);

  if (nargs(params) >= 2) {
    argn(params,1,imname);
    argn(params,nargs(params),outname);
    if (nargs(params) == 3) {
      argn(params,2,tmps); maxdev = atof(tmps);
    }
  } else {
    printf("  Input image    :  "); cscanf("%s",imname);
    printf("  Max. deviation :  "); cscanf("%0.0f",&maxdev);
    printf("  Output image   :  "); cscanf("%s",outname);
  }

  image = floatfitsimage(&hdr,imname,TRUE);

  if (image != NULL) {
    buff1 = (float *)malloc(sizeof(float)*hdr.naxis1*hdr.naxis2);
    xx = hdr.naxis1*hdr.naxis2;
    for (i=0; i<xx; i++) buff1[i] = image[i];

    printf("  Remspot: %s -> %s, maxdev = %0.0f\n",imname,outname,maxdev);
    sprintf(tmps,"Remspot: %s -> %s, maxdev = %0.0f",imname,outname,maxdev);
    addcard(&hdr,"HISTORY",tmps,H_COMM);

    for (y=1; y<hdr.naxis2-1; y++)
      for (x=1; x<hdr.naxis1-1; x++) {
        i    = y*hdr.naxis1+x;
	offs = -hdr.naxis1;
	min  = max = image[i+offs];

        for (yy=-1; yy<=1; yy++) {
          for (xx=-1; xx<=1; xx++)
	    if (xx != 0 || yy != 0) {
	      p = image[i+offs+xx];
	      if (p < min) min = p;
	      if (p > max) max = p;
	    }

	  offs += hdr.naxis1;
	}

	if (image[i] < min-maxdev || image[i] > max+maxdev) {
	  buff1[i] = (max+min)/2;
	  nsubst++;
	} else
	  buff1[i] = image[i];
      }

    printf("  %i pixels substituted.\n",nsubst);
    savefitsfile(&hdr,buff1,-32,outname);
    freehdr(&hdr);
    free(image);
    free(buff1);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void newcol(char *params)
{
  static  char imname[255] = "";
  static  int col;
  char    tmps[255];
  float  *imbuff;
  hstruct hdr;
  int     y,offs;
  float   p1,p2;

  if (nargs(params) == 2) {
    argn(params,1,imname);
    argn(params,2,tmps); col = atoi(tmps);
  } else {
    printf("  Image name    :  "); cscanf("%s",imname);
    printf("  Repair column :  "); cscanf("%i",&col);
  }

  if (!strcmp(imname,"[")) {
    puts("  ** Error: You can't specify part of an image here.");
    return;
  }

  imbuff = floatfitsimage(&hdr,imname,TRUE);

  if (imbuff != NULL) {
    sprintf(tmps,"Repaired column #%i",col);
    addcard(&hdr,"HISTORY",tmps,H_COMM);

    offs = col;
    for (y=0; y<hdr.naxis2; y++) {
      p1 = imbuff[offs-1] / 2;
      p2 = imbuff[offs+1] / 2;
      imbuff[offs] = p1+p2;
      offs += hdr.naxis1;
    }

    savefitsfile(&hdr,imbuff,-32,imname);
    freehdr(&hdr);
    free(imbuff);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void newrow(char *params)
{
  static  char imname[255] = "";
  static  int row;
  char    tmps[255];
  float  *imbuff;
  hstruct hdr;
  int     x,offs;
  float   p1,p2;

  if (nargs(params) == 2) {
    argn(params,1,imname);
    argn(params,2,tmps); row = atoi(tmps);
  } else {
    printf("  Image name  :  "); cscanf("%s",imname);
    printf("  Repair row  :  "); cscanf("%i",&row);
  }

  if (!strcmp(imname,"[")) {
    puts("  ** Error: You can't specify part of an image here.");
    return;
  }

  imbuff = floatfitsimage(&hdr,imname,TRUE);

  if (imbuff != NULL) {
    sprintf(tmps,"Repaired row #%i",row);
    addcard(&hdr,"HISTORY",tmps,H_COMM);

    offs = row*hdr.naxis1;
    for (x=0; x<hdr.naxis1; x++) {
      p1 = imbuff[offs-hdr.naxis1] / 2;
      p2 = imbuff[offs+hdr.naxis1] / 2;
      imbuff[offs] = p1+p2;
      offs++;
    }

    savefitsfile(&hdr,imbuff,-32,imname);
    freehdr(&hdr);
    free(imbuff);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void do_reparea(char *imname,
		int x1,
		int y1,
		int x2,
		int y2
) {
  hstruct hdr;
  float *data;
  char   tmps[100];
  int    x,y,offs;
  float  *fx1,*fy1,*fx2,*fy2;
  float  fx,fy,dx,dy;    

  data = floatfitsimage(&hdr,imname,TRUE);

  if (data != NULL) {
    fx1 = (float *)malloc(sizeof(float)*(y2-y1+1));
    fx2 = (float *)malloc(sizeof(float)*(y2-y1+1));
    fy1 = (float *)malloc(sizeof(float)*(x2-x1+1));
    fy2 = (float *)malloc(sizeof(float)*(x2-x1+1));

    if ((x1 >= 0) && (x1 <= x2) && (x2 < hdr.naxis1) &&
	(y1 >= 0) && (y1 <= y2) && (y2 < hdr.naxis2)) {

      for (y=y1; y<=y2; y++) {
	if (x1>0) fx1[y-y1] = data[y*hdr.naxis1+x1-1];
	if (x2 < hdr.naxis1-1) 
	  fx2[y-y1] = data[y*hdr.naxis1+x2+1]; 
        else 
	  fx2[y-y1] = fx1[y-y1];
        if (x1==0) fx1[y-y1] = fx2[y-y1];
      }

      for (x=x1; x<=x2; x++) {
	if (y1>0) fy1[x-x1] = data[(y1-1)*hdr.naxis1+x];
	if (y2 < hdr.naxis2-1) 
	  fy2[x-x1] = data[(y2+1)*hdr.naxis1+x]; 
        else 
	  fy2[x-x1] = fy1[x-x1];
        if (y1==0) fy1[x-x1] = fy2[x-x1];
      }
 
      for (y=y1; y<=y2; y++) {
	offs = y*hdr.naxis1;
	for (x=x1; x<=x2; x++) {
          fx = (x-x1+1.0)/(x2-x1+2.0) * fx2[y-y1] +
               (x2-x+1.0)/(x2-x1+2.0) * fx1[y-y1];
          fy = (y-y1+1.0)/(y2-y1+2.0) * fy2[x-x1] +
               (y2-y+1.0)/(y2-y1+2.0) * fy1[x-x1];

          dx = (x-x1) < (x2-x) ? x-x1+1 : x2-x+1;
	  dy = (y-y1) < (y2-y) ? y-y1+1 : y2-y+1;

	  data[offs+x] = (short)((fx/dx + fy/dy) / (1/dx+1/dy));
	}
      }

      sprintf(tmps,"Repaired section [%i:%i,%i:%i]",x1,x2,y1,y2);
      addcard(&hdr,"HISTORY",tmps,H_COMM);
      savefitsfile(&hdr,data,-32,imname);
    } else
      printf("  ** Error: Bad image section [%i:%i,%i:%i]\n",x1,x2,y1,y2);

    freehdr(&hdr);
    free(fx1); free(fx2); free(fy1); free(fy2);
  } else
    puts(IM_READ_ERR);
}

/* ==================================================================== */

void reparea(char *params) {

  char tmps[255];
  static char imname[255] = "";
  static int x1 = 0, y1 = 0, x2 = 10, y2 = 10;

  if (nargs(params) == 5) {
    argn(params,1,imname);
    argn(params,2,tmps); x1 = atof(tmps);
    argn(params,3,tmps); x2 = atof(tmps);
    argn(params,4,tmps); y1 = atof(tmps);
    argn(params,5,tmps); y2 = atof(tmps);
  } else {
    printf("  Image to repair       :  "); cscanf("%s",imname);
    sprintf(tmps,"%i %i %i %i",x1,x2,y1,y2);
    printf("  Section (x1 x2 y1 y2) :  "); cscanf("%s",tmps);
    sscanf(tmps,"%i %i %i %i",&x1,&x2,&y1,&y2);
  }

  do_reparea(imname,x1,y1,x2,y2);
}

/* ==================================================================== */

void mkgfilter(char *params) {
  FILE *file;
  static char fname[255] = "";
  char tmps[100];
  float sum;
  static float fwhmx = 3, fwhmy = 3;
  int   fx,fy,x,y;
  int   n,i;
  float *farr;

  if (nargs(params) == 3) {
    argn(params,1,tmps); fwhmx = atof(tmps);
    argn(params,2,tmps); fwhmy = atof(tmps);
    argn(params,3,fname);
  } else {
    printf("  FWHM(x)  :  "); cscanf("%0.3f",&fwhmx);
    printf("  FWHM(y)  :  "); cscanf("%0.3f",&fwhmy);
    printf("  Filename :  "); cscanf("%s",fname);
  }

  file = fopen(fname,"w");

  if (file != NULL) {

    fx = (int)(fwhmx); i = 0;
    fy = (int)(fwhmy); i = 0;

    farr = (float*)malloc(sizeof(float)*(2*fx+1)*(2*fy+1));

    for (y=-fy; y<=fy; y++)
      for (x=-fx; x<=fx; x++)
        farr[i++] = exp(-2.77*(pow(x/fwhmx,2) + pow(y/fwhmy, 2)));

    n = i; sum = 0;
    for (i=0; i<n; i++) sum += farr[i];
    for (i=0; i<n; i++) farr[i] /= sum;

    for (i=0,y=-fy; y<=fy; y++) {
      for (x=-fx; x<=fx; x++)
        fprintf(file,"%0.4f ",farr[i++]);
      fprintf(file,"\n");
    }

    fclose(file);
    free(farr);
  } else
    puts(CANT_OPEN_FILE);
}

/* ==================================================================== */
