/*  Minimize a function using the Nelder-Mead algorithm.               */
/*  Also known as "downhill simplex" or "Amoeba".                      */
/*  This code inspired by                                              */
/*                                                                     */
/*  Numerical Methods for Mathematics, Science and Engineering,        */
/*  John Mathews, 1992                                                 */
/*  Prentice Hall                                                      */
/*                                                                     */
/*  Numerical Recipes in Fortran                                       */
/*  Press, Teukolsky, Vetterling & Flannery 1992                       */
/*  Cambridge University Press                                         */
/*                                                                     */
/*  Also input from Wikipedia "Nelder-Mead method entry" (25.07.2007), */
/*  Lee & Wiswall 2007, Comput. Econ. 30, 171,                         */
/*  and Mark Ellingham's Nonlinear Optimization notes                  */
/*                                                                     */
/*  Conditions labeled "NM" are from Numerical Methods                 */
/*  Conditions labeled "NR" correspond to Numerical Recipes.           */
/*  Differences in sorting (swap two identical entries?) and           */
/*  other numerical precision issues can produce slightly different    */
/*  results compared to NR 'Amoeba' routine.                           */
/*                                                                     */

#define NELDMEAN_MAIN

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "neldmead.h"

int SIMPLEX_ERR;
int ITMAX = 200;

float NM_ALPHA = 1.0;     /* Reflection coefficient  */
float NM_BETA  = 0.5;     /* Contraction coefficient */
float NM_GAMMA = 1.0;     /* Expansion coefficient   */
float NM_SIGMA = 0.5;     /* Shrinking coefficient = 1-tau  */

int neldermead(
  float v[MP][NP],         /* Initial vertices               */
  float y[MP],             /* Function values at v           */
  int   n,                 /* Number of dimensions           */
  float epsilon,           /* Relative convergence tolerance */
  float (*funk)(float [])  /* Function to be minimized       */
)  {
  int retval;
  int lo, hi, j, k;
  int nhi, nlo;
  int iter;
  float s, t, ym, yc, ye, yr;
  float xc[MP], xe[MP], xm[MP], xr[MP], xz[MP];

  /* Initialize a couple of variables */

  retval = 1;
  SIMPLEX_ERR = 0;
  iter=0;

  /* Find highest and lowest point */

  lo=0;                      
  hi=0;
  for (j=1; j<=n; j++) {
    if (y[j] <= y[lo]) lo=j;
    if (y[j] > y[hi]) hi=j;
  }

  /* Find second-highest and second-lowest point */

  nlo=hi;
  nhi=lo;

  for (j=0; j<=n; j++) {
/*  if (j != lo && y[j] < y[nlo]) nlo=j;   We don't actually use this */
    if (j != hi && y[j] > y[nhi]) nhi=j;
  }

  /* Start iterations */

  while ( (2.0*fabs(y[hi]-y[lo])/
	  (fabs(y[hi])+fabs(y[lo])) > epsilon)
	 &&
	  (iter < ITMAX) && (!SIMPLEX_ERR)) {
			      
    /* Calculate centre of gravity of the simplex */
    for (k=0; k<n; k++) {
      s = 0;
      for (j=0; j<=n; j++) s=s+v[j][k];
      xm[k] = (s-v[hi][k])/n;                 /* exclude highest point */
    }

    /* Reflect the highest point around centre of gravity */
    for (k=0; k<n; k++)
      xr[k] = xm[k] + NM_ALPHA* (xm[k] - v[hi][k]);
    yr = (*funk)(xr);

    if (!SIMPLEX_ERR) {

/*      printf("    r    m    e   c   y\n");
      for (k=0; k<n; k++) {
	printf("%0.2f %0.2f %0.2f %0.2f %0.2f\n",r[k], m[k], e[k], c[k], y[k]);
      } */

      /* Is the new point good? */

      if (yr < y[nhi]) {     /* New point better than second-highest: */
                             /* Improve the simplex.                  */
  /*	if (y[nlo] < yr) {    */      /*  NM      */
	if (yr > y[lo]) {             /*  NR      */
	  for (k=0; k<n; k++) v[hi][k]=xr[k];   /* Replace the vertex */
	  y[hi]=yr;
	} else {
	  for (k=0; k<n; k++) xe[k]=xr[k]+NM_GAMMA*(xr[k]-xm[k]); /*  Expand */
	  ye=(*funk)(xe);
/*  	  if (ye < y[nlo]) {   */     /*  NM      */
/*  	  if (ye < y[lo]) {    */
  	  if (ye < yr) {              /*  NR      */
	    for (k=0; k<n; k++) v[hi][k] = xe[k];
	    y[hi]=ye;
	  } else { 
	    for (k=0; k<n; k++) v[hi][k] = xr[k]; /* Replace a vertex */
	    y[hi]=yr;
	  } 
	} 
      } else {            /* New point is above (worse than) second-highest */
	if (yr < y[hi]) {
          for (k=0; k<n; k++) v[hi][k] = xr[k];   /* Replace a vertex */
          y[hi] = yr;
	}
	for (k=0; k<n; k++) xc[k]=xm[k] + NM_BETA*(v[hi][k]-xm[k]); 
        yc= (*funk)(xc);
        if (yc < y[hi]) {
          for (k=0; k<n; k++) v[hi][k]=xc[k];
          y[hi]=yc;
        } else {
				 /* Shrink the simplex: */
	  for (j=0; j<=n; j++) {
	    if (j != lo) {
	      for (k=0; k<n; k++) {
                v[j][k] = v[lo][k] + NM_SIGMA*(v[j][k]-v[lo][k]);
		xz[k]=v[j][k];
	      }
	      y[j]= (*funk)(xz);
	    }
	  }
	}
      }
    }

    /* Find lowest and highest points in new simplex */
    lo=0;               
    hi=0;
    for (j=1; j<=n; j++) {
      if (y[j] <= y[lo]) lo=j;
      if (y[j] > y[hi]) hi=j;
    }
    nlo=hi;
    nhi=lo;

    for (j=0; j<=n; j++) {
/*      if (j != lo && y[j] < y[nlo]) nlo=j;   We don't actually use this */
      if (j != hi && y[j] > y[nhi]) nhi=j;
    }

    iter++;
  }

  /* Done, either because convergence was reached, because ITMAX was   */
  /* exceeded, or because SIMPLEX_ERR was set (by external function).  */

  if (iter >= ITMAX) {
    printf(" ** Warning: ITMAX=%i exceeded in amoeba (convergence not reached)\n",ITMAX);
    retval = 0;
  }

  if (SIMPLEX_ERR) retval = 0;

  /* Organise the simplex so that the minimum is in the first vertex */

  for (k=0; k<n; k++) {
    t = v[0][k];
    v[0][k] = v[lo][k];
    v[lo][k] = t;
  }

  /* Back to single precision.. */

/*
  for (j=0; j<=n; j++) {
    _y[j] = y[j];
    for (k=0; k<n; k++)
      _v[j][k] = v[j][k];
  }
*/

  /* Return 1 (if everythink OK) or 0 if error */

  return retval;
  
}
