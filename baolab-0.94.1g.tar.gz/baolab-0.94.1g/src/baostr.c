#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <ctype.h>

#define BAOSTR_MAIN

#include "baostr.h"

#ifndef TCGETS
#ifndef TCGETATTR
  #define TCGETATTR TIOCGETA
#endif
#define TCGETS TCGETATTR
#endif

#ifndef TCSETS
#ifndef TCSETATTR
  #define TCSETATTR TIOCSETA
#endif
#define TCSETS TCSETATTR
#endif

#define FALSE 0
#define TRUE 1

/* ==================================================================== */

int nargs(           /* Counts the number of arguments in a string by    */
                     /* counting the number of spaces, excluding leading */
		     /* and trailing ones.                               */
  char *paramstr
)
{
  int i=0,n=0;
  char wrkstr[2048];

  i = 0;
  do {
    wrkstr[i] = paramstr[i];
    if (wrkstr[i] == 9) wrkstr[i] = 32;
    i++;
  } while (paramstr[i] != '\0');
  wrkstr[i] = '\0';

  i = 0;

  while (wrkstr[i] == ' ') i++; 
  while ((wrkstr[i] != '\0') && (wrkstr[i] != '\n')) {
    if (wrkstr[i] == '"') {
      i++;
      while ((wrkstr[i] != '"') && (wrkstr[i] != '\0') &&
             (wrkstr[i] != '\n')) i++;
      i++;
      while (wrkstr[i] == ' ') i++;
      n++;
    } else {
      while ((wrkstr[i] != ' ') && (wrkstr[i] != '\0') &&
	     (wrkstr[i] != '\n') ) i++; 
      while (wrkstr[i] == ' ') i++;
      n++;
    }
  } 

  return n;
}

/* ==================================================================== */


void argn( /* Returns the n'th argument of paramstr.  */
           /* The first argument is 1, the next 2 ... */
  char *paramstr,
  int n,
  char *arg
)
{
  int j=0,i=0,nc=1;
  char ch;
  char wrkstr[2048];

  i = 0;
  do {
    wrkstr[i] = paramstr[i];
    if (wrkstr[i] == 9) wrkstr[i] = 32;
    i++;
  } while (paramstr[i] != '\0');
  wrkstr[i] = '\0';

  i = 0;

  while (wrkstr[i] == ' ') i++;
  while ((wrkstr[i] != '\0') && (nc<n)) {
    if (wrkstr[i] == '"') {
      i++;
      while ((wrkstr[i] != '"') && (wrkstr[i] != '\0')) i++;
      i++;
      while (wrkstr[i] == ' ') i++;
      nc++;
    } else {
      while ((wrkstr[i] != ' ') && (wrkstr[i] != '\0')) i++;
      while (wrkstr[i] == ' ') i++;
      nc++;
    }
  }

  if (wrkstr[i] == '"') { i++; ch = '"'; } else ch = ' ';

  while ((wrkstr[i] != '\0') && 
         (wrkstr[i] != ch) &&
	 (wrkstr[i] != '\n') ) {
    arg[j++] = wrkstr[i++];
  }

  arg[j] = '\0';
}

/* ==================================================================== */

char *upcstr(
  char *txt
)
{
  int i;

  for (i=0; i < strlen(txt); i++)
    txt[i] = (char)toupper(txt[i]);

  return txt;
}

/* ==================================================================== */

void getwinsize(
  int *dx, int *dy
)
{
  struct winsize  info;

  ioctl(0,TIOCGWINSZ,&info);
  *dx = info.ws_col;
  *dy = info.ws_row;
}

/* ==================================================================== */

int bgetchar() {            /* Get one character without echoing */
  struct termios termpars;
  struct termios oldpar;
  char   ch;
  int    chint;

/*  ioctl(0,TCGETS,&termpars); */
  tcgetattr(0, &termpars);
  oldpar = termpars;
  termpars.c_lflag &= ~ECHO;
  termpars.c_lflag &= ~ICANON;
  termpars.c_cc[VMIN] = 1;
/*  ioctl(0,TCSETS,&termpars); */
  tcsetattr(0, TCSANOW, &termpars);

  read(0,&ch,1);
  chint = (int)ch;

  if (ch == 27) {
    read(0,&ch,1);

    if (ch == '[') {
      read(0,&ch,1);
      switch (ch) {
	case 'C' : chint = ARROW_RIGHT; break;
	case 'D' : chint = ARROW_LEFT; break;
	case 'A' : chint = ARROW_UP; break;
	case 'B' : chint = ARROW_DOWN; break;
      }
    }
  }

/*  ioctl(0,TCSETS,&oldpar); */
  tcsetattr(0, TCSANOW, &oldpar);
  return chint;
}

/* ==================================================================== */

void bputch(char ch)
{
  write(1,&ch,1);
}

/* ==================================================================== */

void bputs(
  const char *s
)
{
  write(1,s,strlen(s));
}

/* ==================================================================== */

void clreol() {

  struct termios termpars;
  struct termios oldpar;

/*  ioctl(0,TCGETS,&termpars); */
  tcgetattr(0,&termpars);
  oldpar = termpars;
  termpars.c_lflag &= ~ECHO;
  termpars.c_lflag &= ~ICANON;
  termpars.c_lflag &= ~ISIG; 
  termpars.c_cc[VMIN] = 1;
/*  ioctl(0,TCSETS,&termpars); */
  tcsetattr(0, TCSANOW, &termpars);

  bputch(27);
  bputs("[0K");

/*  ioctl(0,TCSETS,&oldpar);  */ /*  Restore original terminal settings. */
  tcsetattr(0, TCSANOW, &oldpar);
}

/* ==================================================================== */

void clreos() {

  bputch(27);
  bputs("[0J");
}

/* ==================================================================== */

void setcurxy(int x, int y) {
  char tmps[25];

  sprintf(tmps,"[%i;%if",y,x);
  bputch(27);
  bputs(tmps);
}

/* ==================================================================== */

void setscroll(int ytop, int ybot) {
  char tmps[25];

  sprintf(tmps,"[%i;%ir",ytop,ybot);
  bputch(27);
  bputs(tmps);
}

/* ==================================================================== */

void sglspc(  /* Removes all spaces wider than " " */
  char *txt
)
{
  char *s1;
  int  n,i;

  s1 = (char *)malloc(sizeof(char)*strlen(txt));

  while (strchr(txt,'\n') != NULL) txt[strchr(txt,'\n')-txt] = ' ';
  while (txt[0] == ' ') {
    strcpy(s1,txt+1);
    strcpy(txt,s1);
  }

  while (strstr(txt,"  ")!=NULL) {
    n = strstr(txt,"  ")-txt;
    for (i=0;i<n;i++) s1[i] = txt[i];
    i++;
    for (;txt[i-1] != '\0';i++) s1[i-1] = txt[i];
    strcpy(txt,s1);
  }

  free(s1);
}

/* ==================================================================== */

void remspace( /* Removes all spaces from a string */
  char *txt
)
{
  int i;

  while (strchr(txt,' ') != NULL) {
    for (i=0;txt[i] != ' '; i++);
    for (;txt[i] != '\0'; i++) txt[i] = txt[i+1];
  }
}

/* ==================================================================== */

void remeqspc(char *txt)   /* Removes spaces around "=" signs in txt */
{
  int i,j;
  char tmps[255];

  while (strstr(txt,"= ") != NULL) {
    i = 0; j = 0;
    while ((txt[i-1] != '=') || (txt[i] != ' ')) tmps[j++] = txt[i++];
    i++; 
    while (txt[i] != '\0') tmps[j++] = txt[i++];
    tmps[j] = '\0';
    strcpy(txt,tmps);
  }

  while (strstr(txt," =") != NULL) {
    i = 0; j = 0;
    while ((txt[i-1] != ' ') || (txt[i] != '=')) tmps[j++] = txt[i++];
    i++; tmps[j-1] = '=';
    while (txt[i] != '\0') tmps[j++] = txt[i++];
    tmps[j] = '\0';
    strcpy(txt,tmps);
  }
}

/* ==================================================================== */

void insargs(

/*
 * Replace occurrences of $1, $2 etc. in s with the corresponding
 * part of "args".
 */

  char *s,
  char *args
)
{
  int n,ii,i=0;
  int i1,i2;
  char tmps[10],s1[255],s2[255];

  while (s[i] != '\0') {
    if (s[i] == '%') {
      i1 = i;   /* 1st position to substitute */
      for (ii=0,i++; (s[i] >= '0') && (s[i] <= '9'); i++,ii++)
        tmps[ii] = s[i];
      tmps[ii] = '\0';
      n = atoi(tmps);

      i2 = i; /* last position to substitute */

      argn(args,n,s1);

      strcpy(s2,s);
      for (i=i1,ii=0; s1[ii] != '\0'; ii++, i++) s[i] = s1[ii];
      for (ii=i2; s2[ii] != '\0'; i++, ii++) s[i] = s2[ii];
      s[i] = '\0';
      i = 0;
    }
    i++;
  }
}

/* ==================================================================== */

void itoa(  /* Converts an integer to a string */
  int i,
  char *a
)
{
  int j,ii,decade;
  char tmp[25];

  decade = 1; ii = 0;
  while (abs(i)>=decade) {
    tmp[ii++] = 48 + (abs(i) % (10*decade)) / decade;
    decade *= 10;
  } 
  if (i<0) tmp[ii++] = '-';

  for (j=0;j<ii;j++) a[j] = tmp[ii-j-1];
  if (i==0) a[ii++] = '0';
  a[ii] = '\0';
}

/* ==================================================================== */

void ftoa(  /* Converts a floating point number to a string  */
  float f,
  char *a
)
{
  float factor;
  int   power,i,ii;
  char  powstr[50], factstr[50];
  float f1;

  if (fabs(f) > 0) {
    power = (int)log10(fabs(f));   if (power<0) power--;
  }
  else
    power = 0;

  itoa(abs(power),powstr);
  i=0; while (powstr[i] != '\0') i++;
  for(ii=0;ii<=i;ii++) powstr[ii+3-i] = powstr[ii];
  for(ii=0;ii<3-i;ii++) powstr[ii]='0';
 
  factor = f/pow(10.0,power);
  
  f1 = fabs(factor);
  factstr[0] = 48+(int)f1;
  factstr[1] = '.';

  for(i=2;i<7;i++) {
    f1 = fmod(f1,1.0);
    f1 *= 10.0;
    factstr[i] = 48+(int)f1;
  } 
  factstr[i+1] = '\0';

  i = 0;
  if (factor<0) a[i++] = '-';
  for(ii=0;ii<7;ii++) a[i++] = factstr[ii];
  a[i++] = 'E';
  a[i++] = (power<0) ? '-' : '+';
  for(ii=0; powstr[ii] != '\0'; ii++) a[i++] = powstr[ii];
  a[i] = '\0';
}

/* ==================================================================== */

void getexitchr(
  char *s,
  int *exitchr,
  int *nexitchr
)
{
  int i;
  char tmps[10];
  
  for (i=1; i<=nargs(s+2); i++) {
    argn(s+2,i,tmps);
    exitchr[(*nexitchr)++] = atoi(tmps);
  } 
}

/* -------------------------------------------------------------------- */

int bscanf(
/*                                            
 *  BAO version of scanf. The primary reason  
 * for using this routine will be that you    
 * have the possibility to modify "data"      
 * instead of just entering a new value.      
 *
 * Format specifiers:
 *  %x c1 c2 ... cn - Specify characters causing bscanf to terminate
 *  %S  -  Enter new string. 
 *  %s  -  Modify existing string.
 *  %I  -  Enter integer value.
 *  %i  -  Modify existing integer.
 *  %F  -  Enter floating point value.
 *  %f  -  Modify ...
*/
  char *ctrlstr,
  void *data
)
{
  char  *tmpstr;
  int   *tmpint;
  float *tmpflt;

  char  ss[10],s1[2048];
  int   i,j,ii;
  int   do_exit = FALSE;
  char  ch, type, format[100];
  int   exitchr[2048];
  int   chint;
  int   nexitchr = 2;
  ssize_t nrd;

  struct termios termpars;
  struct termios oldpar;

  fflush(stdout);

/* Configure the terminal for our use. */

/*  ioctl(0,TCGETS,&termpars); */
  tcgetattr(0, &termpars);
  oldpar = termpars;
  termpars.c_lflag &= ~ECHO;
  termpars.c_lflag &= ~ICANON;
  termpars.c_lflag &= ~ISIG; 
  termpars.c_cc[VMIN] = 1;
/*  ioctl(0,TCSETS,&termpars); */
  tcsetattr(0, TCSANOW, &termpars);

  exitchr[0] = 10;
  exitchr[1] = CTRL_C;

/* Parse the control string. */

  format[0] = '\0';
  for (i=0; ctrlstr[i] != '%' ; i++);

  while (ctrlstr[i] != '\0') {
    for (j=0; (ctrlstr[i+1] != '%') && (ctrlstr[i] != '\0') ; i++, j++)
      s1[j] = ctrlstr[i];
    s1[j] = '\0';
    if ((ctrlstr[i+1] == '%') && (ctrlstr[i] != '\0')) i++;

    if (strstr(s1,"s") != NULL) { type = 's'; strcpy(format,s1); } else
    if (strstr(s1,"S") != NULL) type = 'S'; else
    if (strstr(s1,"i") != NULL) { type = 'i'; strcpy(format,s1); } else
    if (strstr(s1,"I") != NULL) type = 'I'; else
    if (strstr(s1,"f") != NULL) { type = 'f'; strcpy(format,s1); } else
    if (strstr(s1,"F") != NULL) type = 'F'; else
    if (strstr(s1,"x") != NULL) { getexitchr(s1,exitchr, &nexitchr); }
  }

  strcpy(s1,"");
  tmpint = (int *)data;
  tmpflt = (float *)data;
  tmpstr = (char *)data;

  if (type == 'i') sprintf(s1,format,*tmpint);
  if (type == 'f') sprintf(s1,format,*tmpflt);
  if (type == 's') strcpy(s1,tmpstr);

  bputs(s1); fflush(stdout);
  i = j = strlen(s1);

/*  Now we can start reading the actual user input */

  do {
    nrd = read(0,&ch,1);
    chint = (int)ch;

    if (nrd == 0) {
      do_exit = TRUE;
      chint = CTRL_D;
    } else
    switch (ch) {
      case CTRL_C : break;

      case 27     : read(0,&ch,1);

		    if (ch == '[') {
		      read(0,&ch,1);
		      switch (ch) {
		        case 'C' : if (i<j) { 
			             i++; 
				     bputch(27);
				     bputs("[C");
				   } break;

		        case 'D' : if (i>0) {
				     i--;
				     bputch(27);
				     bputs("[D");
			           } break;

		        case 'A' : chint = ARROW_UP; break;
			case 'B' : chint = ARROW_DOWN; break;
		      }
		    }
                    break;

      case CTRL_A : if (i>0) {
                      bputch(27); sprintf(ss,"[%iD",i); bputs(ss);
		      i = 0; 
		    }
		    break;

      case CTRL_B : while (( i > 0) && (s1[i-1] == ' ')) {
                      i--; bputch(8);
		    }
		    while (( i > 0) && (s1[i-1] != ' ')) {
		      i--; bputch(8);
		    }
		    break;

      case CTRL_W : ii=0;
                    while ((i<j) && (s1[i] != ' ')) { i++; ii++; }
                    while ((i<j) && (s1[i] == ' ')) { i++; ii++; }
		    if (ii>0) {
		      bputch(27); sprintf(ss,"[%iC",ii); bputs(ss);
		    }
		    break;

      case CTRL_E : if (i<j) {
		      bputch(27); sprintf(ss,"[%iC",j-i); bputs(ss);
		      i = j;
                    }
		    break;

      case CTRL_K : if (i>0) {
                      bputch(8);
		      i--;
                    }
		    break;

      case CTRL_L : if (i<j) {
		      bputch(27); bputs("[C"); i++;
                    }
		    break;

      case 13     : ch = 10;
      case 10     : break;

      case DEL    :
      case 8      : if (i>0) {
		      j--;
		      i--; bputch(8); bputch(' '); bputch(8);
		      bputch(27); bputch('7');           /* Save cursor */
		      for (ii=i;ii<j;ii++) {
		        bputch(s1[ii+1]); 
		        s1[ii] = s1[ii+1];
	              }
		      bputch(' ');
		      bputch(27); bputch('8');         /* Restore cursor */
		    } break;

      default     : bputch(ch);
		    if (i<j) {
                      bputch(27); bputch('7');
		      for (ii=i; ii<j; ii++) bputch(s1[ii]);
		      for (ii=j; ii>=i; ii--) s1[ii+1] = s1[ii];
                      bputch(27); bputch('8');
		    }
                    s1[i] = ch; 
		    i++, j++;
		    break;
    } 

    for (ii=0; ii<nexitchr; ii++) if (exitchr[ii] == chint) do_exit = TRUE;
  } while (!do_exit);

/*  ioctl(0,TCSETS,&oldpar);  */ /*  Restore original terminal settings. */
  tcsetattr(0, TCSANOW, &oldpar);

  s1[j] = '\0';

  if (type == 'i' || type == 'I') *tmpint = atoi(s1);
  if (type == 'f' || type == 'F') *tmpflt = (float)atof(s1);
  if (type == 's' || type == 'S') strcpy(tmpstr,s1);

  if ((chint == 10) || (chint==CTRL_C)) puts("");
  return chint;
}

/* ==================================================================== */

int bgets(
  char *txt
)
{
  return bscanf("%S",txt);
}

/* ==================================================================== */
/*
void main() {
  char  txt[255];
  int   i;
  float f;

  txt[0] = '\0';
  f = 0;

  f = 1.234567;

  do {
    bscanf("%F",&f);
    printf("%f\n",f);
    puts("");
  } while (strstr(txt,"quit") == NULL);
}
*/
