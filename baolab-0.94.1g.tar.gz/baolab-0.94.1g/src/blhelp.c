#include "fitsutil.h"
#include "baostr.h"
#include "baolab.h"

static void statusln(int nscroll, int wdy) {
  setcurxy(1,wdy); 
  bputch(27); bputs("[7m");
  printf(" <Return>-Down one line, <d>-Down %i lines, <u>-Up %i lines, <q>-quit",
	   nscroll,nscroll);
  fflush(stdout);
  bputch(27); bputs("[0m");
}

/* ==================================================================== */

static void helpscreen(
  char *hlp[],
  int  nhlp
)
{
  int i,j,ch,bot,top;
  int nscroll = 5;
  char tmps[25];
  int  wdx,wdy;

  getwinsize(&wdx,&wdy);
  if (wdy==0) wdy = 24;         /* Some dumb terminals don't return */
                                /* size information. Assume in that */
				/* case that wdy = 24.              */

  if (getpar("HELP.NSCROLL",tmps)) nscroll = atoi(tmps);
  if (nscroll < 1) nscroll = 5;

  for (i=0;(i<wdy-4) && (hlp[i] != NULL); i++) puts(hlp[i]);
  top = -2; bot = i-1;

  if (bot+1 < nhlp) {
    setscroll(1,wdy-1);
    statusln(nscroll,wdy);

    do {
      setcurxy(1,wdy); 
      ch = bgetchar();
      statusln(nscroll,wdy);

      switch (ch) {

	case 'u' : 
	case 'k' :
	case ARROW_UP: 
	case CTRL_P:
	           if (ch == 'u') j = nscroll; else j = 1;
	           if (top > 0) { 
                     i = j;
		     while ((i>0) && (top > 0)) {
		       bputch(27);
		       bputs("[1;1H");
		       bputch(27);
		       bputs("[L");

		       top--;
		       bot--;
		       i--;
		       puts(hlp[top]);
		     }
		   }
		   break;

	case 'd' : if (bot+1<nhlp) {
		     setcurxy(1,wdy-1);
		     j = bot;
		     for (i=bot+1;(i<nhlp) && (i<=bot+nscroll) ;i++) 
		       puts(hlp[i]);
		     bot = i-1;
		     top += (bot-j);
		   } else {
		     setcurxy(1,wdy);
		     bputs("END! 'q'=quit ");
		   }
		   break;

	case 10  :
	case 'j' :
	case ARROW_DOWN :
	case CTRL_N:
	           if (bot+1<nhlp) {
		     setcurxy(1,wdy-1);
		     puts(hlp[++bot]);
		     top++;
		   } else {
		     setcurxy(1,wdy);
		     bputs("END! 'q'=quit ");
		   }
		   break;
      }

    } while (ch != 'q');

    setscroll(1,wdy);
    setcurxy(1,wdy); puts("");
  } 
}

/* -------------------------------------------------------------------- */

static void sort_str(
  char *s[],
  int  n
) {
  int i,j;
  char *p;

  for (i=0; i<n-1; i++) {
    for (j=i+1 ; j<n; j++) {
      if (strcmp(s[j],s[i]) < 0) {
	p = s[j];
	s[j] = s[i];
	s[i] = p;
      }
    }
  }
}

/* -------------------------------------------------------------------- */

void showhlp(char *params) 
{
  char s[255],arg[255];
  char *ch;
  FILE *hlpfile;
  char hlpname[255];
  int  i,ii,nhlp;
  char *hlp[1000];
  char *keywd[255];

  strcpy(hlpname,"baolab.hlp");
  expandname(hlpname);

  setcurxy(1,1); clreos();

  printf("=========================== ");
  printf("BAOLAB Help: ==============================\n\n");

  if (nargs(params) == 0) {
    for (i=0; i<255; i++) keywd[i] = (char *)malloc(100);
    puts(" Syntax:  help <keyword> ");
    puts(" Available keywords: ");

    hlpfile = fopen(hlpname,"r");
    if (hlpfile != NULL) {
      ii = 0;
      do {
        ch = fgets(s,255,hlpfile);
	if (strchr(s,'\\') != NULL) {
	  if (strstr(s,"end") == NULL) {
	    sglspc(s);
	    argn(s,1,arg);
	    strcpy(keywd[ii++],arg+1);
	  }
	}
      } while (ch!=NULL);
      fclose(hlpfile);
      sort_str(keywd,ii);

      for (i=0; i<ii; i++) { 
        printf("  %15s",keywd[i]);
	if ((i+1) % 4 == 0) printf("\n");
      }
      printf("\n");
    }
    for (i=0; i<255; i++) free(keywd[i]);
  } else {

    argn(params,1,arg);
    strcpy(s,"\\");
    strcat(s,arg);
    strcpy(arg,s);

    hlpfile = fopen(hlpname,"r");

    if (hlpfile != NULL) {
      if (strstr(arg,"-s")) {
        nhlp = 0;
        do {
	  ch = fgets(s,255,hlpfile);
	  if ((strchr(s,'\\') != NULL) && (strstr(s,"\\end") != s)) {
	    while (strchr(s,'\n') != NULL) s[strchr(s,'\n')-s] = ' ';
	    hlp[nhlp] = (char *)malloc(sizeof(char)*(strlen(s)+1)); 
	    strcpy(hlp[nhlp++],s+1);
	  }
	} while (ch != NULL);

        hlp[nhlp] = NULL;
        if (nhlp > 0) {
	  sort_str(hlp,nhlp); 
          helpscreen(hlp,nhlp); 
          for (i=0;i<nhlp;i++) free(hlp[i]);
        }
      } else {
	do {
	  ch = fgets(s,255,hlpfile);
	} while ((ch != NULL) && (strstr(s,arg) == NULL));


	if (ch != NULL) {
	  ch = fgets(s,255,hlpfile);
	  while (strchr(s,'\n') != NULL) s[strchr(s,'\n')-s] = ' ';

	  nhlp = 0;
	  while ((ch!=NULL) && (strstr(s,"\\end") == NULL)) {
	    hlp[nhlp] = (char *)malloc(strlen(s)+1); 
	    strcpy(hlp[nhlp++],s);

	    ch = fgets(s,255,hlpfile);
	    while (strchr(s,'\n') != NULL) s[strchr(s,'\n')-s] = ' ';
	  } 
	  hlp[nhlp] = NULL;
	  if (nhlp > 0) {
	    helpscreen(hlp,nhlp);
	    for (i=0;i<nhlp;i++) free(hlp[i]); 
	  }
	} else {
	  printf("Help for keyword '%s' not found\n",arg+1);
	}
      }

      fclose(hlpfile);
    }
  }
}

/* ==================================================================== */
