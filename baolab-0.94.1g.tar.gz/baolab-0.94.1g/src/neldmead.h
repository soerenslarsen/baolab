#define MP 10
#define NP 9

#ifndef NELDMEAN_MAIN

   extern int SIMPLEX_ERR;
   extern int ITMAX;

   extern float NM_ALPHA;     /* Reflection coefficient  */
   extern float NM_BETA;      /* Contraction coefficient */
   extern float NM_GAMMA;     /* Expansion coefficient   */
   extern float NM_SIGMA;     /* Shrinking coefficient = 1-tau  */


   extern int neldermead(
     float v[MP][NP],          /* Initial vertices               */
     float y[MP],              /* Function values at v           */
     int   n,                  /* Number of dimensions           */
     float epsilon,            /* Relative convergence tolerance */
     float (*funk)(float [])   /* Function to be minimized       */
   );

#endif
